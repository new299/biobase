# Natera

## Overview

Natera is a molecular diagnostics company focused on cell-free DNA testing across oncology, women's health, and organ health.[[1]](https://investor.natera.com/news/news-details/2026/Natera-Announces-Strong-Preliminary-Fourth-Quarter-and-2025-Financial-Results-Driven-by-Record-Signatera-Growth/default.aspx)

## Technology

Natera's core technology base is built around cfDNA analysis and personalized molecular diagnostics. Its major product areas include Signatera for molecular residual disease, Panorama for non-invasive prenatal testing, and tests in organ transplant and other precision medicine categories.[[1]](https://investor.natera.com/news/news-details/2026/Natera-Announces-Strong-Preliminary-Fourth-Quarter-and-2025-Financial-Results-Driven-by-Record-Signatera-Growth/default.aspx)

## Investors

Natera is a Nasdaq-listed public company (`NTRA`). In January 2026 it announced strong preliminary 2025 results, including approximately $1.95 billion in total revenue and significant Signatera growth, reflecting its current public-market scale.[[1]](https://investor.natera.com/news/news-details/2026/Natera-Announces-Strong-Preliminary-Fourth-Quarter-and-2025-Financial-Results-Driven-by-Record-Signatera-Growth/default.aspx)

## Acquisitions and Strategic Transactions

In December 2025, Natera completed an all-stock acquisition of Foresight Diagnostics for $275 million upfront plus up to $175 million in earnouts tied to revenue and reimbursement milestones.[[2]](https://investor.natera.com/news/news-details/2025/Natera-Acquires-Foresight-Diagnostics/default.aspx) The transaction expanded Natera's solid tumor MRD capabilities and strengthened its position in lymphoma and phased variant detection.[[2]](https://investor.natera.com/news/news-details/2025/Natera-Acquires-Foresight-Diagnostics/default.aspx)
