# Kisbee Therapeutics

Kisbee Therapeutics was a U.S.-based, early-stage biotechnology company focused on developing **novel therapeutics for neurodegenerative diseases**, particularly by targeting apolipoproteins and lipid biology pathways ([Source 1](https://newpath-partners.webflow.io/companies/kisbee-therapeutics), [Source 2](https://jobs.8vc.com/companies/kisbee-therapeutics/jobs/35947989-research-associate-ii-biochemistry)).

### Approach

Kisbee’s approach centered on **leveraging lipid and apolipoprotein biology to improve brain health and repair**:

- Targeted **apolipoproteins and lipid pathways** implicated in neurodegeneration  
- Aimed to translate **genetic and biochemical insights into therapeutics**  
- Focused on diseases where lipid metabolism plays a role in neuronal dysfunction  

The company’s strategy positioned it within a newer wave of biotech exploring **lipid biology as a therapeutic axis** in the brain ([Source 1](https://newpath-partners.webflow.io/companies/kisbee-therapeutics), [Source 2](https://jobs.8vc.com/companies/kisbee-therapeutics/jobs/35947989-research-associate-ii-biochemistry)).

### Technology

- Development of **lipoprotein-based therapeutics**  
- Exploration of **apolipoprotein modulation**  
- Focus on **central nervous system (CNS) diseases**  

This approach aimed to address underlying biological mechanisms rather than just symptoms ([Source 2](https://jobs.8vc.com/companies/kisbee-therapeutics/jobs/35947989-research-associate-ii-biochemistry)).

### Founders & Background

- Founded by prominent scientists including:
  - Benjamin Cravatt  
  - Jennifer Lippincott-Schwartz  
  - Stuart Schreiber  

([Source 1](https://newpath-partners.webflow.io/companies/kisbee-therapeutics)).

### Market & Positioning

Kisbee operated in the **neurodegenerative disease therapeutics market**, focusing on:

- CNS disorders with high unmet need  
- Mechanism-driven drug discovery based on lipid biology  
- Early-stage, high-risk/high-reward innovation  

### Status (Important)

- **Out of business / inactive** :contentReference[oaicite:0]{index=0}  
- Discontinued at least one key research program (e.g., Niemann-Pick disease) :contentReference[oaicite:1]{index=1}  
- No active development pipeline publicly reported  

### Investors

- Venture-backed (specific investors not clearly disclosed in available sources)

### Funding

- Early-stage venture funding (amounts not publicly disclosed)

---

### Bottom Line

Kisbee Therapeutics was a scientifically ambitious biotech targeting apolipoproteins and lipid biology for neurodegenerative diseases, but it **appears to be inactive/out of business**, with programs discontinued and no ongoing public activity.
