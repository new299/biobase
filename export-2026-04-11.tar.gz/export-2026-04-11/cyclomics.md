# Cyclomics — Research Notes

## Overview

Cyclomics is a Utrecht, Netherlands-based liquid biopsy company and 2018 spinout from University Medical Center Utrecht (UMC Utrecht). Develops CyclomicsSeq, a proprietary consensus sequencing technology using Oxford Nanopore long-read platforms to achieve ultra-sensitive detection of circulating tumor DNA (ctDNA) with ~60-fold improved accuracy vs. standard nanopore sequencing. First clinical application: TP53 mutation detection in head and neck cancer patients. [[1]](https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing) [[2]](https://www.cyclomics.com/)

---

## Technology

- **CyclomicsSeq**: Consensus sequencing approach compatible with Oxford Nanopore Technologies (Flongle, MinION, GridION) that circularizes DNA fragments and sequentially reads them multiple times to reduce error rate by ~60x — enabling detection of rare ctDNA mutations. [[3]](https://nanoporetech.com/resource-centre/cyclomics-ultra-sensitive-nanopore-sequencing-cell-free-tumor-dna)
- **Oxford Nanopore Collaboration**: Research collaboration with Oxford Nanopore Technologies to further develop ultra-sensitive ctDNA solutions. [[4]](https://www.oncodeinstitute.nl/news/cyclomics-starts-new-research-collaboration-oxford-nanopore-technologies)
- **AI Brain Tumor Classification**: Joint Health Holland grant with UMC Utrecht to develop AI-driven software for ultra-rapid intraoperative brain tumor classification. [[1]](https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing)
- **Clinical Application**: TP53 mutation detection for treatment response monitoring and recurrence detection in advanced head and neck cancer patients. [[1]](https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors / Sources |
|-------|------|--------|------------------------------|
| Grants | 2018–present | Various | Oncode Institute, European Commission SME Instruments (€50K), Health Holland |
| Private round | — | Undisclosed | Private investors (for expanding beyond CyclomicsSeq) |

Specific venture funding amounts not fully publicly disclosed. [[1]](https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing)

---

## References

1. GenomeWeb — Dutch startup Cyclomics developing liquid biopsy assay using nanopore sequencing: [https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing](https://www.genomeweb.com/liquid-biopsy/dutch-startup-cyclomics-developing-liquid-biopsy-assay-using-nanopore-sequencing)
2. Cyclomics — Company website: [https://www.cyclomics.com/](https://www.cyclomics.com/)
3. Oxford Nanopore — CyclomicsSeq ultra-sensitive nanopore sequencing: [https://nanoporetech.com/resource-centre/cyclomics-ultra-sensitive-nanopore-sequencing-cell-free-tumor-dna](https://nanoporetech.com/resource-centre/cyclomics-ultra-sensitive-nanopore-sequencing-cell-free-tumor-dna)
4. Oncode Institute — Cyclomics Oxford Nanopore collaboration: [https://www.oncodeinstitute.nl/news/cyclomics-starts-new-research-collaboration-oxford-nanopore-technologies](https://www.oncodeinstitute.nl/news/cyclomics-starts-new-research-collaboration-oxford-nanopore-technologies)
