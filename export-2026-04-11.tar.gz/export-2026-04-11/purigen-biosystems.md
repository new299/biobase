# Purigen Biosystems

Purigen Biosystems is a **biotechnology company** (now a subsidiary of *Bionano Genomics*) that developed a **next‑generation automated platform for nucleic acid (DNA/RNA) purification and quantitation** using a proprietary **isotachophoresis (ITP)** technology originally invented at Stanford University. [[1]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems) [[7]](https://www.selectscience.net/company/purigen-biosystems)

## What the Company Does
Purigen’s core product was the **Ionic® Purification System**, a benchtop instrument and consumable microfluidic chip workflow that performs **hands‑free, automated DNA and RNA extraction and enrichment** from a wide variety of biological samples — including FFPE tissues, liquid biopsies, and other samples that are challenging for traditional methods. [[7]](https://www.selectscience.net/company/purigen-biosystems)  
The platform yields high‑purity nucleic acids suitable for **next‑generation sequencing (NGS), PCR**, and other genomic workflows without bead/matrix binding. [[7]](https://www.selectscience.net/company/purigen-biosystems)

## Founders & Leadership
- **Klint Rose:** Co‑founder and Chief Scientific Officer (Stanford University, microfluidics/ITP background). [[0]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems)  
- **Juan Santiago, PhD:** Co‑founder and inventor of the ITP technology (Stanford University). [[0]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems)  
- **Barney Saunders, PhD:** CEO appointed in 2017 with experience commercializing life science tools. [[4]](https://www.prnewswire.com/news-releases/purigen-biosystems-appoints-life-science-industry-veteran-barney-saunders-phd-as-chief-executive-officer-300566670.html)

## Investors & 5AM Ventures
Purigen Biosystems raised venture capital backing across multiple rounds, notably including **5AM Ventures** as a Series A and Series B investor:  
- **Series A (~$18.2M, 2016):** Led by **5AM Ventures** and **Roche Venture Fund**, also backed by Stanford‑StartX Fund and Western Technology Investment. [[1]](https://www.finsmes.com/2016/05/purigen-biosystems-completes-18-2m-series-a-funding.html) [[5]](https://www.gaebler.com/VC-Funding-5E9E1FC4-2D31-4A37-AAB6-0F8937B85319-Purigen-Biosystems-05-18-2016)  
  - This cohort included Andy Schwab of 5AM Ventures joining the board. [[1]](https://www.finsmes.com/2016/05/purigen-biosystems-completes-18-2m-series-a-funding.html)  
- **Series B ($26.4M, 2019):** Led by **Agilent Technologies** with participation from **5AM Ventures**, **Roche Venture Fund**, and **Cota Capital**. [[3]](https://www.finsmes.com/2019/06/purigen-biosystems-closes-26-4m-series-b-financing.html) [[2]](https://www.gaebler.com/VC-Funding-F0A0FAAE-B9F7-4B22-98F2-6C0D287C7003-Purigen-Biosystems-06-13-2019)  

Estimates suggest total funding in the **tens of millions (~$44M+)** across these rounds. [[0]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems)

## Technology / Market
- Technology is built around **isotachophoresis (ITP)**, an electric‑field driven separation method that enables **efficient, unbiased nucleic acid purification** across sample types where traditional kits struggle. [[7]](https://www.selectscience.net/company/purigen-biosystems)  
- This positioned Purigen in the **genomics sample preparation** market, supporting research and clinical genomics workflows before sequencing or amplification. [[1]](https://www.finsmes.com/2016/05/purigen-biosystems-completes-18-2m-series-a-funding.html)

## Acquisition & Later Status
In **November 2022**, **Bionano Genomics** announced it would **acquire Purigen Biosystems** for up to ~$64 million to incorporate Purigen’s ITP technology into Bionano’s **optical genome mapping (OGM)** workflows. The acquisition closed later that year, making Purigen a subsidiary of Bionano Genomics. [[12]](https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554) [[17]](https://www.annualreports.com/HostedData/AnnualReportArchive/b/NASDAQ_BNGO_2022.pdf)

Under Bionano’s 10‑K, Purigen is now listed as a **wholly owned subsidiary** contributing its nucleic acid purification products to the combined genomics portfolio. [[14]](https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554)

## Headquarters
Pleasanton, California, USA (East Bay/Silicon Valley area). [[0]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems)

## Status
- Purigen’s technology transitioned from **startup VC‑backed company** to being part of **Bionano Genomics**, continuing development and commercialization within the larger organization. [[12]](https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554)  
- The original **Ionic Purification System** continues to be used in genomic sample preparation and integrated into broader genomic workflows under Bionano. [[12]](https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554)

## Summary
Purigen Biosystems was a VC‑backed biotechnology tools company that developed a **novel ITP‑based nucleic acid purification platform**, raised Series A & B funding with participation from **5AM Ventures**, and was ultimately **acquired by Bionano Genomics** to support next‑generation genome analysis solutions. [[1]](https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems) [[12]](https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554)

## References

1. Purigen Biosystems profile & funding overview. https://www.gaebler.com/Funded-Company-385179EF-DF24-488A-AC00-F47A547DD015-Purigen-Biosystems turn0search0  
2. Purigen Series B financing — $26.4M (2019). https://www.gaebler.com/VC-Funding-F0A0FAAE-B9F7-4B22-98F2-6C0D287C7003-Purigen-Biosystems-06-13-2019 turn0search2  
3. BioSpace coverage of Series B financing. https://www.biospace.com/purigen-biosystems-raises-26-4-million-series-b-financing-to-accelerate-commercialization-of-automated-sample-preparation-platform turn0search10  
4. Purigen Series A — $18.2M led by 5AM Ventures & Roche. https://www.finsmes.com/2016/05/purigen-biosystems-completes-18-2m-series-a-funding.html turn0search1  
5. Series A funding including 5AM Ventures and Roche Venture Fund. https://www.gaebler.com/VC-Funding-5E9E1FC4-2D31-4A37-AAB6-0F8937B85319-Purigen-Biosystems-05-18-2016 turn0search5  
6. PR for CEO Barney Saunders appointment. https://www.prnewswire.com/news-releases/purigen-biosystems-appoints-life-science-industry-veteran-barney-saunders-phd-as-chief-executive-officer-300566670.html turn0search4  
7. Product & technology (Ionic system, ITP). https://www.selectscience.net/company/purigen-biosystems turn0search7  
8. Acquisition by Bionano Genomics press. https://ir.bionanogenomics.com/static-files/3c1aa69e-571a-4a72-8320-9897785ba554 turn0search12
