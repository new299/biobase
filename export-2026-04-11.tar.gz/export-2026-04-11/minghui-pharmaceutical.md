# Minghui Pharmaceutical

Minghui Pharmaceutical is a China-based, late-stage clinical biopharmaceutical company focused on developing **innovative therapies in oncology and immunology**. The company is advancing a diversified pipeline of biologics and small molecules targeting major unmet medical needs, with a growing emphasis on global expansion ([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Approach

Minghui’s approach centers on building a **differentiated, multi-modality pipeline** supported by proprietary platforms and strong clinical execution:

- Focus on oncology and immune-mediated diseases  
- Combines biologics (antibodies, ADCs) with small molecules  
- Advances both **first-in-class and best-in-class candidates**  
- Targets global markets alongside China commercialization  

The company emphasizes **scientific rigor and combination strategies**, particularly in immuno-oncology ([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Pipeline & Technology

Minghui has a **late-stage, diversified clinical pipeline**, including:

- **Topical JAK inhibitor**  
  - Under NDA review in China  
  - Targeting immunological/dermatological conditions  

- **IGF-1R antibody (subcutaneous)**  
  - Phase 3 for thyroid eye disease  

- **PD-1/VEGF bispecific antibody**  
  - Phase 2  
  - Evaluated in combination with TROP2 antibody-drug conjugate (ADC)  

- **B7-H3 ADC**  
  - Phase 3 for second-line small cell lung cancer (SCLC)  

These programs reflect a strategy combining **checkpoint inhibition, targeted delivery (ADCs), and immune modulation** ([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Market & Positioning

Minghui operates in the **global biopharmaceutical market**, with a focus on:

- Oncology therapeutics (immunotherapy, ADCs)  
- Immunology and inflammatory diseases  
- Late-stage assets nearing commercialization  

The company is positioned as a **China-based biotech transitioning toward commercialization and global expansion** ([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Investors

Recent Pre-IPO round investors include:

- **OrbiMed** (lead investor)  
- **Qiming Venture Partners** (co-lead)  
- **TF Capital** (existing investor)  
- Additional investors:
  - BioTrack Capital  
  - 5Y Capital  
  - New Day Fund  
  - Wider Link Enterprise Investment  

([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Funding

- **$131M Pre-IPO financing (2025)**  

Use of proceeds:

- Advance clinical pipeline  
- Support combination therapy strategies  
- Enable commercialization (e.g., JAK inhibitor launch in China)  

([Source 1](https://www.prnewswire.com/news-releases/minghui-pharmaceutical-announces-usd-131-million-pre-ipo-financing-to-advance-late-stage-pipeline-and-global-expansion-302524051.html)).

### Status

- Active  
- Late-stage clinical biotech  
- Privately held (pre-IPO)  
- Not acquired  

---

Overall, Minghui Pharmaceutical is a late-stage Chinese biotech company with a strong oncology and immunology pipeline, advancing multiple near-commercial assets and positioning itself for global expansion supported by significant pre-IPO funding.
