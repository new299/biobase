# Hyku Biosciences — Research Notes

## Overview

Hyku Biosciences is a biotechnology company and RA Capital Management portfolio company. No detailed public information is available about the company's technology, pipeline, or funding beyond its RA Capital affiliation. [[1]](https://www.racap.com/)

---

## Funding & Investors

RA Capital Management portfolio company. No additional public funding information found.

---

## References

1. RA Capital — Homepage: [https://www.racap.com/](https://www.racap.com/)
