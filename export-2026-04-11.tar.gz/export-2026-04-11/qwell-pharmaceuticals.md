# Qwell Pharmaceuticals

## Overview

Public information on Qwell Pharmaceuticals appears limited. VentureDeal / Gaebler describes the company as a Seattle-based biopharmaceutical company developing anti-cancer therapeutics and reports that it is out of business [[1]](https://www.gaebler.com/Funded-Company-C16DFBC5-7F87-4EE6-BFF1-662962FBD908-Qwell-Pharmaceuticals).

## Technology

The same company-profile source describes Qwell's technology focus at a high level as therapeutics for anti-cancer activity, but does not provide detailed modality or platform disclosures in the material reviewed for this note [[1]](https://www.gaebler.com/Funded-Company-C16DFBC5-7F87-4EE6-BFF1-662962FBD908-Qwell-Pharmaceuticals).

## Investors

Gaebler reports at least one venture round of about $7 million in January 2009 from ARCH Venture Partners and private investors [[1]](https://www.gaebler.com/Funded-Company-C16DFBC5-7F87-4EE6-BFF1-662962FBD908-Qwell-Pharmaceuticals). ARCH's public portfolio lists also include Qwell Pharmaceuticals among its portfolio companies [[2]](https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf).

## Acquisitions / Strategic Transactions

The main strategic transaction identified in the reviewed sources is Qwell's reported 2009 venture financing round [[1]](https://www.gaebler.com/Funded-Company-C16DFBC5-7F87-4EE6-BFF1-662962FBD908-Qwell-Pharmaceuticals).

## References

[[1]](https://www.gaebler.com/Funded-Company-C16DFBC5-7F87-4EE6-BFF1-662962FBD908-Qwell-Pharmaceuticals)
[[2]](https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf)
