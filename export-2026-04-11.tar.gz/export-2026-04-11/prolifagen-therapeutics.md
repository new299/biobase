# Prolifagen Therapeutics

**Prolifagen Therapeutics** (often shown simply as *Prolifagen, Inc.*) is an **early‑stage RNA technology biotechnology company** focused on **microRNA (miRNA)‑based regenerative therapeutics** to treat **heart damage after myocardial infarction** and prevent progression to chronic heart failure. Its core technology is built around **microRNA biology and controlled delivery** rather than traditional small molecules or gene editing. [[1]](https://prolifagen.com/about/) [[2]](https://prolifagen.com/technology/)

## Company Overview
- **Founded:** 2016 (spin‑out focused on translational cardiac regeneration from academic research). [[3]](https://www.cbinsights.com/company/prolifagen)  
- **Stage:** Preclinical / early biotech development (planned IND/clinic). [[4]](https://medtechalert.com/companies/prolifagen-therapeutics/)  
- **Headquarters:** Villanova, Pennsylvania, USA (registered office and labs). [[3]](https://www.cbinsights.com/company/prolifagen)  

Prolifagen’s mission is to **regenerate heart muscle damaged by myocardial infarction** using a novel RNA therapeutic designed to activate cardiomyocyte proliferation — a capability adult human hearts normally lack. [[1]](https://prolifagen.com/about/)

## Technology & Modality
- **miRNA‑based therapeutic platform:** The company’s lead program leverages **microRNA‑302 (miR‑302)** delivered via a **hydrogel formulation (PRO‑302)** to damaged cardiac tissue following a heart attack. The miRNA is intended to re‑engage proliferative pathways (similar to embryonic heart growth) and encourage regrowth of functional cardiomyocytes. [[2]](https://prolifagen.com/technology/)  
- **Delivery system:** miR‑302 is embedded in a **biodegradable hydrogel** that slowly releases the miRNA into the tissue over several days as the gel dissolves. This approach aims to localize therapy and induce tissue regeneration without systemic exposure. [[2]](https://prolifagen.com/technology/)  

➡️ This is **miRNA therapy**, not RNAi, RNA editing, traditional mRNA vaccines, or gene editing. The platform focuses on **microRNA as a regenerative agent**. [[2]](https://prolifagen.com/technology/)

## Lead Program: PRO‑302
- **Mechanism:** Local delivery of **miR‑302** to activate heart muscle cell proliferation post‑myocardial infarction. [[2]](https://prolifagen.com/technology/)  
- **Preclinical results:** In animal models (mice and pigs), PRO‑302 has demonstrated the ability to induce cardiomyocyte proliferation and improve structural and functional outcomes after infarcts. [[4]](https://medtechalert.com/companies/prolifagen-therapeutics/)  
- **Clinical development:** The company has expressed plans to begin **IND‑enabling studies** and initiate clinical trials (targeted around early to mid‑2025 timeframe according to industry reports). The therapeutic is designed to address the unmet need of preventing post‑infarct heart failure. [[4]](https://medtechalert.com/companies/prolifagen-therapeutics/)  

## Market & Unmet Need
Heart disease remains a leading cause of death and disability, and **current therapies do not regenerate lost cardiac tissue** after a heart attack. Prolifagen’s miRNA therapeutic approach aims to:
- Restore lost myocardial tissue  
- Reduce progression to heart failure  
- Improve long‑term outcomes for heart attack survivors  
This represents a **regenerative medicine strategy** distinct from conventional heart failure drugs or devices. [[1]](https://prolifagen.com/about/)

## Leadership & Team
Prolifagen’s leadership includes executives with experience in biotech and life sciences, including:
- **Mike Behr – CEO:** Life sciences executive with prior experience in commercialization and biotech leadership. [[5]](https://prolifagen.com/leadership/)  
- **Seth Kiernan – Chief Development Officer:** Biotech R&D and regulatory expert. [[5]](https://prolifagen.com/leadership/)  
- **Scientific advisors** with backgrounds in miRNA, regenerative biology, and translational medicine. [[5]](https://prolifagen.com/leadership/)

## Funding & Support
Publicly available profiles indicate Prolifagen has raised modest funding in early investment rounds and grants. It is categorized as a small biotech with a focused preclinical program. According to data aggregators, total reported funding is approximately **~$3 M** from investors like PCI Ventures and JLabs, along with grant backing. [[6]](https://www.cbinsights.com/company/prolifagen)

## Status
- **Preclinical / early development:** PRO‑302 has shown promising regeneration in animal models and is heading toward clinical testing. [[4]](https://medtechalert.com/companies/prolifagen-therapeutics/)  
- **Active research:** Prolifagen remains active in advancing its miRNA platform and preparing for human studies. ClinicalTrials.gov does not yet list registered active trials. [[7]](https://app.biopharmiq.com/companies/8587)  
- **Focus:** Cardiovascular regenerative therapy, specifically targeting post‑myocardial infarction outcomes. [[1]](https://prolifagen.com/about/)

## Summary
Prolifagen Therapeutics is a **U.S. early‑stage biotech company** built around **miRNA technology** — specifically leveraging a **microRNA‑302 therapeutic (PRO‑302)** delivered with a hydrogel to **regenerate heart tissue after heart attacks**. Its approach is distinctly **miRNA‑based (not RNAi, mRNA vaccine, or RNA editing)** with the goal of preventing progression to chronic heart failure. The company has preclinical proof‑of‑concept and is advancing toward clinical development. [[1]](https://prolifagen.com/about/) [[2]](https://prolifagen.com/technology/)

## References
1. Prolifagen Therapeutics company overview. https://prolifagen.com/about/ turn0search0  
2. Prolifagen therapeutic technology and miR302 delivery. https://prolifagen.com/technology/ turn0search1  
3. Prolifagen funding and profile. https://www.cbinsights.com/company/prolifagen turn0search6  
4. Prolifagen description & preclinical focus. https://medtechalert.com/companies/prolifagen-therapeutics/ turn0search4  
5. Leadership and management team. https://prolifagen.com/leadership/ turn0search13  
6. Funding totals and investor data. https://www.cbinsights.com/company/prolifagen turn0search6  
7. BiopharmIQ profile (trial status). https://app.biopharmiq.com/companies/8587 turn0search7
