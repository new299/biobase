# Ansa Biotechnologies — Research Notes

## Overview

Ansa Biotechnologies is a commercial-stage synthetic biology company founded in 2019, headquartered in Emeryville, CA. Develops an **enzymatic DNA synthesis** platform to replace the 40-year-old chemical phosphoramidite synthesis method. Launched first commercial products in July 2024. Total raised: ~$177M. [[1]](https://www.businesswire.com/news/home/20251001701666/en/Ansa-Biotechnologies-Secures-54.4-Million-in-Series-B-Financing)

---

## Technology

- **Enzymatic DNA Synthesis Platform**: Uses enzymes (template-independent DNA polymerases) instead of toxic phosphoramidite chemistry to synthesize oligonucleotides and synthetic DNA. Produces longer, more accurate sequences with a more sustainable and scalable process. Enables longer oligos and gene fragments not achievable by chemical synthesis. [[2]](https://ansabio.com/)
- **Guaranteed On-Time Service**: First synthetic DNA provider offering a delivery guarantee — addressing a key pain point in research and biopharma manufacturing timelines. [[1]](https://www.businesswire.com/news/home/20251001701666/en/Ansa-Biotechnologies-Secures-54.4-Million-in-Series-B-Financing)
- Applications: DNA-encoded libraries, oligo therapeutics manufacturing, synthetic biology, gene therapy vector production.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | ~2019–2021 | Undisclosed | Early investors |
| Series A | Apr 2022 | ~$68M | Undisclosed |
| Series B | Oct 2025 | $54.4M (oversubscribed) | Cerberus Ventures (lead), Blue Water Life Science, Altitude Life Science, Fall Line Capital, AIM13, Black Opal Ventures |

Total raised: ~$177M. [[1]](https://www.businesswire.com/news/home/20251001701666/en/Ansa-Biotechnologies-Secures-54.4-Million-in-Series-B-Financing)

---

## References

1. BusinessWire — Series B (Oct 2025): [https://www.businesswire.com/news/home/20251001701666/en/Ansa-Biotechnologies-Secures-$54.4-Million-in-Series-B-Financing-to-Redefine-How-Scientists-Access-Synthetic-DNA-with-Industrys-First-Guaranteed-On-Time-Service](https://www.businesswire.com/news/home/20251001701666/en/Ansa-Biotechnologies-Secures-$54.4-Million-in-Series-B-Financing-to-Redefine-How-Scientists-Access-Synthetic-DNA-with-Industrys-First-Guaranteed-On-Time-Service)
2. Ansa Biotechnologies — Website: [https://ansabio.com/](https://ansabio.com/)
