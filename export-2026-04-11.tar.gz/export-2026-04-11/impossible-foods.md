# Impossible Foods — Research Notes

## Overview

Impossible Foods is a Redwood City, CA-based food technology company founded in 2011 by Patrick O. Brown (Stanford biochemist), developing plant-based meat products that replicate the taste, texture, and nutritional profile of animal-derived meat using heme protein (soy leghemoglobin) fermentation. The company's flagship product, the Impossible Burger, is sold in grocery stores and restaurants worldwide. Total raised: $2.01B. Key investors include Khosla Ventures, Google Ventures (GV), Bill Gates, Horizons Ventures, Temasek, Coatue, and Viking Global Investors. The company acquired Motif FoodWorks in September 2024. [[1]](https://impossiblefoods.com/) [[2]](https://www.crunchbase.com/organization/impossible-foods)

---

## Technology & Products

- **Heme Technology (Soy Leghemoglobin)**: Core differentiating ingredient — soy leghemoglobin produced by fermentation of genetically engineered yeast provides the characteristic beefy taste, smell, and appearance of meat; FDA-cleared as GRAS. [[1]](https://impossiblefoods.com/)
- **Impossible Burger / Impossible Beef**: Plant-based ground beef made from soy and potato protein; available in retail and foodservice; nutritionally comparable to animal beef with 0mg cholesterol. [[1]](https://impossiblefoods.com/)
- **Expanded Product Line**: Impossible Pork, Impossible Chicken, Impossible Sausage, and other formats. [[1]](https://impossiblefoods.com/)
- **Motif FoodWorks Acquisition**: Acquired Motif FoodWorks (a Ginkgo Bioworks spinout focused on food ingredients) in September 2024. [[2]](https://www.crunchbase.com/organization/impossible-foods)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A–D | 2011–2017 | ~$257M | Khosla Ventures, Google Ventures, Bill Gates, Horizons Ventures, Open Philanthropy |
| Series E | May 2019 | $300M | Temasek, Khosla Ventures |
| Series F | Nov 2019 | $500M | Coatue, Khosla Ventures |
| Later rounds | 2020–2021 | ~$700M+ | Viking Global, UBS, Mirae Asset, others |
| Total | — | $2.01B | — |

[[2]](https://www.crunchbase.com/organization/impossible-foods)

---

## References

1. Impossible Foods — Homepage: [https://impossiblefoods.com/](https://impossiblefoods.com/)
2. Crunchbase — Impossible Foods: [https://www.crunchbase.com/organization/impossible-foods](https://www.crunchbase.com/organization/impossible-foods)
