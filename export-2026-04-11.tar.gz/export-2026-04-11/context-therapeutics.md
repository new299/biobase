# Context Therapeutics

## Overview
Context Therapeutics is a clinical-stage biopharmaceutical company advancing T cell engager bispecific antibodies for solid tumors.[[1]](https://www.contexttherapeutics.com/)[[2]](https://ir.contexttherapeutics.com/news-releases/news-release-details/context-therapeutics-reports-third-quarter-2025-operating-and)

## Technology
Its public pipeline includes CTIM-76, a Claudin 6 x CD3 bispecific antibody, CT-95, a mesothelin x CD3 bispecific antibody, and CT-202, a Nectin-4 x CD3 bispecific antibody. The company positions itself around next-generation T cell engager therapies for difficult-to-treat solid tumors.[[1]](https://www.contexttherapeutics.com/)[[2]](https://ir.contexttherapeutics.com/news-releases/news-release-details/context-therapeutics-reports-third-quarter-2025-operating-and)

## Investors
Context announced a $100 million private placement in May 2024 led by Nextech, with participation from Ally Bridge Group, Avidity Partners, Blackstone Multi-Asset Investing, Blue Owl Healthcare Opportunities, Deep Track Capital, Driehaus Capital Management, Great Point Partners, and other investors.[[3]](https://ir.contexttherapeutics.com/news-releases/news-release-details/context-therapeutics-announces-100-million-private-placement/)

## Acquisitions / Other
In July 2024, Context acquired CT-95 from Link Immunotherapeutics through an asset purchase agreement, expanding its clinical-stage T cell engager pipeline.[[4]](https://ir.contexttherapeutics.com/news-releases/news-release-details/context-therapeutics-acquires-phase-1-ready-t-cell-engager-ct-95/)
