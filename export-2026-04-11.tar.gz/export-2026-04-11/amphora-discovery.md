# Amphora Discovery — Research Notes

## Overview

Amphora Discovery Corporation is a drug discovery company founded in 2002, headquartered in Research Triangle Park (Durham), NC. A pioneer in microfluidic assay technology and high-throughput screening (HTS), providing integrated drug discovery services to the pharmaceutical industry. Has performed 100+ HTS campaigns and generated 35M+ data points. [[1]](https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units)

---

## Technology

- **Microfluidic HTS Platform**: Early-access partner in developing Caliper Life Sciences' microfluidics screening system. Provides in vitro assay protocols, HTS campaigns, compound profiling, custom assay development, and enzymology services. [[1]](https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units)
- **Amphora Pharmaceuticals BU** (Los Altos, CA): In-house IP portfolio of small molecules for cancer, inflammation, and CNS diseases; seeks pharma partnerships. [[1]](https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units)
- **Amphora Discovery BU** (Durham, NC): CRO arm — lead generation, lead optimization, profiling, and drug discovery contract research. [[1]](https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units)

---

## Funding & Investors

No significant external venture funding publicly recorded. Private, primarily service-revenue funded. [[2]](https://www.crunchbase.com/organization/amphora-discovery)

---

## References

1. BioSpace — Business unit formation announcement: [https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units](https://www.biospace.com/amphora-discovery-corporation-announces-formation-of-two-market-driven-business-units)
2. Crunchbase — Amphora Discovery profile: [https://www.crunchbase.com/organization/amphora-discovery](https://www.crunchbase.com/organization/amphora-discovery)
