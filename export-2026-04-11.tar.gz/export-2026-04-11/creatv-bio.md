# Creatv Bio — Research Notes

## Overview

Creatv Bio (a division of Creatv MicroTech, Inc.) is a Rockville, MD-based oncology diagnostics company developing CTC (circulating tumor cell)-based liquid biopsy tests using proprietary CellSieve™ microfiltration technology. Founded 2000. Total raised: ~$2.44M+ (primarily government grants and TEDCO). [[1]](https://creatvbio.com/company) [[2]](https://www.crunchbase.com/organization/creatv-microtech)

---

## Technology

- **CellSieve™ Microfilter**: Precision microfabricated filter with ultra-precise 7-micron pores that remove red blood cells and most white blood cells from blood samples while trapping larger CTCs and other cancer-associated cells. Enables multiplex analysis of captured cells. [[3]](https://pubs.rsc.org/en/content/articlehtml/2016/ra/c5ra21524b)
- **Cancer-Associated Macrophage-Like (CAML) Cells**: Discovery that CellSieve captures not only CTCs but also CAMLs — a novel cancer biomarker found in cancer patients but not healthy controls. CAMLs may provide additional prognostic information. [[1]](https://creatvbio.com/company)
- **LifeTracDx® Tests**: Line of blood tests for early cancer detection, real-time therapy monitoring, and advanced diagnostics using CellSieve-isolated cells. [[1]](https://creatvbio.com/company)

---

## Funding & Investors

| Round | Date | Amount | Source |
|-------|------|--------|--------|
| NIH/DoE/DoD grants | 2008–2011 | $2.44M | TEDCO, Maryland Dept. of Agriculture, NIH, U.S. Dept. of Energy, DHHS |

Total raised: ~$2.44M (primarily government grants). [[2]](https://www.crunchbase.com/organization/creatv-microtech)

---

## References

1. Creatv BIO — Company page: [https://creatvbio.com/company](https://creatvbio.com/company)
2. Crunchbase — Creatv MicroTech: [https://www.crunchbase.com/organization/creatv-microtech](https://www.crunchbase.com/organization/creatv-microtech)
3. RSC Advances — CellSieve precision microfilter paper (2016): [https://pubs.rsc.org/en/content/articlehtml/2016/ra/c5ra21524b](https://pubs.rsc.org/en/content/articlehtml/2016/ra/c5ra21524b)
