# Inflammatix — Research Notes

## Overview

Inflammatix is a Burlingame, CA-based molecular diagnostics company reimagining acute infectious disease diagnostics by measuring the patient's host immune response — using multi-gene expression profiling combined with machine learning — to rapidly distinguish bacterial from viral infection and predict sepsis. Its HostDx™ test platform runs on the company's point-of-care instrument Myrna in under 30 minutes. Total raised: $200M+ private capital plus $50M+ in government grants and contracts. Key investors include Khosla Ventures, Northpond Ventures, D1 Capital Partners, Think.Health Ventures, and OSF Healthcare Ventures. [[1]](https://inflammatix.com/) [[2]](https://www.crunchbase.com/organization/inflammatix)

---

## Technology & Products

- **HostDx™ Sepsis / HostDx™ Fever**: Rapid host response diagnostics measuring expression of multiple immune-response genes in blood to determine: (1) whether a patient has bacterial or viral infection and (2) whether the patient has or is likely to develop sepsis — enabling antibiotic stewardship and early sepsis intervention. [[1]](https://inflammatix.com/)
- **Myrna™ Instrument**: Proprietary sample-to-answer isothermal amplification instrument platform delivering HostDx results in under 30 minutes at point of care. [[1]](https://inflammatix.com/)
- **BARDA / Government Contracts**: Received BARDA contract alongside Series C financing; additional grants from NIH and other agencies totaling $50M+. [[1]](https://inflammatix.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series C | Jan 2020 | $32M | Khosla Ventures, Northpond Ventures, Think.Health, OSF Healthcare Ventures, Stanford StartX Fund |
| Series D | Mar 2021 | $102M | D1 Capital Partners (lead), Northpond Ventures, Khosla Ventures, Think.Health, OSF Healthcare Ventures |
| Series E | Sep 2024 | $57M | Khosla Ventures (lead), Think.Health Ventures |
| Total | — | $200M+ private + $50M+ grants | — |

[[2]](https://www.crunchbase.com/organization/inflammatix)

---

## References

1. Inflammatix — Homepage: [https://inflammatix.com/](https://inflammatix.com/)
2. Crunchbase — Inflammatix: [https://www.crunchbase.com/organization/inflammatix](https://www.crunchbase.com/organization/inflammatix)
