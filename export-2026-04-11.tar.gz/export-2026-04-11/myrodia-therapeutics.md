# Myrodia Therapeutics

Myrodia Therapeutics is a Japan-based, venture capital–backed drug discovery startup focused on developing novel therapeutics based on a proprietary concept called “Sensory Medicine” ([Source 1](https://myrodiatx.com/en/), [Source 2](https://www.cbinsights.com/company/myrodia-therapeutics)).

### Approach

Myrodia’s approach centers on **Sensory Medicine**, a new therapeutic paradigm that uses sensory stimulation (e.g., odor molecules) to activate the body’s latent protective biological functions.

- Targets brain–organ communication via sensory and vagus nerve pathways  
- Induces protective responses such as anti-inflammatory effects, metabolic suppression, and improved blood flow  
- Inspired by natural survival mechanisms such as hibernation  

The company is developing **small-molecule drugs that induce artificial hibernation–like states**, with potential applications in acute and emergency medical conditions ([Source 1](https://myrodiatx.com/en/), [Source 3](https://remigesventures.com/portfolio-companies/myrodia-therapeutics/)).

### Technology

- Sensory stimulation–based drug discovery (“sensory pharmaceutics”)  
- Artificial induction of protective physiological states  
- Translational research originating from Kansai Medical University  

This approach differs from traditional drug discovery by **modulating systemic physiological responses rather than targeting a single molecular pathway** ([Source 1](https://myrodiatx.com/en/), [Source 4](https://startup-db.com/companies/rE5aJP5UOLNGmVbw)).

### Market & Positioning

Myrodia operates in the **biopharmaceutical and novel therapeutics market**, particularly:

- Emergency and acute care therapeutics  
- Organ protection and critical care  
- Next-generation drug discovery paradigms  

Its platform positions it as a **high-risk, high-innovation biotech**, introducing a fundamentally new modality compared to conventional small-molecule or biologic approaches ([Source 2](https://www.cbinsights.com/company/myrodia-therapeutics), [Source 4](https://startup-db.com/companies/rE5aJP5UOLNGmVbw)).

### Investors (Technology / Biotech VCs)

Myrodia is backed by venture capital firms, including:

- ANRI (Japan-based early-stage VC)  
- Remiges Ventures (biotech-focused VC)  

([Source 2](https://www.cbinsights.com/company/myrodia-therapeutics), [Source 3](https://remigesventures.com/portfolio-companies/myrodia-therapeutics/))

### Funding

- At least one disclosed funding round (“Other Investors”)  
- Backed by venture capital (exact amounts not publicly disclosed)  

([Source 2](https://www.cbinsights.com/company/myrodia-therapeutics))

### Status

- Active  
- Privately held  
- Venture-backed  
- Not acquired  

---

Overall, Myrodia Therapeutics is an early-stage biotech company pioneering a novel “Sensory Medicine” approach, aiming to unlock the body’s innate protective mechanisms—particularly through artificial hibernation—as a new class of therapeutic intervention.
