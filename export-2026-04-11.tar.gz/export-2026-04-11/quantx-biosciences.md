# QuantX Biosciences

## Overview

QuantX Biosciences is a private drug-discovery company founded in 2022 and focused on oral small-molecule therapeutics for immune-mediated and inflammatory diseases [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/). The company says it uses a computationally driven discovery and development platform to design and optimize drug candidates [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/).

## Technology

QuantX says its platform integrates physics-based modeling, statistical methods, and computational chemistry to accelerate discovery of differentiated oral small molecules [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/). The company said in 2026 that its lead programs included STAT6 and IL-17 oral small-molecule inhibitors [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/).

## Investors

In February 2026, QuantX announced an oversubscribed $85 million Series B round co-led by Sanofi Ventures and LAV, with participation from Hongshan and existing investors [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/). The company also said it had been incubated by OrbiMed and Creacion Ventures and had raised $130 million to date [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/) [[2]](https://www.htworld.co.uk/news/biotech-news/quantx-raises-us85m-in-series-b-funding-mipo26/).

## Acquisitions / Strategic Transactions

The main strategic transaction identified in the reviewed sources is the 2026 Series B financing, which QuantX said would fund clinical development of its lead oral immunology programs and continued platform expansion [[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/).

## References

[[1]](https://quantxbio.com/press-release/quantx-biosciences-closes-oversubscribed-85m-series-b-financing/)
[[2]](https://www.htworld.co.uk/news/biotech-news/quantx-raises-us85m-in-series-b-funding-mipo26/)
