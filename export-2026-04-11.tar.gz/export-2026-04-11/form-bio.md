# Form Bio

## Overview
Form Bio is a software company providing AI-enabled data infrastructure and analysis tools for genetic medicine and genome engineering.[[1]](https://www.formbio.com/)[[2]](https://www.formbio.com/about)

## Technology
The company says its platform supports AAV, lentivirus, plasmid, mRNA, CRISPR, and broader multi-omics workflows, helping therapy developers manage, analyze, and interpret complex datasets across genetic medicine programs.[[1]](https://www.formbio.com/)[[2]](https://www.formbio.com/about)

## Investors
Form Bio announced a $30 million Series A in October 2023 led by JAZZ Venture Partners and AME Cloud Ventures, with participation from Colossal Biosciences, the Allen Institute for AI, Y Combinator, and several angel investors.[[3]](https://www.prnewswire.com/news-releases/form-bio-raises-30m-series-a-to-expand-its-ai-powered-computational-life-sciences-platform-for-genetic-medicine-and-genome-engineering-301949071.html)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. The company publicly describes itself as the first spinout from Colossal Biosciences.[[1]](https://www.formbio.com/)[[2]](https://www.formbio.com/about)
