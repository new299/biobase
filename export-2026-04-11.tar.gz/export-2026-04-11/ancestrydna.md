# AncestryDNA — Research Notes

## Overview

AncestryDNA is the genetic testing division of Ancestry.com (Ancestry®), a consumer genealogy and family history platform. Launched in 2012, it is one of the largest direct-to-consumer (DTC) DNA testing services in the world, with 25M+ customers in its DNA database as of 2023. Ancestry.com, Inc. is a private company (taken private by Blackstone in 2020 for ~$4.7B). [[1]](https://en.wikipedia.org/wiki/Ancestry.com)

---

## Technology

- **Autosomal SNP Microarray**: Genotypes ~700,000 SNPs per customer using microarray technology; analyzes ancestral composition via ethnicity estimates and matches customers to genetic relatives. [[1]](https://en.wikipedia.org/wiki/Ancestry.com)
- **AncestryHealth** (discontinued 2021): Was offering health predisposition and carrier status reports; discontinued in favor of core genealogy focus.
- Integrates genetic data with 30B+ historical records for family tree building.
- 25M+ customer DNA database is among the world's largest private genetic databases.

---

## Funding & Investors

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| Series C | 2012 | $100M | Permira, others |
| Series D | 2014 | $250M | Permira, others |
| LBO (Permira) | 2012 | ~$1.6B | Permira acquired controlling stake |
| LBO (Blackstone) | Dec 2020 | ~$4.7B | Blackstone Group acquired Ancestry from Permira |

Company valued at ~$4.7B at Blackstone acquisition (2020). [[2]](https://www.cnbc.com/2020/08/05/blackstone-to-acquire-ancestry-in-4point7-billion-deal.html)

---

## References

1. Wikipedia — Ancestry.com: [https://en.wikipedia.org/wiki/Ancestry.com](https://en.wikipedia.org/wiki/Ancestry.com)
2. CNBC — Blackstone acquisition: [https://www.cnbc.com/2020/08/05/blackstone-to-acquire-ancestry-in-4point7-billion-deal.html](https://www.cnbc.com/2020/08/05/blackstone-to-acquire-ancestry-in-4point7-billion-deal.html)
