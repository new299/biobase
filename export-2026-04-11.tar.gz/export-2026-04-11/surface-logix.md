# Surface Logix

## Overview
Surface Logix was a technology company applying surface chemistry and materials science to biomedical and cell-culture applications before becoming part of Nano Terra / platform structures [[1]](https://www.nano-terra.com/about/).

## Technology
Nano Terra's history states that the company was based on a license from Surface Logix and focused on patterns, coatings, and nanoscale surface engineering for biological applications [[1]](https://www.nano-terra.com/about/).

## Investors
Public investor information specifically for Surface Logix was limited in the reviewed sources during this pass [[1]](https://www.nano-terra.com/about/).

## Acquisitions / Strategic Transactions
The clearest strategic relationship visible publicly is Surface Logix's technology licensing / lineage into Nano Terra rather than a documented standalone M&A event in the reviewed sources [[1]](https://www.nano-terra.com/about/).

## References
[[1]](https://www.nano-terra.com/about/)
