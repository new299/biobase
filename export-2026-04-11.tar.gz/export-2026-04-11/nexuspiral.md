# Nexuspiral

## Overview
Nexuspiral is a Japanese biotechnology company developing genome-editing technology based on the PODiR system rather than CRISPR-Cas9.[[1]](https://www.kansai.meti.go.jp/2-4bio/KRIC/leaflets/Nexuspiral.pdf)[[2]](https://www.f6s.com/company/nexuspiral) Public source coverage is limited, so this note is intentionally narrow.

## Technology
According to a regional industry leaflet, Nexuspiral's technology uses the PODiR system to make small insertions and deletions in DNA using oligonucleotides without requiring exogenous nuclease proteins, and the leaflet states that off-target effects had not been confirmed in the demonstrated setting.[[1]](https://www.kansai.meti.go.jp/2-4bio/KRIC/leaflets/Nexuspiral.pdf) The underlying PODiR concept is described by Japan's Advanced Industrial Science and Technology group as a self-genome-editing mechanism being developed as a new genome-editing method distinct from CRISPR-based approaches.[[3]](https://unit.aist.go.jp/bmd/en/gr/agd-e1/index.html)

## Investors
F6S lists Nexuspiral as founded in 2019 and indicates that it has raised capital from Glocalink Singapore and another investor, but it does not provide the full financing history in the publicly accessible profile.[[2]](https://www.f6s.com/company/nexuspiral) I did not identify a more authoritative public investor announcement during this pass, so the funding picture should be treated as partial.[[2]](https://www.f6s.com/company/nexuspiral)

## Acquisitions and Corporate Activity
No acquisition involving Nexuspiral was identified in the reviewed public sources. The clearest public record relates to its attempt to commercialize the PODiR-based genome-editing approach.[[1]](https://www.kansai.meti.go.jp/2-4bio/KRIC/leaflets/Nexuspiral.pdf)[[2]](https://www.f6s.com/company/nexuspiral)
