# ANGLE plc

## Overview
ANGLE plc is a public liquid-biopsy diagnostics company focused on harvesting and analyzing circulating tumor cells and related cancer biomarkers.[[1]](https://angleplc.com/information-for-investors-angle-plc/)[[2]](https://angleplc.com/) It is listed on the London Stock Exchange AIM market and has ADRs traded on OTCQX.[[3]](https://angleplc.com/information-for-investors-angle-plc/share-price/)

## Technology
ANGLE’s core technology is the Parsortix system for capturing circulating tumor cells from blood, with broader liquid-biopsy capabilities extending toward downstream molecular analysis.[[2]](https://angleplc.com/)[[4]](https://www.globenewswire.com/de/news-release/2017/10/05/1292875/0/en/Angle-PLC-Angle-PLC-Announces-Proposed-Placing-of-29-437-152-New-Ordinary-Shares-at-35-pence-per-share-Proposed-subscriptions-of-5-352-026-New-Ordinary-Shares-at-35-pence-per-share.html) The company has also pursued “sample to answer” capability through acquired Axela assets.[[4]](https://www.globenewswire.com/de/news-release/2017/10/05/1292875/0/en/Angle-PLC-Angle-PLC-Announces-Proposed-Placing-of-29-437-152-New-Ordinary-Shares-at-35-pence-per-share-Proposed-subscriptions-of-5-352-026-New-Ordinary-Shares-at-35-pence-per-share.html)

## Investors and Ownership
ANGLE is a public company, so ownership is through public markets.[[1]](https://angleplc.com/information-for-investors-angle-plc/) The company’s investor pages emphasize governance, regulatory news, and significant-shareholder information rather than venture financing.[[1]](https://angleplc.com/information-for-investors-angle-plc/)

## Acquisitions and Corporate Activity
In 2017, ANGLE announced the acquisition of certain assets of Axela Inc. for approximately CAD6.15 million to expand downstream analysis capabilities for circulating tumor cells.[[4]](https://www.globenewswire.com/de/news-release/2017/10/05/1292875/0/en/Angle-PLC-Angle-PLC-Announces-Proposed-Placing-of-29-437-152-New-Ordinary-Shares-at-35-pence-per-share-Proposed-subscriptions-of-5-352-026-New-Ordinary-Shares-at-35-pence-per-share.html)
