# Mariana Oncology

## Overview

Mariana Oncology was a radiopharmaceutical biotechnology company developing precision radioligand therapies for cancer.[[1]](https://marianaoncology.com/news/mariana-oncology-to-be-acquired-by-novartis-to-advance-precision-radiopharmaceuticals-to-treat-cancer/) The company described itself as fully integrated and focused on novel peptide-based radiopharmaceuticals for solid tumors.[[1]](https://marianaoncology.com/news/mariana-oncology-to-be-acquired-by-novartis-to-advance-precision-radiopharmaceuticals-to-treat-cancer/)

## Technology

Mariana's platform centered on next-generation radiopharmaceuticals and isotope-enabled precision oncology. Public materials highlighted a portfolio of peptide-based radiopharmaceutical programs and investment in manufacturing, isotope supply, and formulation capabilities.[[1]](https://marianaoncology.com/news/mariana-oncology-to-be-acquired-by-novartis-to-advance-precision-radiopharmaceuticals-to-treat-cancer/)

## Investors

In September 2023, Mariana announced an oversubscribed $175 million Series B co-led by Deep Track Capital and Forbion, with founding investors Atlas Venture, Access Biotechnology, and RA Capital Management joined by Nextech Invest, Surveyor Capital, and Eli Lilly and Company.[[2]](https://marianaoncology.com/news/mariana-oncology-announces-usd175-million-series-b-financing/)

## Acquisitions and Strategic Transactions

In May 2024, Novartis announced an agreement to acquire Mariana Oncology for $1 billion upfront plus up to $750 million in milestone payments.[[3]](https://www.novartis.com/news/media-releases/novartis-enters-agreement-acquire-mariana-oncology-strengthening-radioligand-therapy-pipeline) Mariana announced the same transaction on its site, framing it as a way to advance its precision radiopharmaceutical pipeline.[[1]](https://marianaoncology.com/news/mariana-oncology-to-be-acquired-by-novartis-to-advance-precision-radiopharmaceuticals-to-treat-cancer/)
