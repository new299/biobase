# Granite Bio

## Overview
Granite Bio is a clinical-stage immunology company developing first-in-class antibodies for inflammation, autoimmunity, and fibrosis.[[1]](https://www.granitebio.com/)[[2]](https://www.granitebio.com/news/granite-bio-debuts-with-100-million-of-capital)

## Technology
The company says its pipeline includes antibody programs targeting key disease biology nodes in autoimmune and inflammatory disease, including GRT-001 and GRT-002.[[1]](https://www.granitebio.com/)[[2]](https://www.granitebio.com/news/granite-bio-debuts-with-100-million-of-capital)

## Investors
Granite emerged from stealth in April 2025 with $100 million in funding, including a $30 million Series A led by Versant Ventures and Novartis Venture Fund and a $70 million Series B led by Forbion and Sanofi Ventures.[[2]](https://www.granitebio.com/news/granite-bio-debuts-with-100-million-of-capital)

## Acquisitions / Other
In October 2025, Granite announced an option-to-purchase agreement with Novartis tied to development of its immuno-inflammatory therapies.[[3]](https://www.granitebio.com/news/granite-bio-enters-into-an-option-to-acquire-agreement)
