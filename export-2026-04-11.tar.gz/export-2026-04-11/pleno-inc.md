# Pleno Inc.

## Overview
Pleno is a multi-omics instrument platform company developing systems for biological target detection in clinical testing and biomedical research.[[1]](https://www.businesswire.com/news/home/20220525005343/en/Multi-omics-Startup-Pleno-Inc.-Announces-%2415-Million-in-Pre-Series-A-Funding)[[2]](https://www.businesswire.com/news/home/20221012005181/en/Multi-omics-Startup-Pleno-Inc.-Announces-%2440-Million-in-Series-A-Funding-Led-by-Deerfield-Management-with-Participation-by-Foresite-Capital)

## Technology
The company says it is building a multi-omic instrument platform, now marketed through its RAPTOR system, to transform biological target detection and personalized health workflows at scale.[[1]](https://www.businesswire.com/news/home/20220525005343/en/Multi-omics-Startup-Pleno-Inc.-Announces-%2415-Million-in-Pre-Series-A-Funding)[[3]](https://www.businesswire.com/news/home/20250806689259/en/Pleno-Inc.-Announces-First-Commercial-Agreement-with-Slopes-Bio-Inc.)

## Investors
Pleno announced a $15 million pre-Series A in May 2022 led by Medical Excellence Capital and Alexandria Venture Investments. In October 2022, it announced a $40 million Series A led by Deerfield Management with participation from Foresite Capital.[[1]](https://www.businesswire.com/news/home/20220525005343/en/Multi-omics-Startup-Pleno-Inc.-Announces-%2415-Million-in-Pre-Series-A-Funding)[[2]](https://www.businesswire.com/news/home/20221012005181/en/Multi-omics-Startup-Pleno-Inc.-Announces-%2440-Million-in-Series-A-Funding-Led-by-Deerfield-Management-with-Participation-by-Foresite-Capital)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. In August 2025, Pleno announced its first commercial agreement with Slopes Bio for RAPTOR instrument deployment.[[3]](https://www.businesswire.com/news/home/20250806689259/en/Pleno-Inc.-Announces-First-Commercial-Agreement-with-Slopes-Bio-Inc.)

## ASeq Posts

- [Pleno](https://aseq.substack.com/p/pleno)
- [Pleno Problems](https://aseq.substack.com/p/pleno-problems)
- [Pleno Inc Pcrquencing](https://aseq.substack.com/p/pleno-inc-pcrquencing)
- [Pleno Inc](https://aseq.substack.com/p/pleno-inc)
