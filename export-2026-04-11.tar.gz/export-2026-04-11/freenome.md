# Freenome — Research Notes

## Overview

Freenome is a South San Francisco, CA-based clinical-stage biotechnology company developing a multiomics blood-based platform for early cancer detection. The company's platform integrates cell-free DNA, RNA, proteins, and other biomarkers from a single blood draw to detect early-stage cancers. Lead programs target colorectal cancer (CRC) and lung cancer screening. Freenome has raised over $750M across multiple rounds, with Roche leading the 2024 $254M round. In December 2025, Freenome announced a $330M SPAC merger to go public (NASDAQ: FRNM). [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html) [[2]](https://medcitynews.com/2025/12/freenome-spac-merger-liquid-biopsy-colorectal-cancer-screening-early-detection-frnm/)

---

## Technology & Pipeline

- **Multiomics Platform**: Proprietary platform integrating cell-free DNA methylation, protein biomarkers, and other multiomics signals from blood to detect early-stage cancers with high sensitivity and specificity — trained via machine learning on large clinical cohorts. [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html)
- **CRC Blood Test**: Lead program for colorectal cancer blood-based screening for average-risk adults. PREEMPT CRC: prospective registrational study with 40,000+ participants. [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html)
- **Lung Cancer Test**: PROACT LUNG: prospective observational study enrolling up to 20,000 participants. [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html)
- **Multi-Cancer Early Detection (MCED)**: Pipeline programs for multiple cancer types from a single blood test. [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html)
- **Roche Licensing/Commercialization Deal**: $200M licensing and commercialization deal with Roche for cancer screening tests. [[3]](https://www.genomeweb.com/cancer/roche-freenome-ink-200m-licensing-commercialization-deal-cancer-screening-tests)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | Mar 2017 | $72M | Andreessen Horowitz (a16z), others |
| Series B | Jul 2019 | $160M | RA Capital Management (lead), Polaris Partners |
| Series C | ~2021–2022 | $270M | Roche, others |
| Additional round | Feb 2024 | $254M | Roche (lead), Quest Diagnostics, American Cancer Society BrightEdge |
| SPAC merger | Dec 2025 | $330M | SPAC — NASDAQ: FRNM |

Total raised: ~$750M+. [[1]](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html) [[2]](https://medcitynews.com/2025/12/freenome-spac-merger-liquid-biopsy-colorectal-cancer-screening-early-detection-frnm/)

---

## References

1. PRNewswire — Freenome $254M funding (Feb 2024): [https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html](https://www.prnewswire.com/news-releases/freenome-raises-254-million-in-new-funding-to-accelerate-its-platform-for-early-cancer-detection-302062419.html)
2. MedCity News — Freenome SPAC merger $330M (Dec 2025): [https://medcitynews.com/2025/12/freenome-spac-merger-liquid-biopsy-colorectal-cancer-screening-early-detection-frnm/](https://medcitynews.com/2025/12/freenome-spac-merger-liquid-biopsy-colorectal-cancer-screening-early-detection-frnm/)
3. GenomeWeb — Roche-Freenome $200M licensing deal: [https://www.genomeweb.com/cancer/roche-freenome-ink-200m-licensing-commercialization-deal-cancer-screening-tests](https://www.genomeweb.com/cancer/roche-freenome-ink-200m-licensing-commercialization-deal-cancer-screening-tests)
