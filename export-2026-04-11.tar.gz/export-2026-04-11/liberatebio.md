# LiberateBio

## Overview

LiberateBio is a biotechnology company developing delivery systems for genetic medicines, with an emphasis on targeted, non-viral delivery of nucleic acid therapeutics.[[1]](https://www.liberatebio.com/) The company positions itself as solving delivery bottlenecks for next-generation genetic medicines.[[1]](https://www.liberatebio.com/)

## Technology

LiberateBio's core platform centers on highly engineered lipid and related nanoparticles for extrahepatic delivery of nucleic acid payloads.[[1]](https://www.liberatebio.com/) The company highlights targeted delivery capabilities across multiple tissues and therapeutic areas, aiming to enable broader use of RNA and DNA medicines beyond current delivery constraints.[[1]](https://www.liberatebio.com/)

## Investors

Public company materials identify Khosla Ventures as a backer in the local note context, but the reviewed public website does not provide a detailed financing history or full syndicate. Because financing disclosures were not prominent in the reviewed official materials, investor detail remains partial in this note.[[1]](https://www.liberatebio.com/)

## Acquisitions and Strategic Transactions

No acquisition involving LiberateBio was identified in the reviewed sources. The public story reviewed is platform- and partnership-oriented rather than M&A-focused.[[1]](https://www.liberatebio.com/)
