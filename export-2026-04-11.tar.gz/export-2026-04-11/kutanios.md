# Kutanios

## Overview

Kutanios is an early-stage skin health company developing peptide-based ingredients to protect skin from environmental and aging-related damage.[[1]](https://sosv.com/company/kutanios/) SOSV describes the company as addressing skin damage caused by sunlight, pollution, tobacco smoke, and age-related degeneration.[[1]](https://sosv.com/company/kutanios/)

## Technology

According to SOSV, Kutanios is developing a topical peptide ingredient that prevents skin damage by stopping skin cells from degrading surrounding collagen and promoting inflammation.[[1]](https://sosv.com/company/kutanios/) The approach is positioned as both anti-aging and skin-protective, with an environmental benefit relative to common sunscreen ingredients.[[1]](https://sosv.com/company/kutanios/)

## Investors

Kutanios is an SOSV / IndieBio portfolio company.[[1]](https://sosv.com/company/kutanios/) No broader institutional syndicate or financing amount was clearly identified in the reviewed public sources.

## Acquisitions and Strategic Transactions

No acquisition involving Kutanios was identified in the reviewed sources. The public footprint reviewed is early-stage and platform-focused.[[1]](https://sosv.com/company/kutanios/)
