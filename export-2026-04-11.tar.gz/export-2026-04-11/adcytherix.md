# Adcytherix

## Overview
Adcytherix is a biopharmaceutical company developing novel antibody-drug conjugates with an emphasis on new payload classes.[[1]](https://www.biospace.com/press-releases/adcytherix-raises-eur-105m-series-a-to-accelerate-breakthrough-antibody-drug-conjugate-pipeline-with-strategic-focus-on-novel-payloads) The company transitioned into the clinic in 2026 with its lead asset ADCX-020.[[2]](https://www.biospace.com/press-releases/adcytherix-doses-first-patient-in-phase-1-trial-of-adcx-020-and-strengthens-leadership-to-support-next-phase-of-growth)

## Technology and Pipeline
Adcytherix’s platform is centered on next-generation ADC design with proprietary payload innovation.[[1]](https://www.biospace.com/press-releases/adcytherix-raises-eur-105m-series-a-to-accelerate-breakthrough-antibody-drug-conjugate-pipeline-with-strategic-focus-on-novel-payloads) Its lead candidate, ADCX-020, entered Phase 1 clinical testing in March 2026.[[2]](https://www.biospace.com/press-releases/adcytherix-doses-first-patient-in-phase-1-trial-of-adcx-020-and-strengthens-leadership-to-support-next-phase-of-growth)

## Investors
In October 2025, Adcytherix announced a EUR105 million Series A led by Bpifrance and co-led by Kurma Partners, Andera Partners, and Angelini Ventures, with participation from Surveyor Capital, aMoon, and existing investors including Pontifax, DawnBiopharma, Pureos Bioventures, and RA Capital.[[1]](https://www.biospace.com/press-releases/adcytherix-raises-eur-105m-series-a-to-accelerate-breakthrough-antibody-drug-conjugate-pipeline-with-strategic-focus-on-novel-payloads)

## Acquisitions and Corporate Activity
I did not identify an acquisition involving Adcytherix in the reviewed public sources. The key recent public milestone is its transition into a clinical-stage company with first-patient dosing of ADCX-020.[[2]](https://www.biospace.com/press-releases/adcytherix-doses-first-patient-in-phase-1-trial-of-adcx-020-and-strengthens-leadership-to-support-next-phase-of-growth)
