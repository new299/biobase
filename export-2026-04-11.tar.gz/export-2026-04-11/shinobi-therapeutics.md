# Shinobi Therapeutics

## Overview
Shinobi Therapeutics is developing hypoimmune iPSC-derived T-cell therapies intended for oncology and other applications [[1]](https://www.gaebler.com/Funded-Company-421A0FA8-4105-4621-9817-14FA2359DD8C-Shinobi-Therapeutics).

## Technology
Gaebler describes Shinobi's platform as comprehensive immune-evasion technology enabling hypoimmune CD8ab iPS-T cells that are compatible with patients' immune systems [[1]](https://www.gaebler.com/Funded-Company-421A0FA8-4105-4621-9817-14FA2359DD8C-Shinobi-Therapeutics).

## Investors
Gaebler reports at least $51 million in venture financing from investors including Astellas Venture Capital, D3, Fast Track Initiative, F-Prime Capital, JIC Venture Growth Investments, EQT Life Sciences, and Eight Roads [[1]](https://www.gaebler.com/Funded-Company-421A0FA8-4105-4621-9817-14FA2359DD8C-Shinobi-Therapeutics).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The key publicly visible milestone was the 2023 venture financing round [[1]](https://www.gaebler.com/Funded-Company-421A0FA8-4105-4621-9817-14FA2359DD8C-Shinobi-Therapeutics).

## References
[[1]](https://www.gaebler.com/Funded-Company-421A0FA8-4105-4621-9817-14FA2359DD8C-Shinobi-Therapeutics)
