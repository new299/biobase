# Vedere Bio

## Overview

Vedere Bio was an ocular gene therapy company focused on vision restoration and preservation through optogenetic and other gene therapy approaches. It first gained visibility through its acquisition by Novartis and later re-emerged as Vedere Bio II. [[1]](https://www.goodwinlaw.com/en/news-and-events/news/2020/10/10_30-vedere-bio-a-novel-optogenetics) [[2]](https://www.biospace.com/vedere-bio-ii-launches-with-77-million-series-a-financing-to-develop-next-generation-ocular-gene-therapies)

## Technology

Public descriptions center on mutation-agnostic optogenetic ocular gene therapies for vision restoration, with a broader next-generation ocular gene therapy pipeline in the successor company. The company was part of the wave of ophthalmic gene therapy startups seeking to address retinal degeneration beyond mutation-specific programs. [[1]](https://www.goodwinlaw.com/en/news-and-events/news/2020/10/10_30-vedere-bio-a-novel-optogenetics) [[2]](https://www.biospace.com/vedere-bio-ii-launches-with-77-million-series-a-financing-to-develop-next-generation-ocular-gene-therapies)

## Acquisition And Financing

Novartis acquired the original Vedere Bio in 2020 for $150 million upfront with up to $280 million total including milestones. In 2021, Vedere Bio II launched with a $77 million Series A led by Octagon Capital and joined by Samsara BioCapital, Casdin Capital, Atlas Venture, Mission BioCapital, and the Foundation Fighting Blindness RD Fund. [[1]](https://www.goodwinlaw.com/en/news-and-events/news/2020/10/10_30-vedere-bio-a-novel-optogenetics) [[2]](https://www.biospace.com/vedere-bio-ii-launches-with-77-million-series-a-financing-to-develop-next-generation-ocular-gene-therapies)

## Strategic Position

Vedere is a transaction-validated ophthalmic gene therapy story. The combination of acquisition and immediate successor financing suggests meaningful investor belief in the underlying science and team. [[1]](https://www.goodwinlaw.com/en/news-and-events/news/2020/10/10_30-vedere-bio-a-novel-optogenetics) [[2]](https://www.biospace.com/vedere-bio-ii-launches-with-77-million-series-a-financing-to-develop-next-generation-ocular-gene-therapies)
