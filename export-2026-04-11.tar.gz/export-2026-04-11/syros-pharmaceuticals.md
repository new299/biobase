# Syros Pharmaceuticals

## Overview
Syros Pharmaceuticals was a clinical-stage biopharmaceutical company focused on gene control and transcriptional regulation in cancer and hematologic disease [[1]](https://www.businesswire.com/news/home/20250703508492/en/Tango-Therapeutics-Completes-Acquisition-of-Syros-Pharmaceuticals).

## Technology
Its programs centered on transcription control biology, with Tango later emphasizing SY-5609, a selective oral CDK7 inhibitor, as a key acquired asset [[1]](https://www.businesswire.com/news/home/20250703508492/en/Tango-Therapeutics-Completes-Acquisition-of-Syros-Pharmaceuticals).

## Investors
As a public company, Syros was financed through public markets. The reviewed source focused on the acquisition and post-bankruptcy process rather than named pre-acquisition holders [[1]](https://www.businesswire.com/news/home/20250703508492/en/Tango-Therapeutics-Completes-Acquisition-of-Syros-Pharmaceuticals).

## Acquisitions / Strategic Transactions
Tango Therapeutics completed its acquisition of Syros in July 2025 following Syros' Chapter 11 process [[1]](https://www.businesswire.com/news/home/20250703508492/en/Tango-Therapeutics-Completes-Acquisition-of-Syros-Pharmaceuticals).

## References
[[1]](https://www.businesswire.com/news/home/20250703508492/en/Tango-Therapeutics-Completes-Acquisition-of-Syros-Pharmaceuticals)
