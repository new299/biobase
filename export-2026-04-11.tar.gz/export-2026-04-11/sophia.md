# SOPHiA GENETICS

## Overview

SOPHiA GENETICS is an AI-driven precision medicine company focused on turning multimodal health data into clinical insights for oncology and rare disease care. The company says it was founded in 2011 and now supports a global network of healthcare institutions using its SOPHiA DDM platform. [[1]](https://www.sophiagenetics.com/about-us/) [[2]](https://www.sophiagenetics.com/)

## Technology

Its core platform is SOPHiA DDM, a cloud-native analytics system for genomic and other health data. The company positions the platform as enabling local clinical decision-making with AI-driven interpretation across oncology, inherited disorders, and liquid biopsy use cases. [[1]](https://www.sophiagenetics.com/about-us/) [[2]](https://www.sophiagenetics.com/)

## Investors And Financing

SOPHiA closed a $234 million IPO in July 2021 and also completed a $20 million private placement at the same time. As a public company, more recent financing visibility comes primarily through its operating results rather than new venture rounds. [[3]](https://www.sophiagenetics.com/news/sophia-genetics-announces-closing-of-234-million-initial-public-offering-and-20-million-private-placement/) [[4]](https://www.sophiagenetics.com/news/sophia-genetics-reports-fourth-quarter-and-full-year-2025-results/)

## Partnerships And Strategic Development

Liquid biopsy has become a visible strategic area for SOPHiA. In September 2024, it expanded its collaboration with AstraZeneca to deploy the MSK-ACCESS liquid biopsy test globally, and in April 2025 the companies expanded that effort to 30 clinical institutions worldwide. [[5]](https://www.sophiagenetics.com/news/astrazeneca-collaborate-expand-global-access-liquid-biopsy-testing/) [[6]](https://www.sophiagenetics.com/news/sophia-genetics-announces-expanded-collaboration-with-astrazeneca-to-accelerate-liquid-biopsy-testing-globally-from-aacr/)
