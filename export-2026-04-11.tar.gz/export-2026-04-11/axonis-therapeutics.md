# Axonis Therapeutics

## Overview
Axonis Therapeutics is a neuro-focused biotechnology company developing medicines targeting KCC2 for neurological disorders.[[1]](https://axonis.us/)[[2]](https://axonis.us/axonis-therapeutics-announces-115-million-series-a-financing/) Its lead candidate is AXN-027.[[2]](https://axonis.us/axonis-therapeutics-announces-115-million-series-a-financing/)

## Technology
Axonis says its discovery engine is centered on KCC2, a critical mediator of inhibitory neurotransmission in the brain.[[1]](https://axonis.us/) The company positions AXN-027 as a first-in-class oral KCC2 potentiator for epilepsy, pain, and other CNS disorders.[[2]](https://axonis.us/axonis-therapeutics-announces-115-million-series-a-financing/)[[3]](https://www.businesswire.com/news/home/20210714005575/en/AXONIS-Therapeutics-Announces-%245-Million-in-Funding-Provides-Update-on-Progress-Advancing-Novel-Therapeutics-for-Neurological-Disorders)

## Investors
In July 2021, Axonis announced an additional $5 million financing led by Alexandria Venture Investments, with participation from R3 Bio, BoxOne Ventures, Civilization Ventures, the Christopher & Dana Reeve Foundation, Spinal Research, and current investors.[[3]](https://www.businesswire.com/news/home/20210714005575/en/AXONIS-Therapeutics-Announces-%245-Million-in-Funding-Provides-Update-on-Progress-Advancing-Novel-Therapeutics-for-Neurological-Disorders) In October 2024, it announced an oversubscribed $115 million Series A co-led by Cormorant Asset Management and venBio Partners, with participation from Sofinnova Investments, MRL Ventures Fund, Perceptive Advisors, Lumira Ventures, Solasta Ventures, and others.[[2]](https://axonis.us/axonis-therapeutics-announces-115-million-series-a-financing/)

## Acquisitions and Corporate Activity
No acquisition involving Axonis Therapeutics was identified in the reviewed public sources. The public record centers on financing and clinical advancement of KCC2-targeted neuromedicines.[[1]](https://axonis.us/)[[2]](https://axonis.us/axonis-therapeutics-announces-115-million-series-a-financing/)
