# Caplin Point Laboratories

## Overview
Caplin Point Laboratories is an India-based, publicly listed pharmaceutical company with a strong presence in Latin America, Francophone Africa, and selected regulated markets including the US and EU.[[1]](https://www.caplinpoint.net/)[[2]](https://model1.caplinpoint.net/index.php/about-us/)[[3]](https://www.caplinpoint.net/index.php/shareholder-information/)

## Technology
The company describes itself as fully integrated and active across manufacturing, export, sterile injectables, ophthalmics, and product development. It says it has filed multiple ANDAs and received approvals for several US products through Caplin Steriles.[[1]](https://www.caplinpoint.net/)[[2]](https://model1.caplinpoint.net/index.php/about-us/)

## Investors
Caplin Point is a public company rather than a venture-backed startup. It says it was founded in 1990 and listed after an IPO in the mid-1990s; current investor-facing materials are organized through its NSE and BSE listings.[[2]](https://model1.caplinpoint.net/index.php/about-us/)[[3]](https://www.caplinpoint.net/index.php/shareholder-information/)[[4]](https://www.caplinpoint.net/index.php/investors-2/)

## Acquisitions / Other
I did not identify a clearly documented transformative acquisition in the reviewed source set. Current public positioning is centered more on organic expansion, filings, and sterile manufacturing scale-up.[[1]](https://www.caplinpoint.net/)[[5]](https://m.economictimes.com/markets/expert-view/caplin-point-bets-big-on-us-complex-injectables-to-drive-next-growth-phase-coo/articleshow/126003206.cms)
