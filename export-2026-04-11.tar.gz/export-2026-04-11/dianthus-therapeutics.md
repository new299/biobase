# Dianthus Therapeutics — Research Notes

## Overview

Dianthus Therapeutics, Inc. (NASDAQ: DNTH) is a New York, NY-based clinical-stage biopharmaceutical company developing complement-targeting antibody therapies for severe autoimmune and rare diseases. Launched 2022 with $100M. Lead program claseprubart (DNTH103): potent, selective anti-C1s antibody with extended half-life for SC dosing — Phase 2 positive in generalized myasthenia gravis (gMG); Phase 3 CAPTIVATE trial in CIDP with early GO decision (Mar 2026). Total raised: ~$1B+. [[1]](https://www.prnewswire.com/news-releases/dianthus-therapeutics-launches-with-100m-to-develop-selective-antibody-complement-therapeutics-to-treat-severe-and-rare-autoimmune-diseases-301537293.html) [[2]](https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-230-million-private-placement)

---

## Technology

- **Claseprubart (DNTH103)**: Engineered monoclonal antibody selectively inhibiting only the active form of C1s (classical complement pathway). Extended half-life (half-life extension engineering); self-administered subcutaneous injection. Phase 2 MaGic trial in gMG: positive data. Phase 3 CAPTIVATE trial in CIDP: early interim GO decision March 2026. [[3]](https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-positive-data-claseprubart) [[4]](https://www.globenewswire.com/news-release/2026/03/09/3251679/0/en/Dianthus-Therapeutics-Announces-Early-GO-Decision-Following-Interim-Responder-Analysis-in-Phase-3-CAPTIVATE-Trial-of-Claseprubart-in-Chronic-Inflammatory-Demyelinating-Polyneuropat.html)
- **DNTH212**: Second clinical candidate — bifunctional inhibitor targeting Type I IFN suppression and B cell modulation for autoimmune diseases. [[2]](https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-230-million-private-placement)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Launch/Series A | 2022 | $100M | — |
| PIPE | Jan 2024 | $230M | — |
| Public offering | Sep 2025 | $251M | Public market |
| Public offering | 2025 | $288M | Public market |
| Public offering | 2025 | $400M+ | Public market |

Total raised: ~$1B+. [[1]](https://www.prnewswire.com/news-releases/dianthus-therapeutics-launches-with-100m-to-develop-selective-antibody-complement-therapeutics-to-treat-severe-and-rare-autoimmune-diseases-301537293.html) [[5]](https://www.stocktitan.net/news/DNTH/dianthus-therapeutics-inc-announces-pricing-of-upsized-251-million-yktitzaf8wrm.html)

---

## References

1. PRNewswire — Dianthus launch with $100M (2022): [https://www.prnewswire.com/news-releases/dianthus-therapeutics-launches-with-100m-to-develop-selective-antibody-complement-therapeutics-to-treat-severe-and-rare-autoimmune-diseases-301537293.html](https://www.prnewswire.com/news-releases/dianthus-therapeutics-launches-with-100m-to-develop-selective-antibody-complement-therapeutics-to-treat-severe-and-rare-autoimmune-diseases-301537293.html)
2. Dianthus IR — $230M PIPE (Jan 2024): [https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-230-million-private-placement](https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-230-million-private-placement)
3. Dianthus IR — Claseprubart Phase 2 MaGic positive data: [https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-positive-data-claseprubart](https://investor.dianthustx.com/news-releases/news-release-details/dianthus-therapeutics-announces-positive-data-claseprubart)
4. GlobeNewsWire — Phase 3 CAPTIVATE early GO decision in CIDP (Mar 2026): [https://www.globenewswire.com/news-release/2026/03/09/3251679/0/en/Dianthus-Therapeutics-Announces-Early-GO-Decision-Following-Interim-Responder-Analysis-in-Phase-3-CAPTIVATE-Trial-of-Claseprubart-in-Chronic-Inflammatory-Demyelinating-Polyneuropat.html](https://www.globenewswire.com/news-release/2026/03/09/3251679/0/en/Dianthus-Therapeutics-Announces-Early-GO-Decision-Following-Interim-Responder-Analysis-in-Phase-3-CAPTIVATE-Trial-of-Claseprubart-in-Chronic-Inflammatory-Demyelinating-Polyneuropat.html)
5. StockTitan — $251M upsized public offering (Sep 2025): [https://www.stocktitan.net/news/DNTH/dianthus-therapeutics-inc-announces-pricing-of-upsized-251-million-yktitzaf8wrm.html](https://www.stocktitan.net/news/DNTH/dianthus-therapeutics-inc-announces-pricing-of-upsized-251-million-yktitzaf8wrm.html)
