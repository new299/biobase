# Geltor — Research Notes

## Overview

Geltor is a San Leandro, CA-based biodesign company founded in 2015, using precision fermentation and AI-driven protein engineering to create designer animal-free structural proteins (collagens, elastins, gelatins) for beauty, nutraceuticals, and food/beverage industries. The company's platform has been scaled up 100× and has produced hundreds of novel proteins. Total raised: ~$137M ($91.3M Series B 2021 + earlier rounds). Key investors: CPT Capital (lead Series B), Cultivian Sandbox, SOSV, iSelect Fund, GELITA, ADM, Blue Horizon Ventures, RIT Capital Partners. [[1]](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/)

---

## Technology & Products

- **Precision Fermentation Platform**: Fermentation-based production of designer animal-free proteins using yeast and microbial hosts; AI-driven protein engineering to optimize sequences for target properties (biocompatibility, functionality, stability). [[1]](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/)
- **HumaColl21® (human-identical type XXI collagen)**: Animal-free recombinant collagen for cosmetics and skin care applications. [[1]](https="https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/")
- **Collume® (recombinant marine collagen)**: Marine-source collagen alternative for nutraceuticals. [[1]](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/)
- **Elastapure (recombinant elastin)**: Plant-based elastin ingredient for personal care. [[1]](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/)
- **Additional round (2024+)**: Equity financing to support animal-free beauty ingredients, bringing total to $137M. [[2]](https://cultivated-x.com/investments-finance/geltor-closes-equity-financing-round-animal-free-beauty-ingredients/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Series A | 2015–2019 | ~$25.7M | Cultivian Sandbox, SOSV, iSelect Fund |
| Series B | 2021 | $91.3M | CPT Capital (lead), iSelect Fund, Cultivian Sandbox, SOSV, GELITA, ADM, Blue Horizon Ventures, RIT Capital Partners, Humboldt Fund, Pegasus Tech Ventures |
| Additional equity | 2024+ | ~$20M | Existing investors |

Total raised: ~$137M. [[1]](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/) [[2]](https://cultivated-x.com/investments-finance/geltor-closes-equity-financing-round-animal-free-beauty-ingredients/)

---

## References

1. Vegconomist — Geltor $91.3M Series B: [https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/](https://vegconomist.com/company-news/biodesign-geltor-receives-91-3m-series-b-funding/)
2. Cultivated X — Geltor additional equity financing: [https://cultivated-x.com/investments-finance/geltor-closes-equity-financing-round-animal-free-beauty-ingredients/](https://cultivated-x.com/investments-finance/geltor-closes-equity-financing-round-animal-free-beauty-ingredients/)
