# Jumpcode Genomics

## Overview

Jumpcode Genomics is a genomics tools company developing CRISPR-based depletion technology that removes abundant, uninformative nucleic acid sequences from sequencing libraries to improve sensitivity and lower sequencing cost.[[1]](https://www.jumpcodegenomics.com/company) [[2]](https://www.jumpcodegenomics.com/company/news/exits-stealth-mode)

## Technology

Jumpcode's core platform is CRISPRclean, a patented technology that depletes unwanted nucleic acid molecules from next-generation sequencing libraries.[[1]](https://www.jumpcodegenomics.com/company) [[2]](https://www.jumpcodegenomics.com/company/news/exits-stealth-mode) The company positions the technology across RNA-seq, infectious disease, oncology, and single-cell workflows.[[1]](https://www.jumpcodegenomics.com/company) [[3]](https://www.jumpcodegenomics.com/company/news/crisprclean-single-cell-rna-boost-kit-launches)

## Investors

In January 2021, Jumpcode announced a $21 million Series B co-led by Baird Capital and Arboretum Ventures with participation from existing investor LYZZ Capital.[[4]](https://www.jumpcodegenomics.com/company/news/series-b-funding) The company site also lists Arboretum Ventures and LYZZ Capital among board-linked investors.[[1]](https://www.jumpcodegenomics.com/company)

## Acquisitions and Strategic Transactions

No acquisition involving Jumpcode Genomics was identified in the reviewed sources. The company's strategic development has centered on commercialization of CRISPRclean and expansion into additional molecular workflows.[[4]](https://www.jumpcodegenomics.com/company/news/series-b-funding) [[3]](https://www.jumpcodegenomics.com/company/news/crisprclean-single-cell-rna-boost-kit-launches)
