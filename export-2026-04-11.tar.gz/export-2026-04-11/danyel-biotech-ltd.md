# Danyel Biotech Ltd

## Overview
Danyel Biotech is an Israeli life-science distribution and solutions company rather than a therapeutics developer. It supplies instruments, consumables, and laboratory technologies for research, diagnostics, and healthcare markets.[[1]](https://www.danyel.co.il/about-us/)[[2]](https://www.danyel.co.il/)

## Technology / Products
Its public materials emphasize molecular biology, genomics, cell biology, cell culture, protein purification and characterization, filtration, and bioprocess solutions delivered through supplier partnerships.[[1]](https://www.danyel.co.il/about-us/)[[2]](https://www.danyel.co.il/)

## Investors / Ownership
Danyel says it is part of the Gamida for Life Group. I did not identify a public venture financing history for Danyel Biotech itself in the reviewed source set.[[1]](https://www.danyel.co.il/about-us/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. This note is intentionally framed as a life-science distribution business, because that is what the reviewed public identity supports.[[1]](https://www.danyel.co.il/about-us/)
