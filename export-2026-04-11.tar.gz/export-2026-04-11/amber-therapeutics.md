# Amber Therapeutics

## Overview
Amber Therapeutics is a medical technology company developing adaptive neuromodulation therapies for functional disorders of the peripheral nervous system, especially mixed urinary incontinence.[[1]](https://www.amber-tx.com/)[[2]](https://www.globenewswire.com/news-release/2026/02/24/3243195/0/en/Amber-Therapeutics-strengthens-its-Board-and-Leadership-team-opens-UK-headquarters-and-expands-EU-feasibility-study-for-mixed-urinary-incontinence-increasing-momentum-towards-a-piv.html) It is a medtech company rather than a therapeutics developer.

## Technology
Amber’s core technology is Amber-UI, a fully implantable adaptive pudendal neuromodulation therapy built on the Picostim system for mixed urinary incontinence.[[1]](https://www.amber-tx.com/)[[2]](https://www.globenewswire.com/news-release/2026/02/24/3243195/0/en/Amber-Therapeutics-strengthens-its-Board-and-Leadership-team-opens-UK-headquarters-and-expands-EU-feasibility-study-for-mixed-urinary-incontinence-increasing-momentum-towards-a-piv.html)

## Investors
Amber’s website states that it closed a $100 million Series A in July 2024 led by NEA, with participation from new investors F-Prime Capital, Lightstone Ventures, and Intuitive Ventures alongside existing investors Oxford Science Enterprises and 8VC.[[1]](https://www.amber-tx.com/)[[3]](https://www.biospace.com/amber-therapeutics-closes-100-million-series-a-financing-to-advance-breakthrough-amber-ui-neuromodulation-therapy-for-mixed-urinary-incontinence-towards-us-fda-approval) The local F-Prime note is directly supported by those sources.[[1]](https://www.amber-tx.com/)

## Acquisitions and Corporate Activity
In September 2023, Amber announced the acquisition of Bioinduction Limited and its Picostim DyNeuMo platform, transforming the company into an integrated developer and manufacturer of intelligent closed-loop neuromodulation therapies.[[4]](https://www.globenewswire.com/news-release/2023/09/05/2736961/0/en/Amber-Tx-acquires-Bioinduction-Limited-and-its-Picostim-DyNeuMo-platform-on-which-Amber-s-closed-loop-neuromodulation-therapy-for-mixed-urinary-incontinence-is-being-developed.html)
