# Genuity Science — Research Notes

## Overview

Genuity Science (formerly WuXiNextCODE) was a Dublin, Ireland-based genomics company founded in 2013, operating a global genomics platform focused on discovery in CNS, cardiometabolic, and inflammatory diseases. The Irish government (via Irish Strategic Investment Fund / ISIF) invested €70M+ to help the company collect genomic data from 400,000 Irish citizens for medical research. Total raised: ~$515M. Key investors: Ireland Strategic Investment Fund (Series C lead), Sequoia Capital, Temasek, Yunfeng Capital, ARCH Venture Partners, Ally Bridge, Amgen Ventures. Genuity Science was acquired by HiberCell in August 2021, and ceased operations in March 2025. [[1]](https://genuitysci.com/about-us/) [[2]](https://www.irishtimes.com/business/2024/04/10/company-that-controls-irish-genomic-data-incurs-23m-loss-as-revenue-drops-again/)

---

## Technology

- **Global Genomics Platform**: End-to-end genomics expertise for population genomics, biobank creation, bioinformatics, and disease gene discovery — particularly large-scale cohort projects combining WGS/WES with clinical data for disease association studies. [[1]](https://genuitysci.com/about-us/)
- **Ireland 400K Genomics Project**: Collaboration with Irish government to collect and analyze DNA from 400,000 Irish participants — one of the world's largest population genomics initiatives. [[2]](https://www.irishtimes.com/business/2024/04/10/company-that-controls-irish-genomic-data-incurs-23m-loss-as-revenue-drops-again/)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded (as WuXiNextCODE) | 2013 | Dublin, Ireland (WuXi AppTec spinout) |
| Series A–B | 2013–2017 | ~$315M |
| Series C | Nov 2018 | $200M — Ireland Strategic Investment Fund (lead), Sequoia, Temasek, ARCH Venture Partners, Ally Bridge, Amgen Ventures |
| Acquired by HiberCell | Aug 2021 | — |
| Ceased operations | Mar 2025 | — |

Total raised: ~$515M. [[1]](https://genuitysci.com/about-us/)

**ARCH Venture Partners Investment**

---

## References

1. Genuity Science — About Us: [https://genuitysci.com/about-us/](https://genuitysci.com/about-us/)
2. Irish Times — Genuity Science $23M loss, revenue drops (Apr 2024): [https://www.irishtimes.com/business/2024/04/10/company-that-controls-irish-genomic-data-incurs-23m-loss-as-revenue-drops-again/](https://www.irishtimes.com/business/2024/04/10/company-that-controls-irish-genomic-data-incurs-23m-loss-as-revenue-drops-again/)
