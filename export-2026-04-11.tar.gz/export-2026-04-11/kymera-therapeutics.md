# Kymera Therapeutics

## Overview

Kymera Therapeutics is a clinical-stage biotechnology company advancing oral small-molecule medicines based on targeted protein degradation (`TPD`).[[1]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-pricing-upsized-602-million-public/) The company says it is focused on immunological diseases while also advancing oncology programs.[[1]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-pricing-upsized-602-million-public/)

## Technology

Kymera's technology platform uses TPD to harness the body's protein recycling machinery and eliminate disease-driving proteins that may be hard to address with conventional inhibitors.[[2]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-series-advance-novel-therapeutic/) Company materials describe the platform as capable of producing oral degraders for difficult or previously inaccessible targets.[[3]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-102-million-series-c-financing)

## Investors

Kymera launched with a $30 million Series A led by Atlas Venture with Lilly Ventures and Amgen Ventures.[[2]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-series-advance-novel-therapeutic/) It later raised a $65 million Series B and a $102 million Series C before becoming public.[[4]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-65-million-series-b-financing) [[3]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-102-million-series-c-financing) As a public company, it has continued to raise large follow-on rounds, including a $275 million public offering in January 2024, a $225 million public offering in August 2024, and a $602 million public offering in December 2025.[[5]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-closing-upsized-275-million-public) [[6]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-closing-upsized-225-million-public/) [[1]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-pricing-upsized-602-million-public/)

## Acquisitions and Strategic Transactions

No acquisition involving Kymera Therapeutics was identified in the reviewed sources. Its strategic story is dominated by financing and pipeline development rather than M&A.[[1]](https://investors.kymeratx.com/news-releases/news-release-details/kymera-therapeutics-announces-pricing-upsized-602-million-public/)
