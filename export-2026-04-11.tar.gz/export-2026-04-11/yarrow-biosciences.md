# Yarrow Biosciences

## Overview

Yarrow Bioscience is a U.S.-based biotechnology company focused on autoimmune and endocrinology disorders. Public disclosures in December 2025 identify its lead program as YB-101 (also called GS-098), a potentially first-in-class anti-TSHR antibody for Graves' disease and thyroid eye disease.[[1]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-and-yarrow-bioscience-announce-merger-agreement/) [[2]](https://www.genscigroup.com/en/news/media/183.html)

## Technology and Pipeline

Yarrow's most visible program is YB-101, a clinical-stage antibody intended to block thyroid-stimulating hormone receptor signaling in autoimmune thyroid disease.[[1]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-and-yarrow-bioscience-announce-merger-agreement/) Earlier in its history, Yarrow Biotechnology was described by ProQR as an RTW-incubated company focused on ASO-based therapeutics for disorders with high unmet need, showing that the company's original strategy included RNA-based drug development before the later autoimmune-thyroid asset focus became public.[[3]](https://www.proqr.com/press-releases/proqr-therapeutics-and-yarrow-biotechnology-an-rtw-investments-lp-incubated-company-announce-exclusive-worldwide-license-and-discovery-collaboration-for-undisclosed-target)

## Investors

Yarrow was created with backing from RTW Investments.[[3]](https://www.proqr.com/press-releases/proqr-therapeutics-and-yarrow-biotechnology-an-rtw-investments-lp-incubated-company-announce-exclusive-worldwide-license-and-discovery-collaboration-for-undisclosed-target) In connection with its announced merger with VYNE Therapeutics on December 17, 2025, a syndicate led by RTW Investments, with participation from OrbiMed, Janus Henderson Investors, venBio Partners, Logos Capital, LifeSci Venture Partners, and Perceptive Advisors, committed approximately $200 million in pre-closing financings.[[1]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-and-yarrow-bioscience-announce-merger-agreement/)

## Acquisitions and Strategic Transactions

Yarrow signed an exclusive global ex-China license with GenSci for GS-098/YB-101 in December 2025. GenSci disclosed deal economics of $70 million upfront, a $50 million near-term development milestone, and total potential value up to $1.365 billion plus royalties.[[2]](https://www.genscigroup.com/en/news/media/183.html) Two days later, VYNE Therapeutics and Yarrow announced a merger agreement under which the combined company planned to operate as Yarrow Bioscience and focus on YB-101.[[1]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-and-yarrow-bioscience-announce-merger-agreement/)
