# Karius

## Overview

Karius is a genomic diagnostics company focused on infectious disease detection from blood using next-generation sequencing and computational analysis.[[1]](https://kariusdx.com/resources/press-releases/karius-raises-usd100m-co-led-by-khosla-ventures-5am-ventures-and-gilde-healthcare-to-expand-access-to-advanced-genomic-diagnostics-in-infectious-disease-addressing-antimicrobial-resistance-crisis) The company says its Karius Test can detect more than 1,000 pathogens from a single blood draw.[[1]](https://kariusdx.com/resources/press-releases/karius-raises-usd100m-co-led-by-khosla-ventures-5am-ventures-and-gilde-healthcare-to-expand-access-to-advanced-genomic-diagnostics-in-infectious-disease-addressing-antimicrobial-resistance-crisis)

## Technology

Karius uses microbial cell-free DNA sequencing plus bioinformatics and AI-driven interpretation to identify pathogens non-invasively.[[1]](https://kariusdx.com/resources/press-releases/karius-raises-usd100m-co-led-by-khosla-ventures-5am-ventures-and-gilde-healthcare-to-expand-access-to-advanced-genomic-diagnostics-in-infectious-disease-addressing-antimicrobial-resistance-crisis) In August 2024, the company announced a BARDA-backed effort to extend the platform from DNA pathogen detection to RNA pathogen detection as well.[[2]](https://kariusdx.com/resources/press-releases/karius-secures-barda-contract-to-expand-agnostic-detection-of-pathogens)

## Investors

In May 2024, Karius announced a $100 million Series C co-led by Khosla Ventures, 5AM Ventures, and Gilde Healthcare, with participation from Seventure Partners and existing investors including SoftBank Vision Fund 2, General Catalyst, HBM Healthcare Investments, Blue Water Life Sciences, Innovation Endeavors, and Waycross Ventures.[[1]](https://kariusdx.com/resources/press-releases/karius-raises-usd100m-co-led-by-khosla-ventures-5am-ventures-and-gilde-healthcare-to-expand-access-to-advanced-genomic-diagnostics-in-infectious-disease-addressing-antimicrobial-resistance-crisis) Axios separately reported that Karius had raised $165 million in 2020 led by SoftBank Vision Fund 2.[[3]](https://www.axios.com/2020/02/24/blood-test-karius-funding-softbank-infections)

## Acquisitions and Strategic Transactions

No acquisition involving Karius was identified in the reviewed sources. Its strategic milestones in the current public record are financing, hospital adoption, and expansion of the underlying pathogen-detection platform.[[1]](https://kariusdx.com/resources/press-releases/karius-raises-usd100m-co-led-by-khosla-ventures-5am-ventures-and-gilde-healthcare-to-expand-access-to-advanced-genomic-diagnostics-in-infectious-disease-addressing-antimicrobial-resistance-crisis) [[2]](https://kariusdx.com/resources/press-releases/karius-secures-barda-contract-to-expand-agnostic-detection-of-pathogens)
