# Interline Therapeutics — Research Notes

## Overview

Interline Therapeutics was a South San Francisco, CA-based biotechnology company founded in 2020, incubated by Foresite Labs, developing a precision medicine platform to systematically map and modulate protein communities — using genomics, proteomics, structural biology, and computational chemistry to understand dysfunctional protein-protein interaction networks as drivers of disease. Interline launched with $92M and was backed by ARCH Venture Partners and Foresite Capital; the company is no longer active. **ARCH Venture Partners Investment.** [[1]](https://www.businesswire.com/news/home/20210513005154/en/Interline-Therapeutics-Launches-With-$92-Million-to-Map-and-Correct-Dysfunctional-Protein-Communities) [[2]](https://www.crunchbase.com/organization/interline-therapeutics)

---

## Technology & Products

- **Protein Community Mapping Platform**: Integration of genomics, proteomics, structural biology, and computational chemistry to identify and therapeutically target disease-driving protein community dysfunction; six preclinical therapeutic programs at launch in undisclosed disease areas. [[1]](https://www.businesswire.com/news/home/20210513005154/en/Interline-Therapeutics-Launches-With-$92-Million-to-Map-and-Correct-Dysfunctional-Protein-Communities)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | May 2021 | $92M | **ARCH Venture Partners Investment** (co-lead), Foresite Capital (co-lead/incubator) |
| Total | — | $92M | — |

[[2]](https://www.crunchbase.com/organization/interline-therapeutics)

**Note**: Interline Therapeutics is no longer active. [[2]](https://www.crunchbase.com/organization/interline-therapeutics)

---

## References

1. Business Wire — Interline Therapeutics launch: [https://www.businesswire.com/news/home/20210513005154/en/Interline-Therapeutics-Launches-With-$92-Million-to-Map-and-Correct-Dysfunctional-Protein-Communities](https://www.businesswire.com/news/home/20210513005154/en/Interline-Therapeutics-Launches-With-$92-Million-to-Map-and-Correct-Dysfunctional-Protein-Communities)
2. Crunchbase — Interline Therapeutics: [https://www.crunchbase.com/organization/interline-therapeutics](https://www.crunchbase.com/organization/interline-therapeutics)
