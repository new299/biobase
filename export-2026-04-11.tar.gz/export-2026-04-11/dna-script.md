# DNA Script — Research Notes

## Overview

DNA Script is a Paris, France-based biotech company (with offices in South San Francisco) founded in 2014. Developed the first commercial enzymatic DNA synthesis (EDS) platform using terminal deoxynucleotidyl transferase (TdT) — enabling faster, chemical-free, benchtop DNA printing without phosphoramidite chemistry. Commercial product: SYNTAX System. Total raised: ~$365M ($165M Series C tranche 1 + $200M Series C tranche 2). [[1]](https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/) [[2]](https://www.genomeweb.com/sequencing/dna-script-nabs-200m-second-tranche-series-c-financing)

---

## Technology

- **Enzymatic DNA Synthesis (EDS)**: Proprietary TdT enzyme-based DNA synthesis that adds nucleotides without templates — enabling DNA printing free of toxic chemicals, shorter synthesis cycles, and novel modifications difficult to incorporate via phosphoramidite chemistry. [[1]](https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/)
- **SYNTAX System**: Commercial benchtop DNA printer leveraging EDS technology. Targeted at synthetic biology, therapeutics development, and genomics research. [[1]](https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/)
- **NIH NHGRI Grant**: $2.2M NIH National Human Genome Research Institute grant to develop next-generation EDS printers. [[3]](https://www.biospace.com/dna-script-to-develop-next-generation-of-enzymatic-dna-synthesis-printers-with-2-2-million-grant-award-from-the-national-human-genome-research-institute-of-the-nih)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series B | Pre-2022 | $89M | Various |
| Series C (tranche 1) | ~2022 | $165M | Coatue Management (lead), Catalio Capital Management |
| Series C (tranche 2) | ~2023 | $200M | — |

Total raised: ~$315M+ ($365M total Series C + prior). [[1]](https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/) [[2]](https://www.genomeweb.com/sequencing/dna-script-nabs-200m-second-tranche-series-c-financing)

---

## References

1. DNA Script — $165M Series C tranche 1 announcement: [https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/](https://www.dnascript.com/press-releases/dna-script-raises-165m-in-oversubscribed-series-c-financing-to-accelerate-commercialization-of-enzymatic-dna-printing-platform/)
2. GenomeWeb — DNA Script $200M Series C tranche 2: [https://www.genomeweb.com/sequencing/dna-script-nabs-200m-second-tranche-series-c-financing](https://www.genomeweb.com/sequencing/dna-script-nabs-200m-second-tranche-series-c-financing)
3. BioSpace — DNA Script NIH NHGRI $2.2M grant: [https://www.biospace.com/dna-script-to-develop-next-generation-of-enzymatic-dna-synthesis-printers-with-2-2-million-grant-award-from-the-national-human-genome-research-institute-of-the-nih](https://www.biospace.com/dna-script-to-develop-next-generation-of-enzymatic-dna-synthesis-printers-with-2-2-million-grant-award-from-the-national-human-genome-research-institute-of-the-nih)
