# SymphoRNA

## Overview
SymphoRNA is an RNA medicines company focused on multi-target therapeutics for complex diseases [[1]](https://www.symphorna.com/) [[2]](https://www.symphorna.com/our-story).

## Technology
The company says its platform combines a polysaccharide-based RNA delivery system with the ability to deliver multiple RNA cargos, including mRNA and siRNA, with high lung targeting and room-temperature stability [[1]](https://www.symphorna.com/) [[2]](https://www.symphorna.com/our-story).

## Investors
SymphoRNA's founding story says the underlying team previously raised $50 million for Uncommon Bio from investors including Sam Altman, Max Altman, Balderton, and Lowercarbon before pivoting the platform into medicine [[2]](https://www.symphorna.com/our-story). I did not locate a separate public financing announcement for SymphoRNA itself during this pass.

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The main strategic development visible publicly is the transition from the cultivated-meat business of Uncommon Bio to the current RNA-medicines platform [[2]](https://www.symphorna.com/our-story).

## References
[[1]](https://www.symphorna.com/)
[[2]](https://www.symphorna.com/our-story)
