# Qitan Technology

## Overview

Qitan Technology is a China-based sequencing company developing nanopore-based genome sequencing systems. Company-profile sources describe it as a developer of single-molecule genome sequencing technology founded in 2016 and headquartered in Chengdu [[1]](https://mindmaps.femtech.health/firms/33239) [[2]](https://www.cbinsights.com/company/qitan-technology).

## Technology

Profile sources say Qitan uses nanopore sequencing to read single nucleic-acid molecules with long reads, real-time output, and direct detection of nucleic-acid modifications [[1]](https://mindmaps.femtech.health/firms/33239). In September 2025, the company unveiled the QPinnacle2 high-throughput nanopore gene sequencer together with its O2 sequencing biochemical system [[3]](https://www.vcbeathealth.com/article/1821).

## Investors

A January 2023 BioWorld report said Qitan raised about $104 million in a Series C round led by Meituan to further develop its nanopore sequencer program [[4]](https://www.bioworld.com/articles/693456-qitan-nets-104-million-to-develop-nanopore-sequencer). Other profile sources list investors such as Empower Investment, Qmangel Investment Partnership, Tsinghua Technology Transfer Fund, and Yahui Precision Medicine Fund [[1]](https://mindmaps.femtech.health/firms/33239).

## Acquisitions / Strategic Transactions

The major strategic event identified in the reviewed sources is the 2025 launch of QPinnacle2, which marked a product-scale milestone for Qitan's domestic nanopore sequencing platform [[3]](https://www.vcbeathealth.com/article/1821).

## References

[[1]](https://mindmaps.femtech.health/firms/33239)
[[2]](https://www.cbinsights.com/company/qitan-technology)
[[3]](https://www.vcbeathealth.com/article/1821)
[[4]](https://www.bioworld.com/articles/693456-qitan-nets-104-million-to-develop-nanopore-sequencer)

## ASeq Posts

- [Qitan Pore Patents](https://aseq.substack.com/p/qitan-pore-patents)
- [A Qitan Technology Nanopore Data](https://aseq.substack.com/p/a-qitan-technology-nanopore-data)
- [More Thoughts On Qitan Technology](https://aseq.substack.com/p/more-thoughts-on-qitan-technology)
- [Qitan Technology](https://aseq.substack.com/p/qitan-technology)
- [P2 Solo Alternatives But Probably](https://aseq.substack.com/p/p2-solo-alternatives-but-probably)
