# Civitas Therapeutics

## Overview
Civitas Therapeutics was a privately held biopharmaceutical company developing inhaled therapeutics using its ARCUS pulmonary delivery platform, with a lead Parkinson’s disease program, CVT-301.[[1]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-20-million-series-a-financing)[[2]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-38-million-financing)

## Technology
Its lead asset, CVT-301, was an inhaled levodopa formulation for OFF episodes in Parkinson’s disease. Civitas positioned ARCUS as a pulmonary delivery technology capable of precise dry-powder delivery across varying inhalation flow rates.[[2]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-38-million-financing)[[3]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-55-million-series-c-financing)

## Investors
Civitas raised a $20 million Series A in 2011 from Longitude Capital and Canaan Partners, a $38 million Series B in 2013 led by Bay City Capital with RA Capital participation, and a $55 million Series C in 2014 with new investors including Adage, OrbiMed, Partner Fund, Rock Springs, and Sofinnova.[[1]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-20-million-series-a-financing)[[2]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-38-million-financing)[[3]](https://www.fiercebiotech.com/biotech/civitas-therapeutics-secures-55-million-series-c-financing)

## Acquisitions / Other
Acorda Therapeutics announced in September 2014 that it would acquire Civitas for $525 million in cash, gaining rights to CVT-301, ARCUS, and the company’s manufacturing facility.[[4]](https://www.fiercebiotech.com/biotech/acorda-therapeutics-to-acquire-civitas-therapeutics)
