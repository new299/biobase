# CASPR Biotech

## Overview
CASPR Biotech was an IndieBio and SOSV-backed diagnostics company that developed CRISPR-based molecular testing technologies using novel Cas proteins discovered in extremophile organisms.[[1]](https://sosv.com/company/caspr-biotech/)

## Technology
SOSV says the company's core technical angle was the discovery of temperature-tolerant Cas proteins intended to make CRISPR diagnostics cheaper, faster, and more compatible with isothermal workflows used in infectious-disease testing.[[1]](https://sosv.com/company/caspr-biotech/)

## Investors
The clearest public investor signal is SOSV/IndieBio portfolio inclusion. Secondary company databases also list IndieBio as a backer, but the reviewed primary source set is thin beyond SOSV's own profile.[[1]](https://sosv.com/company/caspr-biotech/)[[2]](https://www.crunchbase.com/organization/caspr/financial_details)

## Acquisitions / Other
SOSV states that CASPR "has been acquired by a Fortune 100 company" and also notes that Amazon approached the team during the COVID-19 period to assist with employee testing. The reviewed public material did not clearly disclose the final acquirer by name, so that part should be treated as source-limited.[[1]](https://sosv.com/company/caspr-biotech/)
