# Rubius Therapeutics

## Overview
Rubius Therapeutics was a biotechnology company developing engineered red-cell therapeutics as off-the-shelf cellular medicines [[1]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-120-million-financing) [[2]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-100-million-financing).

## Technology
Its platform centered on genetically engineered, long-circulating Red-Cell Therapeutics designed to act as durable cellular drug factories [[1]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-120-million-financing) [[2]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-100-million-financing).

## Investors
Rubius raised $120 million in 2017 and a further $100 million crossover financing in 2018, with Flagship Pioneering identifying the company as part of its ecosystem [[1]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-120-million-financing) [[2]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-100-million-financing).

## Acquisitions / Strategic Transactions
In July 2018, Rubius signed an agreement to acquire a large manufacturing facility in Smithfield, Rhode Island to support production of Red Cell Therapeutics [[3]](https://www.globenewswire.com/news-release/2018/07/25/1541896/0/en/Rubius-Therapeutics-to-Acquire-Manufacturing-Facility-in-Smithfield-Rhode-Island-to-Produce-Red-Cell-Therapeutics.html).

## References
[[1]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-120-million-financing)
[[2]](https://www.flagshippioneering.com/news/press-release/rubius-therapeutics-closes-100-million-financing)
[[3]](https://www.globenewswire.com/news-release/2018/07/25/1541896/0/en/Rubius-Therapeutics-to-Acquire-Manufacturing-Facility-in-Smithfield-Rhode-Island-to-Produce-Red-Cell-Therapeutics.html)
