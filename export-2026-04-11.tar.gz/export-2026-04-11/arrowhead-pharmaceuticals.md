# Arrowhead Pharmaceuticals — Research Notes

## Overview

Arrowhead Pharmaceuticals (NASDAQ: ARWR) is a publicly traded biopharmaceutical company headquartered in Pasadena, CA. Develops RNA interference (RNAi) therapeutics using its proprietary TRiM™ (Targeted RNAi Molecule) platform for subcutaneous delivery. Has transitioned to a commercial-stage company with REDEMPLO® (plozasiran) approved for familial chylomicronemia syndrome (FCS) in 2024–2025. [[1]](https://en.wikipedia.org/wiki/Arrowhead_Pharmaceuticals)

---

## Technology

- **TRiM™ Platform**: Designs subcutaneous, chemically modified siRNA conjugates for liver and extrahepatic targets. Conjugate-based delivery (GalNAc for hepatic targets; other ligands for lung, muscle, CNS) avoids LNP formulation. [[2]](https://arrowheadpharma.com/pipeline/)
- **Approved**: **REDEMPLO® (plozasiran)** — siRNA targeting apoC-III for familial chylomicronemia syndrome (FCS). FDA approved. Also approved in Canada and China. [[3]](https://www.biopharmadive.com/news/arrowhead-fda-approve-redemplo-familial-chylomicronemia-syndrome-ionis/805694/)
- **Key pipeline programs**:
  - ARO-HBV (hepatitis B, Phase 3)
  - Zodasiran/ARO-ANG3 (ANGPTL3, cardiovascular, Phase 3)
  - ARO-INHBE + ARO-ALK7 (obesity/metabolic, clinical-stage)
  - ARO-ATXN2 (spinocerebellar ataxia type 2)
- **Novartis deal (2025)**: $200M upfront + up to $2.2B milestones for ARO-SNCA (alpha-synuclein, Parkinson's disease). [[4]](https://www.drugdiscoverytrends.com/novartis-bets-200m-upfront-on-arrowheads-parkinsons-rnai-total-value-up-to-2-2b/)
- **Sarepta deal (Nov 2024)**: Exclusive global licensing for multiple RNAi programs for rare muscle, CNS, and lung diseases. [[5]](https://investorrelations.sarepta.com/news-releases/news-release-details/sarepta-therapeutics-announces-global-licensing-and)

---

## Funding & Investors

Public company (NASDAQ: ARWR). Key strategic deals:

| Event | Date | Amount |
|-------|------|--------|
| Novartis partnership | 2025 | $200M upfront + up to $2.2B milestones |
| Sarepta partnership | Nov 2024 | Undisclosed upfront + milestones |

[[4]](https://www.drugdiscoverytrends.com/novartis-bets-200m-upfront-on-arrowheads-parkinsons-rnai-total-value-up-to-2-2b/)

---

## References

1. Wikipedia — Arrowhead Pharmaceuticals: [https://en.wikipedia.org/wiki/Arrowhead_Pharmaceuticals](https://en.wikipedia.org/wiki/Arrowhead_Pharmaceuticals)
2. Arrowhead — Pipeline: [https://arrowheadpharma.com/pipeline/](https://arrowheadpharma.com/pipeline/)
3. BioPharma Dive — REDEMPLO FDA approval: [https://www.biopharmadive.com/news/arrowhead-fda-approve-redemplo-familial-chylomicronemia-syndrome-ionis/805694/](https://www.biopharmadive.com/news/arrowhead-fda-approve-redemplo-familial-chylomicronemia-syndrome-ionis/805694/)
4. Drug Discovery Trends — Novartis deal: [https://www.drugdiscoverytrends.com/novartis-bets-200m-upfront-on-arrowheads-parkinsons-rnai-total-value-up-to-2-2b/](https://www.drugdiscoverytrends.com/novartis-bets-200m-upfront-on-arrowheads-parkinsons-rnai-total-value-up-to-2-2b/)
5. Sarepta — Arrowhead licensing deal: [https://investorrelations.sarepta.com/news-releases/news-release-details/sarepta-therapeutics-announces-global-licensing-and](https://investorrelations.sarepta.com/news-releases/news-release-details/sarepta-therapeutics-announces-global-licensing-and)
