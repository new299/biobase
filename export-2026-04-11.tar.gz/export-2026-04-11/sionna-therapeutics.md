# Sionna Therapeutics

## Overview
Sionna Therapeutics is a clinical-stage company developing medicines intended to normalize CFTR function for people with cystic fibrosis [[1]](https://investors.sionnatx.com/) [[2]](https://www.sionnatx.com/).

## Technology
Its pipeline centers on differentiated small molecules engineered to stabilize CFTR's nucleotide-binding domain 1 and complementary modulators designed to work synergistically in F508del cystic fibrosis [[1]](https://investors.sionnatx.com/) [[2]](https://www.sionnatx.com/).

## Investors
Sionna launched with a $111 million Series B in 2022 led by OrbiMed with participation from T. Rowe Price, QIA, RA Capital, TPG's The Rise Fund, Atlas Venture, and the Cystic Fibrosis Foundation [[3]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-launches-111-million-series-b-financing). Its 2025 quarterly report also confirms a strong post-IPO cash position [[4]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-reports-first-quarter-2025-financial-results/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The major strategic milestones were the launch financing and later IPO capital raise supporting clinical development [[3]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-launches-111-million-series-b-financing) [[4]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-reports-first-quarter-2025-financial-results/).

## References
[[1]](https://investors.sionnatx.com/)
[[2]](https://www.sionnatx.com/)
[[3]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-launches-111-million-series-b-financing)
[[4]](https://investors.sionnatx.com/news-releases/news-release-details/sionna-therapeutics-reports-first-quarter-2025-financial-results/)
