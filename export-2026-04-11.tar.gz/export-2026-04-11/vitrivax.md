# VitriVax

## Overview

VitriVax is a vaccine formulation technology company developing thermostable, single-shot vaccine and therapeutics delivery solutions. The company says its proprietary ALTA platform addresses major barriers to vaccine access by improving stability and delivery. [[1]](https://www.biospace.com/press-releases/vitrivax-raises-17-25-million-series-b-financing-to-advance-vaccine-formulation-platform)

## Technology

Its Atomic Layering Thermostable Antigen and Adjuvant, or ALTA, technology is positioned as a thermostable vaccine formulation platform that could reduce cold-chain dependence and enable more practical distribution and administration. Public financing coverage ties the company closely to scale-up, regulatory, and commercialization work around this platform. [[1]](https://www.biospace.com/press-releases/vitrivax-raises-17-25-million-series-b-financing-to-advance-vaccine-formulation-platform)

## Investors

In October 2025, VitriVax announced a $17.25 million Series B financing co-led by Adjuvant Capital and RA Capital Management. That is the clearest public financing event available in the accessible sources reviewed for this note. [[1]](https://www.biospace.com/press-releases/vitrivax-raises-17-25-million-series-b-financing-to-advance-vaccine-formulation-platform)

## Strategic Position

VitriVax appears to be an enabling-platform company for vaccine access and distribution rather than a traditional vaccine developer with a broad proprietary antigen pipeline. The available public materials point to formulation infrastructure as the core business. [[1]](https://www.biospace.com/press-releases/vitrivax-raises-17-25-million-series-b-financing-to-advance-vaccine-formulation-platform)
