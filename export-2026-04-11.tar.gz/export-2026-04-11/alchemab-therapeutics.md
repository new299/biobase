# Alchemab Therapeutics — Research Notes

## Overview

Alchemab Therapeutics is a clinical-stage antibody discovery company founded in 2020, headquartered in London, UK. Discovers therapeutic antibodies by mining the B-cell repertoires of "extreme agers" — individuals aged 90–105 who maintain exceptional health — to identify naturally occurring protective antibodies against neurodegeneration and other diseases. Total raised: ~$127M + $415M Eli Lilly licensing deal. [[1]](https://www.alchemab.com/news/alchemab-therapeutics-raises-60-million-series-a)

---

## Technology

- **Extreme Ager Platform**: Sequences and screens B-cell immunoglobulin repertoires from supercentenarians and healthy extreme-age individuals (90–105 years old) to identify antibodies naturally enriched in people resistant to age-related disease. These antibodies are hypothesized to have evolved protective functions against neurodegeneration and other aging diseases. [[2]](https://www.alchemab.com/science)
- **ATLX-1282**: Lead therapeutic antibody targeting a neurodegeneration-associated antigen for ALS (amyotrophic lateral sclerosis). Licensed to Eli Lilly in 2024 for up to $415M (upfront + milestones). [[3]](https://www.fiercebiotech.com/biotech/alchemab-eli-lilly-415m-als-antibody-deal)
- Additional preclinical programs in neurodegeneration and age-related disease.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2022 | £60M (~$82M) | RA Capital Management (lead), Evotec, Forbion, Parkwalk Advisors |
| Series A extension | 2023 | $32M | Existing investors |
| Lilly licensing deal | 2024 | Up to $415M (milestones) | Eli Lilly (licensee) |

Total equity raised: ~$114M. [[1]](https://www.alchemab.com/news/alchemab-therapeutics-raises-60-million-series-a) [[3]](https://www.fiercebiotech.com/biotech/alchemab-eli-lilly-415m-als-antibody-deal)

---

## References

1. Alchemab — Series A announcement: [https://www.alchemab.com/news/alchemab-therapeutics-raises-60-million-series-a](https://www.alchemab.com/news/alchemab-therapeutics-raises-60-million-series-a)
2. Alchemab — Science page: [https://www.alchemab.com/science](https://www.alchemab.com/science)
3. Fierce Biotech — Eli Lilly ALS deal: [https://www.fiercebiotech.com/biotech/alchemab-eli-lilly-415m-als-antibody-deal](https://www.fiercebiotech.com/biotech/alchemab-eli-lilly-415m-als-antibody-deal)
