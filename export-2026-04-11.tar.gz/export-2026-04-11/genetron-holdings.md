# Genetron Holdings — Research Notes

## Overview

Genetron Holdings Limited (NASDAQ: GTH), also known as Genetron Health, is a Beijing, China-based precision oncology genomics company founded in 2015 by CEO Sizhen Wang. The company specializes in cancer molecular profiling, early cancer screening, and in-vitro diagnostic products for the Chinese market, combining advanced molecular biology and data science for comprehensive cancer genomic services. The company raised ~$163M through NASDAQ IPO (GTH). Revenue ~$96.6M (trailing 12-month as of Dec 2022). [[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo) [[2]](https://pitchbook.com/profiles/company/166564-00)

---

## Technology & Products

- **Onco PanScan™**: Comprehensive genomic profiling (CGP) for solid tumors covering multiple cancer types; next-generation sequencing-based somatic variant detection. [[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)
- **8-Gene Lung Cancer Assay**: Validated liquid biopsy panel for lung cancer somatic mutation detection. [[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)
- **Genetron 3D Biochip + Genetron S5**: In-house IVD instruments enabling clinical lab testing. [[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)
- **Early Cancer Screening**: Liquid biopsy-based programs for early detection of cancers including colorectal and liver cancer. [[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2015 | Beijing, China |
| Pre-IPO rounds | 2015–2019 | Raised from Chinese VC/PE investors |
| IPO (NASDAQ: GTH) | ~2020 | ~$163M raise; valued ~$1.1B |
| Revenue TTM | Dec 2022 | ~$96.6M |

[[1]](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)

---

## References

1. Nasdaq — Genetron Holdings $163M IPO terms: [https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo](https://www.nasdaq.com/articles/chinese-cancer-diagnostics-provider-genetron-holdings-sets-terms-for-$163-million-us-ipo)
