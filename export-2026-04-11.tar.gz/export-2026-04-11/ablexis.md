# Ablexis

## Overview
Ablexis is a biotechnology platform company focused on human therapeutic antibody discovery through its AlivaMab Mouse transgenic mouse system.[[1]](https://www.ablexis.com/ablexis-targets-market-expansion-opportunities-for-alivamab-mouse-following-acquisition-by-deerfield-management-and-the-founding-of-alivamab-discovery-services/)[[2]](https://deerfield.com/companies/ablexis-llc) The company licenses this platform broadly to biopharmaceutical partners rather than operating as a conventional single-asset therapeutics developer.[[2]](https://deerfield.com/companies/ablexis-llc)

## Technology
Ablexis says AlivaMab Mouse is a next-generation transgenic mouse platform optimized for human therapeutic antibody discovery and development.[[1]](https://www.ablexis.com/ablexis-targets-market-expansion-opportunities-for-alivamab-mouse-following-acquisition-by-deerfield-management-and-the-founding-of-alivamab-discovery-services/) Deerfield similarly describes it as a non-exclusively licensed platform used by dozens of pharmaceutical and biotechnology companies.[[2]](https://deerfield.com/companies/ablexis-llc)

## Investors
The reviewed public sources identify Deerfield Management as the acquirer and long-term capital partner following Ablexis’ 2018 transaction.[[1]](https://www.ablexis.com/ablexis-targets-market-expansion-opportunities-for-alivamab-mouse-following-acquisition-by-deerfield-management-and-the-founding-of-alivamab-discovery-services/)[[2]](https://deerfield.com/companies/ablexis-llc) I did not identify a fuller historical financing syndicate during this pass.

## Acquisitions and Corporate Activity
In June 2018, Ablexis announced its acquisition by Deerfield Management and the simultaneous creation of AlivaMab Discovery Services, an independent CRO built around the AlivaMab platform.[[1]](https://www.ablexis.com/ablexis-targets-market-expansion-opportunities-for-alivamab-mouse-following-acquisition-by-deerfield-management-and-the-founding-of-alivamab-discovery-services/)
