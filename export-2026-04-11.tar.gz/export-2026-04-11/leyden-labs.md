# Leyden Labs

## Overview

Leyden Labs is a clinical-stage biotechnology company developing intranasal antibody-based products intended to protect against seasonal and pandemic respiratory viruses.[[1]](https://leydenlabs.com/) The company's lead program is PanFlu, an intranasal broadly protective influenza program.[[1]](https://leydenlabs.com/)

## Technology

Leyden's platform is its Mucosal Protection Platform, which uses broadly protective antibodies delivered intranasally to neutralize respiratory viruses at the portal of entry.[[2]](https://leydenlabs.com/20240006-news-item-leyden-labs-raises-70m-to-advance-its-intranasal-antibody-programs) The company says it holds an exclusive license to CR9114 for the PanFlu program and has reported preclinical and clinical data supporting the feasibility of this approach.[[3]](https://leydenlabs.com/20260001-news-item-leyden-labs-antibody-nasal-spray-influenza-study)

## Investors

Leyden raised a EUR40 million Series A in March 2021 led by GV with participation from F-Prime Capital, Casdin Capital, and Brook Byers.[[4]](https://leydenlabs.com/news-item-launch) It later announced that total 2021 financing reached about $200 million with a $140 million Series B led by Casdin Capital and GV, including SoftBank Vision Fund 2, Invus, and Bluebird Ventures.[[5]](https://leydenlabs.com/140m_seriesb_raise) In January 2025 it raised another $70 million led by ClavystBio and Polaris Partners, and in October 2025 it added a EUR30 million equity investment from the European Innovation Council Fund and Invest-NL.[[2]](https://leydenlabs.com/20240006-news-item-leyden-labs-raises-70m-to-advance-its-intranasal-antibody-programs) [[6]](https://leydenlabs.com/20250003-news-item-leyden-labs-secures-e30-million-from-european-innovation-council-fund-and-invest-nl)

## Acquisitions and Strategic Transactions

No acquisition involving Leyden Labs was identified in the reviewed sources. Its key strategic transactions have been financing rounds and a EUR20 million EIB/HERA-backed financing agreement in June 2025.[[7]](https://leydenlabs.com/20250002-news-item-leyden-labs-lands-e20-million-eib-investment-facilitated-by-hera)
