# Sylentis

## Overview
Sylentis is an RNAi therapeutics company within the PharmaMar group focused on novel drugs based on RNA interference technology [[1]](https://sylentis.com/about-sylentis/).

## Technology
The company says it has built a versatile RNAi drug discovery platform called SirFinder and is applying AI and RNA silencing expertise to ophthalmology and other indications [[1]](https://sylentis.com/about-sylentis/).

## Investors
Sylentis is part of the PharmaMar group rather than a standalone venture-backed startup in the reviewed public materials [[1]](https://sylentis.com/about-sylentis/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The public company materials instead emphasize in-house pipeline development within the PharmaMar structure [[1]](https://sylentis.com/about-sylentis/).

## References
[[1]](https://sylentis.com/about-sylentis/)
