# Ensemble Therapeutics — Research Notes

## Overview

Ensemble Therapeutics Corporation was a Cambridge, MA-based biotechnology company founded in 2004 by Harvard Professor David R. Liu, developing DNA-Programmed Chemistry (DPC)-based macrocycle drug discovery. The company was a pioneer in macrocyclic small molecules ("Ensemblins") targeting protein-protein interactions (PPIs). Funded by ARCH Venture Partners, Oxford Bioscience Partners, and Flagship Pioneering (~$30M total). Ceased operations ~2017; entered high-value partnerships with Boehringer Ingelheim, Genentech, Bristol-Myers Squibb, Alexion Pharmaceuticals, and Pfizer, and formed a global IL-17 macrocycle antagonist collaboration. [[1]](https://www.flagshippioneering.com/companies/ensemble-therapeutics)

---

## Technology

- **DNA-Programmed Chemistry (DPC)**: Proprietary platform using DNA-encoded chemical library technology to discover novel macrocyclic small molecules (Ensemblins) — designed to inhibit protein-protein interactions (PPIs) that are typically "undruggable" for conventional small molecules. Macrocycles have structural properties between small molecules and biologics, enabling PPI disruption. [[2]](https://www.fiercebiotech.com/biotech/ensemble-therapeutics-and-boehringer-ingelheim-initiate-collaboration-to-discover)
- **Oral Macrocyclic IL-17 Antagonists**: Strategic collaboration for development of oral, macrocyclic IL-17 antagonists as an alternative to injectable biologics for inflammatory diseases. [[3]](https://www.fiercebiotech.com/biotech/ensemble-therapeutics-forms-global-strategic-collaboration-for-development-of-oral)

---

## Funding & Corporate History

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A/B | ~2004–2012 | ~$30M | ARCH Venture Partners, Oxford Bioscience Partners, Flagship Pioneering |
| Operations ceased | ~2017 | — | — |

Total raised: ~$30M. [[4]](https://www.tracxn.com/d/companies/ensemble-therapeutics/__drW4Yf3EcEVF_NCkKRIz8P-fyEkAnTcPx6A1iFiJYuo)

---

## References

1. Flagship Pioneering — Ensemble Therapeutics portfolio: [https://www.flagshippioneering.com/companies/ensemble-therapeutics](https://www.flagshippioneering.com/companies/ensemble-therapeutics)
2. Fierce Biotech — Ensemble Therapeutics + Boehringer Ingelheim macrocycle collaboration: [https://www.fiercebiotech.com/biotech/ensemble-therapeutics-and-boehringer-ingelheim-initiate-collaboration-to-discover](https://www.fiercebiotech.com/biotech/ensemble-therapeutics-and-boehringer-ingelheim-initiate-collaboration-to-discover)
3. Fierce Biotech — Ensemble oral macrocyclic IL-17 antagonist collaboration: [https://www.fiercebiotech.com/biotech/ensemble-therapeutics-forms-global-strategic-collaboration-for-development-of-oral](https://www.fiercebiotech.com/biotech/ensemble-therapeutics-forms-global-strategic-collaboration-for-development-of-oral)
4. Tracxn — Ensemble Therapeutics profile: [https://tracxn.com/d/companies/ensemble-therapeutics/__drW4Yf3EcEVF_NCkKRIz8P-fyEkAnTcPx6A1iFiJYuo](https://tracxn.com/d/companies/ensemble-therapeutics/__drW4Yf3EcEVF_NCkKRIz8P-fyEkAnTcPx6A1iFiJYuo)
