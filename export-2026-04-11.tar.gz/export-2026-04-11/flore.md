# Floré (Sun Genomics) — Research Notes

## Overview

Floré (also known as Sun Genomics or Floré by Sun Genomics) is a San Diego, CA-based microbiome consumer health company founded in 2016 by Sunny Jain. The company provides personalized synbiotics (prebiotics + probiotics combinations) based on whole-genome sequencing of individual gut microbiomes from at-home stool samples. Total raised: ~$21.1M over 6 rounds. Key investors: Pangaea Ventures, Plug and Play Tech Center, dsm-firmenich Ventures, Ki Tua Fund, IndieBio, Emerging Technology Partners, Ferter. [[1]](https://app.dealroom.co/companies/sun_genomics) [[2]](https://www.cbinsights.com/company/sun-genomics)

---

## Technology & Products

- **Gut Microbiome Analysis**: At-home stool collection kit sent to a CLIA-certified lab for whole-genome shotgun sequencing of the gut microflora — providing a comprehensive map of the patient's gut microbiome composition.
- **Custom Synbiotics**: Based on the WGS analysis, Floré formulates a personalized blend of prebiotics and probiotics (synbiotics) tailored to the individual's gut microbiome profile. Delivered as a once-daily capsule or powder.
- **Target Applications**: Gut health optimization, IBS management, immune support, and general microbiome wellness.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed + Series A | ~2016–2020 | ~$21.1M | Pangaea Ventures, Plug and Play, dsm-firmenich Ventures, Ki Tua Fund, IndieBio, Emerging Technology Partners, Ferter |

Total raised: ~$21.1M. [[1]](https://app.dealroom.co/companies/sun_genomics)

---

## References

1. Dealroom — Sun Genomics (Floré) company profile: [https://app.dealroom.co/companies/sun_genomics](https://app.dealroom.co/companies/sun_genomics)
2. CBInsights — Sun Genomics (Floré) profile: [https://www.cbinsights.com/company/sun-genomics](https://www.cbinsights.com/company/sun-genomics)
