# Sanofi (Translate Bio)

## Overview
Translate Bio was a clinical-stage mRNA therapeutics company focused on diseases caused by protein or gene dysfunction and on mRNA vaccines [[1]](https://www.sanofi.com/en/media-room/press-releases/2021/2021-03-12-06-00-00-2191846).

## Technology
Sanofi described Translate Bio as contributing mRNA technology, manufacturing capabilities, and a proprietary lung-delivery platform for pulmonary disease and vaccine development [[1]](https://www.sanofi.com/en/media-room/press-releases/2021/2021-03-12-06-00-00-2191846) [[2]](https://www.sanofi.com/en/media-room/press-releases/2020/2020-06-23-04-59-00-2051681).

## Investors
Before the acquisition, Translate Bio was a public company. The reviewed Sanofi collaboration sources emphasize partnership economics, including a $425 million upfront payment and equity investment in 2020 under the expanded vaccine collaboration [[2]](https://www.sanofi.com/en/media-room/press-releases/2020/2020-06-23-04-59-00-2051681).

## Acquisitions / Strategic Transactions
Sanofi agreed in August 2021 to acquire Translate Bio for $38 per share in cash, implying an equity value of approximately $3.2 billion [[3]](https://www.techtarget.com/pharmalifesciences/news/366606810/Sanofi-Translate-Enter-Pharma-Acquisition-Deal-for-mRNA-Vaccines).

## References
[[1]](https://www.sanofi.com/en/media-room/press-releases/2021/2021-03-12-06-00-00-2191846)
[[2]](https://www.sanofi.com/en/media-room/press-releases/2020/2020-06-23-04-59-00-2051681)
[[3]](https://www.techtarget.com/pharmalifesciences/news/366606810/Sanofi-Translate-Enter-Pharma-Acquisition-Deal-for-mRNA-Vaccines)
