# Switch Therapeutics

## Overview
Switch Therapeutics is a preclinical biotechnology company developing conditional RNAi therapeutics [[1]](https://www.switchthera.com/news/switch-therapeutics-launches-with-52-million-to-advance-first-of-its-kind-rnai-technology/).

## Technology
Its core platform is CASi, or Conditionally Activated siRNA, which the company says is designed to switch on siRNA activity only in selected cells [[1]](https://www.switchthera.com/news/switch-therapeutics-launches-with-52-million-to-advance-first-of-its-kind-rnai-technology/).

## Investors
Switch launched in 2023 with $52 million in financing. The Series A was co-led by Insight Partners and UCB Ventures, with participation from existing investors such as Upfront Ventures and BOLD Capital Partners and new investors including Eli Lilly, Ono Venture Investment, Digitalis Ventures, Dolby Family Ventures, Free Flow Ventures, and PhiFund Ventures [[1]](https://www.switchthera.com/news/switch-therapeutics-launches-with-52-million-to-advance-first-of-its-kind-rnai-technology/) [[2]](https://www.gaebler.com/Funded-Company-C7B1B693-71EC-4170-9525-888B71B91276-Switch-Therapeutics).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The major strategic milestone was the 2023 launch financing to advance CASi-based RNAi programs [[1]](https://www.switchthera.com/news/switch-therapeutics-launches-with-52-million-to-advance-first-of-its-kind-rnai-technology/).

## References
[[1]](https://www.switchthera.com/news/switch-therapeutics-launches-with-52-million-to-advance-first-of-its-kind-rnai-technology/)
[[2]](https://www.gaebler.com/Funded-Company-C7B1B693-71EC-4170-9525-888B71B91276-Switch-Therapeutics)
