# Cellino

## Overview
Cellino is an advanced biomanufacturing company focused on making personalized regenerative medicine scalable, especially through automated iPSC and cell-therapy manufacturing.[[1]](https://cellinobio.com/)[[2]](https://cellinobio.com/about-us)[[3]](https://www.businesswire.com/news/home/20240910871353/en/Cellino-Awarded-%2425M-in-Funding-from-the-Advanced-Research-Projects-Agency-for-Health-ARPA-H)

## Technology
The company says it uses optical, AI-guided, cassette-based biomanufacturing systems to generate induced pluripotent stem cells and other personalized regenerative medicine inputs at scale. In 2025 it said its iPSC manufacturing technology received FDA Advanced Manufacturing Technology designation.[[1]](https://cellinobio.com/)[[3]](https://www.businesswire.com/news/home/20240910871353/en/Cellino-Awarded-%2425M-in-Funding-from-the-Advanced-Research-Projects-Agency-for-Health-ARPA-H)[[4]](https://www.biospace.com/press-releases/cellinos-ipsc-manufacturing-technology-receives-fda-advanced-manufacturing-technology-amt-designation)

## Investors
Cellino announced a $16 million seed financing in 2021 co-led by The Engine and Khosla Ventures, then an $80 million Series A in 2022 led by Leaps by Bayer, 8VC, and Humboldt Fund, with participation from Felicis and existing investors. In 2024 it also received up to $25 million in ARPA-H funding.[[5]](https://www.businesswire.com/news/home/20210201005301/en/Cellino-Closes-%2416M-Seed-Financing-Led-by-The-Engine-and-Khosla-Ventures)[[6]](https://www.bayer.com/media/en-us/leaps-by-bayer-leads-80m-series-a-financing-for-cellino-biotech-to-autonomize-stem-cell-therapy-manufacturing/)[[3]](https://www.businesswire.com/news/home/20240910871353/en/Cellino-Awarded-%2425M-in-Funding-from-the-Advanced-Research-Projects-Agency-for-Health-ARPA-H)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://cellinobio.com/)
