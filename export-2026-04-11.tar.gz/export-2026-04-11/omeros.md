# Omeros

## Overview
Omeros is a commercial-stage biopharmaceutical company focused on inflammation, complement-mediated diseases, CNS disorders, and immune-related diseases.[[1]](https://investor.omeros.com/news-releases/news-release-details/omeros-announces-pricing-public-offerings) In addition to its commercial ophthalmic product OMIDRIA, the company has maintained a pipeline in complement biology and related therapeutic areas.[[1]](https://investor.omeros.com/news-releases/news-release-details/omeros-announces-pricing-public-offerings)

## Technology and Pipeline
Omeros has publicly emphasized its complement and GPCR discovery platforms, including assets such as narsoplimab historically and later complement-pathway programs such as zaltenibart.[[1]](https://investor.omeros.com/news-releases/news-release-details/omeros-announces-pricing-public-offerings) The company has also described ownership of a novel antibody-generating platform and a proprietary GPCR platform spanning dozens of targets.[[1]](https://investor.omeros.com/news-releases/news-release-details/omeros-announces-pricing-public-offerings)

## Investors and Financing
As a public company, Omeros is financed through public-market investors rather than venture rounds. In August 2020 it priced concurrent public offerings of common stock and convertible senior notes totaling roughly $310 million in gross proceeds before options and expenses.[[1]](https://investor.omeros.com/news-releases/news-release-details/omeros-announces-pricing-public-offerings) In 2024 and 2025 it also completed significant debt-management transactions and exchanges with noteholders.[[2]](https://investor.omeros.com/news-releases/news-release-details/omeros-corporation-further-strengthens-its-balance-sheet-through)[[3]](https://www.businesswire.com/news/home/20250509242099/en/Omeros-Corporation-Announces-Agreements-to-Acquire-%2480.5-Million-of-its-Convertible-Senior-Notes-Due-2026)

## Acquisitions and Corporate Activity
I did not identify an acquisition of Omeros in the reviewed sources. A major recent corporate event reported in October 2025 was a licensing agreement with Novo Nordisk for zaltenibart worth up to $2.1 billion, but the source I found for that was secondary reporting, so I am not framing it here as an acquisition event.[[4]](https://www.investors.com/news/technology/omeros-stock-novo-nordisk-licensing-deal/)
