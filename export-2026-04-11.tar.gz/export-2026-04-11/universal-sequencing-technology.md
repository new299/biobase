# Universal Sequencing Technology

## Overview

Universal Sequencing Technology, or UST, is a biotechnology company commercializing long-range sequencing library preparation and analysis tools. The company says its mission is to advance DNA sequencing technologies for everyone through innovation. [[1]](https://universalsequencing.com/pages/about-us) [[2]](https://universalsequencing.com/)

## Technology

UST's flagship platform is TELL-Seq, which it describes as an ultra-long linked-read technology that brings long-range information to short-read sequencers. Public materials say TELL-Seq supports de novo assembly, metagenomics, whole-genome phasing, structural variant detection, and targeted sequencing, and can generate long-range results above 200 kb from very low DNA input. [[1]](https://universalsequencing.com/pages/about-us) [[2]](https://universalsequencing.com/)

## Partnerships

UST says it signed a co-marketing and co-development relationship with Illumina in 2021. That is the clearest major strategic relationship disclosed in the public materials reviewed here. [[1]](https://universalsequencing.com/pages/about-us)

## Investors And Funding

I did not find a clearly disclosed financing history in the accessible public sources reviewed for this note. The company appears commercially active, with products and service offerings online, but does not publicly present named investor or round information in the sources I used. [[1]](https://universalsequencing.com/pages/about-us) [[2]](https://universalsequencing.com/)
