# AvenCell

## Overview
AvenCell Therapeutics is a clinical-stage cell-therapy company developing autologous and allogeneic switchable CAR-T therapies for hard-to-treat cancers and autoimmune diseases.[[1]](https://avencell.com/about/)[[2]](https://avencell.com/avencell-raises-112-million-in-series-b-funding-led-by-novo-holdings/) The company incorporated GEMoaB GmbH, now AvenCell Europe GmbH, into its platform at launch.[[1]](https://avencell.com/about/)

## Technology and Pipeline
AvenCell says its platform combines switchable universal T-cell technology from GEMoaB with a license to Intellia’s CRISPR/Cas9-based allogeneic platform to create reprogrammable CAR-T products.[[1]](https://avencell.com/about/) Public materials highlight programs spanning hematologic malignancies and autoimmune disease, including AVC203.[[2]](https://avencell.com/avencell-raises-112-million-in-series-b-funding-led-by-novo-holdings/)[[3]](https://avencell.com/avencell-awarded-up-to-40-million-amed-grant-to-advance-allogeneic-car-t-program/)

## Investors
AvenCell’s about page states that it launched with $250 million in committed capital from founding investor Blackstone Life Sciences.[[1]](https://avencell.com/about/) In October 2024, the company announced a $112 million Series B led by Novo Holdings, with participation from F-Prime Capital, Eight Roads Ventures Japan, Piper Heartland Healthcare Capital, NYBC Ventures, and Blackstone Life Sciences.[[2]](https://avencell.com/avencell-raises-112-million-in-series-b-funding-led-by-novo-holdings/)

## Acquisitions and Corporate Activity
No acquisition involving AvenCell was identified in the reviewed public sources. A notable recent corporate-development event was the June 2025 AMED grant of up to $40 million to support AvenCell Japan’s allogeneic CAR-T program.[[3]](https://avencell.com/avencell-awarded-up-to-40-million-amed-grant-to-advance-allogeneic-car-t-program/)
