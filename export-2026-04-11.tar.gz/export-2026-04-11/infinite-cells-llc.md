# Infinite Cells LLC

## Overview
Infinite Cells is a pediatric genetic disease company developing engineered stem-cell-based "Personalized Manufacturing Units" intended to provide long-term therapeutic protein delivery from a patient's own cells.[[1]](https://infinitecells.com/)

## Technology
The company says it uses a unique stem cell population and rational engineering to create autologous PMUs that secrete therapeutic proteins over the long term, potentially for the patient's lifetime.[[1]](https://infinitecells.com/)

## Investors
Its site states that the company has an initial investment and support from several companies, but I did not identify a detailed named financing announcement in the reviewed public sources.[[1]](https://infinitecells.com/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://infinitecells.com/)
