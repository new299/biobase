# Andson Biotech

## Overview
Andson Biotech is a biotools company developing microfluidic sample-preparation and analytics solutions for mass spectrometry workflows.[[1]](https://andsonbiotech.com/about/)[[2]](https://andsonbiotech.com/andson-biotech-raises-3-6m-seed-round/) The company positions itself as expanding access to mass spectrometry in biopharma and advanced biotherapeutics.[[1]](https://andsonbiotech.com/about/)

## Technology
Andson’s flagship platform is DynaChip, a microfluidic sample-preparation system designed to streamline mass spectrometry workflows and reduce manual sample handling.[[1]](https://andsonbiotech.com/about/)[[2]](https://andsonbiotech.com/andson-biotech-raises-3-6m-seed-round/) The company also references DynaMARK for analytics and quality applications in advanced cell and gene therapy workflows.[[2]](https://andsonbiotech.com/andson-biotech-raises-3-6m-seed-round/)

## Investors
Andson announced a $3.6 million seed round in April 2024 led by Glenn H. Epstein.[[2]](https://andsonbiotech.com/andson-biotech-raises-3-6m-seed-round/) In October 2025, it announced a further $4.7 million funding round to scale commercialization of DynaChip and expand its product portfolio.[[3]](https://andsonbiotech.com/andson-biotech-secures-5-0m-in-funding-to-accelerate-commercialization-expand-product-portfolio/) The local note’s Y Combinator reference is consistent with the company’s public statement that it has received YC support.[[2]](https://andsonbiotech.com/andson-biotech-raises-3-6m-seed-round/)

## Acquisitions and Corporate Activity
No acquisition involving Andson Biotech was identified in the reviewed public sources. The public record centers on fundraising, product launch, and commercialization growth.[[1]](https://andsonbiotech.com/about/)[[3]](https://andsonbiotech.com/andson-biotech-secures-5-0m-in-funding-to-accelerate-commercialization-expand-product-portfolio/)
