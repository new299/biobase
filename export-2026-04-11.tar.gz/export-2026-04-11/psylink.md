# Psylink

Psylink is a **biotechnology startup** headquartered in **Vilnius, Lithuania**, focused on using **engineered yeast biosynthesis** to produce **psychedelic compounds** and explore their therapeutic potential for **mental health disorders** such as depression and PTSD. [[1]](https://www.psylink.io/) [[7]](https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/)

## What the Company Does
Psylink develops a **microbial biosynthesis platform** where **genetically modified yeast cells** are programmed to recreate natural biosynthetic pathways to produce psychedelics and related molecules. This enables a **scalable, cost‑effective, and sustainable** supply of compounds that are often difficult to extract from natural sources. [[1]](https://www.psylink.io/) [[11]](https://www.psylink.io/process)

The compounds targeted include classic tryptamines such as:
- **Psilocybin**
- **Psilocin**
- **Norbaeocystin**
- **Baeocystin**
- **DMT**
- **5‑MeO‑DMT**
The platform also mentions potential capability to access other psychedelic families like LSD and mescaline via engineered pathways. [[1]](https://www.psylink.io/)

## Founders and Leadership
- **Laura Korsakova, MPharm** – CEO, with experience in pharmacology and psychopharmacology research. [[1]](https://www.psylink.io/)  
- **Evaldas Ciplys, PhD** – CSO, with experience in protein production and yeast biotechnology. [[1]](https://www.psylink.io/)

## History & Development
- **Founded:** 2020 (Vilnius, Lithuania). [[7]](https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/)  
- The company built out its biosynthesis platform through multiple R&D phases, including licensing to work with controlled substances and technology development for psychedelic biosynthesis. [[1]](https://www.psylink.io/)

## Funding & Investors
Psylink has completed at least one **pre‑seed funding round** in 2025, raising **over €500,000**. The round was led by **Coinvest Capital** with participation from **Firstpick**, **BSV Ventures**, and angel investors. Funding supports further development of the biotechnology platform and discovery of novel therapeutic candidates. [[4]](https://tech.eu/2025/07/29/coinvest-capital-backs-psylinks-next-gen-mental-health-biotech-solution/) [[15]](https://bebeez.eu/2025/07/29/psylink-secures-e501k-pre-seed/)

## Technology & Platform
Psylink’s platform uses **metabolic engineering of yeast cells** to reproduce natural biosynthetic routes for complex molecules. The process involves:
1. Selecting target molecule
2. Choosing enzymes for pathway
3. Engineering yeast strains
4. Fermentation optimization
5. Purification and formulation for pharmaceutical use  
This approach emphasizes **scalability, GMP compatibility**, lower costs, and **environmental sustainability** compared to traditional extraction or chemical synthesis. [[11]](https://www.psylink.io/process) [[1]](https://www.psylink.io/)

## Market & Strategic Focus
- Psylink positions itself at the **intersection of biotechnology and mental health**, focusing on treatment‑resistant conditions where existing therapies are often ineffective. [[5]](https://discover-pharma.com/biotech-and-psychedelics-converge-psylink-ceo-laura-korsakova-on-reshaping-mental-health-at-baltic-life-sciences/)  
- The company’s biosynthetic approach aims to **ensure consistent supply of active compounds**, addressing supply bottlenecks and variability seen in natural extraction or traditional chemical synthesis. [[7]](https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/)

## Status & Activity
- Psylink was **active as of 2025** with completed fundraising and ongoing platform development. [[7]](https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/)  
- It remains **early stage**, focused on R&D rather than clinical candidates at this point. Public details on clinical pipelines or regulatory filings (e.g., INDs) are not available.

## Summary
Psylink is a **2020‑founded Lithuanian biotech startup** using synthetic biology to produce **psychedelic compounds (psilocybin, psilocin, DMT, etc.)** in engineered yeast, with the goal of enabling scalable pharmaceutical supply and discovering novel mental health therapies. It has raised pre‑seed funding and is developing its biosynthesis platform. [[1]](https://www.psylink.io/) [[7]](https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/)

## References
1. Psylink official site — biosynthesis platform and product list. https://www.psylink.io/ turn0search0  
2. Lithuanian biotech startup Psylink raises over €500k. https://www.eu-startups.com/2025/07/lithuanian-biotech-platform-psylink-raises-over-e500k-for-mental-health-innovation/ turn0search7  
3. Psylink funding and Coinvest Capital support. https://tech.eu/2025/07/29/coinvest-capital-backs-psylinks-next-gen-mental-health-biotech-solution/ turn0search4  
4. Psylink R&D timeline and founder details. https://www.psylink.io/ turn0search3  
5. CEO interview on biotech & psychedelics strategy. https://discover-pharma.com/biotech-and-psychedelics-converge-psylink-ceo-laura-korsakova-on-reshaping-mental-health-at-baltic-life-sciences/ turn0search5  
6. Psylink company profile overview. https://zoonop.com/articles/psylink turn0search6
