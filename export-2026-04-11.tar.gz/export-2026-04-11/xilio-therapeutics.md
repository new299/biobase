# Xilio Therapeutics

## Overview

Xilio Therapeutics is a clinical-stage immuno-oncology company developing tumor-activated biologics designed to activate primarily in the tumor microenvironment rather than systemically.[[1]](https://ir.xiliotx.com/news-releases/news-release-details/abbvie-and-xilio-therapeutics-announce-collaboration-and-option) The company originated as Akrevia Therapeutics and rebranded to Xilio Therapeutics in 2020.[[2]](https://www.businesswire.com/news/home/20200302005061/en/Akrevia-Therapeutics-Rebrands-as-Xilio-Therapeutics-and-Announces-%24100.5-Million-Series-B-Financing)

## Technology

Xilio’s platform centers on tumor-activated immunotherapies, including masked cytokines, checkpoint antibodies, and newer antibody-based formats such as masked T-cell engagers.[[1]](https://ir.xiliotx.com/news-releases/news-release-details/abbvie-and-xilio-therapeutics-announce-collaboration-and-option) Earlier company disclosures described lead programs such as XTX101, a tumor-selective anti-CTLA-4 antibody, and XTX202/XTX301, tumor-activated cytokine programs intended to improve the therapeutic index of potent immune modulators.[[3]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-announces-fda-acceptance-ind-application) [[4]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-announces-preclinical-data-demonstrating-anti)

## Investors

In March 2020, the company announced a $100.5 million Series B financing led by Takeda Ventures with participation from SV Health Investors, MRL Ventures Fund, RiverVest Venture Partners, F-Prime Capital, and Atlas Venture.[[2]](https://www.businesswire.com/news/home/20200302005061/en/Akrevia-Therapeutics-Rebrands-as-Xilio-Therapeutics-and-Announces-%24100.5-Million-Series-B-Financing) In February 2021, Xilio announced a $95 million Series C led by Rock Springs Capital with participation from Bain Capital Life Sciences, Deerfield Management, RA Capital Management, and others.[[5]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-raises-95-million-series-c-financing-advance/) Xilio then completed its IPO in October 2021, raising approximately $117.6 million in gross proceeds.[[6]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-announces-closing-initial-public-offering/) In March 2024, it also announced an $11.3 million private placement involving existing investors including Bain Capital Life Sciences and Rock Springs Capital.[[7]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-announces-113-million-private-placement/)

## Partnerships and Strategic Transactions

Xilio has used partnerships as a major strategic lever. In 2021 it announced a clinical trial collaboration with Merck for XTX101 in combination with KEYTRUDA.[[8]](https://ir.xiliotx.com/news-releases/news-release-details/xilio-therapeutics-announces-clinical-trial-collaboration-merck/) In February 2025, AbbVie and Xilio announced a collaboration and option agreement to develop novel tumor-activated immunotherapies, including masked T-cell engagers.[[1]](https://ir.xiliotx.com/news-releases/news-release-details/abbvie-and-xilio-therapeutics-announce-collaboration-and-option) No acquisition of the company was identified in the reviewed sources.
