# CStone Pharmaceuticals — Research Notes

## Overview

CStone Pharmaceuticals (HKEX: 2616) is a Suzhou, China-based innovation-driven biopharmaceutical company founded in late 2015, focused on immuno-oncology and molecularly targeted therapies for cancer patients in China and globally. Listed on the Main Board of the Hong Kong Stock Exchange on February 26, 2019 (net IPO proceeds ~HK$2,085M / ~$266M USD). Pre-IPO: ~$412M raised in two private financing rounds from leading VC/PE funds. Pfizer made a $200M strategic equity investment in 2020. [[1]](https://www.cstonepharma.com/en/html/news/2036.html) [[2]](https://www.businesswire.com/news/home/20200929006175/en/CStone-Pfizer-Enter-into-Strategic-Collaboration-to-Address-Oncological-Needs-in-China)

---

## Technology & Pipeline

- **Sugemalimab (CS1001)**: Anti-PD-L1 monoclonal antibody; the core of CStone's collaboration with Pfizer for development and commercialization in mainland China. Part of a broader immuno-oncology franchise. [[2]](https://www.businesswire.com/news/home/20200929006175/en/CStone-Pfizer-Enter-into-Strategic-Collaboration-to-Address-Oncological-Needs-in-China)
- **Broad Oncology Pipeline**: Multiple immuno-oncology agents and molecularly targeted drugs across solid tumors and hematologic malignancies, including early-stage programs (CS1002 and others) and clinical-stage assets. [[3]](https://www.cstonepharma.com/en/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-IPO rounds | 2016–2018 | ~$412M (combined) | Prestigious VC/PE funds (not fully disclosed) |
| IPO (HKEX: 2616) | Feb 2019 | ~HK$2,085M (~$266M) | Public market |
| Pfizer strategic investment | Sep 2020 | $200M | Pfizer (equity investment) |

Total raised: ~$412M pre-IPO + IPO proceeds + $200M Pfizer. [[1]](https://www.cstonepharma.com/en/html/news/2036.html) [[2]](https://www.businesswire.com/news/home/20200929006175/en/CStone-Pfizer-Enter-into-Strategic-Collaboration-to-Address-Oncological-Needs-in-China)

---

## References

1. CStone — HKEX listing announcement: [https://www.cstonepharma.com/en/html/news/2036.html](https://www.cstonepharma.com/en/html/news/2036.html)
2. BusinessWire — CStone and Pfizer strategic collaboration (Sep 2020): [https://www.businesswire.com/news/home/20200929006175/en/CStone-Pfizer-Enter-into-Strategic-Collaboration-to-Address-Oncological-Needs-in-China](https://www.businesswire.com/news/home/20200929006175/en/CStone-Pfizer-Enter-into-Strategic-Collaboration-to-Address-Oncological-Needs-in-China)
3. CStone — Company website: [https://www.cstonepharma.com/en/](https://www.cstonepharma.com/en/)
