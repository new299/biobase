# XGenomes

## Overview

XGenomes is a Cambridge, Massachusetts genomics company developing a sequencing platform aimed at precision healthcare and lifelong multi-omic monitoring. The company describes its product vision as `One Box` for prep and sequencing, multi-omic readout, and mid- to high-throughput workflows.[[1]](https://www.xgenomes.com/)

## Technology

XGenomes says its sequencing approach uses super-resolution imaging and AI to read densely packed single molecules, with machine-learning models translating fluorescent probe signals into sequence and epigenetic information.[[1]](https://www.xgenomes.com/) Its careers materials further describe the platform as an optical super-resolution system for decoding sequence and epigenetic states.[[2]](https://www.xgenomes.com/careers)

## Investors

Public funding information is limited in official materials. Third-party startup profiles identify XGenomes as a Y Combinator Winter 2019 company and show it as a resident company of The Engine.[[3]](https://www.ycombinator.com/companies/xgenomes) [[4]](https://engine.xyz/resident-companies/xgenomes) Crunchbase also indicates historical support that included Massachusetts Life Sciences Center and other investors, but the amount details are partially obscured in the public profile, so those entries should be treated as directional rather than comprehensive.[[5]](https://www.crunchbase.com/organization/xgenomes)

## Acquisitions and Strategic Transactions

No acquisition involving XGenomes was identified in the reviewed public sources. The public footprint suggests the company remains focused on platform development rather than M&A.[[1]](https://www.xgenomes.com/) [[4]](https://engine.xyz/resident-companies/xgenomes)
