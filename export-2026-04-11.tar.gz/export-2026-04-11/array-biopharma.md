# Array BioPharma — Research Notes

## Overview

Array BioPharma was a small molecule drug discovery company founded in 1998, headquartered in Boulder, CO. Focused on oncology and inflammatory disease. **Acquired by Pfizer in July 2019 for $10.64B** (~$48/share), primarily to gain rights to **binimetinib (MEKTOVI®)** and **encorafenib (BRAFTOVI®)** for BRAF/MEK-mutant melanoma and colorectal cancer. [[1]](https://en.wikipedia.org/wiki/Array_BioPharma)

---

## Technology

- **Small Molecule Drug Discovery Platform**: Combinatorial chemistry + structure-based drug design for targeted oncology and inflammation. Large compound library and medicinal chemistry capabilities. [[1]](https://en.wikipedia.org/wiki/Array_BioPharma)
- **BRAFTOVI® (encorafenib)**: BRAF V600E/K inhibitor. Approved in combo with binimetinib for melanoma (2018) and with cetuximab for BRAF V600E+ colorectal cancer (2020). [[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_array_biopharma)
- **MEKTOVI® (binimetinib)**: MEK1/2 inhibitor; approved in combo for melanoma. [[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_array_biopharma)

---

## Funding & Acquisition

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| IPO (NASDAQ: ARRY) | 2000 | ~$68M | Public offering |
| Acquired by Pfizer | Jul 2019 | $10.64B | All-cash deal at $48/share |

[[1]](https://en.wikipedia.org/wiki/Array_BioPharma)

---

## References

1. Wikipedia — Array BioPharma: [https://en.wikipedia.org/wiki/Array_BioPharma](https://en.wikipedia.org/wiki/Array_BioPharma)
2. Pfizer — Acquisition completion: [https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_array_biopharma](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_array_biopharma)
