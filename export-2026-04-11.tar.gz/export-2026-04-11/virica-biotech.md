# Virica Biotech

## Overview

Virica Biotech is a Canadian life sciences company developing manufacturing enhancers for viral medicines, including gene therapies, cell therapies, oncolytic viruses, and vaccines. The company says its purpose is to realize the promise of viral medicines by improving manufacturing efficiency and scale. [[1]](https://www.viricabiotech.com/our-story/)

## Technology

Virica's core product category is Viral Sensitizers, or VSE, formulations designed to improve viral vector production and related manufacturing workflows. Public materials say these formulations were originally developed in the oncolytic virus field and later broadened into gene therapy and vaccine manufacturing applications. [[1]](https://www.viricabiotech.com/our-story/) [[2]](https://www.viricabiotech.com/development-of-supporting-analytical-assays-and-regulatory-compliance-package-for-viral-sensitizer-technology-commercialization/)

## Investors

Virica announced a first closing of its Series A financing in October 2021, led by Dynamk Capital. The company also announced a 2022 collaboration with the Government of Canada supported by $400,000 from Innovative Solutions Canada, and earlier project grant support from BioCanRx. [[3]](https://www.viricabiotech.com/virica-biotech-raises-series-a-financing-expands-operations-to-support-clients-manufacturing-of-viral-medicines/) [[4]](https://www.viricabiotech.com/virica-biotech-announces-collaboration-with-the-government-of-canada/) [[2]](https://www.viricabiotech.com/development-of-supporting-analytical-assays-and-regulatory-compliance-package-for-viral-sensitizer-technology-commercialization/)

## Strategic Position

Virica is a manufacturing-enablement company rather than a therapeutics developer. Its business depends on solving upstream process bottlenecks in viral medicine production and embedding those solutions into partner manufacturing workflows. [[1]](https://www.viricabiotech.com/our-story/) [[3]](https://www.viricabiotech.com/virica-biotech-raises-series-a-financing-expands-operations-to-support-clients-manufacturing-of-viral-medicines/)
