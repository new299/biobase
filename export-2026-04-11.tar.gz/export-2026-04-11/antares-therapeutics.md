# Antares Therapeutics

Antares Therapeutics is a U.S.-based biotechnology company developing **precision small-molecule medicines** for cancer and other serious diseases. The company emerged as a spinout from Scorpion Therapeutics, leveraging its discovery platform and pipeline to target historically “undruggable” proteins ([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:0]{index=0}).

### Origins & Formation

- Spinout from **Scorpion Therapeutics** (acquired by Eli Lilly in 2025)  
- Built on validated discovery platforms and preclinical pipeline  
- Launched with significant venture backing (~$177M)  

Antares continues to advance and expand programs originally developed at Scorpion while building new capabilities ([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:1]{index=1}).

### Approach

Antares’ approach focuses on **precision medicine through advanced small-molecule drug discovery**:

- Targets **previously “undruggable” proteins**, especially transcription factors  
- Uses integrated computational and experimental methods  
- Emphasizes **selectivity, speed, and scalability** in discovery  

The company aims to unlock new therapeutic opportunities by identifying novel binding sites and mechanisms for intervention ([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:2]{index=2}).

### Technology

Antares integrates multiple advanced technologies:

- **Medicinal chemistry + proprietary compound libraries**  
- **Next-generation mass spectrometry platforms**  
- Computational modeling and predictive sciences  
- Novel “pocket-finding” approaches to identify druggable sites  

These capabilities allow the company to:

- Discover new chemical binding pockets  
- Design highly selective small molecules  
- Accelerate translation from discovery to clinic  

([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:3]{index=3}).

### Pipeline & Programs

- Multiple **preclinical-stage small molecule programs**  
- First clinical program expected to enter trials around **2026**  

Key partnered assets include:

- **EGFR inhibitors (PFL-721, PFL-241)** – licensed to Pierre Fabre for lung cancer  
- **PARP1 inhibitor (MOMA-989)** – advanced by Moma Therapeutics  
- Ongoing collaboration with **AstraZeneca** targeting transcription factors  

([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:4]{index=4}).

### Market & Positioning

Antares operates in the **precision oncology and targeted therapeutics market**, positioning itself as:

- A **next-generation small molecule platform company**  
- Focused on difficult targets (e.g., transcription factors)  
- Combining computational biology with chemistry innovation  

Its strategy aims to expand the universe of druggable targets in cancer and beyond ([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:5]{index=5}).

### Investors

- Venture-backed (specific investors not listed on page, but launch financing reported)  

([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:6]{index=6}).

### Funding

- **~$177M raised at launch (2025)**  

([Source 1](https://antaresrx.com/#science), :contentReference[oaicite:7]{index=7}).

### Status

- Active  
- Privately held  
- Early-stage / preclinical biotech  
- Not acquired  

---

Overall, Antares Therapeutics is a precision medicine biotech leveraging advanced small-molecule discovery technologies to target historically undruggable proteins, with a strong focus on oncology and a pipeline advancing toward clinical development.
