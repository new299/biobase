# NeurogesX

## Overview
NeurogesX was a specialty pharmaceutical company focused on developing and commercializing non-opioid pain-management therapies.[[1]](https://www.prnewswire.com/news-releases/neurogesx-completes-phase-2-enrollment-of-ngx-1998-topical-liquid-capsaicin-formulation-trial-123988774.html) Its commercial product was Qutenza, a high-concentration capsaicin patch for neuropathic pain, and it also developed NGX-1998, a liquid capsaicin formulation.[[1]](https://www.prnewswire.com/news-releases/neurogesx-completes-phase-2-enrollment-of-ngx-1998-topical-liquid-capsaicin-formulation-trial-123988774.html)

## Technology and Pipeline
NeurogesX built its platform around prescription-strength capsaicin for neuropathic pain.[[1]](https://www.prnewswire.com/news-releases/neurogesx-completes-phase-2-enrollment-of-ngx-1998-topical-liquid-capsaicin-formulation-trial-123988774.html) Qutenza launched in the U.S. in 2010 for neuropathic pain associated with postherpetic neuralgia, while NGX-1998 was positioned as a next-generation topical capsaicin product intended to offer comparable efficacy with shorter treatment time.[[2]](https://www.prnewswire.com/news-releases/neurogesx-reports-second-quarter-2010-results-100059894.html)[[3]](https://www.globenewswire.com/news-release/2012/08/30/487876/16630/en/NeurogesX-NGX-1998-Well-Tolerated-Treatment-Demonstrated-Clear-Dose-Response-in-Patients.html)

## Investors and Financing
Public-company filings show NeurogesX operated as a Nasdaq-listed company before later trading OTC, but the reviewed sources for this note did not provide a clean recent investor roster.[[2]](https://www.prnewswire.com/news-releases/neurogesx-reports-second-quarter-2010-results-100059894.html)[[3]](https://www.globenewswire.com/news-release/2012/08/30/487876/16630/en/NeurogesX-NGX-1998-Well-Tolerated-Treatment-Demonstrated-Clear-Dose-Response-in-Patients.html)

## Acquisitions and Asset Sales
Acorda Therapeutics announced in July 2013 that it acquired NeurogesX's two neuropathic pain assets, Qutenza and NP-1998, for approximately $8 million in rights for the United States and selected markets.[[4]](https://www.sec.gov/Archives/edgar/data/1008848/000100884813000057/release_ngsx-070813.htm) That transaction effectively transferred NeurogesX's principal commercial and late-stage development assets to Acorda.[[4]](https://www.sec.gov/Archives/edgar/data/1008848/000100884813000057/release_ngsx-070813.htm)
