# Lupeng Pharmaceutical

Lupeng Pharmaceutical is a China-based, clinical-stage biopharmaceutical company focused on developing **innovative small-molecule therapies** for cancer and autoimmune diseases. Founded in 2018 and headquartered in Guangzhou, the company is advancing a differentiated pipeline based on its proprietary drug discovery platform ([Source 1](https://news.futunn.com/en/post/64264531/lupeng-pharmaceuticals-b-has-filed-its-ipo-prospectus-and-plans), :contentReference[oaicite:0]{index=0}).

### Approach

Lupeng’s approach centers on **bRo5 (“beyond Rule of Five”) small-molecule drug design**, enabling the development of complex oral drugs beyond traditional chemistry constraints:

- Designs **high-bioavailability oral drugs** outside Lipinski’s Rule of Five  
- Targets difficult-to-drug pathways in oncology and autoimmune disease  
- Uses its proprietary **BeyondX platform** for discovery and optimization  

This allows the company to pursue targets and mechanisms not accessible to conventional small-molecule approaches :contentReference[oaicite:1]{index=1}.

### Technology

- **BeyondX oral drug chemistry platform**  
- Focus on **bRo5 molecules** (larger, more complex compounds)  
- Enables targeting of protein-protein interactions and resistance mechanisms  

### Pipeline

Lupeng has a **multi-asset clinical pipeline**, including:

- **LP-168 (lobutinib)**  
  - Core asset, under NDA review  
  - Dual covalent + non-covalent **BTK inhibitor**  
  - Potential best-in-class for B-cell malignancies  

- **LP-108 (Bcl-2 inhibitor)**  
  - Phase II  
  - Targets apoptosis pathway  

- **LP-118 (Bcl-2/Bcl-xL inhibitor)**  
  - Phase I  
  - Designed to overcome resistance to earlier Bcl-2 therapies  

The company is also exploring **combination therapies** (e.g., LP-168 + LP-108) for hematologic cancers .

### Market & Positioning

Lupeng operates in the **global oncology and autoimmune therapeutics market**:

- Focus on **hematologic malignancies and immune diseases**  
- Positioned as a **platform biotech with differentiated chemistry capabilities**  
- Competes in next-generation small-molecule innovation  

([Source 1](https://news.futunn.com/en/post/64264531/lupeng-pharmaceuticals-b-has-filed-its-ipo-prospectus-and-plans), :contentReference[oaicite:3]{index=3}).

### Investors (including OrbiMed)

Lupeng is backed by multiple global and China-based investors, including:

- **OrbiMed**  
- **Qiming Venture Partners**  
- **Temasek**  
- **Tencent**  
- **TF Capital**  
- **LAV Fund / Cowin Capital / others**  

OrbiMed is a major healthcare-focused global VC and is represented at the board level :contentReference[oaicite:4]{index=4}.

### Funding

- Multiple venture rounds (e.g., Series A and later rounds)  
- Reported total funding in the tens of millions USD range  
- Filed for **Hong Kong IPO (2025)**  

([Source 1](https://news.futunn.com/en/post/64264531/lupeng-pharmaceuticals-b-has-filed-its-ipo-prospectus-and-plans), :contentReference[oaicite:5]{index=5}).

### Status

- Active  
- Clinical-stage biotech  
- Pre-IPO (Hong Kong listing planned)  
- Not acquired  

---

Overall, Lupeng Pharmaceutical is a clinical-stage Chinese biotech leveraging its BeyondX platform to develop next-generation oral small-molecule therapies, with strong backing from global investors such as OrbiMed and a pipeline advancing toward commercialization.
