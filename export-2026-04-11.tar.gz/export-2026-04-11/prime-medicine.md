# Prime Medicine

**Prime Medicine** is a **clinical‑stage biotechnology company** pioneering the use of **Prime Editing**, a next‑generation gene editing platform designed to **precisely correct disease‑causing genetic mutations** at their native genomic locations with fewer off‑target effects than traditional editing technologies such as CRISPR‑Cas9. The company’s focus is on developing **one‑time, potentially curative therapies** for a broad range of **genetic diseases**. [[1]](https://primemedicine.com/) [[2]](https://primemedicine.com/about/)

## Overview

- **Founded:** 2020 (company launch with initial financing) [[5]](https://primemedicine.com/media/prime-medicine-launches-with-315-million-financing-to-deliver-on-the-promise-of-prime-editing)  
- **Headquarters:** **Cambridge, Massachusetts, USA** (biotech hub near MIT/Broad Institute) [[2]](https://primemedicine.com/about/)  
- **Technology:** **Prime Editing**, a precision “search‑and‑replace” gene editing system for correcting genetic mutations at the DNA level [[6]](https://primemedicine.com/science/)  
- **Stage:** Clinical development and preclinical programs across multiple genetic disease areas [[10]](https://primemedicine.com/pipeline/)  
- **Public Company:** Traded on NASDAQ under **PRME** with ongoing financial reporting and strategic updates.

## Technology: Prime Editing

Prime Editing is an advanced gene editing approach that uses a **Prime Editor** (a fusion of CRISPR‑Cas9 nickase and reverse transcriptase) guided by a **pegRNA** (Prime Editing guide RNA) to **search for and replace specific DNA sequences**. This enables precise correction of disease‑causing mutations **without creating double‑strand DNA breaks**, reducing unwanted edits and improving specificity. It has the theoretical potential to correct **most types of pathogenic mutations across many tissues and cell types**. [[6]](https://primemedicine.com/science/)  

The platform also includes proprietary enhancements such as **PASSIGE™** (Prime Assisted Site‑Specific Integrase Gene Editing) to insert larger gene sequences with high precision. [[6]](https://primemedicine.com/science/)

## Founders & Leadership

Prime Medicine was founded by scientists including **David R. Liu, PhD** and **Andrew Anzalone, MD, PhD**, both instrumental in the original development of Prime Editing at the Broad Institute of MIT and Harvard. Leadership has evolved with CEO transitions, including **Allan Reine, MD** taking the role, and a strategic focus on key disease programs. [[1]](https://primemedicine.com/about/) [[3]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-announces-strategic-restructuring-focus)

## Funding & Investors

At launch, Prime Medicine completed a **landmark financing of $315 million**, including a **$115M Series A** and a **$200M Series B**, enabling development of Prime Editing therapeutic programs. Investors in these rounds included **ARCH Venture Partners, F‑Prime Capital, GV (formerly Google Ventures), Newpath Partners**, and a suite of additional institutional backers. [[5]](https://primemedicine.com/media/prime-medicine-launches-with-315-million-financing-to-deliver-on-the-promise-of-prime-editing)

Since becoming a public company (NASDAQ: PRME), Prime Medicine has **continued to raise capital through public markets** and selective strategic funding (e.g., from the **Cystic Fibrosis Foundation**) to advance its pipeline. [[7]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-reports-second-quarter-2025-financial-results-and) [[4]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-announces-additional-funding-24-million-cystic)

## Pipeline & Therapeutic Programs

Prime Medicine’s pipeline is organized around several core therapeutic areas:

### Liver Diseases
- **Wilson’s Disease & Alpha‑1 Antitrypsin Deficiency (AATD):** Programs designed to correct underlying genetic mutations with Prime Editors, with IND/CTA submissions targeted for 2026 and initial clinical data expected in 2027. [[3]](https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus)

### Lung & Cystic Fibrosis
- **Cystic Fibrosis:** Prime Editing programs targeting common CFTR mutations are funded in part by up to **$24M from the Cystic Fibrosis Foundation** to accelerate development for diverse CF genotypes. [[4]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-announces-additional-funding-24-million-cystic)

### Immunology, Oncology & CAR‑T
- **Prime Edited CAR‑T cell programs** developed with partners such as **Bristol Myers Squibb**, aimed at immuno‑oncology and hematology. [[3]](https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus)

### Other Programs
- Chronic Granulomatous Disease (CGD) early human data have provided proof‑of‑concept for Prime Editing in vivo, though strategic focus has shifted toward core liver and CF programs. [[3]](https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus)  
- Additional research includes programs in non‑human primates showing efficient correction of mutations (e.g., GSD1b). [[11]](https://primemedicine.gcs-web.com/news-release-details/prime-medicine-presents-first-ever-prime-editing-data-non-human)

## Market & Strategy

Prime Medicine operates in the **gene editing therapeutics market**, aiming to deliver **durable, one‑time treatments for genetic diseases** with high unmet need. The company’s strategy includes:
- Advancing targeted **in vivo editing programs** with well‑defined clinical paths. [[10]](https://primemedicine.com/pipeline/)  
- Leveraging external partnerships (e.g., cystic fibrosis and oncology collaborations) to accelerate development. [[4]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-announces-additional-funding-24-million-cystic)  
- Focusing internal resources on programs with *near‑term clinical milestones* and optimizing platform delivery and manufacturing. [[3]](https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus)

## Status

- Prime Medicine is **active and clinical‑stage**, with multiple programs progressing through IND/CTA preparation and early human proof‑of‑concept data emerging. [[3]](https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus)  
- The company continues to refine its pipeline strategy and operate with financial discipline. [[7]](https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-reports-second-quarter-2025-financial-results-and)

## Headquarters

- **Cambridge, Massachusetts, USA** — close to the Broad Institute and major genomics hubs. [[2]](https://primemedicine.com/about/)

## Summary

Prime Medicine is a biotech company at the forefront of **Prime Editing gene therapy**, a next‑generation editing technology capable of precise “search‑and‑replace” corrections of disease‑causing mutations. It was launched with significant venture backing, has transitioned into public markets, and is advancing a **pipeline of in vivo programs** for liver, lung (CF), and immuno‑oncology diseases. Its technology promises **one‑time, potentially curative genetic therapies** with broad applicability across diverse disorders. [[1]](https://primemedicine.com/) [[6]](https://primemedicine.com/science/)

## References

1. Prime Medicine official website — company overview and mission. https://primemedicine.com/ turn0search2  
2. Prime Medicine about page — technology, founders, and leadership. https://primemedicine.com/about/ turn0search1  
3. Strategic restructuring and program focus update (May 2025). https://investors.primemedicine.com/news-release-details/prime-medicine-announces-strategic-restructuring-focus/ turn0search3  
4. Additional Cystic Fibrosis funding by CF Foundation. https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-announces-additional-funding-24-million-cystic/ turn0search4  
5. Prime Medicine launch with $315 M financing. https://primemedicine.com/media/prime-medicine-launches-with-315-million-financing-to-deliver-on-the-promise-of-prime-editing/ turn0search5  
6. Prime Editing science and capabilities. https://primemedicine.com/science/ turn0search6  
7. Second quarter 2025 financial results and business update. https://investors.primemedicine.com/news-releases/news-release-details/prime-medicine-reports-second-quarter-2025-financial-results-and turn0search7  
8. Pipeline overview. https://primemedicine.com/pipeline/ turn0search10
