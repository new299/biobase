# Izon Science

## Overview
Izon Science is a New Zealand-founded life-science tools company focused on nanoparticle isolation and characterization, especially extracellular vesicles and lipid nanoparticles.[[1]](https://www.izon.com/about)

## Technology
Its core technologies include tunable resistive pulse sensing (TRPS) for high-resolution nanoparticle measurement and the qEV size-exclusion chromatography platform for EV and nanoparticle isolation.[[1]](https://www.izon.com/about)[[2]](https://www.izon.com/)

## Investors / Ownership
I did not identify a public venture financing announcement in the reviewed source set. Public materials emphasize the company’s operating history, installed base, and technology adoption rather than fundraising.[[1]](https://www.izon.com/about)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.izon.com/about)

## ASeq Posts

- [Izon](https://aseq.substack.com/p/izon)
