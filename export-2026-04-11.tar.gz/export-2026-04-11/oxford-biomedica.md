# Oxford Biomedica

## Overview
Oxford Biomedica is a cell and gene therapy CDMO specializing in viral-vector development and manufacturing.[[1]](https://www.oxb.com/about-us/)[[2]](https://www.oxb.com/) The company says it combines lentiviral-vector heritage with broader AAV and other advanced-therapy manufacturing capabilities.[[1]](https://www.oxb.com/about-us/)

## Technology and Services
Oxford Biomedica's business is centered on viral-vector process development, manufacturing, analytical development, and related CDMO services for gene and cell therapies.[[1]](https://www.oxb.com/about-us/)[[2]](https://www.oxb.com/) The local note's lentiviral vector manufacturing description is accurate, though the company now publicly frames itself as a broader advanced-therapy manufacturing platform.

## Investors and Ownership
Oxford Biomedica is a public company, so ownership is through public markets rather than venture rounds.[[2]](https://www.oxb.com/) In August 2025 the company completed a 60 million pound equity raise, as referenced in legal-adviser coverage tied to subsequent corporate activity.[[3]](https://www.cooley.com/news/coverage/2025/2025-10-07-oxford-biomedica-acquires-commercial-scale-viral-vector-facility)

## Acquisitions and Corporate Activity
In October 2025, Oxford Biomedica acquired a commercial-scale viral-vector manufacturing facility in North Carolina from RTP Operating, a subsidiary of National Resilience Holdco, expanding its U.S. GMP capacity.[[3]](https://www.cooley.com/news/coverage/2025/2025-10-07-oxford-biomedica-acquires-commercial-scale-viral-vector-facility) Media reports in early 2026 also stated that EQT had approached Oxford Biomedica regarding a potential takeover, but those reports described preliminary discussions rather than a completed transaction.[[4]](https://www.ft.com/content/83487c28-9d31-466f-bc60-54754469b934)
