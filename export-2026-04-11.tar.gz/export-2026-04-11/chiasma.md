# Chiasma — Research Notes

## Overview

Chiasma, Inc. (formerly NASDAQ: CHMA) was a Waltham, MA-based biopharmaceutical company focused on developing oral therapies for rare diseases using its Transient Permeability Enhancer (TPE®) technology platform. **Acquired by Amryt Pharma plc in 2021.** Key achievement: FDA approval of MYCAPSSA® (octreotide capsules) in June 2020 — the first and only oral somatostatin analog for acromegaly. [[1]](https://www.globenewswire.com/news-release/2020/06/26/2054210/0/en/Chiasma-Announces-FDA-Approval-of-MYCAPSSA-Octreotide-Capsules-the-First-and-Only-Oral-Somatostatin-Analog.html) [[2]](https://www.globenewswire.com/news-release/2021/05/05/2223243/0/en/Amryt-Pharma-to-Acquire-Chiasma-Inc-to-Further-Strengthen-Global-Leadership-in-Rare-and-Orphan-Diseases.html)

---

## Technology

- **Transient Permeability Enhancer (TPE®) Technology**: Oral drug delivery platform using fatty acid-based excipients that transiently enhance permeability of the gastrointestinal epithelium, enabling oral delivery of large peptide/protein drugs normally requiring injection. Applied to octreotide (a somatostatin analog peptide). [[1]](https://www.globenewswire.com/news-release/2020/06/26/2054210/0/en/Chiasma-Announces-FDA-Approval-of-MYCAPSSA-Octreotide-Capsules-the-First-and-Only-Oral-Somatostatin-Analog.html)
- **MYCAPSSA® (octreotide capsules)**: First oral somatostatin analog; FDA-approved June 2020 for long-term maintenance therapy in acromegaly patients previously controlled on injectable octreotide or lanreotide. Co-developed with Lonza for manufacturing. [[3]](https://www.lonza.com/news/2019-05-14-20-05)

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2003 | Jerusalem, Israel/Waltham, MA |
| NASDAQ IPO | 2015 | NASDAQ: CHMA |
| MYCAPSSA FDA approval | Jun 2020 | First oral SSA; acromegaly |
| Acquired by Amryt Pharma | 2021 | 0.396 Amryt ADS/share (~$5.13/share, 81% premium) |

[[2]](https://www.globenewswire.com/news-release/2021/05/05/2223243/0/en/Amryt-Pharma-to-Acquire-Chiasma-Inc-to-Further-Strengthen-Global-Leadership-in-Rare-and-Orphan-Diseases.html)

---

## References

1. GlobeNewswire — MYCAPSSA FDA approval (Jun 2020): [https://www.globenewswire.com/news-release/2020/06/26/2054210/0/en/Chiasma-Announces-FDA-Approval-of-MYCAPSSA-Octreotide-Capsules-the-First-and-Only-Oral-Somatostatin-Analog.html](https://www.globenewswire.com/news-release/2020/06/26/2054210/0/en/Chiasma-Announces-FDA-Approval-of-MYCAPSSA-Octreotide-Capsules-the-First-and-Only-Oral-Somatostatin-Analog.html)
2. GlobeNewswire — Amryt acquires Chiasma (May 2021): [https://www.globenewswire.com/news-release/2021/05/05/2223243/0/en/Amryt-Pharma-to-Acquire-Chiasma-Inc-to-Further-Strengthen-Global-Leadership-in-Rare-and-Orphan-Diseases.html](https://www.globenewswire.com/news-release/2021/05/05/2223243/0/en/Amryt-Pharma-to-Acquire-Chiasma-Inc-to-Further-Strengthen-Global-Leadership-in-Rare-and-Orphan-Diseases.html)
3. Lonza — Oral octreotide capsule development with Chiasma: [https://www.lonza.com/news/2019-05-14-20-05](https://www.lonza.com/news/2019-05-14-20-05)
