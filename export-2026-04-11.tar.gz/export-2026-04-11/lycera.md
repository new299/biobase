# Lycera

## Overview

Lycera was a biotechnology company developing small-molecule therapies modulating immune metabolism for autoimmune diseases and cancer.[[1]](https://www.gurnetpointrlp.com/gurnet-point-capital-acquires-lycera)

## Technology

Lycera focused on immunometabolism, with programs including RORgamma agonist and inverse agonist approaches and immune-cell metabolic modulation for inflammatory disease and oncology.[[1]](https://www.gurnetpointrlp.com/gurnet-point-capital-acquires-lycera)

## Investors

The reviewed public sources are strongest on the acquisition phase rather than a detailed financing history, so this note does not attempt to reconstruct the full early investor syndicate.

## Acquisitions and Strategic Transactions

In January 2019, Gurnet Point Capital announced that it had acquired Lycera.[[1]](https://www.gurnetpointrlp.com/gurnet-point-capital-acquires-lycera) Gurnet Point later used the acquisition as the basis for launching a new clinical-stage immunology company, Pandion Therapeutics.[[1]](https://www.gurnetpointrlp.com/gurnet-point-capital-acquires-lycera)
