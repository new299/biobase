# Zafgen

## Overview

Zafgen was a public biopharmaceutical company built around MetAP2 biology and the development of MetAP2 inhibitors for metabolic disorders. In its 2019 merger announcement, the company described itself as having pioneered the study of MetAP2 inhibitors in both common and rare metabolic disorders.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger)

## Technology

Zafgen's technology platform centered on inhibition of methionine aminopeptidase 2 (MetAP2), with programs historically aimed at obesity and rare metabolic disease settings.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger) By the time of its strategic endgame, the company was no longer advancing the original platform as an independent growth story and instead pursued a merger transaction.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger)

## Investors

Zafgen was a publicly traded company on Nasdaq under ticker `ZFGN`, so later-stage financing occurred through public-market ownership rather than recent private venture rounds.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger) The original local note referenced Third Rock Ventures, which is directionally consistent with Zafgen's well-known venture-backed origins, but the sources reviewed here are strongest on Zafgen's public-company and merger phase rather than on its earliest venture syndicate.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger)

## Acquisitions and Strategic Transactions

In December 2019, Zafgen and Chondrial Therapeutics announced a definitive merger agreement under which Chondrial would become a wholly owned subsidiary of Zafgen and the combined company would be renamed Larimar Therapeutics.[[1]](https://investors.larimartx.com/news-releases/news-release-details/zafgen-and-chondrial-therapeutics-announce-definitive-merger) The merger closed in May 2020. At closing, the combined company also signed an $80 million private placement led by Cowen Healthcare Investments with participation from Acuta Capital, Janus Henderson Investors, Logos Capital, OrbiMed, RA Capital Management, Vivo Capital, and Deerfield Management.[[2]](https://investors.larimartx.com/news-releases/news-release-details/chondrial-therapeutics-and-zafgen-complete-merger-and-begin)
