# SciThera

## Overview

SciThera is an early-stage biotechnology company backed by Venrock. Public information is sparse, but Venrock lists the company in its health portfolio and references the domain `scithera.bio`, while the company website itself is currently only a placeholder. [[1]](https://www.venrock.com/companies/scithera/?sector=all-health) [[2]](https://scithera.bio/)

## Technology

I did not find enough detailed public technical disclosure to characterize SciThera's platform with confidence. The available public sources reviewed here do not yet provide a substantive description of its modality, pipeline, or scientific approach. [[1]](https://www.venrock.com/companies/scithera/?sector=all-health) [[2]](https://scithera.bio/)

## Investors

The clearest public investor signal is that Venrock lists SciThera as a portfolio company. I did not identify a fuller financing syndicate in the accessible sources reviewed for this note. [[1]](https://www.venrock.com/companies/scithera/?sector=all-health)

## Public Disclosure Status

Because the company's own website is not yet informative and public materials are thin, this note should be treated as a limited snapshot rather than a full company profile. [[2]](https://scithera.bio/)
