# Unlocked Labs

## Overview

Unlocked Labs is a U.S. biotech company developing medical foods and targeted probiotic or postbiotic products for chronic health conditions. The company says it started in 2020 to build precision products that address disease-driving metabolic compounds, beginning with oxalate and kidney stone risk. [[1]](https://www.unlocked.bio/) [[2]](https://unlocked.bio/)

## Technology

Unlocked's public materials describe "active postbiotic ingredients," enzyme-rich bacterial husks designed to remove compounds that drive disease in the GI tract. Its lead product is StoneShield, powered by OX164, which the company says breaks down dietary oxalate in the stomach to help manage kidney stone risk. [[1]](https://www.unlocked.bio/) [[2]](https://unlocked.bio/)

## Investors And Funding

Unlocked's site says it has received support from federal research grant agencies, venture capital firms, state agencies, and angels, but it does not list a detailed financing syndicate. The local note's SOSV link could not be confirmed from a primary financing release in the sources reviewed here. [[1]](https://www.unlocked.bio/)

## Strategic Position

Unlocked is not a classical therapeutics company. It is building a regulated nutrition/medical foods business around targeted microbial or postbiotic ingredients, aiming for faster and more capital-efficient development than traditional drug pathways. [[1]](https://www.unlocked.bio/) [[2]](https://unlocked.bio/)
