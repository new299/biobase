# Strand Therapeutics

## Overview
Strand Therapeutics is a synthetic biology company developing programmable mRNA medicines for cancer and other diseases [[1]](https://www.strandtx.com/) [[2]](https://www.strandtx.com/about).

## Technology
The company says it engineers mRNA programs with programmable expression logic to improve precision and safety, and brands this broader approach as programmable mRNA therapeutics [[1]](https://www.strandtx.com/).

## Investors
Strand announced a $52 million Series A in 2021 co-led by Playground Global, Pear VC, and Section 32, with additional participation from CRV, Eli Lilly, and others [[3]](https://www.businesswire.com/news/home/20211025005284/en/Strand-Therapeutics-Launches-to-Develop-Programmable-mRNA-Therapeutics-and-Raises-%2452-Million-Series-A). It later closed a $45 million Series B in 2023 with investors including Cytokinetics, Eli Lilly, Limitless Ventures, Playground Global, and Regeneron Ventures [[4]](https://www.businesswire.com/news/home/20230725123901/en/Strand-Therapeutics-Announces-%2445-Million-Series-B-Financing-and-New-Data-Demonstrating-Selective-Expression-of-Programmable-mRNA-Therapeutics-in-Cancer).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The central strategic events were the Series A and Series B financings used to expand programmable mRNA therapeutics [[3]](https://www.businesswire.com/news/home/20211025005284/en/Strand-Therapeutics-Launches-to-Develop-Programmable-mRNA-Therapeutics-and-Raises-%2452-Million-Series-A) [[4]](https://www.businesswire.com/news/home/20230725123901/en/Strand-Therapeutics-Announces-%2445-Million-Series-B-Financing-and-New-Data-Demonstrating-Selective-Expression-of-Programmable-mRNA-Therapeutics-in-Cancer).

## References
[[1]](https://www.strandtx.com/)
[[2]](https://www.strandtx.com/about)
[[3]](https://www.businesswire.com/news/home/20211025005284/en/Strand-Therapeutics-Launches-to-Develop-Programmable-mRNA-Therapeutics-and-Raises-%2452-Million-Series-A)
[[4]](https://www.businesswire.com/news/home/20230725123901/en/Strand-Therapeutics-Announces-%2445-Million-Series-B-Financing-and-New-Data-Demonstrating-Selective-Expression-of-Programmable-mRNA-Therapeutics-in-Cancer)
