# OneCell Diagnostics (1Cell.Ai)

## Overview
1Cell.Ai, formerly OneCell Diagnostics, is a precision-oncology diagnostics company combining single-cell multi-omics, ctDNA analysis, and AI-driven interpretation.[[1]](https://1cell.ai/1cell-ai-formerly-onecell-diagnostics-launches-oncoincytes-integrating-multi-modal-data-for-precision-oncology/)[[2]](https://1cell.ai/) The company positions itself as moving beyond genomics-only testing into broader AI-powered oncology decision support.[[1]](https://1cell.ai/1cell-ai-formerly-onecell-diagnostics-launches-oncoincytes-integrating-multi-modal-data-for-precision-oncology/)

## Technology
In April 2025, the company launched OncoIncytes, a multi-modal cancer panel integrating ctDNA, circulating tumor cells at single-cell resolution, RNA transcriptomics, and proteomics.[[1]](https://1cell.ai/1cell-ai-formerly-onecell-diagnostics-launches-oncoincytes-integrating-multi-modal-data-for-precision-oncology/) Its current site describes a broader platform spanning single-cell multi-omics, AI-powered digital pathology, real-time reporting, and integrated data infrastructure for oncology research and care.[[2]](https://1cell.ai/)

## Investors
The April 2025 launch release states that the rebrand and product launch followed a recent oversubscribed $16 million Series A financing.[[1]](https://1cell.ai/1cell-ai-formerly-onecell-diagnostics-launches-oncoincytes-integrating-multi-modal-data-for-precision-oncology/) Public secondary databases attribute that round to investors including Cedars-Sinai, Tenacity Ventures, and Celesta, but I did not find a company-issued full syndicate announcement during this pass.[[3]](https://www.thecompanycheck.com/company/b/onecell-diagnostics/553fe12e1c7b46d59)

## Acquisitions and Corporate Activity
No acquisition involving the company was identified in the reviewed public sources. The key corporate event identified in this pass is the April 22, 2025 rebrand from OneCell Diagnostics to 1Cell.Ai and launch of the OncoIncytes platform.[[1]](https://1cell.ai/1cell-ai-formerly-onecell-diagnostics-launches-oncoincytes-integrating-multi-modal-data-for-precision-oncology/)
