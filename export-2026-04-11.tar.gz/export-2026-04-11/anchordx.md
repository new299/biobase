# AnchorDx — Research Notes

## Overview

AnchorDx is a clinical-stage liquid biopsy diagnostics company founded in 2015 by CEO Jian-Bing Fan (former senior director at Illumina), headquartered in Guangzhou, China. Develops DNA methylation-based blood tests for early cancer detection. Total raised: $68M+. [[1]](https://www.prnewswire.com/news-releases/anchordx-completes-usd-40-million-series-c-financing-to-advance-cancer-screening-and-early-detection-programs-301232500.html)

---

## Technology

- **DNA Methylation Liquid Biopsy**: Detects circulating tumor DNA (ctDNA) by profiling 100–200 methylation biomarkers to identify six major cancer types — lung, breast, colorectal, gastric, esophageal, and liver cancer — at early stages. [[2]](https://www.genomeweb.com/cancer/anchordx-demonstrates-liquid-biopsy-dna-methylation-test-early-cancer-detection)
- **Aurora Test**: Multi-cancer early detection (MCED) test targeting a $100 price point for six cancer types. [[2]](https://www.genomeweb.com/cancer/anchordx-demonstrates-liquid-biopsy-dna-methylation-test-early-cancer-detection)
- **UriFind**: Non-invasive bladder cancer early detection urine test; received FDA **Breakthrough Device Designation**. [[3]](https://www.prnewswire.com/news-releases/anchordxs-non-invasive-bladder-cancer-early-detection-test-urifind-earns-breakthrough-device-designation-from-fda-301338551.html)
- **Thunder Project**: World's largest prospective lung cancer early diagnosis clinical trial (initiated 2018), led by Prof. Zhong Nanshan across 23 top Chinese hospitals. [[1]](https://www.prnewswire.com/news-releases/anchordx-completes-usd-40-million-series-c-financing)
- Partnership with Twist Bioscience for pan-cancer methylation panel (2021). [[4]](https://www.prnewswire.com/news-releases/twist-alliance-pan-cancer-methylation-panel-global-launch-event---a-strategic-collaboration-between-anchordx-and-twist-bioscience-for-pan-cancer-liquid-biopsy-301396510.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A/A+ | ~2017 | $10M | NorthernLight, 6 Dimensions, Jianxin Capital |
| Series B | 2017 | $28M | NorthernLight, 6 Dimensions, Marathon, WuXi AppTec, KingMed, ARCH Venture Partners |
| Series C | Feb 2021 | $40M | OrbiMed (co-lead), WuXi Huiying Investment (co-lead) |

Total raised: ~$78M+. [[1]](https://www.prnewswire.com/news-releases/anchordx-completes-usd-40-million-series-c-financing-to-advance-cancer-screening-and-early-detection-programs-301232500.html)

**ARCH Venture Partners Investment** (Series B). **OrbiMed Investment** (Series C co-lead).

---

## References

1. PRNewswire — Series C close (Feb 2021): [https://www.prnewswire.com/news-releases/anchordx-completes-usd-40-million-series-c-financing-to-advance-cancer-screening-and-early-detection-programs-301232500.html](https://www.prnewswire.com/news-releases/anchordx-completes-usd-40-million-series-c-financing-to-advance-cancer-screening-and-early-detection-programs-301232500.html)
2. GenomeWeb — Technology overview: [https://www.genomeweb.com/cancer/anchordx-demonstrates-liquid-biopsy-dna-methylation-test-early-cancer-detection](https://www.genomeweb.com/cancer/anchordx-demonstrates-liquid-biopsy-dna-methylation-test-early-cancer-detection)
3. PRNewswire — UriFind FDA Breakthrough Designation: [https://www.prnewswire.com/news-releases/anchordxs-non-invasive-bladder-cancer-early-detection-test-urifind-earns-breakthrough-device-designation-from-fda-301338551.html](https://www.prnewswire.com/news-releases/anchordxs-non-invasive-bladder-cancer-early-detection-test-urifind-earns-breakthrough-device-designation-from-fda-301338551.html)
4. PRNewswire — Twist Bioscience collaboration: [https://www.prnewswire.com/news-releases/twist-alliance-pan-cancer-methylation-panel-global-launch-event---a-strategic-collaboration-between-anchordx-and-twist-bioscience-for-pan-cancer-liquid-biopsy-301396510.html](https://www.prnewswire.com/news-releases/twist-alliance-pan-cancer-methylation-panel-global-launch-event---a-strategic-collaboration-between-anchordx-and-twist-bioscience-for-pan-cancer-liquid-biopsy-301396510.html)
