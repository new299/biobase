# Biogen — Research Notes

## Overview

Biogen Inc. (NASDAQ: BIIB) is a Cambridge, MA-based multinational biopharmaceutical company founded in 1978. Specializes in neurological and neurodegenerative disease treatments. FY2025 revenue: ~$9.2B. [[1]](https://www.biogen.com/company.html) [[2]](https://investors.biogen.com/)

---

## Key Products & Pipeline

- **Multiple Sclerosis**: VUMERITY (diroximel fumarate), TYSABRI (natalizumab), AVONEX/PLEGRIDY. MS products remain largest revenue segment. [[2]](https://investors.biogen.com/)
- **SMA (Spinal Muscular Atrophy)**: SPINRAZA (nusinersen) — antisense oligonucleotide; Phase 3 high-dose regimen under FDA review. [[2]](https://investors.biogen.com/)
- **Alzheimer's Disease**: LEQEMBI (lecanemab, with Eisai) — FDA-approved for early Alzheimer's (2023). [[2]](https://investors.biogen.com/)
- **Rare Neurological**: SKYCLARYS (omaveloxolone, Friedreich ataxia); QALSODY (tofersen, SOD1-ALS). [[2]](https://investors.biogen.com/)
- **Psychiatric**: ZURZUVAE (zuranolone, postpartum depression, with Sage Therapeutics). [[2]](https://investors.biogen.com/)
- **Pipeline**: Litifilimab (BIIB059, cutaneous lupus — FDA BTD granted 2025); litifilimab co-funded via $200M Royalty Pharma deal. [[3]](https://www.biogen.com/science-and-innovation/pipeline.html)
- **2025 Acquisitions/Deals**: Alcyone Therapeutics (~$85M, ThecaFlex DRx intrathecal delivery); collaborations with Dayra, Vanqua, City Therapeutics, Stoke (upfronts $16M–$165M). [[3]](https://www.biogen.com/science-and-innovation/pipeline.html)

---

## Financials

| Metric | FY2025 |
|--------|--------|
| Revenue | ~$9.2B |
| Growth Products Revenue | +19% YoY |
| Net Income | ~$1.29B |

[[2]](https://investors.biogen.com/)

---

## References

1. Biogen — Company: [https://www.biogen.com/company.html](https://www.biogen.com/company.html)
2. Biogen — Investor Relations: [https://investors.biogen.com/](https://investors.biogen.com/)
3. Biogen — Pipeline: [https://www.biogen.com/science-and-innovation/pipeline.html](https://www.biogen.com/science-and-innovation/pipeline.html)
