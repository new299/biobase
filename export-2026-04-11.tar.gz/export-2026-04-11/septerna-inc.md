# Septerna, Inc.

## Overview
Septerna, Inc. is a clinical-stage biotechnology company focused on oral small-molecule GPCR therapies for endocrinology, inflammation, and metabolic disease [[1]](https://ir.septerna.com/investor-relations).

## Technology
The company says its Native Complex Platform enables industrial-scale GPCR drug discovery and has generated a diversified oral small-molecule pipeline [[1]](https://ir.septerna.com/investor-relations) [[2]](https://www.septerna.com/about/).

## Investors
Septerna became public in October 2024 through an upsized IPO that generated $331.2 million in gross proceeds [[3]](https://ir.septerna.com/news-releases/news-release-details/septerna-announces-closing-3312-million-upsized-initial-public/). In 2025 it also secured major non-dilutive collaboration economics from Novo Nordisk [[4]](https://ir.septerna.com/news-releases/news-release-details/novo-nordisk-septerna-and-novo-nordisk-collaborate-oral-small/).

## Acquisitions / Strategic Transactions
Septerna's key strategic transaction in the reviewed sources is the Novo Nordisk collaboration for multiple oral cardiometabolic programs, worth up to approximately $2.2 billion in aggregate payments and royalties [[4]](https://ir.septerna.com/news-releases/news-release-details/novo-nordisk-septerna-and-novo-nordisk-collaborate-oral-small/).

## References
[[1]](https://ir.septerna.com/investor-relations)
[[2]](https://www.septerna.com/about/)
[[3]](https://ir.septerna.com/news-releases/news-release-details/septerna-announces-closing-3312-million-upsized-initial-public/)
[[4]](https://ir.septerna.com/news-releases/news-release-details/novo-nordisk-septerna-and-novo-nordisk-collaborate-oral-small/)
