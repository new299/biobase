# IO Biotech — Research Notes

## Overview

IO Biotech is a Copenhagen, Denmark-based oncology company (with US headquarters in New York) founded and backed by Novo Holdings, developing long-peptide cancer vaccines targeting immune-suppressive elements in the tumor microenvironment. Its lead program IO102-IO103 — combining an IDO (indoleamine 2,3-dioxygenase) peptide vaccine (IO102) and a PD-L1 peptide vaccine (IO103) — received FDA Breakthrough Therapy Designation for melanoma in combination with pembrolizumab. IO Biotech raised $155M and secured €57.5M EIB venture debt in 2025. [[1]](https://iobiotech.com/) [[2]](https://www.fiercebiotech.com/biotech/io-biotech-raises-155m-to-trial-ido-and-pd-l1-cancer-vaccines)

---

## Technology & Products

- **IO102 (IDO Peptide Vaccine)**: Long peptide vaccine targeting indoleamine 2,3-dioxygenase 1 (IDO1) — an enzyme overexpressed in cancer cells and immunosuppressive cells in the tumor microenvironment; activates and expands cytotoxic T cells against IDO1-expressing cells. [[1]](https://iobiotech.com/)
- **IO103 (PD-L1 Peptide Vaccine)**: Long peptide vaccine targeting PD-L1 (CD274); activates T cells against PD-L1-expressing cancer and immunosuppressive cells. [[1]](https://iobiotech.com/)
- **IO102-IO103 Combination (+ Pembrolizumab)**: Combined vaccine approach targeting both IDO and PD-L1 immune checkpoints; FDA Breakthrough Therapy Designation for unresectable/metastatic melanoma; Phase 1/2 five-year outcomes published in Nature Communications (Dec 2025); Phase 2 trial in SCCHN; pivotal development for melanoma and other indications. [[1]](https://iobiotech.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Earlier rounds | Pre-2021 | Undisclosed | Novo Holdings (founding backer) |
| Series B+ financing | ~2021 | $155M | Novo Holdings lead + undisclosed |
| EIB venture debt | 2025 | Up to €57.5M | European Investment Bank (EIB) |
| Total | — | $155M+ | — |

[[2]](https://www.fiercebiotech.com/biotech/io-biotech-raises-155m-to-trial-ido-and-pd-l1-cancer-vaccines)

---

## References

1. IO Biotech — Homepage: [https://iobiotech.com/](https://iobiotech.com/)
2. Fierce Biotech — IO Biotech $155M raise: [https://www.fiercebiotech.com/biotech/io-biotech-raises-155m-to-trial-ido-and-pd-l1-cancer-vaccines](https://www.fiercebiotech.com/biotech/io-biotech-raises-155m-to-trial-ido-and-pd-l1-cancer-vaccines)
