# Base4 — Research Notes

## Overview

Base4 Innovation Ltd was a Cambridge, UK-based genomics company developing a microdroplet-based nanopore sequencing technology for single-molecule DNA sequencing without amplification. The company later split into three separate companies focused on different technology applications; it is no longer operating as a unified entity. Total raised: ~£21.3M (~$24.9M). [[1]](https://www.cbinsights.com/company/base4-innovation) [[2]](https://www.genomeweb.com/sequencing/base4-hitachi-aim-develop-solid-state-nanopore-sequencer-optical-detection)

---

## Technology

- **Microdroplet Nanopore Sequencing**: Developed a platform for encapsulating single DNA molecules in microdroplets and sequencing them in real time via nanopore-based optical detection. Claimed long-read sequencing from single molecules without amplification. [[2]](https://www.genomeweb.com/sequencing/base4-hitachi-aim-develop-solid-state-nanopore-sequencer-optical-detection)
- **Hitachi Collaboration**: Partnered with Hitachi to develop a solid-state nanopore sequencer with optical detection. [[2]](https://www.genomeweb.com/sequencing/base4-hitachi-aim-develop-solid-state-nanopore-sequencer-optical-detection)
- **Spinoffs**: The company split into three entities, including **Base Genomics** (focused on DNA methylation and 5hmC detection for epigenetic cancer diagnostics). [[1]](https://www.cbinsights.com/company/base4-innovation)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Early | ~2013–2015 | Undisclosed | Longwall Venture Partners, Royal Society Enterprise Fund |
| Series A | Nov 2017 | ~$5.88M | Amadeus Capital Partners, Meridian Corporate Finance, Oxford Technology Enterprise Capital |
| Total | | ~£21.3M (~$24.9M) | |

[[1]](https://www.cbinsights.com/company/base4-innovation)

---

## References

1. CBInsights — Base4 Innovation profile: [https://www.cbinsights.com/company/base4-innovation](https://www.cbinsights.com/company/base4-innovation)
2. GenomeWeb — Base4/Hitachi solid-state nanopore collaboration: [https://www.genomeweb.com/sequencing/base4-hitachi-aim-develop-solid-state-nanopore-sequencer-optical-detection](https://www.genomeweb.com/sequencing/base4-hitachi-aim-develop-solid-state-nanopore-sequencer-optical-detection)
