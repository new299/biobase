# CellVoyant — Research Notes

## Overview

CellVoyant is a Bristol, UK-based AI-first biotech company spun out from the University of Bristol in 2021. Develops AI-powered cell analytics platforms to accelerate development of cell-based therapeutics by predicting cell fate and quality during manufacturing. Total raised: ~$11.9M. [[1]](https://cellvoyant.com/) [[2]](https://www.iptonline.com/articles/cellvoyant-secures-76-million-seed-funding-to-accelerate-the-development-of-stem-cell-therapies)

---

## Technology

- **FateView Platform**: Combines live-cell time-lapse imaging with advanced AI to predict cell fate, quality, and behavior hours, days, or weeks into the future from current cell microscopy images. Enables more selective cell progression decisions during manufacturing, eliminating waste and improving therapy success rates. [[3]](https://fortune.com/2025/12/18/cellvoyant-ai-platform-fateview-reduce-cost-of-cell-based-therapies-car-t/)
- Accessible via an online interface for uploading microscope images and an API for high-volume industrial users. [[3]](https://fortune.com/2025/12/18/cellvoyant-ai-platform-fateview-reduce-cost-of-cell-based-therapies-car-t/)
- Applications: stem cell therapy development, CAR-T manufacturing quality analytics, cell therapy process optimization. [[2]](https://www.iptonline.com/articles/cellvoyant-secures-76-million-seed-funding-to-accelerate-the-development-of-stem-cell-therapies)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-seed | Jan 2022 | ~$2.2M | Undisclosed |
| Seed | Oct 2023 | £7.6M (~$9.7M) | Octopus Ventures, Horizon Ventures, Verve Ventures, Air Street Capital |

Total raised: ~$11.9M. [[2]](https://www.iptonline.com/articles/cellvoyant-secures-76-million-seed-funding-to-accelerate-the-development-of-stem-cell-therapies) [[4]](https://www.bristol.ac.uk/cellmolmed/news/2024/news---cellvoyant---funding-success.html)

---

## References

1. CellVoyant — Company website: [https://cellvoyant.com/](https://cellvoyant.com/)
2. IPT Online — CellVoyant £7.6M seed funding: [https://www.iptonline.com/articles/cellvoyant-secures-76-million-seed-funding-to-accelerate-the-development-of-stem-cell-therapies](https://www.iptonline.com/articles/cellvoyant-secures-76-million-seed-funding-to-accelerate-the-development-of-stem-cell-therapies)
3. Fortune — CellVoyant FateView platform (Dec 2025): [https://fortune.com/2025/12/18/cellvoyant-ai-platform-fateview-reduce-cost-of-cell-based-therapies-car-t/](https://fortune.com/2025/12/18/cellvoyant-ai-platform-fateview-reduce-cost-of-cell-based-therapies-car-t/)
4. University of Bristol — CellVoyant funding success (2024): [https://www.bristol.ac.uk/cellmolmed/news/2024/news---cellvoyant---funding-success.html](https://www.bristol.ac.uk/cellmolmed/news/2024/news---cellvoyant---funding-success.html)
