# NanoString

## Overview
NanoString Technologies was a life-science tools company focused on spatial biology and molecular profiling platforms for translational research and diagnostics.[[1]](https://nanostring.com/pressrelease/news-news-details-2024-nanostring-announces-completion-of-financing-to-support-restructuring-process/)[[2]](https://nanostring.com/pressrelease/news-news-details-2024-nanostring-technologies-to-be-acquired-by-bruker-corporation/)

## Technology
Its public identity centered on spatial transcriptomics, spatial proteomics, gene expression profiling, and associated analysis instruments and consumables.[[2]](https://nanostring.com/pressrelease/news-news-details-2024-nanostring-technologies-to-be-acquired-by-bruker-corporation/)

## Investors / Financing
During its 2024 restructuring, NanoString announced $47.5 million in new financing from existing noteholders to support operations through its chapter 11 process.[[1]](https://nanostring.com/pressrelease/news-news-details-2024-nanostring-announces-completion-of-financing-to-support-restructuring-process/)

## Acquisitions / Other
After a bankruptcy auction process, NanoString announced in April 2024 that substantially all of its assets would be acquired by Bruker for approximately $392.6 million in cash plus assumed liabilities.[[2]](https://nanostring.com/pressrelease/news-news-details-2024-nanostring-technologies-to-be-acquired-by-bruker-corporation/)
