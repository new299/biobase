# Sunbird Bio

## Overview
Sunbird Bio is a diagnostics company developing blood-based technologies for neurological disorders and early-stage cancer [[1]](https://www.biospace.com/press-releases/sunbird-bio-raises-additional-14-million-to-advance-broadest-blood-based-diagnostic-platform-in-alzheimers-disease-and-other-neurological-disorders) [[2]](https://www.alzdiscovery.org/research-and-grants/portfolio-details/22498891).

## Technology
The company says its platform directly measures extracellular-vesicle-bound biomarkers in blood, including disease-relevant protein aggregation states associated with neurological disorders such as Alzheimer's and Parkinson's disease [[1]](https://www.biospace.com/press-releases/sunbird-bio-raises-additional-14-million-to-advance-broadest-blood-based-diagnostic-platform-in-alzheimers-disease-and-other-neurological-disorders) [[2]](https://www.alzdiscovery.org/research-and-grants/portfolio-details/22498891).

## Investors
In October 2024, Sunbird announced an additional $14 million financing round backed by Eli Lilly, EDBI, and existing investors ClavystBio, Polaris Partners, and S32 [[1]](https://www.biospace.com/press-releases/sunbird-bio-raises-additional-14-million-to-advance-broadest-blood-based-diagnostic-platform-in-alzheimers-disease-and-other-neurological-disorders). ADDF also lists active grant support for Sunbird in 2025–2026 through its Diagnostics Accelerator program [[2]](https://www.alzdiscovery.org/research-and-grants/portfolio-details/22498891).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The most visible strategic developments were the 2024 financing round and ADDF-backed diagnostic development work [[1]](https://www.biospace.com/press-releases/sunbird-bio-raises-additional-14-million-to-advance-broadest-blood-based-diagnostic-platform-in-alzheimers-disease-and-other-neurological-disorders) [[2]](https://www.alzdiscovery.org/research-and-grants/portfolio-details/22498891).

## References
[[1]](https://www.biospace.com/press-releases/sunbird-bio-raises-additional-14-million-to-advance-broadest-blood-based-diagnostic-platform-in-alzheimers-disease-and-other-neurological-disorders)
[[2]](https://www.alzdiscovery.org/research-and-grants/portfolio-details/22498891)
