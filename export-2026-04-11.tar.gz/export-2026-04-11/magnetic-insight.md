# Magnetic Insight

## Overview

Magnetic Insight is an imaging company commercializing Magnetic Particle Imaging (`MPI`) systems for preclinical research and pursuing clinical applications in cell therapy monitoring, oncology, and vascular disease.[[1]](https://magneticinsight.com/news/magnetic-insight-raises-18m-to-support-commercial-growth-of-magnetic-particle-imaging-in-cell-therapy-vascular-and-oncology-applications/) [[2]](https://magneticinsight.com/news/magnetic-insight-raises-17m-series-b-to-expand-magnetic-particle-imaging-and-monitoring-technology-into-clinical-applications/)

## Technology

MPI directly detects magnetic tracers and enables deep-tissue functional imaging with high contrast and sensitivity.[[1]](https://magneticinsight.com/news/magnetic-insight-raises-18m-to-support-commercial-growth-of-magnetic-particle-imaging-in-cell-therapy-vascular-and-oncology-applications/) Magnetic Insight's products include the MOMENTUM preclinical imager and newer clinical/imaging-therapy concepts such as HYPER for localized hyperthermia and MPI-based theranostics.[[3]](https://magneticinsight.com/news/magnetic-insight-introduces-hyper-the-first-magnetic-particle-imaging-mpi-based-localized-hyperthermia-platform/) [[4]](https://magneticinsight.com/news/magnetic-insight-and-johns-hopkins-university-receive-sbir-grant-for-theranostic-platform-for-brain-tumor-treatment/)

## Investors

Magnetic Insight raised an $18 million Series A in December 2018 led by 5AM Ventures, with support from Sand Hill Angels, CEG Ventures, StartX-Stanford Fund, and SVTech Ventures.[[1]](https://magneticinsight.com/news/magnetic-insight-raises-18m-to-support-commercial-growth-of-magnetic-particle-imaging-in-cell-therapy-vascular-and-oncology-applications/) In 2024 it announced a $17 million Series B led by Celesta Capital with participation from Alumni Ventures Group, Gaingels, and others, alongside existing investors 5AM Ventures and Sand Hill Angels.[[2]](https://magneticinsight.com/news/magnetic-insight-raises-17m-series-b-to-expand-magnetic-particle-imaging-and-monitoring-technology-into-clinical-applications/)

## Acquisitions and Strategic Transactions

No acquisition involving Magnetic Insight was identified in the reviewed sources. The company's public strategic path is defined by financings, grants, and movement from preclinical research tools toward clinical MPI applications.[[2]](https://magneticinsight.com/news/magnetic-insight-raises-17m-series-b-to-expand-magnetic-particle-imaging-and-monitoring-technology-into-clinical-applications/) [[4]](https://magneticinsight.com/news/magnetic-insight-and-johns-hopkins-university-receive-sbir-grant-for-theranostic-platform-for-brain-tumor-treatment/)
