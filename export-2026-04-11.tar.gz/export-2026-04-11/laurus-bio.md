# Laurus Bio

## Overview

Laurus Bio is an integrated biomanufacturing company focused on precision fermentation, recombinant technology, and animal-free proteins and growth factors for biopharma, food, health, and personal care markets.[[1]](https://laurus.bio/) The company operates as part of the Laurus Labs group.[[2]](https://www.fprimecapital.com/company/laurus-bio/)

## Technology

Laurus Bio says it engineers microbes as cell factories to manufacture animal-free proteins, growth factors, and other recombinant products for biologics manufacturing and broader industrial markets.[[1]](https://laurus.bio/) The company also offers CDMO and process development services built around microbial fermentation and recombinant technology.[[1]](https://laurus.bio/)

## Investors

F-Prime Capital lists Laurus Bio as a portfolio company and describes it as an engineering-microbes platform for animal-free proteins and growth factors.[[2]](https://www.fprimecapital.com/company/laurus-bio/) Laurus Labs' public corporate milestones page states that in 2024 Laurus Labs, Eight Roads Ventures, and F-Prime Capital made strategic investments totaling INR 120 crore in Laurus Bio.[[3]](https://www.lauruslabs.com/about.html)

## Acquisitions and Strategic Transactions

Laurus Bio was created from Richcore Lifesciences after Laurus Labs acquired a majority stake in Richcore in 2020-2021.[[4]](https://www.lauruslabs.com/pdf/PressReleases/Nov.25.2020-LaurusLabs-PressRelease.pdf) Laurus Labs' transaction presentation says post-closing Richcore would be renamed Laurus Bio Pvt. Ltd.[[5]](https://www.lauruslabs.com/Investors/PDF/Disclosures/InvestorPresentationRICHCOREAcquistion.pdf)
