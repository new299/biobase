# Moonlight Bio

## Overview

Moonlight Bio is a Seattle-based preclinical-stage biotechnology company developing cell therapies for cancer.[[1]](https://www.linkedin.com/company/moonlightbio)

## Technology

According to its LinkedIn company profile, Moonlight is focused on innovative cell therapy technologies and candidates across discovery, component design and screening, preclinical modeling, process and analytical development, translational studies, and partnerships.[[1]](https://www.linkedin.com/company/moonlightbio) The reviewed public sources did not surface a richer official technical archive in this pass, so this summary stays relatively narrow.

## Investors

No clearly disclosed institutional financing round or investor syndicate was identified in the reviewed public sources. The strongest public source reviewed in this pass was the company's LinkedIn profile rather than a financing announcement.[[1]](https://www.linkedin.com/company/moonlightbio)

## Acquisitions and Strategic Transactions

No acquisition involving Moonlight Bio was identified in the reviewed sources. The public footprint reviewed is early-stage and company-building oriented.[[1]](https://www.linkedin.com/company/moonlightbio)
