# Javelin Biotech

## Overview

Javelin Biotech is a drug discovery tools company building human microphysiological systems (`organ-on-a-chip`) and digital-twin software to improve prediction of human drug response in preclinical development.[[1]](https://javelinbiotech.com/) [[2]](https://javelinbiotech.com/team)

## Technology

Javelin says its platform combines human tissue chips with software models to generate longitudinal, clinically relevant data on pharmacokinetics, toxicology, and disease biology earlier in the discovery process.[[1]](https://javelinbiotech.com/) [[2]](https://javelinbiotech.com/team) Its current product footprint includes a liver tissue chip platform for pharmacokinetic, toxicity, and drug disposition studies.[[3]](https://javelinbiotech.com/liver-tissue-chip)

## Investors

Clear financing details are limited in the reviewed sources. Javelin's board includes Venkat Srinivasan of Innospark Ventures, indicating venture backing, but the company does not prominently disclose a financing announcement on its public site.[[2]](https://javelinbiotech.com/team) Because the available public footprint is heavier on technology and partnerships than on financing, investor details should be treated as incomplete from the sources reviewed.

## Partnerships and Strategic Transactions

In September 2020, Javelin and Pfizer announced a three-year collaboration to design an organ-on-a-chip platform for human pharmacokinetic prediction, with the goal of commercializing the system broadly if successful.[[4]](https://www.pfizer.com/news/press-release/press-release-detail/javelin-biotech-aims-develop-industry-leading-organ-chip) No acquisition involving Javelin Biotech was identified in the reviewed sources.
