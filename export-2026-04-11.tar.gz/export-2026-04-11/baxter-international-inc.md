# Baxter International Inc.

## Overview
Baxter International is a global medical products and healthcare technology company, not a biotechnology therapeutics company.[[1]](https://www.baxter.com/) It operates in areas such as infusion therapies, renal care, medical devices, and hospital products.[[1]](https://www.baxter.com/)

## Technology and Business
Baxter’s business spans medical products, connected care systems, hospital and home therapies, and related healthcare infrastructure.[[1]](https://www.baxter.com/) This is medtech and healthcare manufacturing rather than drug discovery or molecular therapeutics.

## Investors and Ownership
As a public company, Baxter is owned through public markets.[[2]](https://investor.baxter.com/) The reviewed primary sources focused on corporate transactions rather than investor syndicate disclosures.

## Acquisitions and Corporate Activity
In 2021, Baxter agreed to acquire Hillrom in a transaction valued at approximately $10.5 billion in equity value and $12.4 billion enterprise value including debt.[[3]](https://www.baxter.com/baxter-newsroom/baxter-acquire-hillrom-expanding-connected-care-and-medical-innovation-globally) In August 2024, Baxter announced an agreement to divest its kidney care segment, to be named Vantive, to Carlyle for $3.8 billion.[[4]](https://investor.baxter.com/investors/events-and-news/news/press-release-details/2024/Baxter-Announces-Definitive-Agreement-to-Divest-Its-Vantive-Kidney-Care-Segment-to-Carlyle-for-3.8-Billion/default.aspx)
