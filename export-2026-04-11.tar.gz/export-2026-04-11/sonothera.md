# SonoThera

## Overview
SonoThera is a genetic medicines company developing ultrasound-mediated, nonviral delivery technologies for gene therapy [[1]](https://sonothera.com/) [[2]](https://sonothera.com/about/).

## Technology
The company says its proprietary ultrasound-mediated delivery approach enables broad but targeted biodistribution, delivery of diverse genetic payloads without size restriction, redosing, and avoidance of viral-vector limitations [[1]](https://sonothera.com/) [[2]](https://sonothera.com/about/).

## Investors
SonoThera announced a $60.75 million Series A in 2022 led by ARCH Venture Partners, with investors including Illumina Ventures, JJDC, Vertex Ventures HC, Medical Excellence Capital, Lilly, Alexandria Venture Investments, Lifespan Investments, Formic Ventures, and Foothill Ventures [[3]](https://sonothera.com/press-releases/sonothera-completes-60-75m-series-a-funding-for-ultrasound-guided-nonviral-gene-therapy-platform-development/). The company later launched a $125 million Series B in 2026 and its site names a broader investor syndicate including RA Capital and Duquesne [[1]](https://sonothera.com/) [[4]](https://www.biospace.com/press-releases/sonothera-launches-125m-series-b-at-44th-j-p-morgan-healthcare-conference-to-advance-multiple-genetic-medicine-programs-toward-first-in-human-studies).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The main strategic milestones were the Series A and Series B financings used to advance first-in-human genetic medicine programs [[3]](https://sonothera.com/press-releases/sonothera-completes-60-75m-series-a-funding-for-ultrasound-guided-nonviral-gene-therapy-platform-development/) [[4]](https://www.biospace.com/press-releases/sonothera-launches-125m-series-b-at-44th-j-p-morgan-healthcare-conference-to-advance-multiple-genetic-medicine-programs-toward-first-in-human-studies).

## References
[[1]](https://sonothera.com/)
[[2]](https://sonothera.com/about/)
[[3]](https://sonothera.com/press-releases/sonothera-completes-60-75m-series-a-funding-for-ultrasound-guided-nonviral-gene-therapy-platform-development/)
[[4]](https://www.biospace.com/press-releases/sonothera-launches-125m-series-b-at-44th-j-p-morgan-healthcare-conference-to-advance-multiple-genetic-medicine-programs-toward-first-in-human-studies)
