# ExploRNA Therapeutics — Research Notes

## Overview

ExploRNA Therapeutics is a Warsaw, Poland-based biotechnology company founded in 2019, developing proprietary cap analogs and mRNA technology to enhance therapeutic mRNA performance. The company was the first Polish biotech to receive funding from the Bill & Melinda Gates Foundation. Technology focus: novel cap analogs that increase protein production from mRNA beyond what standard cap analogs can achieve — enabling more potent and durable mRNA therapeutics and vaccines. Total raised: ~$0.8M+ (primarily grant-funded). Key investors/partners: Bill & Melinda Gates Foundation, Axcend Health, Primrose Bio. [[1]](https://www.prnewswire.com/news-releases/explorna-therapeutics-receives-funding-to-advance-its-novel-mrna-technology-301697070.html) [[2]](https://explorna.com/)

---

## Technology

- **Novel mRNA Cap Analogs**: Proprietary cap analog technology improving the 5' cap structure at the start of mRNA molecules — the cap is critical for mRNA stability, nuclear export, and translation efficiency. ExploRNA's caps increase protein production beyond levels achievable with standard cap analogs used in existing mRNA medicines. [[1]](https://www.prnewswire.com/news-releases/explorna-therapeutics-receives-funding-to-advance-its-novel-mrna-technology-301697070.html)
- **Applications**: mRNA therapeutics and vaccines — applicable to any mRNA-based medicine as a foundational enhancement to manufacturing and potency.
- **Primrose Bio Partnership (Sep 2024)**: Strategic partnership to advance mRNA medicines using ExploRNA's cap analog technology.

---

## Funding & Partners

| Source | Amount | Details |
|--------|--------|---------|
| Bill & Melinda Gates Foundation | $813,578 | 14-month project; novel mRNA technology development (Dec 2022) |
| Axcend Health | Undisclosed | Institutional investor |
| Primrose Bio | Undisclosed | Strategic partnership Sep 2024 |

Total raised: ~$0.8M+ (primarily grant-funded). [[1]](https://www.prnewswire.com/news-releases/explorna-therapeutics-receives-funding-to-advance-its-novel-mrna-technology-301697070.html)

---

## References

1. PRNewswire — ExploRNA Therapeutics receives Gates Foundation funding (Dec 2022): [https://www.prnewswire.com/news-releases/explorna-therapeutics-receives-funding-to-advance-its-novel-mrna-technology-301697070.html](https://www.prnewswire.com/news-releases/explorna-therapeutics-receives-funding-to-advance-its-novel-mrna-technology-301697070.html)
2. ExploRNA Therapeutics — Homepage: [https://explorna.com/](https://explorna.com/)
