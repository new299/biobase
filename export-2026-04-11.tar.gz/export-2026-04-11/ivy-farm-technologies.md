# Ivy Farm Technologies

## Overview
Ivy Farm Technologies is a cultivated meat company developing cell-cultured meat products and bioprocess technology.[[1]](https://www.ivy.farm/)[[2]](https://www.ivy.farm/our-story)

## Technology
The company says it has developed induced pluripotent stem cell-derived production methods, computational bioprocessing tools, and scalable manufacturing systems for cultivated meat. Public materials emphasize reduced serum use, efficient cell selection, and industrial bioreactor scale-up.[[1]](https://www.ivy.farm/)[[2]](https://www.ivy.farm/our-story)

## Investors
Ivy Farm announced a £20 million Series A in 2022 led by Synthesis Capital with participation from Valo Ventures, Lowercarbon Capital, Collaborative Fund, and others.[[3]](https://www.prnewswire.com/news-releases/ivy-farm-raises-20m-series-a-to-accelerate-the-transition-to-sustainable-cultivated-meat-301663226.html)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.ivy.farm/)
