# Coherus Biosciences

## Overview
Coherus BioSciences is a biotechnology company that started as a biosimilars developer and has since repositioned around oncology, including LOQTORZI and immuno-oncology pipeline assets.[[1]](https://investors.coherus.com/news-releases/news-release-details/coherus-biosciences-secures-55-million-series-c-financing)[[2]](https://investors.coherus.com/news-releases/news-release-details/coherus-announces-full-repayment-pharmakon-advisors-75-million/)

## Technology
Earlier company materials described Coherus as a biologics platform company focused on biosimilars. More recent public disclosures frame it as a focused oncology company with LOQTORZI and other oncology assets.[[1]](https://investors.coherus.com/news-releases/news-release-details/coherus-biosciences-secures-55-million-series-c-financing)[[2]](https://investors.coherus.com/news-releases/news-release-details/coherus-announces-full-repayment-pharmakon-advisors-75-million/)

## Investors
Coherus announced a $55 million Series C in 2014 from KKR, Venrock, RA Capital, Rock Springs Capital, Fidelity Biosciences, Sofinnova Ventures, Lilly Ventures, and Vivo Capital. Later public financing included a $75 million credit facility from HealthCare Royalty Partners in 2019 and a Barings loan plus royalty financing arrangement in 2024.[[1]](https://investors.coherus.com/news-releases/news-release-details/coherus-biosciences-secures-55-million-series-c-financing)[[3]](https://investors.coherus.com/news-releases/news-release-details/coherus-biosciences-secures-75-million-credit-financing/)[[2]](https://investors.coherus.com/news-releases/news-release-details/coherus-announces-full-repayment-pharmakon-advisors-75-million/)

## Acquisitions / Other
I did not identify a flagship corporate acquisition in the reviewed source set. A notable 2024 portfolio move was the sale of the YUSIMRY franchise to Hong Kong King-Friend Industrial.[[4]](https://www.marketwatch.com/story/coherus-biosciences-files-8k-entry-into-definitive-agreement-chrs-1377e8d9)
