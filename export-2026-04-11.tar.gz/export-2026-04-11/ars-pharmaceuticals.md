# ARS Pharmaceuticals — Research Notes

## Overview

ARS Pharmaceuticals (NASDAQ: SPRY) is a commercial-stage biopharmaceutical company headquartered in San Diego, CA. Developed and commercialized **neffy® (epinephrine nasal spray)** — the first and only needle-free epinephrine for emergency treatment of Type I allergic reactions and anaphylaxis. FDA approved August 9, 2024; EC approved August 22, 2024. Cash at year-end 2024: $314M. [[1]](https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-receives-fda-approval-neffyr-epinephrine)

---

## Technology

- **neffy® (epinephrine nasal spray)**: 2mg intranasal epinephrine formulation using a proprietary excipient system enabling rapid systemic absorption through the nasal mucosa — matching EpiPen® pharmacokinetic profiles without an injection. Available for adults and children ≥30kg. Needle-free convenience addresses patient hesitancy with auto-injectors. [[1]](https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-receives-fda-approval-neffyr-epinephrine)
- 1mg formulation for children 15–30kg also received FDA approval (2025).
- Regulatory filings in China, Japan, and Australia. [[2]](https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-announces-filings-approval-neffyr-china)

---

## Funding & Investors

Public company (NASDAQ: SPRY). Key deals:

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| ALK-Abelló licensing deal | Nov 2024 | $145M upfront + up to $320M milestones | European/Canadian commercialization rights |
| Cash position | Year-end 2024 | $314M | ≥3 years runway |

[[3]](https://www.globenewswire.com/news-release/2025/01/13/3008466/0/en/ARS-Pharmaceuticals-Announces-Preliminary-Fourth-Quarter-2024-Financial-Results-and-2025-Objectives-for-neffy-epinephrine-nasal-spray.html)

---

## References

1. ARS Pharmaceuticals — FDA approval press release: [https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-receives-fda-approval-neffyr-epinephrine](https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-receives-fda-approval-neffyr-epinephrine)
2. ARS Pharmaceuticals — International filings: [https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-announces-filings-approval-neffyr-china](https://ir.ars-pharma.com/news-releases/news-release-details/ars-pharmaceuticals-announces-filings-approval-neffyr-china)
3. GlobeNewswire — Q4 2024 results: [https://www.globenewswire.com/news-release/2025/01/13/3008466/0/en/ARS-Pharmaceuticals-Announces-Preliminary-Fourth-Quarter-2024-Financial-Results-and-2025-Objectives-for-neffy-epinephrine-nasal-spray.html](https://www.globenewswire.com/news-release/2025/01/13/3008466/0/en/ARS-Pharmaceuticals-Announces-Preliminary-Fourth-Quarter-2024-Financial-Results-and-2025-Objectives-for-neffy-epinephrine-nasal-spray.html)
