# SyneuRx International (Taiwan) Corp.

## Overview
SyneuRx is a CNS- and infectious-disease-focused therapeutics company developing drug candidates for schizophrenia, depression, dementia, COVID-19, and influenza.[[1]](https://www.syneurx.com/)[[2]](https://www.syneurx.com/about/)

## Technology
The company says it follows a "human-health focus" and safety-first philosophy while advancing multiple CNS compounds and antiviral programs such as Pentarlandir and Airnecflu. Public materials emphasize drug discovery, reformulation, and clinical development rather than a single platform technology.[[1]](https://www.syneurx.com/)[[2]](https://www.syneurx.com/about/)

## Investors / Financing
I did not identify a public financing announcement in the reviewed source set. The site is stronger on pipeline and executive updates than on capital formation details.[[1]](https://www.syneurx.com/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Current public updates focus on clinical progression and new drug discoveries in CNS and infectious disease programs.[[1]](https://www.syneurx.com/)
