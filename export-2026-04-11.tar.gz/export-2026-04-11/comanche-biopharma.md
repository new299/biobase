# Comanche Biopharma — Research Notes

## Overview

Comanche Biopharma Corp. is a Cambridge, MA-based biopharmaceutical company developing a first-in-class siRNA medicine targeting the root cause of preterm preeclampsia — one of the leading causes of maternal and neonatal mortality worldwide. Total raised: ~$126M. [[1]](https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/) [[2]](https://www.biopharmadive.com/news/comanche-series-b-funding-preeclampsia-gottlieb/704726/)

---

## Technology

- **Placental siRNA (sFLT-1 Silencing)**: Lead program uses siRNA to silence the sFLT-1 (soluble fms-like tyrosine kinase-1) gene in the placenta. Excess sFLT-1 is a key driver of preeclampsia; targeted silencing in placental tissue reduces sFLT-1 protein production to halt disease progression. [[1]](https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/)
- Designed to be globally accessible, including to patients in low- and middle-income countries where preeclampsia mortality is highest. [[1]](https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2021–2022 | ~$51M | GV (Google Ventures), F-Prime Capital, Lilly Asia Ventures (LAV), Longview Healthcare Ventures |
| Series B | Jan 2024 | $75M | NEA (lead), Atlas Venture; GV, F-Prime, LAV, Longview (existing) |

Total raised: ~$126M. [[1]](https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/)

---

## References

1. Comanche Biopharma — $75M Series B close (Jan 2024): [https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/](https://comanchebiopharma.com/comanche-biopharma-closes-oversubscribed-75-million-series-b-financing-to-advance-mission-to-develop-and-make-globally-available-the-first-treatment-targeting-a-root-cause-of-preeclampsia/)
2. BioPharma Dive — Comanche $75M Series B for preeclampsia: [https://www.biopharmadive.com/news/comanche-series-b-funding-preeclampsia-gottlieb/704726/](https://www.biopharmadive.com/news/comanche-series-b-funding-preeclampsia-gottlieb/704726/)
3. F-Prime Capital — Comanche Biopharma portfolio: [https://fprimecapital.com/company/comanche-biopharma/](https://fprimecapital.com/company/comanche-biopharma/)
