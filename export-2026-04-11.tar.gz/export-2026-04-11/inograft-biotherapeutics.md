# Inograft Biotherapeutics — Research Notes

## Overview

Inograft Biotherapeutics is a Palo Alto, CA-based preclinical-stage biotechnology company founded in 2022, developing novel non-genotoxic conditioning regimens for hematopoietic stem cell transplantation (HSCT) — enabling safer bone marrow transplantation for patients with hematologic cancers, genetic blood disorders, severe autoimmune diseases, and for promoting immune tolerance in solid organ transplantation. Inograft is an ARCH Venture Partners portfolio company. **ARCH Venture Partners Investment.** [[1]](https://www.inograft.com/) [[2]](https://www.archventure.com/portfolio/)

---

## Technology & Products

- **Non-Genotoxic HSCT Conditioning**: Developing targeted, non-cytotoxic conditioning agents to replace chemotherapy- and radiation-based conditioning regimens in hematopoietic stem cell transplantation — potentially enabling safer transplantation with reduced toxicity for broader patient populations. [[1]](https://www.inograft.com/)

---

## Funding & Investors

| Event | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Series A | 2022–2023 | Undisclosed | **ARCH Venture Partners Investment** |

No public funding amounts disclosed.

---

## References

1. Inograft Biotherapeutics — Homepage: [https://www.inograft.com/](https://www.inograft.com/)
2. ARCH Venture Partners — Portfolio: [https://www.archventure.com/portfolio/](https://www.archventure.com/portfolio/)
