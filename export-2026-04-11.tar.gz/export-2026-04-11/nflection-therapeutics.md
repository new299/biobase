# NFlection Therapeutics

## Overview
NFlection Therapeutics is a clinical-stage biopharmaceutical company focused on rare dermatological diseases driven by aberrant activation of the RAS pathway.[[1]](https://nflection.com/) The company highlights indications including neurofibromatosis type 1, immunosuppressant-mediated squamous cell carcinoma, keratinocytic epidermal nevi, and nevi sebacei.[[1]](https://nflection.com/)

## Technology and Pipeline
NFlection's therapeutic strategy is centered on first-in-class topical MEK inhibitors for RAS-mediated skin disorders.[[1]](https://nflection.com/) F-Prime similarly describes the company as developing therapies for NF1 and other dermatologic disorders, with the current company site emphasizing targeted topical treatment rather than systemic therapy.[[2]](https://fprimecapital.com/company/nflection-therapeutics/)

## Investors
F-Prime Capital lists NFlection Therapeutics as a portfolio company with an initial investment in 2016.[[2]](https://fprimecapital.com/company/nflection-therapeutics/) I did not identify a detailed public financing release on the company's current website during this pass, so the investor picture here should be treated as partial.[[1]](https://nflection.com/)[[2]](https://fprimecapital.com/company/nflection-therapeutics/)

## Acquisitions and Corporate Activity
No acquisition involving NFlection was identified in the reviewed public sources. The public record reviewed here shows an independent private company advancing topical therapies for rare RAS-driven dermatology indications.[[1]](https://nflection.com/)
