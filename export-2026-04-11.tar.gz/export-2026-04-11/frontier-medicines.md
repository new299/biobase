# Frontier Medicines — Research Notes

## Overview

Frontier Medicines is a San Francisco, CA-based clinical-stage precision medicine company founded in 2018, developing covalent small molecule medicines against historically undruggable cancer targets using its proprietary chemoproteomics-powered Frontier™ Platform. Lead program FMC-376 targets KRASG12C (both ON and OFF states) and is in the Phase 1/2 PROSPER trial. The company has raised $235.5M total through Series C. [[1]](https://www.globenewswire.com/news-release/2024/02/22/2834057/0/en/Frontier-Medicines-Announces-Oversubscribed-80-Million-Series-C-Financing-to-Support-Progress-of-Clinical-Stage-Pipeline.html) [[2]](https://www.frontiermeds.com/press-release/frontier-medicines-announces-oversubscribed-80-million-series-c-financing-to-support-progress-of-clinical-stage-pipeline/)

---

## Technology & Pipeline

- **Frontier™ Platform (Chemoproteomics + ML)**: Combines covalent chemistry with machine learning to identify new binding sites on previously undruggable disease-causing proteins — enabling discovery of covalent small molecules for precision oncology and immunology targets. [[1]](https://www.globenewswire.com/news-release/2024/02/22/2834057/0/en/Frontier-Medicines-Announces-Oversubscribed-80-Million-Series-C-Financing-to-Support-Progress-of-Clinical-Stage-Pipeline.html)
- **FMC-376 (KRASG12C dual ON+OFF inhibitor)**: First-in-class small molecule with dual direct mechanism targeting both ON and OFF states of KRASG12C — in Phase 1/2 PROSPER trial (NCT06244771) for KRAS G12C-mutant cancers. Differentiated mechanism vs. approved sotorasib and adagrasib (OFF-state only). [[2]](https://www.frontiermeds.com/press-release/frontier-medicines-announces-oversubscribed-80-million-series-c-financing-to-support-progress-of-clinical-stage-pipeline/)
- **Additional Pipeline**: Preclinical programs against other high-value precision medicine targets in oncology and immunology.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2019 | ~$55.5M | DCVC Bio, MPM Capital, RA Capital Management |
| Series B | ~2021 | ~$100M | Existing investors |
| Series C | Feb 2024 | $80M | Deerfield Management (co-lead), Droia Ventures (co-lead), Galapagos NV, DCVC Bio, MPM Capital, RA Capital Management |
| Series C extension | Jun 2024 | $20M | Deep Track Capital, ArrowMark Partners |

Total raised: $235.5M. [[1]](https://www.globenewswire.com/news-release/2024/02/22/2834057/0/en/Frontier-Medicines-Announces-Oversubscribed-80-Million-Series-C-Financing-to-Support-Progress-of-Clinical-Stage-Pipeline.html) [[2]](https://www.frontiermeds.com/press-release/frontier-medicines-announces-oversubscribed-80-million-series-c-financing-to-support-progress-of-clinical-stage-pipeline/)

---

## References

1. GlobeNewswire — Frontier Medicines $80M Series C (Feb 2024): [https://www.globenewswire.com/news-release/2024/02/22/2834057/0/en/Frontier-Medicines-Announces-Oversubscribed-80-Million-Series-C-Financing-to-Support-Progress-of-Clinical-Stage-Pipeline.html](https://www.globenewswire.com/news-release/2024/02/22/2834057/0/en/Frontier-Medicines-Announces-Oversubscribed-80-Million-Series-C-Financing-to-Support-Progress-of-Clinical-Stage-Pipeline.html)
2. Frontier Medicines — Series C press release: [https://www.frontiermeds.com/press-release/frontier-medicines-announces-oversubscribed-80-million-series-c-financing-to-support-progress-of-clinical-stage-pipeline/](https://www.frontiermeds.com/press-release/frontier-medicines-announces-oversubscribed-80-million-series-c-financing-to-support-progress-of-clinical-stage-pipeline/)
