# Dalton Bioanalytics

## Overview
Dalton Bioanalytics is developing a liquid-biopsy and blood analysis platform based on integrated liquid chromatography mass spectrometry workflows.[[1]](https://sosv.com/company/dalton-bioanalytics/)[[2]](https://daltonbioanalytics.com/)

## Technology
SOSV says Dalton measures proteins, lipids, electrolytes, metabolites, and other small molecules from blood in one integrated workflow, with applications in biomarker discovery, clinical testing, drug development, and broader industrial analytics.[[1]](https://sosv.com/company/dalton-bioanalytics/)

## Investors
The clearest public investor signal is SOSV/IndieBio 09 portfolio inclusion. The reviewed public material did not surface a later named institutional round beyond this early-stage backing.[[1]](https://sosv.com/company/dalton-bioanalytics/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://sosv.com/company/dalton-bioanalytics/)
