# Korro Bio

## Overview

Korro Bio is a biopharmaceutical company developing genetic medicines based on RNA editing for rare and highly prevalent diseases.[[1]](https://ir.korrobio.com/) The company positions RNA editing as a way to make precise but transient single-base changes at the RNA level without altering DNA.[[1]](https://ir.korrobio.com/)

## Technology

Korro's core technology is its OPERA platform (`Oligonucleotide Promoted Editing of RNA`), which uses oligonucleotides to recruit natural RNA editing machinery and create targeted edits in mRNA.[[2]](https://ir.korrobio.com/news-releases/news-release-details/korro-bio-and-genevant-sciences-enter-collaboration-agreement) The company combines this with established delivery modalities such as GalNAc conjugates and LNP-based approaches.[[1]](https://ir.korrobio.com/) [[2]](https://ir.korrobio.com/news-releases/news-release-details/korro-bio-and-genevant-sciences-enter-collaboration-agreement)

## Investors

Korro completed a $116 million Series B in December 2021.[[3]](https://ir.korrobio.com/news-releases/news-release-details/korro-bio-completes-116m-series-b-financing-expand-frontier/) In March 2026, it announced an oversubscribed $85 million PIPE led by Venrock Healthcare Capital Partners with participation from ADAR1 Capital Management, Affinity Asset Advisors, Balyasny Asset Management, Driehaus Capital Management, Kalehua Capital, Lynx1 Capital Management, Nantahala Capital, and New Enterprise Associates.[[4]](https://ir.korrobio.com/news-releases/news-release-details/korro-announces-oversubscribed-85-million-private-placement)

## Acquisitions and Strategic Transactions

Korro has used partnerships as a major strategic lever. In March 2023, it entered a collaboration with Genevant Sciences to combine Korro's RNA editing technology with Genevant's LNP delivery platform for alpha-1 antitrypsin deficiency.[[2]](https://ir.korrobio.com/news-releases/news-release-details/korro-bio-and-genevant-sciences-enter-collaboration-agreement) In September 2024, it announced a collaboration with Novo Nordisk covering two cardiometabolic RNA editing programs with total potential deal value up to $530 million plus royalties and R&D funding.[[5]](https://ir.korrobio.com/news-releases/news-release-details/korro-bio-announces-collaboration-novo-nordisk-develop-two) No acquisition of Korro itself was identified in the reviewed sources.
