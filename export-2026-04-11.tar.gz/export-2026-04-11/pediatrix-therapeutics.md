## Pediatrix Therapeutics (祐儿医药) – Company Summary

Pediatrix Therapeutics (祐儿医药) is a China-based biotechnology company focused on developing and commercializing innovative medicines specifically for pediatric patients. The company aims to improve treatment options and clinical outcomes for children in China by introducing and developing safe, effective, and easy-to-use pediatric therapies ([Source 1](https://pediatrixtherapeutics.com/#/about3)).

### Approach

Pediatrix’s approach combines **global in-licensing and local R&D (“dual-engine” model)** to advance pediatric healthcare:

- Leverages deep expertise in pediatrics  
- Introduces innovative therapies from global markets into China  
- Conducts local development tailored to Chinese pediatric needs  
- Focuses on improving treatment experience and accessibility for children  

The company aims to provide **new therapeutic options for pediatricians, patients, and families** in China ([Source 1](https://pediatrixtherapeutics.com/#/about3)).

### Strategy (Translated)

- Identify and unlock the **large unmet potential in China’s pediatric drug market**  
- Build a **highly differentiated product pipeline**  
- Become a **leading commercialization platform for pediatric medicines in China**  
- Act as a **pioneer in delivering comprehensive pediatric treatment solutions**  

Pediatrix emphasizes strong execution capabilities, deep market insight, and guidance from a specialized pediatric advisory board to drive transformation in pediatric care in China ([Source 1](https://pediatrixtherapeutics.com/#/about3)).

### Technology & Pipeline

- Focus on pediatric-specific drug development and adaptation  
- Portfolio includes both **imported innovative drugs** and **locally developed therapies**  
- Targets diseases affecting children across multiple therapeutic areas  

([Source 1](https://pediatrixtherapeutics.com/#/about3)).

### Market & Positioning

Pediatrix operates in the **pediatric pharmaceuticals market**, a historically underserved segment:

- Addresses lack of child-specific formulations and therapies  
- Focus on safety, dosing, and usability for pediatric populations  
- Positioned as a **specialized pediatric pharma platform in China**  

([Source 1](https://pediatrixtherapeutics.com/#/about3)).

### Investors

F-Prime Investment?

### Status

- Active  
- Privately held  
- China-based pediatric-focused biotech/pharma company  
- Not acquired  

---

Overall, Pediatrix Therapeutics is a pediatric-focused pharmaceutical company aiming to transform children’s healthcare in China through a combination of global drug sourcing and local innovation, targeting unmet needs in pediatric medicine.
