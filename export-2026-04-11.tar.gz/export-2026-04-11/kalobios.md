# KaloBios

## Overview

KaloBios Pharmaceuticals was a public biopharmaceutical company that later transformed into Humanigen. By 2017, the company described itself as focused on neglected and rare diseases, with benznidazole and monoclonal antibody programs including lenzilumab and ifabotuzumab.[[1]](https://www.globenewswire.com/news-release/2017/07/27/1063782/0/en/KaloBios-To-Change-Company-Name-To-Humanigen-Inc.html)

## Technology

In its later form before the Humanigen rename, KaloBios/Humanigen's pipeline included benznidazole for Chagas disease and the proprietary antibodies lenzilumab and ifabotuzumab.[[1]](https://www.globenewswire.com/news-release/2017/07/27/1063782/0/en/KaloBios-To-Change-Company-Name-To-Humanigen-Inc.html) Public records from successor entities show lenzilumab became the main continuing asset.[[2]](https://www.tarantherapeutics.com/partnerships)

## Investors

The local note referenced 5AM Ventures. 5AM has publicly identified KaloBios as one of its portfolio exits.[[3]](https://5amventures.com/) By the time of its later restructuring, KaloBios was a public company, so its capitalization also depended on public-market financing.[[1]](https://www.globenewswire.com/news-release/2017/07/27/1063782/0/en/KaloBios-To-Change-Company-Name-To-Humanigen-Inc.html)

## Acquisitions and Strategic Transactions

The key strategic transaction in the reviewed sources is not an external acquisition but the company's transformation and August 2017 rename from KaloBios Pharmaceuticals to Humanigen, Inc.[[1]](https://www.globenewswire.com/news-release/2017/07/27/1063782/0/en/KaloBios-To-Change-Company-Name-To-Humanigen-Inc.html) Later, Taran Therapeutics disclosed that it acquired Humanigen's assets in a 2024 bankruptcy sale, which effectively closed the long arc of the KaloBios/Humanigen corporate history.[[2]](https://www.tarantherapeutics.com/partnerships)
