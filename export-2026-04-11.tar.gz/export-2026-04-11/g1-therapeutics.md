# G1 Therapeutics — Research Notes

## Overview

G1 Therapeutics (NASDAQ: GTHX) was a Research Triangle Park, NC-based clinical-stage biopharmaceutical company developing CDK4/6 inhibitors. The company's lead product, Cosela (trilaciclib), became the first FDA-approved therapy to decrease the incidence of chemotherapy-induced myelosuppression in adults with extensive-stage small cell lung cancer (ES-SCLC), approved in February 2021. G1 Therapeutics was acquired by Pharmacosmos A/S for approximately $405M ($7.15/share, 68% premium) in 2023. [[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance) [[2]](https://www.pharmaceutical-technology.com/news/pharmacosmos-ventures-into-oncology-and-merges-with-g1-therapeutics/)

---

## Technology & Pipeline

- **Trilaciclib (Cosela, CDK4/6 inhibitor — myeloprotection)**: First-in-class IV CDK4/6 inhibitor administered before chemotherapy to transiently arrest hematopoietic stem cells in G1 phase, protecting bone marrow from chemotherapy damage (myelopreservation). FDA approved Feb 2021 for ES-SCLC. Revenue ~$46M at time of acquisition. [[2]](https://www.pharmaceutical-technology.com/news/pharmacosmos-ventures-into-oncology-and-merges-with-g1-therapeutics/)
- **Lerociclib (oral CDK4/6 inhibitor)**: Differentiated profile vs. palbociclib/ribociclib with lower neutropenia allowing continuous dosing. Phase 3 data in HR+/HER2- breast cancer; licensed to Pepper Bio post-G1 for $6.5M. [[3]](https://www.fiercebiotech.com/biotech/pepper-bio-spices-pipeline-135m-deal-g1-therapeutics-cdk46-inhibitor)
- **Rintodestrant (oral SERD)**: Selective estrogen receptor degrader for ER+/HER2- advanced breast cancer; in combination with CDK4/6 inhibitors.

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2008 | Research Triangle Park, NC |
| IPO (NASDAQ: GTHX) | May 2017 | ~$144M |
| FDA approval (Cosela/trilaciclib) | Feb 2021 | Myeloprotection in ES-SCLC |
| Acquired by Pharmacosmos | 2023 | ~$405M ($7.15/share, 68% premium) |

[[2]](https://www.pharmaceutical-technology.com/news/pharmacosmos-ventures-into-oncology-and-merges-with-g1-therapeutics/)

---

## References

1. Wikipedia — G1 Therapeutics: [https://en.wikipedia.org/wiki/G1_Therapeutics](https://en.wikipedia.org/wiki/G1_Therapeutics)
2. Pharmaceutical Technology — Pharmacosmos acquires G1 Therapeutics: [https://www.pharmaceutical-technology.com/news/pharmacosmos-ventures-into-oncology-and-merges-with-g1-therapeutics/](https://www.pharmaceutical-technology.com/news/pharmacosmos-ventures-into-oncology-and-merges-with-g1-therapeutics/)
3. Fierce Biotech — Pepper Bio acquires lerociclib from G1: [https://www.fiercebiotech.com/biotech/pepper-bio-spices-pipeline-135m-deal-g1-therapeutics-cdk46-inhibitor](https://www.fiercebiotech.com/biotech/pepper-bio-spices-pipeline-135m-deal-g1-therapeutics-cdk46-inhibitor)
