# NURO CORP

## Overview
NURO CORP is a Canadian neurotechnology company developing non-invasive systems to help severely impaired patients communicate and interact without surgery.[[1]](https://www.nuro.world/about)[[2]](https://sosv.com/company/nuro-corp/) Its public materials focus on stroke, ALS, trauma, neurodegeneration, and locked-in patients.[[1]](https://www.nuro.world/about)

## Technology
NURO says its core product family is the NUOS platform, a non-invasive neural operating system and headset that combines signals such as EEG and EOG to enable communication and computing by brain activity.[[2]](https://sosv.com/company/nuro-corp/)[[3]](https://ca.linkedin.com/company/nuro-corp-) The SOSV profile further states that the system has regulatory clearances in Canada and expanded-access authorization contexts in the U.S. for communication by brain in advanced ALS patients.[[2]](https://sosv.com/company/nuro-corp/)

## Investors
SOSV lists NURO CORP as one of its portfolio companies through the IndieBio program.[[2]](https://sosv.com/company/nuro-corp/) I did not identify a fuller source-backed institutional financing history during this pass.

## Acquisitions and Corporate Activity
No acquisition involving NURO CORP was identified in the reviewed public sources. The public record mainly reflects its evolution as a neurotechnology and assistive-communication company.[[1]](https://www.nuro.world/about)[[2]](https://sosv.com/company/nuro-corp/)
