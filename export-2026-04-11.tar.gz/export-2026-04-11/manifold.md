# Manifold

## Overview

Manifold Bio is a platform therapeutics company building AI-guided direct-to-vivo discovery systems for tissue-targeted biologics and delivery shuttles.[[1]](https://www.manifold.bio/news/manifold-bio-announces-strategic-collaboration-with-roche-to-develop-multiple-next-generation-brain-shuttles-for-neurological-diseases) The company positions itself around testing thousands to millions of biologic variants directly in vivo to generate physiologically relevant data for drug design.[[1]](https://www.manifold.bio/news/manifold-bio-announces-strategic-collaboration-with-roche-to-develop-multiple-next-generation-brain-shuttles-for-neurological-diseases)

## Technology

Manifold's core technology is its `mDesign` AI-guided direct-to-vivo discovery engine, which combines protein design with high-throughput in vivo measurement.[[1]](https://www.manifold.bio/news/manifold-bio-announces-strategic-collaboration-with-roche-to-develop-multiple-next-generation-brain-shuttles-for-neurological-diseases) The company applies this platform to tissue-targeting biologics, including blood-brain barrier shuttles and other targeted delivery modalities for antibodies, oligonucleotides, and related therapeutics.[[1]](https://www.manifold.bio/news/manifold-bio-announces-strategic-collaboration-with-roche-to-develop-multiple-next-generation-brain-shuttles-for-neurological-diseases)

## Investors

The reviewed sources did not surface a clean official financing round announcement in this pass. Investor detail is therefore left incomplete here, though the company has clearly reached a stage where it can support major pharmaceutical collaborations.

## Acquisitions and Strategic Transactions

In November 2025, Manifold announced a strategic research collaboration and license agreement with Roche to develop multiple next-generation brain shuttles for neurological diseases. The deal included $55 million upfront with potential for more than $2 billion in milestones plus royalties and a co-funding option for one program.[[1]](https://www.manifold.bio/news/manifold-bio-announces-strategic-collaboration-with-roche-to-develop-multiple-next-generation-brain-shuttles-for-neurological-diseases) No acquisition of Manifold itself was identified in the reviewed sources.
