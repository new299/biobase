# BioPhero — Research Notes

## Overview

BioPhero was a Copenhagen, Denmark-based agricultural biotech company founded in 2016 as a spinout from the Technical University of Denmark by Prof. Irina Borodina. Developed a yeast fermentation platform to produce insect sex pheromones at commercial scale for sustainable pest control. **Acquired by FMC Corporation for ~$200M in Q3 2022.** Total raised pre-acquisition: ~$19.9M. [[1]](https://agfundernews.com/fmc-buys-biophero-for-200m-to-boost-biologicals-portfolio) [[2]](https://www.prnewswire.com/news-releases/biophero-announces-17-million-series-a-for-sustainable-pest-control-301242569.html)

---

## Technology

- **Yeast Fermentation Pheromone Platform**: Uses engineered Saccharomyces cerevisiae to biosynthetically produce insect sex pheromones from renewable agricultural byproducts (plant oil and sugar residues). Dramatically reduces cost vs. chemical synthesis. Enables commercial-scale pheromone production for mating disruption pest control. [[3]](https://investindk.com/cases/biophero-from-danish-spin-out-to-global-biologicals-player)
- Target crops: corn, rice, soybean, other row crops. Applications: replace chemical insecticides with species-specific, non-toxic pheromone-based biocontrols. [[3]](https://investindk.com/cases/biophero-from-danish-spin-out-to-global-biologicals-player)
- FMC initiated commercial-scale production of BioPhero pheromone active ingredients in March 2025. [[1]](https://agfundernews.com/fmc-buys-biophero-for-200m-to-boost-biologicals-portfolio)

---

## Funding & Corporate History

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| Seed | 2018 | $2.9M | Syngenta Ventures, Novo Seeds, Syddansk Innovation |
| Series A | Mar 2021 | $17M | DCVC Bio (lead), FMC Ventures, Novo Holdings, Syngenta Ventures |
| Acquired by FMC | Q3 2022 | ~$200M | All-cash acquisition |

[[1]](https://agfundernews.com/fmc-buys-biophero-for-200m-to-boost-biologicals-portfolio) [[2]](https://www.prnewswire.com/news-releases/biophero-announces-17-million-series-a-for-sustainable-pest-control-301242569.html)

---

## References

1. AgFunder News — FMC acquires BioPhero for $200M: [https://agfundernews.com/fmc-buys-biophero-for-200m-to-boost-biologicals-portfolio](https://agfundernews.com/fmc-buys-biophero-for-200m-to-boost-biologicals-portfolio)
2. PR Newswire — $17M Series A (Mar 2021): [https://www.prnewswire.com/news-releases/biophero-announces-17-million-series-a-for-sustainable-pest-control-301242569.html](https://www.prnewswire.com/news-releases/biophero-announces-17-million-series-a-for-sustainable-pest-control-301242569.html)
3. Invest in Denmark — BioPhero story: [https://investindk.com/cases/biophero-from-danish-spin-out-to-global-biologicals-player](https://investindk.com/cases/biophero-from-danish-spin-out-to-global-biologicals-player)
