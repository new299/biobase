# Toray Industries

## Overview
Toray Industries is a public Japanese advanced materials company active across fibers, chemicals, composites, pharmaceuticals, medical products, water treatment, and related industrial technologies.[[1]](https://www.toray.com/global/news/details/20210322000602.html)[[2]](https://www.toray.com/technology/history/)

## Technology / Business
Toray’s business spans advanced materials rather than a pure biotech focus. Its public history highlights synthetic fibers, carbon fiber composites, pharmaceuticals, medical products, and other specialty materials.[[1]](https://www.toray.com/global/news/details/20210322000602.html)[[2]](https://www.toray.com/technology/history/)

## Investors
Toray is a public company listed in Japan, so its capital structure is public-market based rather than venture financed.[[1]](https://www.toray.com/global/news/details/20210322000602.html)

## Acquisitions / Other
Toray has grown partly through acquisitions. Its public history notes the 2013 acquisition of Zoltek, and in 2018 it announced the acquisition of TenCate Advanced Composites to expand advanced composites capabilities.[[2]](https://www.toray.com/technology/history/)[[3]](https://www.toraytac.com/media/5d3a82be-73b8-439c-83ed-d73a4201c0e4/-MvDAw/TAC/Documents/Press%20releases/180314_Press_release_Toray_to_acquire_TenCate_Advanced_Composites.pdf)
