# Boreal Genomics — Research Notes

## Overview

Boreal Genomics is a Vancouver, BC, Canada-based genomics company founded in 2007 by Dr. Andre Marziali (UBC Professor of Physics & Astronomy). Develops novel DNA enrichment and library construction technologies for high-accuracy sequencing in liquid biopsy and cancer diagnostics. Initially focused on liquid biopsy; pivoted to OnTarget™ high-accuracy sequencing platform and linked-molecule sequencing technology. Total raised: ~$24.9M. [[1]](https://www.genomebc.ca/impact-story/boreal-genomics) [[2]](https://www.genomeweb.com/companies/boreal-genomics)

**ARCH Venture Partners Investment** (2010 first institutional round).

---

## Technology

- **SCODA (Synchronous Coefficient of Drag Alteration)**: Core physics-based DNA enrichment method using rotating electric fields to selectively extract specific DNA sequences from complex biological samples. Enables extreme enrichment of rare mutant alleles from plasma. [[3]](https://innovation.ubc.ca/news/april-04-2024/biomedical-innovation-legacy-story-boreal-genomics)
- **OnTarget™ Platform**: Performs highly sensitive mutation detection for tumor profiling and real-time cancer monitoring from cell-free DNA in plasma. Detects up to 100 mutations across multiple genes in parallel. [[2]](https://www.genomeweb.com/companies/boreal-genomics)
- **Trovagene Partnership**: Strategic partnership with Trovagene to integrate OnTarget liquid biopsy technology. [[4]](https://www.prnewswire.com/news-releases/trovagene-and-boreal-genomics-announce-strategic-partnership-300370372.html)
- Company later pivoted to focus on linked-molecule sequencing technology rather than liquid biopsy. [[5]](https://www.genomeweb.com/sequencing/boreal-genomics-scraps-liquid-biopsy-plans-focus-linked-molecule-technology)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| First institutional round | 2010 | $6.9M | ARCH Venture Partners, others |
| Second round | 2013 | $18M | Various |
| Total | | ~$24.9M | |

[[1]](https://www.genomebc.ca/impact-story/boreal-genomics)

**ARCH Venture Partners Investment** — led 2010 institutional round.

---

## References

1. Genome BC — Boreal Genomics impact story: [https://www.genomebc.ca/impact-story/boreal-genomics](https://www.genomebc.ca/impact-story/boreal-genomics)
2. GenomeWeb — Boreal Genomics news archive: [https://www.genomeweb.com/companies/boreal-genomics](https://www.genomeweb.com/companies/boreal-genomics)
3. UBC Innovation — Boreal Genomics biomedical innovation legacy (Apr 2024): [https://innovation.ubc.ca/news/april-04-2024/biomedical-innovation-legacy-story-boreal-genomics](https://innovation.ubc.ca/news/april-04-2024/biomedical-innovation-legacy-story-boreal-genomics)
4. PR Newswire — Trovagene/Boreal Genomics partnership: [https://www.prnewswire.com/news-releases/trovagene-and-boreal-genomics-announce-strategic-partnership-300370372.html](https://www.prnewswire.com/news-releases/trovagene-and-boreal-genomics-announce-strategic-partnership-300370372.html)
5. GenomeWeb — Boreal scraps liquid biopsy for linked molecule: [https://www.genomeweb.com/sequencing/boreal-genomics-scraps-liquid-biopsy-plans-focus-linked-molecule-technology](https://www.genomeweb.com/sequencing/boreal-genomics-scraps-liquid-biopsy-plans-focus-linked-molecule-technology)
