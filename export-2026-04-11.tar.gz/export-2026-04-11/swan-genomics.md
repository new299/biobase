# SWAN Genomics

## Overview

SWAN Genomics is an Australian DNA sequencing startup commercializing a novel single-molecule sequencing approach. The company says it aims to make genomics more accessible without compromising information quality, and UNSW describes it as a staff-led spinout at proof-of-concept stage. [[1]](https://www.swangenomics.com/) [[2]](https://www.unsw.edu.au/research/partner-with-us/investment-portfolio/swan-genomics)

## Technology

UNSW's investment profile says SWAN is building an ultra-scalable, affordable, and precise single-molecule DNA sequencing platform. In February 2026, UNSW also quoted the company saying its technology surpasses current short-read and long-read constraints while maintaining information integrity. [[2]](https://www.unsw.edu.au/research/partner-with-us/investment-portfolio/swan-genomics) [[3]](https://www.unsw.edu.au/newsroom/news/2026/02/nsw-treasurer-praises-unsw-spinouts-at-fund-launch)

## Investors And Funding

Investible lists SWAN as a portfolio company in its Early Stage Fund 2 and says it invested at the pre-seed stage in 2023. Crunchbase's public profile also indicates the company has raised multiple rounds, including grant funding, and names Australian Economic Accelerator and Pacific Channel among recent investors, though exact totals are not fully visible in the public profile. [[4]](https://www.investible.com/company/swan-genomics) [[5]](https://www.crunchbase.com/organization/swan-genomics/company_financials)

## Strategic Position

SWAN positions itself as a next-generation sequencing platform company rather than a tools reseller or reagent niche player. Public descriptions emphasize population-scale affordability and deployment beyond elite research centers, including diagnostic labs and field settings. [[1]](https://www.swangenomics.com/) [[2]](https://www.unsw.edu.au/research/partner-with-us/investment-portfolio/swan-genomics)
