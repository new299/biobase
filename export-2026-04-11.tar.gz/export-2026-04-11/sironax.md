# Sironax

## Overview
Sironax is a clinical-stage biotechnology company developing therapies for age-related degenerative diseases [[1]](https://www.sironax.com/about-us/).

## Technology
The company says its pipeline targets dysregulated cellular death, uncontrolled inflammation, and disrupted energy homeostasis, with multiple clinical programs and a proprietary Brain Delivery Module platform [[1]](https://www.sironax.com/about-us/) [[2]](https://www.sironax.com/sironax-grants-novartis-exclusive-option-to-acquire-its-brain-delivery-platform-while-retaining-rights-to-advance-selected-therapeutic-assets/?id=6).

## Investors
Sironax announced a $200 million Series B in August 2022 led by Gaorong Capital and Yunfeng Capital, with participation from existing investors including Temasek, Invus, F-Prime Capital, Eight Roads, ARCH Venture Partners, K2 Venture Partners, and others [[3]](https://www.sironax.com/company-news-details.php?id=1). The company later highlighted that it had raised over $300 million since founding [[4]](https://www.sironax.com/sironax-named-to-2025-endpoints-11-list-of-the-most-promising-biotech-startups/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources, but in July 2025 Sironax granted Novartis an exclusive option to acquire its Brain Delivery Module platform in a deal that could yield up to $175 million in upfront and near-term payments [[2]](https://www.sironax.com/sironax-grants-novartis-exclusive-option-to-acquire-its-brain-delivery-platform-while-retaining-rights-to-advance-selected-therapeutic-assets/?id=6).

## References
[[1]](https://www.sironax.com/about-us/)
[[2]](https://www.sironax.com/sironax-grants-novartis-exclusive-option-to-acquire-its-brain-delivery-platform-while-retaining-rights-to-advance-selected-therapeutic-assets/?id=6)
[[3]](https://www.sironax.com/company-news-details.php?id=1)
[[4]](https://www.sironax.com/sironax-named-to-2025-endpoints-11-list-of-the-most-promising-biotech-startups/)
