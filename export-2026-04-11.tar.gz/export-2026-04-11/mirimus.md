# Mirimus

## Overview

Mirimus is a preclinical CRO and biotechnology tools company providing animal and cell models, gene editing, and RNAi-based research services to accelerate drug discovery.[[1]](https://www.mirimus.com/)

## Technology

Mirimus says its core capabilities include in vivo gene modulation, genetically engineered animal and cellular models, RNAi technologies, and other next-generation preclinical testing tools.[[1]](https://www.mirimus.com/) The company presents itself as an `XPRIZE award-winning biotech and preclinical CRO` focused on scalable and precise research models.[[1]](https://www.mirimus.com/)

## Investors

No clearly disclosed institutional financing round or investor syndicate was identified in the reviewed public sources. The company operates as a service-oriented biotech tools business, and the public site reviewed focuses on capabilities rather than fundraising.[[1]](https://www.mirimus.com/)

## Acquisitions and Strategic Transactions

No acquisition involving Mirimus was identified in the reviewed sources. The public footprint reviewed is centered on CRO services and preclinical technology offerings rather than M&A.[[1]](https://www.mirimus.com/)
