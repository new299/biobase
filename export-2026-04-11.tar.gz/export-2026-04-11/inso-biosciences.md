# Inso Biosciences — Research Notes

## Overview

Inso Biosciences (Inso Bio) is a New York, NY-based biotechnology company founded in 2018 as a spinout from Cornell University (Prof. Harold Craighead's lab), developing micropillar array microfluidic technology for rapid DNA extraction and purification from biological samples — processing samples 8–10× faster than conventional methods. The company is a SOSV/IndieBio portfolio company. Total raised: $3.64M. Key investors include 2048 Ventures, SOSV, Whitecap Venture Partners, Ataraxia Ventures, and CRCM Ventures. [[1]](https://www.2048.vc/blog/our-investment-in-inso-biosciences) [[2]](https://www.crunchbase.com/organization/inso-biosciences)

---

## Technology & Products

- **Micropillar Array DNA Extraction**: Microfluidic platform using micropillar arrays to extract and purify DNA while keeping it in solution — enabling 8–10× faster nucleic acid sample preparation than bead-based or column-based methods; applications in NGS sample prep, diagnostics, and field-deployable genomics. [[1]](https://www.2048.vc/blog/our-investment-in-inso-biosciences)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-seed | ~2022 | $2.275M | 2048 Ventures (lead), SOSV, Whitecap Venture Partners, Ataraxia Ventures, CRCM Ventures |
| Total | — | $3.64M | — |
| Grants | Ongoing | Undisclosed | USDA, NY State, IndieBio/SOSV, NSF I-Corps |

[[2]](https://www.crunchbase.com/organization/inso-biosciences)

---

## References

1. 2048 Ventures — Inso Biosciences investment: [https://www.2048.vc/blog/our-investment-in-inso-biosciences](https://www.2048.vc/blog/our-investment-in-inso-biosciences)
2. Crunchbase — Inso Biosciences: [https://www.crunchbase.com/organization/inso-biosciences](https://www.crunchbase.com/organization/inso-biosciences)

## ASeq Posts

- [Inso Biosciences](https://aseq.substack.com/p/inso-biosciences)
