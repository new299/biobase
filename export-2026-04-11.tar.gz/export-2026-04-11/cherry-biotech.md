# Cherry Biotech

## Overview
Cherry Biotech is a French life-science tools company developing microphysiological systems and organ-on-chip style platforms for drug discovery and disease modeling.[[1]](https://www.cherrybiotech.com/about-us/)[[2]](https://www.cherrybiotech.com/)

## Technology
The company says it builds human-centric preclinical systems including its CubiX platform and organoid-based workflows to study disease mechanisms, drug responses, and microenvironmental control in more physiologic settings.[[2]](https://www.cherrybiotech.com/)[[1]](https://www.cherrybiotech.com/about-us/)

## Investors
Public financing detail is limited in the reviewed source set. The company’s site and public announcements are clearer on commercial collaborations and product rollout than on a detailed venture financing history.[[1]](https://www.cherrybiotech.com/about-us/)[[3]](https://www.cherrybiotech.com/news-media/cherry-biotech-and-atelerix-announce-entering-in-an-agreement/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Cherry Biotech has publicly emphasized partnerships, including a 2025 agreement with Atelerix on organoid transport integration.[[3]](https://www.cherrybiotech.com/news-media/cherry-biotech-and-atelerix-announce-entering-in-an-agreement/)
