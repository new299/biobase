# Hyasynth — Research Notes

## Overview

Hyasynth is a Montreal, Canada-based biotechnology company and SOSV/IndieBio portfolio company developing yeast-based biosynthesis of cannabinoids — producing cannabinoids such as CBD and THC via fermentation rather than cannabis cultivation. The company uses synthetic biology to engineer Saccharomyces cerevisiae yeast to produce pure cannabinoid compounds at scale for pharmaceutical, nutraceutical, and research applications. [[1]](https://sosv.com/company/hyasynth/) [[2]](https://hyasynth.com/)

---

## Technology

- **Cannabinoid Biosynthesis via Yeast Fermentation**: Engineered S. cerevisiae producing cannabinoids (CBD, THC, CBG, and rare cannabinoids) through fermentation — enabling consistent, scalable, and solvent-free production without agriculture, extraction, or purification challenges of plant-derived cannabinoids. [[2]](https://hyasynth.com/)

---

## Funding & Investors

SOSV / IndieBio portfolio company. Additional funding details not publicly available.

---

## References

1. SOSV — Hyasynth portfolio: [https://sosv.com/company/hyasynth/](https://sosv.com/company/hyasynth/)
2. Hyasynth — Homepage: [https://hyasynth.com/](https://hyasynth.com/)
