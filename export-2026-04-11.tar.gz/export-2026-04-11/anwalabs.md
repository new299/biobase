## Anwa Labs – Company Summary

Anwa Labs (Anwa Medical Labs / Anwa Biosciences) is a Saudi Arabia–based genomics diagnostics company headquartered in Riyadh, focused on advancing precision medicine through genetic testing and sequencing technologies ([Source 1](https://anwalabs.com), [Source 2](https://dharab.com/dbentry/anwa-labs/)).

### Approach

Anwa’s approach centers on **genomic profiling and next-generation sequencing (NGS)** to decode genetic data and apply it to clinical decision-making, particularly in oncology and hereditary diseases ([Source 1](https://anwalabs.com), [Source 3](https://anwalabs.com/about-us/)).

- Uses next-generation sequencing and bioinformatics analysis  
- Focuses on cancer genomics and inherited genetic conditions  
- Provides high-throughput sequencing and molecular profiling services  
- Enables personalized treatment selection and disease monitoring  

The company offers services such as hereditary cancer testing, solid tumor profiling, and myeloid molecular profiling, leveraging advanced sequencing platforms (e.g., Illumina MiSeq, Ion Torrent S5) ([Source 3](https://anwalabs.com/about-us/), [Source 4](https://anwalabs.com/services/myeloid-molecular-profiling/)).

### Market & Positioning

Anwa operates in the **clinical genomics and precision medicine diagnostics market**, with a strong regional focus on Saudi Arabia and the broader MENA region.

- Runs genomic profiling programs across multiple cancer types (lung, breast, ovarian, bladder)  
- Supports over 30 hospitals through nationwide programs  
- Positioned as a local provider of advanced genomic diagnostics to reduce reliance on overseas testing  

([Source 2](https://dharab.com/dbentry/anwa-labs/), [Source 5](https://www.businesswire.com/news/home/20220721005275/en/Imagia-Canexia-Health-and-Anwa-Medical-Company-Enter-Memorandum-of-Understanding-to-Bring-Liquid-Biopsy-to-Middle-East-and-North-Africa-MENA))

### Partnerships & Technology

Anwa has engaged in partnerships to expand advanced diagnostics capabilities, including a collaboration with Imagia Canexia Health to bring **liquid biopsy and AI-enabled cancer testing** to the MENA region ([Source 5](https://www.businesswire.com/news/home/20220721005275/en/Imagia-Canexia-Health-and-Anwa-Medical-Company-Enter-Memorandum-of-Understanding-to-Bring-Liquid-Biopsy-to-Middle-East-and-North-Africa-MENA)).

### Investors

No clearly disclosed venture investors or funding sources are publicly available.

### Funding

No publicly disclosed funding rounds or capital raised identified.

### Status

- Active  
- Privately held  
- Operating clinical genomics laboratory  
- Focused on regional expansion in MENA  

---

Overall, Anwa Labs is an active genomics diagnostics company providing next-generation sequencing–based testing and precision oncology solutions, with a strong emphasis on localizing advanced healthcare infrastructure in the Middle East.
