# Bruker — Spatial Proteomics & Multi-Omics Imaging Platforms

**Website:** https://www.bruker.com

---

# Company overview

**Bruker Corporation** is a publicly traded scientific instrumentation company focused on life-science tools, mass spectrometry, and analytical systems used in proteomics, metabolomics, spatial biology, and clinical research. :contentReference[oaicite:0]{index=0}  

The company develops mass spectrometry–based platforms and imaging workflows that enable **spatial proteomics and multi-omics imaging directly from tissue samples**, a rapidly growing field within cancer, neuroscience, and immunology research. :contentReference[oaicite:1]{index=1}  

---

# Investors / Public market status

Bruker is a **publicly traded company (NASDAQ: BRKR)**, meaning investors include public shareholders rather than venture capital investors. :contentReference[oaicite:2]{index=2}  

Bruker has also made **strategic investments** to expand spatial biology capabilities, including an investment in **AmberGen Inc.** to support multiplexed spatial proteomics workflows. :contentReference[oaicite:3]{index=3}  

---

# Strategic acquisitions and partnerships relevant to spatial biology

## Canopy Biosciences acquisition
Bruker acquired **Canopy Biosciences** to strengthen spatial proteomics capabilities. :contentReference[oaicite:4]{index=4}  

The acquisition added the **ChipCytometry platform**, enabling high-plex spatial proteomics and single-cell imaging workflows. :contentReference[oaicite:5]{index=5}  

## AmberGen strategic investment
Bruker made a **strategic investment in AmberGen Inc.** to enable peptide-coded antibody workflows for multiplex tissue imaging. :contentReference[oaicite:6]{index=6}  

---

# Core spatial proteomics and multi-omics platforms

Bruker’s spatial biology strategy combines **mass spectrometry imaging (MSI)**, **single-cell proteomics**, and **multiplexed antibody imaging** into integrated workflows.

---

## 1) timsTOF fleX platform (flagship spatial proteomics + multiomics)

The **timsTOF fleX** platform integrates MALDI imaging with deep proteomics workflows. :contentReference[oaicite:7]{index=7}  

Key capabilities:

- Enables **multiplexed spatial protein mapping** using MALDI HiPLEX-IHC workflows. :contentReference[oaicite:8]{index=8}  
- Combines **targeted protein imaging with unbiased lipidomics, glycomics, and metabolomics** from the same tissue section. :contentReference[oaicite:9]{index=9}  
- Can identify **up to 13,000 proteins** with dia-PASEF proteomics workflows. :contentReference[oaicite:10]{index=10}  
- Identifies **>8,000 proteins in ~35 minutes** from deep libraries. :contentReference[oaicite:11]{index=11}  

This ability to combine targeted and untargeted modalities from the same tissue section is described as a **unique multi-omics capability**. :contentReference[oaicite:12]{index=12}  

---

## 2) MALDI HiPLEX-IHC (multiplex spatial proteomics)

MALDI HiPLEX-IHC combines:

- Peptide-coded antibody probes  
- Mass spectrometry imaging  
- Wide-field tissue imaging  

This allows **highly multiplexed protein expression mapping** across tissue slides. :contentReference[oaicite:13]{index=13}  

Applications include:

- Immuno-oncology  
- Tumor microenvironment (TME) research  
- Metastasis studies :contentReference[oaicite:14]{index=14}  

---

## 3) Canopy CellScape / ChipCytometry platform

The **Canopy CellScape ChipCytometry platform** enables:

- Iterative staining workflows  
- Open-source antibody use  
- Highly quantitative single-cell spatial proteomics :contentReference[oaicite:15]{index=15}  

This allows **virtually unlimited immuno-oncology marker analysis** on whole tissue sections. :contentReference[oaicite:16]{index=16}  

---

## 4) timsTOF SCP — single-cell proteomics

The **timsTOF SCP platform** enables **unbiased single-cell proteomics**, complementing single-cell RNA-seq in spatial biology workflows. :contentReference[oaicite:17]{index=17}  

This supports the emerging **multi-modal spatial biology paradigm**. :contentReference[oaicite:18]{index=18}  

---

## 5) neofleX MALDI-TOF spatial biology system (2024)

The **neofleX MALDI-TOF system** expands spatial multi-omics imaging. :contentReference[oaicite:19]{index=19}  

Capabilities include simultaneous spatial imaging of:

- Proteins  
- Glycans  
- Metabolites  
- Lipids  
- Endogenous peptides  
- Xenobiotics  
- RNA and DNA (via MALDI-ISH) :contentReference[oaicite:20]{index=20}  

This allows **correlation of proteins with nucleic acids and metabolites in tissue**. :contentReference[oaicite:21]{index=21}  

---

# Multi-omics data analysis software

Bruker integrates multi-omics imaging data using software platforms:

## SCiLS Lab
SCiLS Lab enables:

- Automated segmentation  
- Statistical profiling  
- Integrated multi-omics analysis :contentReference[oaicite:22]{index=22}  

## MetaboScape
MetaboScape supports:

- Lipid and metabolite annotation  
- Stable isotope workflows  
- Integration with MassQL queries :contentReference[oaicite:23]{index=23}  

Together, these tools provide an **end-to-end spatial biology workflow** from tissue imaging to analysis. :contentReference[oaicite:24]{index=24}  

---

# Technology stack summary

Bruker’s spatial biology approach is based on **mass spectrometry imaging (MSI)** combined with multiplexed antibody labeling and deep proteomics.

Core technological pillars:

| Layer | Technology |
|---|---|
| Molecular imaging | MALDI mass spectrometry imaging |
| Proteomics | dia-PASEF 4D proteomics |
| Single-cell proteomics | timsTOF SCP |
| Multiplex antibody imaging | MALDI HiPLEX-IHC |
| Multi-omics integration | Lipidomics, glycomics, metabolomics, transcript imaging |
| Software | SCiLS Lab + MetaboScape |

All modalities can be applied to the **same tissue section**, enabling true spatial multi-omics. :contentReference[oaicite:25]{index=25}  

---

# Patents and IP positioning (inferred from platform launches)

Bruker’s spatial biology IP strategy is primarily reflected in:

- MALDI HiPLEX-IHC workflows  
- dia-PASEF proteomics methods  
- TIMScore algorithm for phosphopeptide identification :contentReference[oaicite:26]{index=26}  

The TIMScore algorithm enables **>25% more phosphopeptide identification**, highlighting ongoing algorithmic innovation. :contentReference[oaicite:27]{index=27}  

---

# Strategic positioning in spatial biology

Bruker is positioned as a **mass-spec-first spatial biology company**, differentiated by:

1. Mass-spectrometry imaging vs fluorescence imaging competitors  
2. Ability to measure **proteins + metabolites + lipids + glycans + RNA/DNA** in one workflow  
3. Integration of **single-cell proteomics and spatial proteomics**

This positions Bruker as a major instrumentation provider for **next-generation spatial multi-omics research**. :contentReference[oaicite:28]{index=28}  

---
