# Prevention Genetics

**Prevention Genetics** is a **comprehensive hereditary disease genetic testing laboratory** based in the United States, providing clinical genetic testing services covering **nearly all clinically relevant genes** and supporting patients, clinicians, researchers, and clinical trials worldwide. [[1]](https://preventiongenetics.com/) [[0]](https://preventiongenetics.com/about)

## Company Overview

- **Founded:** 2004 by Dr. James Weber, a contributor to the Human Genome Project. [[1]](https://preventiongenetics.com/)  
- **Headquarters:** **Marshfield, Wisconsin, USA** (laboratory and corporate office). [[0]](https://preventiongenetics.com/about)  
- **Accreditations:** CLIA certified and ISO 15189:2012 accredited, ensuring high standards in clinical genetic testing. [[0]](https://preventiongenetics.com/about)  
- **Ownership:** **Wholly owned subsidiary of Exact Sciences Corporation** (acquired in January 2022 for $190 million, combining Prevention Genetics’ testing portfolio with Exact Sciences’ cancer diagnostics business). [[6]](https://investor.exactsciences.com/investor-relations/press-releases/press-release-details/2022/Exact-Sciences-Acquires-PreventionGenetics-to-Accelerate-Availability-of-Hereditary-Cancer-Testing-for-More-Patients/default.aspx)

## Mission & Services

Prevention Genetics provides **genetic testing services** that help clinicians diagnose and manage hereditary diseases, rare disorders, and cancer risk. The company’s services include:  
- **Targeted gene panels** for specific disorders and disease categories. [[0]](https://preventiongenetics.com/about)  
- **Comprehensive sequencing** tests for nearly all clinically relevant human genes. [[1]](https://preventiongenetics.com/)  
- **Whole exome (PGxome®) and whole genome (PGnome®) sequencing**, plus custom test designs. [[1]](https://preventiongenetics.com/)  
- **Clinical reporting and genetic counseling support** to guide result interpretation. [[0]](https://preventiongenetics.com/about)

Clinical test menus cover **hereditary disease categories** such as metabolic, neurological, cardiovascular, immunological, muscular, and developmental disorders — often providing multiple test options for gene panels, exomes, or genomes. The lab’s capabilities extend to **supporting clinical trials** with custom test design and rapid turnaround for germline disease studies. [[2]](https://preventiongenetics.com/clinical-trials-and-research-services) [[9]](https://www.ncbi.nlm.nih.gov/gtr/labs/239772/)

### Sponsored & No‑Cost Programs

Prevention Genetics collaborates with biopharma and advocacy organizations to offer **sponsored testing programs** for patients meeting clinical criteria, including tests for:  
- **Hereditary transthyretin amyloidosis** (hATTR) with AstraZeneca partnership. [[5]](https://preventiongenetics.com/sponsoredTesting/)  
- **Friedreich ataxia** with Biogen sponsorship. [[5]](https://preventiongenetics.com/sponsoredTesting/)  
- **Hypoparathyroidism, ALS, obesity genetics, and other rare conditions** with partners such as Ionis, Rhythm, UCB, and others. [[5]](https://preventiongenetics.com/sponsoredTesting/)  
These programs can provide no‑charge genetic testing when ordered by qualified healthcare providers under sponsor eligibility criteria. [[5]](https://preventiongenetics.com/sponsoredTesting/)

## Market & Use Cases

Prevention Genetics serves multiple healthcare and research segments:  
- **Clinical diagnostics** for hereditary diseases and rare disorders. [[1]](https://preventiongenetics.com/)  
- **Cancer risk and hereditary cancer panel testing**, particularly after the acquisition by **Exact Sciences**, enhancing broader cancer diagnostics reach. [[6]](https://investor.exactsciences.com/investor-relations/press-releases/press-release-details/2022/Exact-Sciences-Acquires-PreventionGenetics-to-Accelerate-Availability-of-Hereditary-Cancer-Testing-for-More-Patients/default.aspx)  
- **Clinical trial support** for pharmaceutical and gene discovery research. [[2]](https://preventiongenetics.com/clinical-trials-and-research-services)

## Technology & Expertise

- Prevention Genetics uses **next‑generation sequencing (NGS)**, **copy number variant (CNV) detection**, **exome and genome sequencing**, and custom panel testing to detect inherited mutations across a broad spectrum of genes. [[10]](https://preventiongenetics.com/articles/preventiongenetics-comprehensive-menu-of-endocrinology-genetic-tests-helps-you-treat-patients-with-common-or-rare-conditions)  
- The laboratory employs experienced **PhD geneticists, laboratory genetic counselors, and specialized analysts** to curate and interpret results. [[3]](https://preventiongenetics.com/About/Company/genetics-experts)

## Status & Activity

- **Active clinical genetics testing service:** preventiongenetics.com continues to offer testing globally with patient samples accepted from multiple countries. [[1]](https://preventiongenetics.com/)  
- **Part of Exact Sciences:** Integration into Exact Sciences expands the company’s role in hereditary cancer testing and complementary diagnostics alongside tests like Cologuard® and Oncotype DX®. [[6]](https://investor.exactsciences.com/investor-relations/press-releases/press-release-details/2022/Exact-Sciences-Acquires-PreventionGenetics-to-Accelerate-Availability-of-Hereditary-Cancer-Testing-for-More-Patients/default.aspx)

## Summary

Prevention Genetics is a **well‑established genetic testing laboratory** with over 20 years of experience providing **comprehensive hereditary disease testing**, including gene panels, exome and genome sequencing, and test customization. It supports clinicians, researchers, and clinical trials worldwide and is now a **subsidiary of Exact Sciences**, enhancing its impact on hereditary cancer and inherited disease diagnostics. [[1]](https://preventiongenetics.com/) [[6]](https://investor.exactsciences.com/investor-relations/press-releases/press-release-details/2022/Exact-Sciences-Acquires-PreventionGenetics-to-Accelerate-Availability-of-Hereditary-Cancer-Testing-for-More-Patients/default.aspx)

## References

1. PreventionGenetics official site — testing overview and capabilities. https://preventiongenetics.com/ turn0search1  
2. Clinical trial and research genetic testing services. https://preventiongenetics.com/clinical-trials-and-research-services turn0search2  
3. Laboratory genetics experts & staff. https://preventiongenetics.com//About/Company/genetics-experts turn0search3  
5. Sponsored testing programs partnerships. https://preventiongenetics.com/sponsoredTesting/ turn0search5  
6. Exact Sciences acquisition press release. https://investor.exactsciences.com/investor-relations/press-releases/press-release-details/2022/Exact-Sciences-Acquires-PreventionGenetics-to-Accelerate-Availability-of-Hereditary-Cancer-Testing-for-More-Patients/default.aspx turn0search6
