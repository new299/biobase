# Jaguar Gene Therapy

## Overview

Jaguar Gene Therapy is a private gene therapy company developing AAV-based medicines for severe genetic diseases. At launch in 2021, the company said it was created in collaboration with Deerfield Management and led by former AveXis executives.[[1]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-launches-with-mission-to-accelerate-breakthroughs-in-gene-therapy-for-patients-suffering-from-severe-genetic-diseases/)

## Technology

Jaguar's early platform centered on the AAV9 vector and internally built chemistry, manufacturing and controls (`CMC`) capabilities.[[1]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-launches-with-mission-to-accelerate-breakthroughs-in-gene-therapy-for-patients-suffering-from-severe-genetic-diseases/) The company initially highlighted programs for galactosemia, SHANK3-related neurodevelopmental disease including Phelan-McDermid syndrome, and Type 1 diabetes.[[1]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-launches-with-mission-to-accelerate-breakthroughs-in-gene-therapy-for-patients-suffering-from-severe-genetic-diseases/) In February 2026, Jaguar reported ongoing clinical dosing for JAG201 in Phelan-McDermid syndrome.[[2]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-announces-successful-completion-of-dosing-of-first-patient-cohort-in-clinical-trial-evaluating-jag201-for-the-treatment-of-a-leading-monogenic-cause-of-autism-spectrum-disorder-kno/)

## Investors

Jaguar launched with Deerfield Management backing its Series A financing.[[1]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-launches-with-mission-to-accelerate-breakthroughs-in-gene-therapy-for-patients-suffering-from-severe-genetic-diseases/) In April 2021, it announced a $139 million Series B co-led by Eli Lilly and Company and Deerfield Management, with participation from ARCH Venture Partners, Goldman Sachs, and Nolan Capital.[[3]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-closes-139-million-series-b-funding-co-led-by-eli-lilly-and-company-and-deerfield-management/) In March 2022, Jaguar added Samsung Ventures and the JDRF T1D Fund as new investors.[[4]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-announces-samsung-and-jdrf-t1d-fund-as-new-investors/)

## Acquisitions and Strategic Transactions

No acquisition involving Jaguar Gene Therapy was identified in the reviewed sources. Its public strategic activity has centered on fundraising, manufacturing buildout, and clinical advancement rather than M&A.[[3]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-closes-139-million-series-b-funding-co-led-by-eli-lilly-and-company-and-deerfield-management/) [[2]](https://jaguargenetherapy.com/press-release/jaguar-gene-therapy-announces-successful-completion-of-dosing-of-first-patient-cohort-in-clinical-trial-evaluating-jag201-for-the-treatment-of-a-leading-monogenic-cause-of-autism-spectrum-disorder-kno/)
