# Caerus Molecular Diagnostics — Research Notes

## Overview

Caerus Molecular Diagnostics Inc. is a small molecular diagnostics company developing engineered enzyme-switch technology as a molecular amplifier for single-molecule DNA sequencing signal detection. Primarily SBIR/NIH grant-funded; limited venture investment. Total raised: ~$1.2M (NIH SBIR grants). [[1]](https://www.sbir.gov/sbc/caerus-molecular-diagnostics-inc) [[2]](https://www.cbinsights.com/company/caerus-molecular-diagnostic)

---

## Technology

- **Engineered Enzyme Switch**: A molecular amplifier that converts the product of a single-molecule DNA sequencing reaction into many copies of a reporter molecule that are easily detected. Designed to improve signal detection sensitivity for single-molecule sequencing. [[1]](https://www.sbir.gov/sbc/caerus-molecular-diagnostics-inc)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| SBIR Grant | 2014 | ~$700K | NIH |
| Total SBIR | ~2012–2014 | ~$1.2M | NIH |

Total raised: ~$1.2M (NIH grant-funded). [[2]](https://www.cbinsights.com/company/caerus-molecular-diagnostic)

---

## References

1. SBIR.gov — Caerus Molecular Diagnostics: [https://www.sbir.gov/sbc/caerus-molecular-diagnostics-inc](https://www.sbir.gov/sbc/caerus-molecular-diagnostics-inc)
2. CBInsights — Caerus Molecular Diagnostic: [https://www.cbinsights.com/company/caerus-molecular-diagnostic](https://www.cbinsights.com/company/caerus-molecular-diagnostic)
