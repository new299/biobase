# PHINOMICS

## Overview
PHINOMICS is a cancer intelligence platform company focused on decoding circular DNA and cryptic proteins to improve oncology target discovery, biomarker development, and precision medicine.[[1]](https://www.phinomics.com/)

## Technology
The company says it isolates and decodes circular DNA and cryptic proteins, aiming to uncover hidden drivers of oncogenesis, resistance, and relapse that are missed by conventional sequencing approaches.[[1]](https://www.phinomics.com/)

## Investors
I did not identify a public financing announcement in the reviewed source set. The company’s visible public footprint is still platform- and science-oriented rather than financing-disclosure-heavy.[[1]](https://www.phinomics.com/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.phinomics.com/)
