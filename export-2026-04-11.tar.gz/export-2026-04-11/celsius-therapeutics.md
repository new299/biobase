# Celsius Therapeutics

## Overview
Celsius Therapeutics was a clinical-stage biotechnology company developing novel medicines for inflammatory disease, with CEL383 as its lead anti-TREM1 antibody candidate for inflammatory bowel disease.[[1]](https://news.abbvie.com/2024-06-27-AbbVie-Acquires-Celsius-Therapeutics)[[2]](https://www.abbvie.com/celsius-therapeutics.html)

## Technology
AbbVie described CEL383 as a potential first-in-class antibody against TREM1, a target implicated in inflammatory monocytes and neutrophils and positioned as an amplifier of inflammatory signaling in IBD.[[1]](https://news.abbvie.com/2024-06-27-AbbVie-Acquires-Celsius-Therapeutics)

## Investors
The reviewed public source set here is strongest on the exit rather than the private financing history. Public M&A databases describe Celsius as Third Rock-backed, but the clearest primary-source fact is the later cash acquisition by AbbVie.[[1]](https://news.abbvie.com/2024-06-27-AbbVie-Acquires-Celsius-Therapeutics)[[3]](https://mergr.com/celsius-therapeutics-overview)

## Acquisitions / Other
AbbVie acquired Celsius Therapeutics on June 27, 2024 for $250 million in cash, subject to customary adjustments.[[1]](https://news.abbvie.com/2024-06-27-AbbVie-Acquires-Celsius-Therapeutics)
