# Nido Biosciences

## Overview
Nido Biosciences is a clinical-stage company developing precision medicines for neurological diseases.[[1]](https://nidobio.com/)[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases) The company says its strategy is based on advances in human genetics and disease biology.[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases)

## Technology and Pipeline
At emergence from stealth, Nido said it was building a pipeline of novel small-molecule precision medicines for debilitating neurological diseases, with an initial focus on genetically validated mechanisms.[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases) The company site presents it as a precision-neurology company and publicly lists leadership, scientific advisers, and investors rather than a broad marketed product portfolio.[[1]](https://nidobio.com/)

## Investors
Nido announced in May 2023 that it had raised a combined $109 million across seed, Series A, and Series B financings.[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases) The Series A was co-led by 5AM Ventures, Abingworth, and Bessemer Venture Partners, with participation from Osage University Partners and Eli Lilly and Company, while Bioluminescence Ventures led the Series B with participation from additional new and existing investors.[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases)

## Acquisitions and Corporate Activity
No acquisition involving Nido Biosciences was identified in the reviewed public sources. A notable formation detail is that Nido was founded through the 4:59 Initiative at 5AM Ventures.[[2]](https://www.businesswire.com/news/home/20230515005029/en/Nido-Biosciences-Emerges-as-Clinical-Stage-Company-Raising-%24109-Million-to-Advance-Treatments-for-Debilitating-Neurological-Diseases)
