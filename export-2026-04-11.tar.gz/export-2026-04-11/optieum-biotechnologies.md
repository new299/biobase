# Optieum Biotechnologies

## Overview
Optieum Biotechnologies is a Japanese biotechnology company developing next-generation CAR-T cell therapies.[[1]](https://optieumbio.com/)[[2]](https://optieumbio.com/optieum-biotechnologies-inc-secures-series-a-financing-and-appoints-board-of-directors/) The company is focused on solid-tumor and hematologic applications using engineered CAR constructs.[[1]](https://optieumbio.com/)

## Technology and Pipeline
Optieum says its core platform is the Eumbody System, a CAR discovery engine that empirically optimizes CAR binding domains to improve immune-cell function.[[1]](https://optieumbio.com/) The company identifies OPTF01, a FAPalpha-targeting CAR-T candidate for glioblastoma and other solid tumors, as its lead program.[[2]](https://optieumbio.com/optieum-biotechnologies-inc-secures-series-a-financing-and-appoints-board-of-directors/)

## Investors
Optieum announced in September 2021 that it raised JPY290 million, approximately $2.6 million, in seed funding led by ANRI with participation from Real Tech Fund, Iyogin Capital, and an angel investor.[[3]](https://optieumbio.com/wp-content/uploads/2021/09/20210930_Optieum-Biotechnologies-Raises-JPY-290-million-in-Seed-Round-Funding.pdf) In January 2025 it announced a JPY1.33 billion Series A led by Saisei Ventures with participation from Keio Innovation Initiatives, ZEON Corporation, Kobe University Capital, and existing investors ANRI, UntroD Capital Japan, and Iyogin Capital.[[2]](https://optieumbio.com/optieum-biotechnologies-inc-secures-series-a-financing-and-appoints-board-of-directors/)

## Acquisitions and Corporate Activity
No acquisition involving Optieum was identified in the reviewed public sources. The public record instead highlights collaborations with Daiichi Sankyo, the National Cancer Center Japan, GI CELL, Genezen, and Cellipont to advance its CAR-T programs.[[1]](https://optieumbio.com/)
