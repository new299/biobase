# Artiva Biotherapeutics

## Overview
Artiva Biotherapeutics is a clinical-stage biotechnology company focused on allogeneic NK cell-based therapies for autoimmune diseases and cancer.[[1]](https://investors.artivabio.com/)[[2]](https://investors.artivabio.com/News-and-Events/news/news-details/2025/Artiva-Biotherapeutics-Reports-First-Quarter-2025-Financial-Results-Recent-Business-Highlights/default.aspx) Its lead program is AlloNK, also known as AB-101.[[2]](https://investors.artivabio.com/News-and-Events/news/news-details/2025/Artiva-Biotherapeutics-Reports-First-Quarter-2025-Financial-Results-Recent-Business-Highlights/default.aspx)

## Technology and Pipeline
Artiva says AlloNK is a non-genetically modified, cryopreserved allogeneic NK cell therapy candidate designed to enhance antibody-dependent cellular cytotoxicity and drive B-cell depletion.[[2]](https://investors.artivabio.com/News-and-Events/news/news-details/2025/Artiva-Biotherapeutics-Reports-First-Quarter-2025-Financial-Results-Recent-Business-Highlights/default.aspx) The company is evaluating the program across autoimmune diseases and also has CAR-NK candidates in oncology.[[2]](https://investors.artivabio.com/News-and-Events/news/news-details/2025/Artiva-Biotherapeutics-Reports-First-Quarter-2025-Financial-Results-Recent-Business-Highlights/default.aspx)

## Investors
In February 2021, Artiva announced a $120 million Series B led by Venrock Healthcare Capital Partners, with participation from 5AM Ventures, RA Capital Management, venBio Partners, GC LabCell, GC, and several crossover investors including EcoR1, Logos Capital, Surveyor Capital, Wellington Management, Franklin Templeton, and others.[[3]](https://investors.artivabio.com/News-and-Events/news/news-details/2021/Artiva-Biotherapeutics-Raises-120-Million-in-Series-B-Financing-to-Advance-Pipeline-of-Allogeneic-NK-Cell-Therapies/default.aspx) The local 5AM note is directly supported by that financing announcement.

## Acquisitions and Corporate Activity
I did not identify an acquisition involving Artiva in the reviewed public sources. The public record centers on its IPO, clinical progress, and financing runway into 2027.[[1]](https://investors.artivabio.com/)[[4]](https://investors.artivabio.com/News-and-Events/news/news-details/2026/Artiva-Biotherapeutics-Reports-Full-Year-2025-Financial-Results-and-Recent-Business-Highlights/default.aspx)
