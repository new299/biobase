# AAVantgarde

## Overview
AAVantgarde is a clinical-stage biotechnology company developing gene therapies for inherited retinal diseases.[[1]](https://www.aavantgarde.com/company/)[[2]](https://www.aavantgarde.com/en/about-us/) The company originated from research at TIGEM and the University of Naples Federico II.[[1]](https://www.aavantgarde.com/company/)

## Technology and Pipeline
AAVantgarde says it has two proprietary AAV-based large-gene delivery platforms, one based on dual-hybrid DNA recombination and one based on protein trans-splicing with inteins.[[3]](https://www.aavantgarde.com/en/news/aavantgarde-closes-61-million-series-a-financing-to-advance-two-therapeutic-programs-into-the-clinic/) Its programs target inherited retinal diseases including Stargardt disease and Usher 1B syndrome.[[4]](https://www.aavantgarde.com/en/news/aavantgarde-closes-141-million-series-b-financing/)

## Investors
AAVantgarde states that it was supported by a seed round in June 2021 led by Sofinnova Partners-Telethon Fund, followed by a EUR61 million Series A in June 2023 co-led by Atlas Venture and Forbion with participation from Sofinnova Partners-Telethon Fund and Longwood Fund.[[1]](https://www.aavantgarde.com/company/)[[3]](https://www.aavantgarde.com/en/news/aavantgarde-closes-61-million-series-a-financing-to-advance-two-therapeutic-programs-into-the-clinic/) In November 2025 it closed a $141 million Series B co-led by Schroders Capital, Atlas Venture, and Forbion, with participation from Amgen Ventures, Athos KG, CDP Venture Capital, Columbia IMC, Neva SGR, Sixty Degree Capital, XGen Venture, Willett Advisors, Longwood Fund, and Sofinnova Partners.[[4]](https://www.aavantgarde.com/en/news/aavantgarde-closes-141-million-series-b-financing/)

## Acquisitions and Corporate Activity
No acquisition involving AAVantgarde was identified in the reviewed public sources. The public record centers on financing and clinical development of its inherited-retinal-disease programs.[[1]](https://www.aavantgarde.com/company/)[[4]](https://www.aavantgarde.com/en/news/aavantgarde-closes-141-million-series-b-financing/)
