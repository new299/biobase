# Reneo Pharmaceutical

## Overview
Reneo Pharmaceuticals was a clinical-stage biopharmaceutical company focused on therapies for genetically defined mitochondrial disease and related rare conditions before its merger into OnKure [[1]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/reneo-pharmaceuticals-and-onkure-announce-proposed-merger/).

## Technology
Before the merger, Reneo's lead program was mavodelpar, a PPAR-delta agonist studied in mitochondrial myopathies and related metabolic disorders, though the reviewed source focused on the corporate transaction rather than detailed platform science [[1]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/reneo-pharmaceuticals-and-onkure-announce-proposed-merger/).

## Investors
Reneo's terminal strategic financing event was the concurrent $65 million private placement completed alongside the merger with OnKure. New and existing investors included Acorn Bioventures, Cormorant Asset Management, Deep Track Capital, Perceptive Advisors, Samsara BioCapital, Surveyor Capital, Vestal Point Capital, and others [[2]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/onkure-announces-closing-merger-reneo-pharmaceuticals-and).

## Acquisitions / Strategic Transactions
Reneo announced a proposed all-stock reverse merger with OnKure in May 2024 and the transaction closed in October 2024, after which the combined company operated as OnKure Therapeutics [[1]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/reneo-pharmaceuticals-and-onkure-announce-proposed-merger/) [[2]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/onkure-announces-closing-merger-reneo-pharmaceuticals-and).

## References
[[1]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/reneo-pharmaceuticals-and-onkure-announce-proposed-merger/)
[[2]](https://investors.onkuretherapeutics.com/news-releases/news-release-details/onkure-announces-closing-merger-reneo-pharmaceuticals-and)
