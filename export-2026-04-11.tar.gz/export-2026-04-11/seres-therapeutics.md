# Seres Therapeutics

## Overview
Seres Therapeutics is a clinical-stage biotechnology company developing live biotherapeutics based on rationally selected bacterial consortia [[1]](https://www.serestherapeutics.com/about-us/) [[2]](https://ir.serestherapeutics.com/).

## Technology
The company says it pioneered the development and FDA approval of the first oral live biotherapeutic, VOWST, and continues to develop cultivated live biotherapeutic candidates [[1]](https://www.serestherapeutics.com/about-us/).

## Investors
As a public company, Seres is financed through public markets. In connection with its 2024 VOWST transaction, Nestle also made an equity investment in Seres as part of the deal economics [[3]](https://ir.serestherapeutics.com/news-releases/news-release-details/seres-therapeutics-announces-signing-vowsttm-asset-purchase).

## Acquisitions / Strategic Transactions
Seres signed and then completed the sale of its VOWST business to Nestle Health Science in 2024, receiving approximately $175 million at closing plus additional staged payments and potential future milestones [[3]](https://ir.serestherapeutics.com/news-releases/news-release-details/seres-therapeutics-announces-signing-vowsttm-asset-purchase) [[4]](https://ir.serestherapeutics.com/news-releases/news-release-details/seres-therapeutics-announces-completion-vowsttm-asset-sale).

## References
[[1]](https://www.serestherapeutics.com/about-us/)
[[2]](https://ir.serestherapeutics.com/)
[[3]](https://ir.serestherapeutics.com/news-releases/news-release-details/seres-therapeutics-announces-signing-vowsttm-asset-purchase)
[[4]](https://ir.serestherapeutics.com/news-releases/news-release-details/seres-therapeutics-announces-completion-vowsttm-asset-sale)
