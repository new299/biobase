# PlasmaGen Biosciences

## Overview
PlasmaGen BioSciences is an Indian biopharmaceutical company focused on plasma protein and specialty care therapies.[[1]](https://www.plasmagen.com/about_us)

## Technology / Products
The company says it provides plasma-derived and specialty care therapies across neurology, hematology, oncology, immunology, pediatrics, rheumatology, gynecology, critical care, transplantation, and dermatology.[[1]](https://www.plasmagen.com/about_us)

## Investors
Recent public reporting states that PlasmaGen raised Rs 150 crore in a minority equity financing round in December 2025 led by ViNS Bioproducts, with participation from HNIs, family offices, pharma entrepreneurs, and existing investors. Reporting also notes backing from Eight Roads Ventures and total funding above Rs 600 crore.[[2]](https://www.business-standard.com/companies/news/companies-plasmagen-biosciences-raises-rs-150-crore-overseas-expansion-125122200476_1.html)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Current public reporting centers on scaling international operations and portfolio expansion.[[2]](https://www.business-standard.com/companies/news/companies-plasmagen-biosciences-raises-rs-150-crore-overseas-expansion-125122200476_1.html)
