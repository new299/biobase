# Century Therapeutics — Research Notes

## Overview

Century Therapeutics, Inc. (NASDAQ: IPSC) is a Philadelphia, PA-based clinical-stage biopharmaceutical company developing allogeneic ("off-the-shelf") induced pluripotent stem cell (iPSC)-derived cell therapies for autoimmune diseases and cancer. Co-founded by Versant Ventures and Bristol Myers Squibb. Cash and marketable securities of $132.7M as of Sep 30, 2025; runway into Q4 2027. [[1]](https://www.centurytx.com/) [[2]](https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-third-quarter-2025-financial-results)

---

## Technology

- **iPSC-Derived Allogeneic Cell Therapies**: Uses induced pluripotent stem cells as an unlimited, genetically defined manufacturing starting material for NK cell and T cell therapies. Enables standardized, "off-the-shelf" manufacturing at scale. [[1]](https://www.centurytx.com/)
- **Allo-Evasion™ 5.0**: Proprietary multiplex genome-editing platform engineering immune evasion into allogeneic cell therapies to resist rejection by the host immune system (allogeneic immune cells and antibody-mediated rejection). [[3]](https://www.nasdaq.com/articles/century-therapeutics-announces-pipeline-re-prioritization-focus-transformational-programs)
- **CNTY-101**: iPSC-derived allogeneic anti-CD19 CAR-NK therapy. Phase 1/2 investigator-initiated trial (IIT) in B-cell-mediated autoimmune diseases (Professors Schett and Mackensen, Germany); first allogeneic iPSC-derived CD19 NK cell therapy in autoimmune disease clinical evaluation. [[4]](https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-second-quarter-2025-financial)
- **CNTY-308**: CD19-targeted CD4+/CD8+ αβ CAR-iT cell therapy with Allo-Evasion™ 5.0 for B-cell-mediated autoimmune diseases and malignancies. IND-enabling; EULAR 2025 data demonstrated rapid B cell ablation and immune evasion. [[3]](https://www.nasdaq.com/articles/century-therapeutics-announces-pipeline-re-prioritization-focus-transformational-programs)
- **CNTY-341**: CD19/CD22 dual-targeted CAR-iT with Allo-Evasion™ 5.0 for B cell malignancies. [[3]](https://www.nasdaq.com/articles/century-therapeutics-announces-pipeline-re-prioritization-focus-transformational-programs)
- **CNTY-813**: iPSC-derived beta islet cell program for Type 1 diabetes; preclinical data showing rapid, sustained glucose normalization in diabetic models. [[2]](https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-third-quarter-2025-financial-results)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2018 | $250M | Versant Ventures, Bristol Myers Squibb |
| IPO (NASDAQ: IPSC) | Jun 2021 | ~$258M | Public markets |
| Various follow-ons | 2022–2025 | — | Public markets |

Total raised (pre-IPO): ~$250M Series A; IPO raised ~$258M. [[5]](https://www.crunchbase.com/organization/century-therapeutics)

---

## References

1. Century Therapeutics — Company website: [https://www.centurytx.com/](https://www.centurytx.com/)
2. Century Therapeutics — Q3 2025 financial results: [https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-third-quarter-2025-financial-results](https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-third-quarter-2025-financial-results)
3. NASDAQ — Century pipeline re-prioritization: [https://www.nasdaq.com/articles/century-therapeutics-announces-pipeline-re-prioritization-focus-transformational-programs](https://www.nasdaq.com/articles/century-therapeutics-announces-pipeline-re-prioritization-focus-transformational-programs)
4. Century Therapeutics — Q2 2025 business update: [https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-second-quarter-2025-financial](https://investors.centurytx.com/news-releases/news-release-details/century-therapeutics-reports-second-quarter-2025-financial)
5. Crunchbase — Century Therapeutics: [https://www.crunchbase.com/organization/century-therapeutics](https://www.crunchbase.com/organization/century-therapeutics)
