# Advanced Medicine Partners

Advanced Medicine Partners (AMP) is a North Carolina–based biotechnology services company specializing in **process development and manufacturing for gene and cell therapies**, with a particular focus on **viral vectors such as AAV (adeno-associated virus)**. The company was formed as a spin-off from Jaguar Gene Therapy to address manufacturing and development bottlenecks in advanced therapeutics ([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Origins & Formation

- Spin-out from **Jaguar Gene Therapy**  
- Created to provide dedicated **CMC (Chemistry, Manufacturing, and Controls)** capabilities  
- Facilities located in **Cary and Durham, North Carolina**  
- Operating footprint:
  - ~33,000 sq ft existing space  
  - Building a **174,000 sq ft GMP manufacturing facility**  

([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Approach

AMP’s approach is to serve as an **end-to-end development and manufacturing partner** for advanced therapies:

- Provides:
  - Process development  
  - Manufacturing  
  - Analytical development and testing  
- Focus on **scaling gene and cell therapies efficiently and reliably**  
- Addresses industry-wide constraints in **manufacturing capacity and quality**  

The company aims to accelerate the transition of therapies from development to commercialization.

### Technology

- Proprietary **AAV manufacturing platform**  
- Supports:
  - Wild-type AAV serotypes  
  - Engineered capsids  
  - Multiple gene constructs  

Additional capabilities:

- Assay development services  
- Platform analytical methods (licensable)  
- End-to-end viral vector production workflows  

([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Market & Positioning

AMP operates in the **gene therapy manufacturing and CDMO (contract development and manufacturing organization) market**:

- Focus on viral vector production for:
  - Gene therapies  
  - Cell therapies  
- Positioned as a **specialized manufacturing partner** in a supply-constrained market  
- Addresses a critical bottleneck in scaling precision medicines  

### Investors

- **Deerfield Management** (lead investor)  
- **ARCH Venture Partners**  
- Additional undisclosed investors  

([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Funding

- **$32M new financing round**  
- **$60M total funding since spin-out**  

Funds are being used to:

- Expand manufacturing capacity  
- Build GMP facilities  
- Scale operations  

([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Leadership

- **Ray Kaczmarek** – Executive Chair (biopharma manufacturing veteran)  
- **Felix Hsu** – Board member (experienced biotech executive)  

([Source 1](https://www.ncbiotech.org/news/advanced-medicine-partners-secures-additional-32m-financing)).

### Status

- Active  
- Privately held  
- Gene therapy CDMO / platform company  
- Not acquired  

---

### Bottom Line

Advanced Medicine Partners is a gene therapy-focused CDMO spun out of Jaguar Gene Therapy, providing AAV manufacturing and development services to address industry bottlenecks, with strong backing from Deerfield and ARCH and a growing GMP infrastructure to support next-generation therapies at scale.
