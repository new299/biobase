# Forge Biologics — Research Notes

## Overview

Forge Biologics is a Columbus, OH-based gene therapy contract development and manufacturing organization (CDMO) and clinical-stage gene therapy developer. The company operates The Hearth — a 200,000 sq ft purpose-built cGMP facility with 20 custom cGMP suites and 20,000L of bioreactor capacity for AAV manufacturing. Total raised: ~$330M ($120M Series B + $90M Series C + $80M additional). Key investors: RA Capital Management (Series B lead), Perceptive Xontogeny Venture Fund. FUEL™ platform provides proprietary Ignition Cells™, pEMBR™ 2.0, and improved analytics for AAV manufacturing. [[1]](https://www.forgebiologics.com/forge-biologics-announces-closing-of-120-million-series-b-financing/) [[2]](https://www.forgebiologics.com/forge-biologics-closes-80-million-in-additional-financing-to-accelerate-planned-cdmo-expansion/)

---

## Technology & Services

- **FUEL™ AAV Manufacturing Platform**: Proprietary innovations including Ignition Cells™ (specialized producer cell lines), pEMBR™ 2.0 Ad Helper (improved helper plasmid), modified rep/cap constructs, and advanced analytical methods for AAV characterization — delivering improved yield, quality, and manufacturing efficiency. [[1]](https://www.forgebiologics.com/forge-biologics-announces-closing-of-120-million-series-b-financing/)
- **CDMO Services**: End-to-end AAV gene therapy manufacturing from cell line development through clinical and commercial GMP manufacturing. 60+ developer clients.
- **The Hearth Facility**: 200,000 sq ft, Columbus, OH; 20 cGMP suites; 20,000L bioreactor capacity; automated fill-finish capabilities.
- **Internal Gene Therapy Pipeline**: Hybrid CDMO + clinical developer model with internal AAV gene therapy programs.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series B | ~2022 | $120M | RA Capital Management (lead), Perceptive Xontogeny |
| Additional financing | ~2023 | $80M | Existing investors |
| Series C | ~2024 | $90M | RA Capital Management + existing investors |

Total raised: ~$330M. [[2]](https://www.forgebiologics.com/forge-biologics-closes-80-million-in-additional-financing-to-accelerate-planned-cdmo-expansion/)

---

## References

1. Forge Biologics — $120M Series B closing: [https://www.forgebiologics.com/forge-biologics-announces-closing-of-120-million-series-b-financing/](https://www.forgebiologics.com/forge-biologics-announces-closing-of-120-million-series-b-financing/)
2. Forge Biologics — $80M additional financing: [https://www.forgebiologics.com/forge-biologics-closes-80-million-in-additional-financing-to-accelerate-planned-cdmo-expansion/](https://www.forgebiologics.com/forge-biologics-closes-80-million-in-additional-financing-to-accelerate-planned-cdmo-expansion/)
