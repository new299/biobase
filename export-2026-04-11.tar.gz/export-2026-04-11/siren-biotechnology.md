# Siren Biotechnology

## Overview
Siren Biotechnology is a clinical-stage cancer gene therapy company developing AAV-based immuno-gene therapies for oncology.[[1]](https://www.biospace.com/press-releases/siren-biotechnology-announces-fda-clearance-of-first-ind-advancing-company-to-clinical-stage)[[2]](https://www.biospace.com/press-releases/siren-biotechnology-receives-fda-fast-track-designation-for-srn-101-for-the-treatment-of-recurrent-high-grade-glioma)

## Technology
The company’s lead program is SRN-101, described as a universal AAV immuno-gene therapy for recurrent high-grade glioma. Public materials note that Siren believes this represents the first FDA-cleared IND for an AAV-based oncology therapy.[[1]](https://www.biospace.com/press-releases/siren-biotechnology-announces-fda-clearance-of-first-ind-advancing-company-to-clinical-stage)[[2]](https://www.biospace.com/press-releases/siren-biotechnology-receives-fda-fast-track-designation-for-srn-101-for-the-treatment-of-recurrent-high-grade-glioma)

## Investors / Support
The reviewed source set did not surface a detailed financing announcement, but MilliporeSigma announced in 2024 that Siren was the North American winner of its Advance Biotech Grant Program, receiving products, technologies, and contract testing services.[[3]](https://www.sigmaaldrich.com/US/en/collections/press/siren-biotechnology-winner-advance-biotech-grant-program)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Recent milestones include FDA clearance of the first IND in January 2026 and Fast Track designation in February 2026.[[1]](https://www.biospace.com/press-releases/siren-biotechnology-announces-fda-clearance-of-first-ind-advancing-company-to-clinical-stage)[[2]](https://www.biospace.com/press-releases/siren-biotechnology-receives-fda-fast-track-designation-for-srn-101-for-the-treatment-of-recurrent-high-grade-glioma)
