# Acceleron Pharma Inc.

## Overview
Acceleron Pharma was a biotechnology company focused on therapeutics derived from the biology of the transforming growth factor-beta superfamily.[[1]](https://www.merck.com/news/merck-to-acquire-acceleron-pharma-inc/)[[2]](https://www.merck.com/news/merck-completes-acquisition-of-acceleron-pharma-inc/) Its portfolio included sotatercept and Reblozyl.[[1]](https://www.merck.com/news/merck-to-acquire-acceleron-pharma-inc/)

## Technology and Pipeline
Merck described Acceleron as leveraging deep expertise in TGF-beta superfamily biology to develop medicines for cardiopulmonary and hematologic diseases.[[1]](https://www.merck.com/news/merck-to-acquire-acceleron-pharma-inc/) At acquisition, sotatercept was a Phase 3 candidate for pulmonary arterial hypertension and Reblozyl was an approved erythroid maturation agent.[[1]](https://www.merck.com/news/merck-to-acquire-acceleron-pharma-inc/)

## Investors
The local note references Venrock, which reflects Acceleron’s early venture-backed history. The public sources reviewed in this pass focused more on the later public-company and acquisition phase than on the original cap table.

## Acquisitions and Corporate Activity
Merck announced in September 2021 that it would acquire Acceleron for $180 per share in cash, representing an approximate total equity value of $11.5 billion, and completed the acquisition in November 2021.[[1]](https://www.merck.com/news/merck-to-acquire-acceleron-pharma-inc/)[[2]](https://www.merck.com/news/merck-completes-acquisition-of-acceleron-pharma-inc/)
