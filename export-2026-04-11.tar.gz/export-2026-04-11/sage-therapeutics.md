# Sage Therapeutics

## Overview
Sage Therapeutics is a biopharmaceutical company focused on brain health medicines, with approved products for postpartum depression and a pipeline centered on GABA and NMDA receptor biology [[1]](https://investor.sagerx.com/).

## Technology
The company says its therapeutic focus includes GABA and NMDA receptor modulation, and its commercial portfolio includes ZURZUVAE and ZULRESSO [[1]](https://investor.sagerx.com/).

## Investors
As a public company, Sage is financed through public markets and institutional investors. The reviewed investor-relations source focused on corporate profile and transaction activity rather than named holders [[1]](https://investor.sagerx.com/).

## Acquisitions / Strategic Transactions
In June 2025, Supernus Pharmaceuticals agreed to acquire Sage in a transaction worth up to approximately $795 million, including upfront cash plus contingent value rights [[2]](https://investor.sagerx.com/news-releases/news-release-details/supernus-pharmaceuticals-acquire-sage-therapeutics-strengthening).

## References
[[1]](https://investor.sagerx.com/)
[[2]](https://investor.sagerx.com/news-releases/news-release-details/supernus-pharmaceuticals-acquire-sage-therapeutics-strengthening)
