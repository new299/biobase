# Rarity Bioscience

## Overview
Rarity Bioscience is a Sweden-based spinout from Uppsala University founded in 2021 to commercialize the superRCA assay platform for highly sensitive mutation detection and liquid-biopsy applications [[1]](https://raritybioscience.com/about-us/) [[2]](https://raritybioscience.com/).

## Technology
The company says superRCA is an ultrasensitive, multiplex assay technology capable of rare-sequence detection, with flow-cytometry-based readout and applications in precision diagnostics [[1]](https://raritybioscience.com/about-us/) [[2]](https://raritybioscience.com/).

## Investors
Rarity announced a EUR 2.5 million seed round in 2022 led by founders and joined by Navigare Ventures, then added Novalis Biotech in a 2023 oversubscription of that round, bringing disclosed financing in that period to EUR 3 million [[3]](https://raritybioscience.com/rarity-bioscience-raises-e25m-in-seed-funding-to-improve-cancer-care/) [[4]](https://raritybioscience.com/novalis-biotech-invests-in-rarity-biosciencesultra-sensitive-genomics-technology/).

## Acquisitions / Strategic Transactions
The reviewed sources emphasize financing and commercial expansion rather than M&A; the most material strategic transactions identified were the 2022 seed financing and 2023 strategic investment by Novalis Biotech [[3]](https://raritybioscience.com/rarity-bioscience-raises-e25m-in-seed-funding-to-improve-cancer-care/) [[4]](https://raritybioscience.com/novalis-biotech-invests-in-rarity-biosciencesultra-sensitive-genomics-technology/).

## References
[[1]](https://raritybioscience.com/about-us/)
[[2]](https://raritybioscience.com/)
[[3]](https://raritybioscience.com/rarity-bioscience-raises-e25m-in-seed-funding-to-improve-cancer-care/)
[[4]](https://raritybioscience.com/novalis-biotech-invests-in-rarity-biosciencesultra-sensitive-genomics-technology/)

## ASeq Posts

- [Rarity Biosciences Superrca](https://aseq.substack.com/p/rarity-biosciences-superrca)
