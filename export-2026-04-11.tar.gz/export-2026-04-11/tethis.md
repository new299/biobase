# Tethis

## Overview

Tethis is an Italian liquid biopsy company developing automated pre-analytical workflows for cancer diagnostics. The company says its goal is to make liquid biopsy widely available in clinical practice by preserving sample integrity and standardizing blood processing. [[1]](https://tethis-lab.com/) [[2]](https://tethis-lab.com/news/tethis-launches-see-d/)

## Technology

Its platform combines the See.d blood sample preparation instrument with proprietary SmartBioSurface slides and AI-assisted image analysis. Tethis says this workflow enables automated preparation of both cellular and plasma fractions for multiomic liquid biopsy, including circulating tumor cells, ctDNA, RNA, and protein-related analyses. [[2]](https://tethis-lab.com/news/tethis-launches-see-d/) [[3]](https://tethis-lab.com/news/enea-tech-and-biomedical-foundation-invests-e15-million-in-tethis-to-develop-new-diagnostic-methods-in-oncology-using-liquid-biopsy/)

## Investors

In January 2025, Enea TECH and Biomedical Foundation announced a EUR15 million investment in Tethis. The company said that round followed prior support from Genextra and Indaco Venture Partners, including Atlante Ventures and Indaco-related funds. [[3]](https://tethis-lab.com/news/enea-tech-and-biomedical-foundation-invests-e15-million-in-tethis-to-develop-new-diagnostic-methods-in-oncology-using-liquid-biopsy/)

## Partnerships And Clinical Development

Tethis has disclosed collaborations with Sheba Medical Center and with Sapienza University/Takis to advance liquid-biopsy-enabled oncology applications. It also announced first patient enrollment in a clinical study evaluating See.d for automated standardized plasma and cell sample preparation. [[4]](https://tethis-lab.com/news/tethis-s-p-a-collaborateswith-sheba-medical-center-to-advance-ai-powered-liquid-biopsy-in-rectal-cancer/) [[5]](https://tethis-lab.com/news/tethis-s-p-a-announces-enrollment-of-the-first-two-patients-in-a-clinical-study-of-its-see-d-platform-which-allows-automated-standardized-plasma-and-cell-sample-preparation-for-multiomic-liquid-biop/)
