# Newleos Therapeutics

## Overview
Newleos Therapeutics is a clinical-stage biotechnology company focused on mental health and neuropsychiatric disorders.[[1]](https://newleos.com/) The company says it was co-founded by Longwood Fund and seasoned CNS drug-development leaders, and that its pipeline was licensed from Roche.[[1]](https://newleos.com/)

## Technology and Pipeline
Newleos is developing oral small molecules targeting GABAA-gamma1, V1a, TAAR1, and GABAA-alpha5 mechanisms for generalized anxiety disorder, social anxiety disorder, substance use disorders, and cognitive impairment.[[1]](https://newleos.com/)[[2]](https://newleos.com/pipeline/) The company frames these as first- or best-in-class neuropsychiatric programs intended to improve on current standards of care.[[1]](https://newleos.com/)

## Investors
The reviewed public materials identify Newleos as a company co-founded by Longwood Fund, and its board and corporate materials prominently reflect Longwood's role in company formation and governance.[[1]](https://newleos.com/)[[3]](https://newleos.com/team/) I did not find a detailed public financing announcement on the company's site during this pass, so the investor picture here should be treated as partial and source-limited.[[1]](https://newleos.com/)[[3]](https://newleos.com/team/)

## Acquisitions and Corporate Activity
No acquisition of Newleos was identified in the reviewed sources. A notable corporate detail is that its pipeline was licensed from Roche rather than internally originated, which is central to the company's formation story.[[1]](https://newleos.com/)
