# Mitra Biotech Inc.

## Overview

Mitra Biotech is an oncology precision medicine company developing functional drug response platforms to guide cancer therapy selection.[[1]](https://www.mitrabiotech.com/)

## Technology

The company's key technology is `CANscript`, a functional precision oncology platform that tests patient-derived tumor tissue against drugs ex vivo to predict therapy response.[[1]](https://www.mitrabiotech.com/) The company positions this as a way to enable more personalized treatment selection in oncology and to support biopharma development.[[1]](https://www.mitrabiotech.com/)

## Investors

The reviewed public site did not surface a clean financing history or investor syndicate list in this pass. Public materials are centered on the platform and clinical utility rather than financing disclosure.[[1]](https://www.mitrabiotech.com/)

## Acquisitions and Strategic Transactions

No acquisition involving Mitra Biotech was identified in the reviewed sources. The public footprint reviewed is centered on commercial deployment of CANscript and oncology partnerships rather than M&A.[[1]](https://www.mitrabiotech.com/)
