# Avila Therapeutics

## Overview
Avila Therapeutics was a biotechnology company focused on covalent small-molecule drugs using its Covalent Drug Discovery platform.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc) The company pursued oncology, antiviral, and other therapeutic applications.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc)

## Technology and Pipeline
Avila’s platform centered on covalent protein silencing and irreversible enzyme inhibition, with the goal of generating differentiated small molecules against challenging targets.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc) Celgene’s acquisition release described the platform as having potential across oncology, antiviral, and inflammatory disease.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc)

## Investors
The local note references Atlas Venture, reflecting Avila’s historical venture-backed roots. The acquisition release I reviewed did not enumerate the full syndicate, so this investor section remains intentionally narrow.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc)

## Acquisitions and Corporate Activity
Celgene agreed in 2012 to acquire Avila for $350 million upfront plus potential milestone payments of up to $575 million, for a total potential value of $925 million.[[1]](https://www.biospace.com/press-releases/celgene-agrees-to-acquire-avila-therapeutics-inc)
