# EveryONE Medicines — Research Notes

## Overview

EveryONE Medicines, Inc. was a Boston, MA-based biotechnology company founded in 2020, dedicated to developing personalized genetic medicines for patients with rare neurological diseases caused by unique individual mutations. The company's founding was inspired by the development of Milasen — a personalized ASO designed by Dr. Timothy Yu (Boston Children's Hospital) for a single patient with Batten disease — and was co-founded by Mila's mother, Julia Vitarello. EveryONE focused on creating standardized, regulator-aligned development pathways for N-of-1 medicines, initially using antisense oligonucleotides (ASOs). The company shut down in March 2026 after FDA's new guidance for individualized genetic therapies fell short of enabling a commercially viable pathway. [[1]](https://endpoints.news/everyone-medicines-shuts-down-ending-custom-cure-venture-that-banked-on-new-fda-pathway/) [[2]](https://www.businesswire.com/news/home/20240710919827/en/EveryONE-Medicines-Appoints-Kent-Rogers-as-Chief-Executive-Officer-and-Josh-Ofman-MD-MSHS-as-Chairman-of-the-Board)

---

## Technology & Approach

- **N-of-1 Personalized ASO Platform**: Developed standardized process for designing and manufacturing custom antisense oligonucleotides (ASOs) tailored to each patient's unique genetic mutation — using the same manufacturing process and regulatory strategy across all personalized programs to enable scalable individualized medicine.
- **Target Indications**: Rare neurological diseases with patient-specific mutations for which no approved therapy exists.
- **Business Model**: "Process, not product" — same end-to-end process (patient identification → modality matching → drug design → clinical delivery → regulatory approval → reimbursement) applied to different patients with different mutations.

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2020 | Julia Vitarello co-founder; inspired by Milasen (Dr. Timothy Yu, Boston Children's Hospital) |
| CEO appointment | Jul 2024 | Kent Rogers appointed CEO; Josh Ofman, MD MSHS as Chairman |
| Shutdown | Mar 2026 | Closed after FDA guidance fell short of expectations for individualized genetic therapy pathway |

No disclosed external venture funding. [[1]](https://endpoints.news/everyone-medicines-shuts-down-ending-custom-cure-venture-that-banked-on-new-fda-pathway/)

---

## References

1. Endpoints News — EveryONE Medicines shuts down (Mar 2026): [https://endpoints.news/everyone-medicines-shuts-down-ending-custom-cure-venture-that-banked-on-new-fda-pathway/](https://endpoints.news/everyone-medicines-shuts-down-ending-custom-cure-venture-that-banked-on-new-fda-pathway/)
2. BusinessWire — EveryONE Medicines appoints Kent Rogers as CEO (Jul 2024): [https://www.businesswire.com/news/home/20240710919827/en/EveryONE-Medicines-Appoints-Kent-Rogers-as-Chief-Executive-Officer-and-Josh-Ofman-MD-MSHS-as-Chairman-of-the-Board](https://www.businesswire.com/news/home/20240710919827/en/EveryONE-Medicines-Appoints-Kent-Rogers-as-Chief-Executive-Officer-and-Josh-Ofman-MD-MSHS-as-Chairman-of-the-Board)
