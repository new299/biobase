# Arteaus Therapeutics

## Overview
Arteaus Therapeutics was a biotechnology company developing migraine therapeutics, particularly antibody-based approaches targeting CGRP biology.[[1]](https://www.gaebler.com/Funded-Company-A5DF03AD-4D61-42C8-8FEF-E45F267AF27F-Arteaus-Therapeutics) Publicly accessible information is now mostly historical and database-based.

## Technology and Pipeline
Secondary company databases describe Arteaus as focused on treatments for migraine prevention.[[1]](https://www.gaebler.com/Funded-Company-A5DF03AD-4D61-42C8-8FEF-E45F267AF27F-Arteaus-Therapeutics)[[2]](https://www.cbinsights.com/company/arteaus-therapeutics) The commercial significance of its work is reflected indirectly by the later Emgality royalty transaction tied to Eli Lilly’s galcanezumab.[[2]](https://www.cbinsights.com/company/arteaus-therapeutics)

## Investors
Gaebler reports that Arteaus raised at least $25.5 million, with backing from Atlas Venture, OrbiMed, and private investors.[[1]](https://www.gaebler.com/Funded-Company-A5DF03AD-4D61-42C8-8FEF-E45F267AF27F-Arteaus-Therapeutics) The local Atlas note is therefore supported by the reviewed public sources.

## Acquisitions and Corporate Activity
Secondary company databases report that Arteaus was acquired by Lilly in January 2014.[[3]](https://www.thecompanycheck.com/company/b/arteaus-therapeutics/mfurv0l6omvvi9d8m) I did not locate a stronger primary-source acquisition release during this pass, so this note stays intentionally narrow and source-constrained.
