# deCODE Genetics — Research Notes

## Overview

deCODE Genetics is a Reykjavik, Iceland-based genomics and human genetics research company founded in 1996 by Kári Stefánsson. A global leader in human population genomics — has sequenced the genomes of more than two-thirds of Iceland's adult population to discover genetic risk factors for dozens of common diseases (cardiovascular, cancer, psychiatric, neurological). IPO on NASDAQ July 2000 ($200M, first Icelandic company on US exchange); filed Chapter 11 bankruptcy in 2009; acquired by Amgen in December 2012 for $415M. Operates as an Amgen subsidiary. Total pre-Amgen raised: $500M+ R&D spend over first decade. **ARCH Venture Partners** was an early investor. [[1]](https://en.wikipedia.org/wiki/DeCODE_genetics) [[2]](https://www.amgen.com/stories/2022/06/decoding-disease)

---

## Technology

- **Population Genomics Platform**: Whole-genome sequencing (WGS) + comprehensive genealogical, medical, and phenotypic records from Iceland's unique founder population (highly homogeneous, excellent genealogical records extending centuries). Enables identification of rare coding variants and causal disease genes. [[1]](https://en.wikipedia.org/wiki/DeCODE_genetics)
- **Large-Scale WGS**: 2,636 Icelanders sequenced to 20× depth; variants imputed into 104,220 individuals — described in Nature Genetics 2015. [[3]](https://pubmed.ncbi.nlm.nih.gov/25807286/)
- **Actionable Genotype Study**: ~4% of Icelanders (1 in 25) carry actionable variants per ACMG SF v3.0; associated with reduced lifespan. Published in NEJM 2023. [[4]](https://www.nejm.org/doi/full/10.1056/NEJMoa2300792)
- **Drug Target Discovery**: Amgen leverages deCODE to identify genetic evidence for drug targets; unique rare variant data from population sampling. [[2]](https://www.amgen.com/stories/2022/06/decoding-disease)

---

## Funding & Corporate History

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| Founded | 1996 | — | Kári Stefánsson, Reykjavik Iceland |
| IPO (NASDAQ) | Jul 2000 | $200M | First Icelandic company on US exchange |
| Chapter 11 | Nov 2009 | — | Bankruptcy protection |
| Amgen acquisition | Dec 2012 | $415M | Acquired by Amgen; ongoing subsidiary |

Pre-acquisition investors included: Amgen (strategic pre-acquisition), **ARCH Venture Partners**, Alta Partners, Polaris Partners, Saga Investments. [[5]](https://tracxn.com/d/companies/decode-genetics/__uzxZYimwHMSeiU_knrBnbpKC14mvpypKLKnQvA9amEw)

**ARCH Venture Partners Investment** (early investor)

---

## References

1. Wikipedia — deCODE Genetics: [https://en.wikipedia.org/wiki/DeCODE_genetics](https://en.wikipedia.org/wiki/DeCODE_genetics)
2. Amgen — Decoding Disease (deCODE story): [https://www.amgen.com/stories/2022/06/decoding-disease](https://www.amgen.com/stories/2022/06/decoding-disease)
3. PubMed — Large-scale WGS of Icelandic population (2015): [https://pubmed.ncbi.nlm.nih.gov/25807286/](https://pubmed.ncbi.nlm.nih.gov/25807286/)
4. NEJM — Actionable genotypes and life span in Iceland (2023): [https://www.nejm.org/doi/full/10.1056/NEJMoa2300792](https://www.nejm.org/doi/full/10.1056/NEJMoa2300792)
5. Tracxn — deCODE Genetics profile: [https://tracxn.com/d/companies/decode-genetics/__uzxZYimwHMSeiU_knrBnbpKC14mvpypKLKnQvA9amEw](https://tracxn.com/d/companies/decode-genetics/__uzxZYimwHMSeiU_knrBnbpKC14mvpypKLKnQvA9amEw)
