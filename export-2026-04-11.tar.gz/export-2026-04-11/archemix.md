# Archemix — Research Notes

## Overview

Archemix was an RNA aptamer therapeutics company co-founded in 2001 by Andrew Ellington, headquartered in Cambridge, MA. Developed therapeutic aptamers (structured oligonucleotide ligands) against diverse pharmaceutical targets. **Acquired by Baxter International on December 1, 2010** for $30M upfront + up to $285M in milestones (hemophilia-related assets and anti-TFPI aptamer technology). Total raised: $152M. [[1]](https://www.biospace.com/baxter-international-inc-announces-acquisition-of-all-hemophilia-related-assets-of-archemix-corporation-and-an-exclusive-license-of-its-anti-tfpi-ap)

---

## Technology

- **RNA Aptamer Platform (SELEX)**: Used SELEX (Systematic Evolution of Ligands by EXponential enrichment) to discover high-affinity, highly specific oligonucleotide aptamers against protein targets. Aptamers act as synthetic antibody mimics that can be chemically synthesized at scale. [[2]](https://pmc.ncbi.nlm.nih.gov/articles/PMC3555175/)
- **ARC1779 / Anti-vWF aptamer**: Antagonist of von Willebrand Factor; developed for thrombotic disorders. [[1]](https://www.biospace.com/baxter-international-inc-announces-acquisition-of-all-hemophilia-related-assets-of-archemix-corporation)
- **Anti-TFPI aptamer**: Targeting Tissue Factor Pathway Inhibitor for hemophilia B rebalancing therapy — the key asset acquired by Baxter.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A–D | 2001–2009 | $152M total | Athenian Venture Partners, Atlas Venture, Care Capital, GSK, Highland Capital Partners |
| Strategic deals | 2005–2010 | $100M+ milestones | GSK ($6.5M equity + $21M + $200M milestones), Takeda ($6M), Pfizer, Merck KGaA, Nuvelo |
| Acquired by Baxter | Dec 2010 | $30M upfront + $285M milestones | Baxter International |

Total raised: $152M equity. [[1]](https://www.biospace.com/baxter-international-inc-announces-acquisition-of-all-hemophilia-related-assets-of-archemix-corporation-and-an-exclusive-license-of-its-anti-tfpi-ap) [[3]](https://www.crunchbase.com/organization/archemix)

---

## References

1. BioSpace — Baxter acquisition: [https://www.biospace.com/baxter-international-inc-announces-acquisition-of-all-hemophilia-related-assets-of-archemix-corporation-and-an-exclusive-license-of-its-anti-tfpi-ap](https://www.biospace.com/baxter-international-inc-announces-acquisition-of-all-hemophilia-related-assets-of-archemix-corporation-and-an-exclusive-license-of-its-anti-tfpi-ap)
2. PMC — Aptamer therapeutics review: [https://pmc.ncbi.nlm.nih.gov/articles/PMC3555175/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3555175/)
3. Crunchbase — Archemix profile: [https://www.crunchbase.com/organization/archemix](https://www.crunchbase.com/organization/archemix)
