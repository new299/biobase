# Singular Genomics Systems

## Overview

Singular Genomics Systems is a sequencing and spatial multiomics company that developed high-throughput genomics instruments for research and precision-medicine applications. In February 2025, the company announced the closing of its acquisition by an affiliate of Deerfield Management and returned to private ownership. [[1]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-announces-closing-acquisition-deerfield/) [[2]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-systems-inc-announces-closing-initial-public)

## Technology

Singular's platform portfolio centered on the G4 sequencing platform and the G4X spatial sequencer. The company described G4X as a dual-purpose system combining traditional NGS with in situ spatial multiomics, including direct RNA sequencing, targeted transcriptomics, and proteomics profiling from FFPE tissues. [[3]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-unveils-g4xtm-spatial-sequencer-transforming) [[4]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-launches-g4x-us-delivering-industry-leading)

## Investors And Financing

Singular raised approximately $258.1 million gross in its June 2021 IPO after pricing shares at $22.00. By late 2024, Deerfield was already an existing stockholder and moved to acquire the remaining shares it did not own. [[2]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-systems-inc-announces-closing-initial-public) [[5]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-enters-agreement-be-acquired-deerfield-2000)

## Acquisition

On December 23, 2024, Singular announced a definitive agreement to be acquired by Deerfield for $20.00 per share in cash, and the transaction closed on February 21, 2025. [[5]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-enters-agreement-be-acquired-deerfield-2000) [[1]](https://investor.singulargenomics.com/news-releases/news-release-details/singular-genomics-announces-closing-acquisition-deerfield/)
