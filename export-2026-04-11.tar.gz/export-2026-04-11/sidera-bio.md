# Sidera Bio

## Overview
Sidera Bio is a Danish biotechnology company developing genetics-driven cardiometabolic therapies [[1]](https://www.mainsights.io/ma-news/danish-biotech-sidera-bio-raises-dkk-700m-in-series-a-funding-from-major-investors-including-existing-backer-novo-holdings) [[2]](https://finance.sina.com.cn/jjxw/2025-10-31/doc-infvuxst4353419.shtml).

## Technology
Secondary coverage describes the company as building obesity and metabolic disease programs, including rights outside Greater China to MWN105, a GLP-1/GIP/FGF21 agonist injection licensed from Shanghai Minwei Biotech [[1]](https://www.mainsights.io/ma-news/danish-biotech-sidera-bio-raises-dkk-700m-in-series-a-funding-from-major-investors-including-existing-backer-novo-holdings) [[2]](https://finance.sina.com.cn/jjxw/2025-10-31/doc-infvuxst4353419.shtml).

## Investors
Recent deal coverage states that Sidera raised about DKK 700 million / $109 million in Series A financing in late 2025, with investors including Novo Holdings, Forbion, RA Capital, and Gilde Healthcare [[1]](https://www.mainsights.io/ma-news/danish-biotech-sidera-bio-raises-dkk-700m-in-series-a-funding-from-major-investors-including-existing-backer-novo-holdings) [[3]](https://vrsxp.com/virology-news/pharma-news/stealthy-biotech-sidera-bio-raises-109m-assemblys-data-for-oral-herpes-drugs/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. A notable strategic transaction was the 2025 licensing deal with Shanghai Minwei Biotech for ex-Greater-China rights to MWN105, with milestone economics reported up to roughly $1.045 billion and an equity stake for Minwei [[2]](https://finance.sina.com.cn/jjxw/2025-10-31/doc-infvuxst4353419.shtml) [[4]](https://www.vcbeatglobal.com/article/2015).

## References
[[1]](https://www.mainsights.io/ma-news/danish-biotech-sidera-bio-raises-dkk-700m-in-series-a-funding-from-major-investors-including-existing-backer-novo-holdings)
[[2]](https://finance.sina.com.cn/jjxw/2025-10-31/doc-infvuxst4353419.shtml)
[[3]](https://vrsxp.com/virology-news/pharma-news/stealthy-biotech-sidera-bio-raises-109m-assemblys-data-for-oral-herpes-drugs/)
[[4]](https://www.vcbeatglobal.com/article/2015)
