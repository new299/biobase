# Orca Bio

## Overview
Orca Bio is a late-stage biotechnology company developing high-precision cell therapies for cancer and autoimmune diseases.[[1]](https://orcabio.com/) The company says its therapies aim to replace diseased blood and immune systems with healthy ones using precisely defined cellular compositions.[[1]](https://orcabio.com/)

## Technology and Pipeline
Orca Bio's approach is based on high-precision cell sorting and manufacturing to create allogeneic or donor-derived cell therapy products with controlled cellular composition.[[1]](https://orcabio.com/) Public materials identify Orca-T as its lead investigational allogeneic T-cell immunotherapy, with additional programs including Orca-Q.[[2]](https://www.finsmes.com/2026/01/orca-bio-raises-250m-in-aggregate-funding.html)

## Investors
Cooley reported that Orca Bio raised a $192 million Series D in June 2020 co-led by Lightspeed Venture Partners and an undisclosed investor, with participation from 8VC, DCVC Bio, ND Capital, Mubadala Investment Company, Kaiser Foundation Hospitals, Kaiser Permanente Group Trust, and IMRF.[[3]](https://www.cooley.com/news/coverage/2020/2020-06-23-orca-bio-raises-192-million-series-d-to-transform-allogenic-cell-therapy) Secondary reporting in January 2026 stated that Orca had raised $250 million in aggregate across its two most recent financings, including a Series F led by Lightspeed Venture Partners, plus expanded debt capacity from Silicon Valley Bank.[[2]](https://www.finsmes.com/2026/01/orca-bio-raises-250m-in-aggregate-funding.html)

## Acquisitions and Corporate Activity
I did not identify an acquisition involving Orca Bio in the reviewed public sources. The clearest recent corporate milestones are the late-stage financing activity and commercial-readiness buildup around Orca-T.[[2]](https://www.finsmes.com/2026/01/orca-bio-raises-250m-in-aggregate-funding.html)
