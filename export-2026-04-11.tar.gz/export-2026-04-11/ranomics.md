# Ranomics

## Overview
Ranomics is a biotechnology company offering high-throughput cell and protein engineering services for biologics development and related applications [[1]](https://www.ranomics.com/) [[2]](https://www.ranomics.com/biotechnology-services).

## Technology
The company highlights integrated platforms including yeast and mammalian display, deep mutational scanning, directed evolution, CRISPR/Cas9 engineering, stable cell-line development, and next-generation sequencing-based functional analysis [[3]](https://www.ranomics.com/technology) [[4]](https://www.ranomics.com/cell-engineering).

## Investors
SOSV lists Ranomics as a portfolio company and describes it as a company built around functional characterization of genetic variants; the company also identifies itself as an IndieBio alumnus [[5]](https://sosv.com/company/ranomics/) [[1]](https://www.ranomics.com/).

## Acquisitions / Strategic Transactions
No acquisition or major strategic transaction was identified in the reviewed sources during this pass; the clearest external financing reference was SOSV / IndieBio backing [[5]](https://sosv.com/company/ranomics/).

## References
[[1]](https://www.ranomics.com/)
[[2]](https://www.ranomics.com/biotechnology-services)
[[3]](https://www.ranomics.com/technology)
[[4]](https://www.ranomics.com/cell-engineering)
[[5]](https://sosv.com/company/ranomics/)
