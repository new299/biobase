# Gradalis — Research Notes

## Overview

Gradalis, Inc. is a Dallas (Carrollton), TX-based privately-held biotechnology company founded in 2010 by John Nemunaitis, developing personalized cancer immunotherapies centered on its FANG™ (now Vigil™) vaccine platform. Vigil is a personalized whole-tumor-cell vaccine incorporating autologous tumor cells modified by electroporation with a plasmid encoding GM-CSF and a bifunctional shRNA against furin (which suppresses immunosuppressive TGF-β1/β2). The company has its own GMP manufacturing facility. Total raised: ~$80.7M. [[1]](https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html)

---

## Technology & Pipeline

- **Vigil™ (formerly FANG™ — Personalized Autologous Cancer Vaccine)**: Autologous irradiated tumor cells electroporated with a bifunctional construct encoding GM-CSF (immune stimulation) + bifunctional shRNA against furin (suppresses TGF-β1/β2 production, reducing tumor immune evasion). Administered as monthly intradermal injections. Phase 2 in ovarian cancer showed doubled time-to-recurrence vs. placebo. [[1]](https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html)
- **Indications**: Advanced ovarian cancer (Phase 2/3), Ewing's sarcoma, melanoma, colorectal cancer with liver metastases. [[1]](https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html)
- **ddRNAi Platform**: Bifunctional RNA interference system simultaneously blocking both TGF-β1 and TGF-β2 (furin substrates) to reduce immunosuppression.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2011 | ~$20M | Private investors |
| Series B | Jan 2013 | $24M | Undisclosed investors |
| Additional | Various | ~$36.7M | Total to $80.7M |

Total raised: ~$80.7M. [[1]](https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html)

---

## References

1. PRNewswire — Gradalis $24M Series B (Jan 2013): [https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html](https://www.prnewswire.com/news-releases/gradalis-inc-closes-24-million-in-series-b-financing-to-advance-late-stage-trials-of-fang-personalized-cancer-vaccine-185525702.html)
