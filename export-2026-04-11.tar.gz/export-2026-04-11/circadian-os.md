# Circadian OS

## Overview
Circadian OS is a therapeutics company developing circadian medicine approaches intended to measure and reprogram the body’s internal clock to improve treatment outcomes, especially in cancer care.[[1]](https://sosv.com/company/circadian-os/)[[2]](https://www.circadian-os.com/)

## Technology
SOSV says the company combines a proprietary blood test with software-guided personalized light dosing delivered through common devices, with the goal of restoring immune readiness and synchronizing peak immune activity with time-sensitive treatment. The company frames this as a circadian therapeutics platform based on multimodal temporal data.[[1]](https://sosv.com/company/circadian-os/)[[2]](https://www.circadian-os.com/)

## Investors
The clearest public investor signal is SOSV/IndieBio NY 2025 H2 portfolio inclusion. The SOSV profile also notes partnerships with Mount Sinai, Roche, and Cornell, but not a large disclosed institutional financing round.[[1]](https://sosv.com/company/circadian-os/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://sosv.com/company/circadian-os/)
