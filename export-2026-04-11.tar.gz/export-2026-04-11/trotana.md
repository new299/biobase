# Trotana

## Overview

Trotana is a San Diego biotechnology company developing novel oral anti-inflammatory medicines. Public company profiles indicate it was founded in 2023 and is operating as a privately held therapeutics startup. [[1]](https://www.linkedin.com/company/trotana-inc) [[2]](https://www.thecompanycheck.com/company/b/trotana/o1zk6r5arteby6rrg)

## Technology

The most consistent publicly visible description is that Trotana is building oral anti-inflammatory medicines. The accessible sources reviewed here do not provide deeper details on targets, modality, or pipeline composition beyond that therapeutic area framing. [[1]](https://www.linkedin.com/company/trotana-inc) [[2]](https://www.thecompanycheck.com/company/b/trotana/o1zk6r5arteby6rrg)

## Investors

I did not find a clearly disclosed financing round or named investor syndicate in the accessible public sources reviewed for this note. The company appears to be early and still lightly disclosed publicly. [[1]](https://www.linkedin.com/company/trotana-inc)

## Disclosure Limits

This note is intentionally narrow. Trotana has a visible company identity and therapeutic focus, but the public detail available is not yet strong enough to support more specific claims about investors, acquisitions, or lead assets. [[1]](https://www.linkedin.com/company/trotana-inc) [[2]](https://www.thecompanycheck.com/company/b/trotana/o1zk6r5arteby6rrg)
