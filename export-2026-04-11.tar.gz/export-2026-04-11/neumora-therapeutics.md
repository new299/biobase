# Neumora Therapeutics

## Overview

Neumora Therapeutics is a neuroscience-focused biopharmaceutical company developing precision medicines for brain diseases and neuropsychiatric disorders.[[1]](https://www.neumoratx.com/) The company positions itself around translational neuroscience, biomarkers, and data-driven patient stratification.[[1]](https://www.neumoratx.com/)

## Technology

Neumora's model combines neuroscience drug development with human data, biomarker strategies, and patient subgrouping. Its pipeline has included programs for major depressive disorder, agitation associated with Alzheimer's disease, schizophrenia, and other neuropsychiatric indications.[[1]](https://www.neumoratx.com/)

## Investors

Neumora was a public company by 2025. Market coverage in January 2025 noted that after a major Phase 3 setback the company still had approximately $342 million in cash, expected to support operations into mid-2026.[[2]](https://www.marketwatch.com/story/neumora-therapeutics-stock-craters-after-trial-of-major-depressive-disorder-fails-to-meet-main-goals-5417d73d)

## Acquisitions and Strategic Transactions

No acquisition involving Neumora Therapeutics was identified in the reviewed sources. The major recent event in the reviewed record was the January 2025 Phase 3 failure of navacaprant in major depressive disorder, which materially affected the company's trajectory.[[2]](https://www.marketwatch.com/story/neumora-therapeutics-stock-craters-after-trial-of-major-depressive-disorder-fails-to-meet-main-goals-5417d73d)
