# Element Science — Research Notes

## Overview

Element Science is a San Francisco, CA-based medical device company developing the Jewel® Patch Wearable Cardioverter Defibrillator (P-WCD) — a discreet, wearable patch-based defibrillator for patients with temporary elevated risk of sudden cardiac arrest (e.g., post-MI, pre-ICD implant). Total raised: ~$192.6M (including $145.6M Series C). FDA PMA approval received May 2025. First patient save demonstrated 2022. [[1]](https://www.businesswire.com/news/home/20250501248318/en/Element-Science-Receives-FDA-Approval-for-the-Revolutionary-Jewel-Patch-Wearable-Cardioverter-Defibrillator) [[2]](https://www.mobihealthnews.com/news/element-science-collects-nearly-150m-series-c-wearable-personal-defibrillator-patch)

---

## Technology & Products

- **Jewel® Patch-WCD**: Wearable patch-based cardioverter defibrillator — a low-profile, discreet alternative to Zoll's LifeVest vest-style WCD. FDA PMA approved May 2025; CE mark and UK UKCA mark received January 2024. First documented patient save with Jewel announced August 2022. [[1]](https://www.businesswire.com/news/home/20250501248318/en/Element-Science-Receives-FDA-Approval-for-the-Revolutionary-Jewel-Patch-Wearable-Cardioverter-Defibrillator) [[3]](https://www.businesswire.com/news/home/20220802005269/en/Element-Science-Announces-First-Patient-Save-with-Jewel-Patch-Wearable-Cardioverter-Defibrillator-P-WCD)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A/B | ~2015–2019 | ~$47M | Third Rock Ventures, Google Ventures |
| Series C | ~2021 | $145.6M | Deerfield Healthcare (lead), Qiming Venture Partners USA, Cormorant Asset Management, Invus Opportunities, Third Rock Ventures, Google Ventures |

Total raised: ~$192.6M. [[2]](https://www.mobihealthnews.com/news/element-science-collects-nearly-150m-series-c-wearable-personal-defibrillator-patch)

---

## References

1. BusinessWire — Element Science Jewel® Patch WCD FDA approval (May 2025): [https://www.businesswire.com/news/home/20250501248318/en/Element-Science-Receives-FDA-Approval-for-the-Revolutionary-Jewel-Patch-Wearable-Cardioverter-Defibrillator](https://www.businesswire.com/news/home/20250501248318/en/Element-Science-Receives-FDA-Approval-for-the-Revolutionary-Jewel-Patch-Wearable-Cardioverter-Defibrillator)
2. MobiHealth News — Element Science $145M Series C: [https://www.mobihealthnews.com/news/element-science-collects-nearly-150m-series-c-wearable-personal-defibrillator-patch](https://www.mobihealthnews.com/news/element-science-collects-nearly-150m-series-c-wearable-personal-defibrillator-patch)
3. BusinessWire — Element Science first patient save with Jewel Patch WCD (Aug 2022): [https://www.businesswire.com/news/home/20220802005269/en/Element-Science-Announces-First-Patient-Save-with-Jewel-Patch-Wearable-Cardioverter-Defibrillator-P-WCD](https://www.businesswire.com/news/home/20220802005269/en/Element-Science-Announces-First-Patient-Save-with-Jewel-Patch-Wearable-Cardioverter-Defibrillator-P-WCD)
