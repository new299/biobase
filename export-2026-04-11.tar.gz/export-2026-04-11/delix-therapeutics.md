# Delix Therapeutics — Research Notes

## Overview

Delix Therapeutics, Inc. is a Cambridge, MA-based CNS drug discovery company developing non-hallucinogenic neuroplastogens (psychoplastogens) for depression, PTSD, substance use disorders, hearing loss, and other brain disorders. Founded ~2020 by David Olson (UC Davis). Total raised: ~$100M ($70M Series A, Sep 2021). Lead compound DLX-001 (zalsupindole / AAZ-A-154): Phase 1 completed Dec 2024 with favorable safety/tolerability and no hallucinogenic/dissociative effects. [[1]](https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html) [[2]](https://www.delixtherapeutics.com/news/delix-presents-full-results-from-phase-1-trial/)

---

## Technology

- **Neuroplastogens / Psychoplastogens**: Novel small molecules that promote neuroplasticity (structural and functional synaptic growth) without the hallucinogenic, cardiotoxic, or psychostimulant effects of first-generation compounds like ketamine and psilocybin. [[1]](https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html)
- **DLX-001 (Zalsupindole / AAZ-A-154)**: Lead compound. Phase 1 clinical trial in healthy volunteers completed December 2024; demonstrated favorable safety and tolerability with no hallucinogenic, psychotomimetic, or dissociative effects. [[2]](https://www.delixtherapeutics.com/news/delix-presents-full-results-from-phase-1-trial/)
- **DLX-007 (Tabernanthalog)**: Second pipeline compound. [[1]](https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html)
- **Government Grants**: NIH grant (Dec 2023, ~$320K) for substance use disorders; DoD grant (Jun 2024) for hearing loss program. [[3]](https://www.businesswire.com/news/home/20231213417680/en/Delix-Therapeutics-Awarded-National-Institutes-of-Health-Grant-to-Advance-Vital-Research-of-Novel-Neuroplastogen-for-Substance-Use-Disorders)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/pre-Series A | 2020–2021 | ~$30M | OMX Ventures (founding) |
| Series A | Sep 2021 | $70M | ARTIS Ventures (lead), RA Capital Management, OMX Ventures, Apeiron, Dolby Family Ventures, Re.Mind Capital, PsyMed Ventures, and others |

Total raised: ~$100M. [[1]](https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html)

---

## References

1. PRNewswire — Delix $70M Series A (Sep 2021): [https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html](https://www.prnewswire.com/news-releases/delix-therapeutics-closes-70-million-series-a-financing-to-advance-pipeline-of-novel-psychoplastogen-therapeutics-to-treat-brain-disorders-301385016.html)
2. Delix Therapeutics — DLX-001 Phase 1 full results (Dec 2024): [https://www.delixtherapeutics.com/news/delix-presents-full-results-from-phase-1-trial/](https://www.delixtherapeutics.com/news/delix-presents-full-results-from-phase-1-trial/)
3. BusinessWire — NIH grant for substance use disorders (Dec 2023): [https://www.businesswire.com/news/home/20231213417680/en/Delix-Therapeutics-Awarded-National-Institutes-of-Health-Grant-to-Advance-Vital-Research-of-Novel-Neuroplastogen-for-Substance-Use-Disorders](https://www.businesswire.com/news/home/20231213417680/en/Delix-Therapeutics-Awarded-National-Institutes-of-Health-Grant-to-Advance-Vital-Research-of-Novel-Neuroplastogen-for-Substance-Use-Disorders)
