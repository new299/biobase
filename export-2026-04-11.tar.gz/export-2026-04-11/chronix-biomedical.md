# Chronix Biomedical — Research Notes

## Overview

Chronix Biomedical, Inc. was a San Jose, CA-based (with German research facilities) liquid biopsy company founded in 1997. Developed proprietary copy number instability (CNI) Monitor technology — a liquid biopsy measuring circulating nucleic acids in blood to monitor cancer drug efficacy and organ transplant rejection. **Acquired by Oncocyte in February 2021.** Total raised: ~$31M. [[1]](https://www.cbinsights.com/company/chronix-biomedical) [[2]](https://www.globenewswire.com/news-release/2020/10/01/2102141/0/en/Oncocyte-Agrees-to-Enter-Licensing-and-Collaboration-Agreement-with-Chronix-Biomedical.html)

---

## Technology

- **CNI Monitor (Copy Number Instability)**: Tumor-naïve liquid biopsy technology measuring the concentration of specific DNA sequences in blood associated with cancer, quantified as a CNI score. Real-time monitoring of changes in CNI scores over the course of cancer treatment can assess response to therapy (including immunotherapy) without requiring knowledge of the tumor's mutational profile. [[3]](https://www.businesswire.com/news/home/20141008005188/en/Chronix-Biomedical-Files-Patent-Application-on-Liquid-Biopsy)
- **Applications**: Cancer therapy monitoring, organ transplant rejection surveillance. [[1]](https://www.cbinsights.com/company/chronix-biomedical)
- **Post-Acquisition**: Oncocyte launched TheraSure™-CNI MONITOR clinical assay based on Chronix's patented technology. [[2]](https://www.globenewswire.com/news-release/2020/10/01/2102141/0/en/Oncocyte-Agrees-to-Enter-Licensing-and-Collaboration-Agreement-with-Chronix-Biomedical.html)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 1997 | San Jose, CA |
| Total funding | ~1997–2021 | $31M (Atlas Accelerator, Boston Harbor Angels, German Federal Ministry BMBF, Keiretsu Forum) |
| Licensing agreement with Oncocyte | Oct 2020 | Technology licensing precursor to acquisition |
| Acquired by Oncocyte | Feb 2021 | Terms undisclosed |

[[1]](https://www.cbinsights.com/company/chronix-biomedical) [[2]](https://www.globenewswire.com/news-release/2020/10/01/2102141/0/en/Oncocyte-Agrees-to-Enter-Licensing-and-Collaboration-Agreement-with-Chronix-Biomedical.html)

---

## References

1. CBInsights — Chronix Biomedical profile: [https://www.cbinsights.com/company/chronix-biomedical](https://www.cbinsights.com/company/chronix-biomedical)
2. GlobeNewswire — Oncocyte licensing agreement with Chronix (Oct 2020): [https://www.globenewswire.com/news-release/2020/10/01/2102141/0/en/Oncocyte-Agrees-to-Enter-Licensing-and-Collaboration-Agreement-with-Chronix-Biomedical.html](https://www.globenewswire.com/news-release/2020/10/01/2102141/0/en/Oncocyte-Agrees-to-Enter-Licensing-and-Collaboration-Agreement-with-Chronix-Biomedical.html)
3. BusinessWire — Chronix Biomedical liquid biopsy patent (2014): [https://www.businesswire.com/news/home/20141008005188/en/Chronix-Biomedical-Files-Patent-Application-on-Liquid-Biopsy](https://www.businesswire.com/news/home/20141008005188/en/Chronix-Biomedical-Files-Patent-Application-on-Liquid-Biopsy)
