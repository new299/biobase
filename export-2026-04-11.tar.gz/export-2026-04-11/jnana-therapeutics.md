# Jnana Therapeutics

## Overview

Jnana Therapeutics was a Boston-area biotechnology company developing small-molecule medicines using its RAPID platform for difficult-to-drug targets, including transporters and other challenging protein classes.[[1]](https://www.otsuka.co.jp/en/company/newsreleases/2024/20240924_1.html)

## Technology

Otsuka described Jnana's core platform as `Reactive Affinity Probe Interaction Discovery` (`RAPID`), a discovery approach intended to unlock drug targets that were difficult to address through traditional screening systems.[[1]](https://www.otsuka.co.jp/en/company/newsreleases/2024/20240924_1.html) Jnana had applied this platform across multiple therapeutic areas and target classes prior to its sale.[[1]](https://www.otsuka.co.jp/en/company/newsreleases/2024/20240924_1.html)

## Investors

The local note associated Jnana with RA Capital, and the company was widely known as venture-backed, but the clearest reviewed source here is the acquisition announcement rather than a financing press release. The reviewed Otsuka source does not enumerate the venture syndicate, so investor detail remains incomplete in this note.[[1]](https://www.otsuka.co.jp/en/company/newsreleases/2024/20240924_1.html)

## Acquisitions and Strategic Transactions

Otsuka Pharmaceutical announced in August 2024 that it would acquire Jnana for $800 million upfront plus up to $325 million in development and regulatory milestones, and completed the acquisition on September 24, 2024.[[1]](https://www.otsuka.co.jp/en/company/newsreleases/2024/20240924_1.html)
