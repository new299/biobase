# BillionToOne — Research Notes

## Overview

BillionToOne is a Menlo Park, CA-based precision molecular diagnostics company founded in 2016. Uses its proprietary Quantitative Counting Templates™ (QCTs™) technology to count DNA molecules with single base-pair precision. Products span prenatal diagnostics and oncology liquid biopsy. Total raised: ~$400M; valuation $1B+ (Series D). Filed for IPO (BLLN). [[1]](https://billiontoone.com/) [[2]](https://billiontoone.com/leading-molecular-diagnostics-company-billiontoone-raises-130-million-in-oversubscribed-series-d-funding-over-1b-valuation/)

---

## Technology

- **Quantitative Counting Templates™ (QCTs™)**: Proprietary platform that enables ultra-precise counting of DNA molecules at single base-pair resolution from cell-free DNA. Enables very high sensitivity for rare variant detection. [[1]](https://billiontoone.com/)
- **UNITY (Prenatal)**: First NIPT test using cfDNA to assess fetal risk for recessive conditions without requiring a paternal sample or invasive procedures. Launched 2019. [[1]](https://billiontoone.com/)
- **Northstar Select**: Pan-cancer liquid biopsy test for therapy selection guidance. Launched 2023. [[1]](https://billiontoone.com/)
- **Northstar Response**: Methylation-based assay that quantifies cancer burden at the single-molecule level without tissue biopsy. Launched 2023. [[1]](https://billiontoone.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2019–2020 | $15M | Undisclosed |
| Series B/C | ~2021–2022 | Undisclosed | Hummingbird Ventures, Libertus Capital, Fifty Years, Civilization Ventures |
| Series D | Jul 2024 | $130M (oversubscribed) | Premji Invest (lead), Neuberger Berman, Adam Street Partners, Baillie Gifford, Hummingbird Ventures, Civilization Ventures, Libertus Capital, Fifty Years |
| Total | | ~$400M | |

[[2]](https://billiontoone.com/leading-molecular-diagnostics-company-billiontoone-raises-130-million-in-oversubscribed-series-d-funding-over-1b-valuation/)

**IPO Filing**: Filed S-1 for $100M IPO (ticker BLLN); terms set at $200M. [[3]](https://www.renaissancecapital.com/IPO-Center/News/114331/Molecular-diagnostics-company-BillionToOne-sets-terms-for-$200-million-IPO)

---

## References

1. BillionToOne — Website: [https://billiontoone.com/](https://billiontoone.com/)
2. BillionToOne — $130M Series D announcement: [https://billiontoone.com/leading-molecular-diagnostics-company-billiontoone-raises-130-million-in-oversubscribed-series-d-funding-over-1b-valuation/](https://billiontoone.com/leading-molecular-diagnostics-company-billiontoone-raises-130-million-in-oversubscribed-series-d-funding-over-1b-valuation/)
3. Renaissance Capital — BillionToOne IPO terms: [https://www.renaissancecapital.com/IPO-Center/News/114331/Molecular-diagnostics-company-BillionToOne-sets-terms-for-$200-million-IPO](https://www.renaissancecapital.com/IPO-Center/News/114331/Molecular-diagnostics-company-BillionToOne-sets-terms-for-$200-million-IPO)

## ASeq Posts

- [Billiontoone Ipo](https://aseq.substack.com/p/billiontoone-ipo)
