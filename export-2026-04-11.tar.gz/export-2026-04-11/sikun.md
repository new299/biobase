# Sikun

## Overview

Sikun is a China-based sequencing company developing desktop short-read next-generation sequencing platforms. Its public website highlights the Sikun 2000 and RapidGS480 systems and positions the company around accessible, flexible SBS sequencing. [[1]](https://www.sikun.com/) [[2]](https://www.nature.com/articles/s41598-025-04170-6)

## Technology

According to both the company website and an independent 2025 Scientific Reports evaluation, the Sikun 2000 uses sequencing-by-synthesis chemistry with reversible terminators, upgraded optics, and image-analysis algorithms, and can produce up to 200 Gb per run. The independent evaluation concluded that the platform performed competitively in whole-genome sequencing versus Illumina NovaSeq systems, especially for SNV accuracy. [[1]](https://www.sikun.com/) [[2]](https://www.nature.com/articles/s41598-025-04170-6)

## Investors

I did not find a clearly disclosed institutional financing history in the accessible public sources reviewed for this note. The most informative public materials are product- and performance-focused rather than financing-focused. [[1]](https://www.sikun.com/) [[2]](https://www.nature.com/articles/s41598-025-04170-6)

## Strategic Position

Sikun appears to be competing as an alternative short-read platform provider, with emphasis on lower-cost, desktop-scale deployment and compatibility with established sequencing workflows. [[1]](https://www.sikun.com/) [[2]](https://pubmed.ncbi.nlm.nih.gov/40447879/)

## ASeq Posts

- [Sikun Sequencers](https://aseq.substack.com/p/sikun-sequencers)
