# Craif — Research Notes

## Overview

Craif, Inc. is a Nagoya, Japan-based liquid biopsy company and Nagoya University spinout co-founded in 2018 by nanotechnology professor Takao Yasui. Develops urinary microRNA-based cancer detection using AI analysis. First product miSignal (7-cancer panel) commercially available in Japan with ~20,000 users. Total raised: ~$57M; valuation just below $100M. US market entry planned with FDA clearance target by ~2029. [[1]](https://techcrunch.com/2025/04/27/craif-a-non-invasive-early-cancer-detection-platform-grabs-22m/) [[2]](https://craif.com/en)

---

## Technology

- **Urinary microRNA Multi-Cancer Detection**: Uses urinary microRNAs as biomarkers for cancer detection — first demonstrated by Prof. Yasui in 2017 for 5 cancer types (bladder, prostate, lung, pancreas, liver). Urine chosen over blood due to lower impurities and cleaner microRNA signal. [[3]](https://www.nature.com/articles/d42473-021-00334-w)
- **miSignal**: Commercial multi-cancer early detection test covering 7 cancer types. Available through Japanese clinics, pharmacies, direct sales, and corporate wellness programs. [[1]](https://techcrunch.com/2025/04/27/craif-a-non-invasive-early-cancer-detection-platform-grabs-22m/)
- **Clinical Validation**: Lancet-published study (eClinicalMedicine, 2024) demonstrating non-invasive urinary microRNA assay for pancreatic cancer detection from early to late stages. [[4]](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00515-7/fulltext)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Earlier rounds | ~2018–2022 | ~$35M | X&KSK, KIRIN HEALTH INNOVATION FUND (Mar 2022) |
| Series (Apr 2025) | Apr 2025 | $22M | X&KSK (lead), Unreasonable Group, TAUNS Laboratories, Daiwa House Industry, Aozora Bank Group |

Total raised: ~$57M. [[1]](https://techcrunch.com/2025/04/27/craif-a-non-invasive-early-cancer-detection-platform-grabs-22m/)

---

## References

1. TechCrunch — Craif raises $22M (Apr 2025): [https://techcrunch.com/2025/04/27/craif-a-non-invasive-early-cancer-detection-platform-grabs-22m/](https://techcrunch.com/2025/04/27/craif-a-non-invasive-early-cancer-detection-platform-grabs-22m/)
2. Craif — Company website: [https://craif.com/en](https://craif.com/en)
3. Nature — Advanced extraction of urinary microRNA (Yasui research): [https://www.nature.com/articles/d42473-021-00334-w](https://www.nature.com/articles/d42473-021-00334-w)
4. eClinicalMedicine / The Lancet — Urinary microRNA pancreatic cancer detection study (2024): [https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00515-7/fulltext](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00515-7/fulltext)
