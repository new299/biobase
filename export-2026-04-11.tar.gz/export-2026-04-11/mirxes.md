# MiRXES

## Overview

MiRXES is a molecular diagnostics company focused on microRNA-based blood tests for cancer early detection and other diseases.[[1]](https://www.mirxes.com/) The company is headquartered in Singapore and has expanded across Asia-Pacific and other markets.[[1]](https://www.mirxes.com/)

## Technology

MiRXES' core technology uses proprietary microRNA assays and qPCR-based workflows for molecular diagnostics. Its best-known product is GASTROClear, a blood test for gastric cancer screening.[[1]](https://www.mirxes.com/) The company also markets additional multi-cancer early detection and molecular diagnostics programs built on circulating microRNA biomarkers.[[1]](https://www.mirxes.com/)

## Investors

MiRXES became publicly listed in Hong Kong in May 2025 and in January 2026 announced a HK$711.36 million placing agreement at HK$32.50 per share, raising gross proceeds of roughly HK$711 million.[[2]](https://www.mirxes.com/media-releases/mirxes-announces-hk711-million-placing-agreement-at-hk32-50-per-share-40-above-ipo-price/) The company stated that the placing was oversubscribed and intended to fund clinical programs, regulatory approvals, and business development.[[2]](https://www.mirxes.com/media-releases/mirxes-announces-hk711-million-placing-agreement-at-hk32-50-per-share-40-above-ipo-price/)

## Acquisitions and Strategic Transactions

No acquisition involving MiRXES was identified in the reviewed sources. The public record reviewed is centered on diagnostics commercialization and public-market financing rather than M&A.[[1]](https://www.mirxes.com/) [[2]](https://www.mirxes.com/media-releases/mirxes-announces-hk711-million-placing-agreement-at-hk32-50-per-share-40-above-ipo-price/)
