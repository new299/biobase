# Revvity

## Overview
Revvity is a public health-science tools and diagnostics company formed from the rebranding and portfolio refocus of PerkinElmer, serving pharma, biotech, diagnostic labs, academia, and governments [[1]](https://news.revvity.com/press-announcements/press-releases/press-release-details/2026/Revvity-Announces-Financial-Results-for-the-Fourth-Quarter-and-Full-Year-of-2025/default.aspx) [[2]](https://ir.revvity.com/home/default.aspx).

## Technology
The company says it provides workflows spanning translational multi-omics, biomarker identification, imaging, screening, detection, diagnosis, and informatics [[1]](https://news.revvity.com/press-announcements/press-releases/press-release-details/2026/Revvity-Announces-Financial-Results-for-the-Fourth-Quarter-and-Full-Year-of-2025/default.aspx).

## Investors
As a public company, Revvity's capital base is primarily the public markets and institutional shareholders; in operational terms, the company reported 2025 revenue of $2.9 billion [[1]](https://news.revvity.com/press-announcements/press-releases/press-release-details/2026/Revvity-Announces-Financial-Results-for-the-Fourth-Quarter-and-Full-Year-of-2025/default.aspx).

## Acquisitions / Strategic Transactions
The major strategic transition reflected in the reviewed sources is the 2023 PerkinElmer portfolio split and rebranding to Revvity, which positioned the company around life sciences and diagnostics rather than applied markets [[2]](https://ir.revvity.com/home/default.aspx).

## References
[[1]](https://news.revvity.com/press-announcements/press-releases/press-release-details/2026/Revvity-Announces-Financial-Results-for-the-Fourth-Quarter-and-Full-Year-of-2025/default.aspx)
[[2]](https://ir.revvity.com/home/default.aspx)
