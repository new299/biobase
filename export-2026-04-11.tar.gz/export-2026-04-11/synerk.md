# SynerK

## Overview

SynerK PharmaTech is a biopharmaceutical company focused on RNA-targeted therapeutics, particularly siRNA medicines. The company says it operates from Suzhou, Beijing, and Boston and aims to build integrated discovery, development, manufacturing, and commercialization capabilities. [[1]](https://www.synerk.cn/) [[2]](https://www.synerk.cn/aboutus)

## Technology

SynerK's public materials describe a proprietary GalNexus liver-targeted delivery platform for siRNA therapeutics. Its lead candidate, SNK-2726, targets angiotensinogen for hypertension and has been presented as a long-acting RNAi therapy. [[1]](https://www.synerk.cn/) [[3]](https://synerk.cn/newsinfo/1042178.html)

## Investors And Partners

I did not find a clearly disclosed venture syndicate in the accessible public sources reviewed for this note. The most visible strategic counterparty is Huadong Medicine, which in December 2024 entered a cooperation agreement with SynerK around SNK-2726 and obtained an exclusive option for Greater China rights. [[4]](https://www.synerk.cn/productinfo/1368958.html)

## Partnerships And Clinical Progress

In December 2024, SynerK and Huadong Medicine announced their strategic cooperation on SNK-2726. In February 2025, SynerK said the U.S. FDA cleared the IND for SNK-2726, and in May 2025 the company announced first-subject dosing in its China Phase I trial. [[4]](https://www.synerk.cn/productinfo/1368958.html) [[3]](https://synerk.cn/newsinfo/1042178.html)
