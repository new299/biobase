# Adela — Research Notes

## Overview

Adela (formerly DNAMx) is a Canadian liquid biopsy company based in Toronto, Ontario. Develops whole-methylome blood tests for cancer early detection, diagnosis, and monitoring. Total raised: $108M across two rounds. [[1]](https://www.adelabio.com/press/adela-debuts-with-60m) [[2]](https://www.precisionmedicineonline.com/molecular-diagnostics/adela-closes-48m-financing-develop-cancer-monitoring-early-detection-test)

**Co-founder & CSO:** Daniel De Carvalho (developer of cfMeDIP-seq at University Health Network).

---

## Technology

- **cfMeDIP-seq (cell-free Methylated DNA ImmunoPrecipitation + sequencing)**: Genome-wide methylation profiling of cell-free DNA (cfDNA) from blood. Licensed from U Toronto/UHN. Unlike competitors, does **not** require bisulfite conversion (which destroys ~99% of DNA), preserving far more material for analysis. [[1]](https://www.adelabio.com/press/adela-debuts-with-60m)
- **Whole methylome capture**: Captures information from information-rich methylated regions genome-wide — not a subset. Enables high-sensitivity detection and tissue-of-origin classification. [[1]](https://www.adelabio.com/press/adela-debuts-with-60m)
- Demonstrated across 10+ cancer types including tissue of origin classification and histologic subtype identification. [[1]](https://www.adelabio.com/press/adela-debuts-with-60m)

---

## Funding & Investors

| Round | Date | Amount | Investors |
|-------|------|--------|-----------|
| Series A | Jun 2021 | $60M | F-Prime Capital, OrbiMed, Deerfield Management, Decheng Capital, RA Capital Management |
| Series B extension | ~2022 | $48M | Above + Labcorp (new) |

Total raised: ~$108M. [[1]](https://www.adelabio.com/press/adela-debuts-with-60m) [[2]](https://www.precisionmedicineonline.com/molecular-diagnostics/adela-closes-48m-financing-develop-cancer-monitoring-early-detection-test)

**Labcorp** joined as strategic investor in Series B — potential commercial partnership for laboratory processing. [[2]](https://www.precisionmedicineonline.com/molecular-diagnostics/adela-closes-48m-financing-develop-cancer-monitoring-early-detection-test)

---

## References

1. Adela — Series A press release: `https://www.adelabio.com/press/adela-debuts-with-60m` | [https://www.adelabio.com/press/adela-debuts-with-60m](https://www.adelabio.com/press/adela-debuts-with-60m)
2. Precision Medicine Online — $48M round: [https://www.precisionmedicineonline.com/molecular-diagnostics/adela-closes-48m-financing-develop-cancer-monitoring-early-detection-test](https://www.precisionmedicineonline.com/molecular-diagnostics/adela-closes-48m-financing-develop-cancer-monitoring-early-detection-test)
