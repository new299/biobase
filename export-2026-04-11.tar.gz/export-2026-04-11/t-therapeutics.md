# T-Therapeutics

## Overview

T-Therapeutics is a University of Cambridge spinout developing next-generation T cell receptor therapeutics for cancer and autoimmune disease. The company says it is building first-in-class TCR-based bispecific medicines. [[1]](https://t-therapeutics.com/about/) [[2]](https://t-therapeutics.com/)

## Technology

Its core platform is OpTiMus, a fully humanized TCR mouse system designed to generate high-specificity, fully human TCRs. T-Therapeutics combines those TCRs with proprietary next-generation CD3 T cell engagers to create TCR-CD3 bispecific drug candidates aimed at previously undruggable intracellular targets. [[1]](https://t-therapeutics.com/about/) [[3]](https://t-therapeutics.com/t-therapeutics-announces-series-a-extension-to-91-million-to-advance-first-in-class-bispecifics-towards-the-clinic/)

## Investors

In November 2023, T-Therapeutics announced a £48 million ($59 million) Series A led by Sofinnova Partners, F-Prime Capital, Digitalis Ventures, and Cambridge Innovation Capital, with participation from Sanofi Ventures and the University of Cambridge Venture Fund. In November 2025, it announced a $32 million Series A extension, bringing the total Series A to $91 million, with new investors Tencent and BGF joining the syndicate. [[4]](https://t-therapeutics.com/t-therapeutics-raises-48-million-series-a-for-development-of-next-generation-tcr-therapeutics-to-transform-cancer-treatment/) [[3]](https://t-therapeutics.com/t-therapeutics-announces-series-a-extension-to-91-million-to-advance-first-in-class-bispecifics-towards-the-clinic/)

## Strategic Position

T-Therapeutics is building a bispecific-drug company rather than a cell therapy manufacturer, despite the TCR heritage. Its pitch is that natural TCR biology and proprietary T cell engagers can unlock high-value intracellular targets across both oncology and autoimmune indications. [[1]](https://t-therapeutics.com/about/) [[3]](https://t-therapeutics.com/t-therapeutics-announces-series-a-extension-to-91-million-to-advance-first-in-class-bispecifics-towards-the-clinic/)
