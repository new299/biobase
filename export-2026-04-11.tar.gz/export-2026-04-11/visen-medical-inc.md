# VisEn Medical, Inc.

## Overview
VisEn Medical was a molecular imaging company developing optical imaging platforms and probes for preclinical research and related biomedical applications.[[1]](https://www.flagshippioneering.com/news/press-release/visen-medical-announces-4m-venture-capital-financing)[[2]](https://www.gaebler.com/Funded-Company-6BCBBDDC-0BCF-4F73-AC73-188622F30024-VisEn-Medical)

## Technology
The company’s public record describes molecular imaging product platforms for pharmaceutical and academic users, including tomographic optical imaging systems and imaging probes.[[1]](https://www.flagshippioneering.com/news/press-release/visen-medical-announces-4m-venture-capital-financing)

## Investors
VisEn announced a $4 million financing in August 2005 led by Flagship Ventures, with follow-on investments from Bollard Group and other existing investors. Secondary funding databases report later financings and total funding of at least $22.5 million.[[1]](https://www.flagshippioneering.com/news/press-release/visen-medical-announces-4m-venture-capital-financing)[[2]](https://www.gaebler.com/Funded-Company-6BCBBDDC-0BCF-4F73-AC73-188622F30024-VisEn-Medical)

## Acquisitions / Other
Secondary company databases report that VisEn Medical was acquired by PerkinElmer in 2010. I did not locate the acquisition press release directly in the reviewed source set, so that exit detail should be read as database-backed rather than primary-source confirmed here.[[2]](https://www.gaebler.com/Funded-Company-6BCBBDDC-0BCF-4F73-AC73-188622F30024-VisEn-Medical)
