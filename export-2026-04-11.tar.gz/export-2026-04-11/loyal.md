# Loyal

## Overview

Loyal is a clinical-stage veterinary medicine company developing drugs intended to extend the healthspan and lifespan of dogs.[[1]](https://loyal.com/about) The company positions itself as building the first FDA-approved lifespan extension drugs for veterinary use.[[1]](https://loyal.com/about)

## Technology

Loyal's programs target aging-related biology in dogs. Its public materials reference LOY-001 and LOY-002, with LOY-002 positioned as a daily tablet for senior dogs and LOY-001 as an injectable approach for large-breed lifespan extension.[[1]](https://loyal.com/about) The company frames its science around metabolic and aging pathways rather than conventional companion-animal symptomatic treatments.[[2]](https://loyal.com/posts/125m-to-extend-dog-lifespan)

## Investors

In March 2024, Loyal announced a $45 million Series B, bringing total financing to more than $125 million.[[2]](https://loyal.com/posts/125m-to-extend-dog-lifespan) Public coverage of the round identified Bain Capital Ventures as lead investor, with participation from returning investors including Khosla Ventures and Valor Equity Partners.[[3]](https://www.wsj.com/articles/dog-longevity-startup-loyal-secures-45-million-in-funding-23d85cf1)

## Acquisitions and Strategic Transactions

No acquisition involving Loyal was identified in the reviewed sources. Its major public milestones are financing rounds and FDA regulatory progress, including key effectiveness-related milestones for its dog longevity programs.[[1]](https://loyal.com/about) [[2]](https://loyal.com/posts/125m-to-extend-dog-lifespan)
