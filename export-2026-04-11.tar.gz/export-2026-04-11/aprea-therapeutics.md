# Aprea Therapeutics

## Overview
Aprea Therapeutics is a clinical-stage precision oncology company focused on targeted therapies for biomarker-defined cancers.[[1]](https://ir.aprea.com/news-releases/news-release-details/aprea-therapeutics-announces-oversubscribed-30-million-private) The company’s current strategy centers on DNA damage response and synthetic lethality targets.[[2]](https://ir.aprea.com/news-releases/news-release-details/aprea-therapeutics-announces-acquisition-atrin-pharmaceuticals)

## Technology and Pipeline
Aprea’s current pipeline is based on DDR pathway inhibition, including assets obtained through its acquisition of Atrin Pharmaceuticals in 2022.[[2]](https://ir.aprea.com/news-releases/news-release-details/aprea-therapeutics-announces-acquisition-atrin-pharmaceuticals) The company is focused on oncology rather than the earlier p53-reactivation approach that characterized its original program set.

## Investors and Financing
In March 2026, Aprea announced an oversubscribed $30 million private placement led by Soleus Capital, with participation from Vestal Point Capital, Squadron Capital Management, and additional new and existing investors.[[1]](https://ir.aprea.com/news-releases/news-release-details/aprea-therapeutics-announces-oversubscribed-30-million-private) The local note’s 5AM reference reflects earlier company history, but the strongest current primary source reviewed here is the 2026 private placement.

## Acquisitions and Corporate Activity
In May 2022, Aprea announced that it had acquired Atrin Pharmaceuticals, a privately held biotechnology company developing DDR-pathway oncology therapeutics through synthetic lethality, thereby reshaping Aprea’s pipeline and strategic focus.[[2]](https://ir.aprea.com/news-releases/news-release-details/aprea-therapeutics-announces-acquisition-atrin-pharmaceuticals)
