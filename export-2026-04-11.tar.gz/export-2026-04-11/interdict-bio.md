# Interdict Bio — Research Notes

## Overview

Interdict Bio is a San Francisco, CA-based biotechnology company founded in 2022 by Larry Hamann, developing a small molecule therapeutics platform targeting historically undruggable proteins in oncology, rare diseases, neurodegeneration, and autoimmunity. Total raised: $26.5M. Key investors include Mission Bay Capital, Altitude Life Science Ventures, and Venrock. [[1]](https://www.crunchbase.com/organization/interdict-bio) [[2]](https://pitchbook.com/profiles/company/503666-29)

---

## Technology & Products

- **Undruggable Target Platform**: Small molecule drug discovery platform addressing protein targets historically considered undruggable — such as transcription factors, protein-protein interactions, and intrinsically disordered proteins — across oncology, rare diseases, neurodegeneration, and autoimmunity. [[1]](https://www.crunchbase.com/organization/interdict-bio)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | 2022–2023 | $26.5M | Mission Bay Capital, Altitude Life Science Ventures, Venrock |
| Total | — | $26.5M | — |

[[1]](https://www.crunchbase.com/organization/interdict-bio)

---

## References

1. Crunchbase — Interdict Bio: [https://www.crunchbase.com/organization/interdict-bio](https://www.crunchbase.com/organization/interdict-bio)
2. PitchBook — Interdict Bio: [https://pitchbook.com/profiles/company/503666-29](https://pitchbook.com/profiles/company/503666-29)
