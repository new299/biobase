# Micromet

## Overview

Micromet was a biopharmaceutical company focused on antibody-based cancer therapies, especially its Bispecific T-cell Engager (`BiTE`) platform.[[1]](https://investors.amgen.com/news-releases/news-release-details/amgen-acquire-micromet/)

## Technology

Micromet's core technology was the proprietary BiTE antibody platform, designed to redirect T cells toward tumor cells. The acquisition announcement specifically highlighted blinatumomab, a CD19-directed BiTE antibody, as the lead asset.[[1]](https://investors.amgen.com/news-releases/news-release-details/amgen-acquire-micromet/)

## Investors

Micromet was a public company by the time of its sale, so later-stage capitalization came through public markets rather than only private venture financing.[[1]](https://investors.amgen.com/news-releases/news-release-details/amgen-acquire-micromet/) The local note's Atlas Venture association is directionally consistent with the company's venture-backed history, but the reviewed source here is strongest on the public-company acquisition stage.

## Acquisitions and Strategic Transactions

In January 2012, Amgen announced a definitive merger agreement to acquire Micromet for $11 per share in cash, valuing the company at approximately $1.16 billion.[[1]](https://investors.amgen.com/news-releases/news-release-details/amgen-acquire-micromet/)
