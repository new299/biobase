# LigoCyte

## Overview

LigoCyte Pharmaceuticals was a private clinical-stage vaccine company focused on gastrointestinal and respiratory vaccines based on virus-like particle (`VLP`) technology.[[1]](https://www.takeda.com/en-us/newsroom/news-releases/2012/takeda-to-acquire-ligocyte-pharmaceuticals-inc/)

## Technology

LigoCyte's core platform was proprietary VLP vaccine technology. Takeda's acquisition announcement highlighted LigoCyte's lead norovirus vaccine candidate in Phase I/II development and preclinical programs in RSV, influenza, and rotavirus.[[1]](https://www.takeda.com/en-us/newsroom/news-releases/2012/takeda-to-acquire-ligocyte-pharmaceuticals-inc/)

## Investors

Takeda's 2012 acquisition announcement identified LigoCyte shareholders as Forward Ventures, JAFCO, Novartis Venture Fund, Fidelity Biosciences, MedImmune Ventures, Athenian Venture Partners, MC Life Sciences Ventures, and GlaxoSmithKline.[[1]](https://www.takeda.com/en-us/newsroom/news-releases/2012/takeda-to-acquire-ligocyte-pharmaceuticals-inc/)

## Acquisitions and Strategic Transactions

In October 2012, Takeda and LigoCyte announced a definitive agreement for Takeda to acquire LigoCyte for $60 million upfront plus future contingent consideration based on development progress.[[1]](https://www.takeda.com/en-us/newsroom/news-releases/2012/takeda-to-acquire-ligocyte-pharmaceuticals-inc/)
