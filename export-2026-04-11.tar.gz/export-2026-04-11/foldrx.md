# FoldRx Pharmaceuticals — Research Notes

## Overview

FoldRx Pharmaceuticals was a Cambridge, MA-based biopharmaceutical company founded in 2003 by Jeffery W. Kelly (The Scripps Research Institute) and Susan Lindquist (MIT/Whitehead Institute), developing small molecule stabilizers of misfolded proteins for amyloid diseases. Lead product: tafamidis — a first-in-class oral TTR tetramer stabilizer for transthyretin (TTR) amyloidosis. FoldRx was acquired by Pfizer in September 2010. Tafamidis was subsequently approved in Europe (2011), the US (2019 for ATTR-CM as Vyndaqel/Vyndamax), and became a blockbuster — generating $3.321B in Pfizer revenues in 2023. [[1]](https://www.prnewswire.com/news-releases/pfizer-to-acquire-foldrx-pharmaceuticals-101963188.html) [[2]](https://en.wikipedia.org/wiki/Tafamidis)

---

## Technology & Products

- **Protein Misfolding / Amyloid Disease Platform**: Drug discovery approach identifying small molecules that bind and kinetically stabilize the native tetramer structure of transthyretin (TTR), preventing TTR misfolding and dissociation into amyloidogenic monomers — the rate-limiting step in ATTR amyloid fibril formation. [[2]](https://en.wikipedia.org/wiki/Tafamidis)
- **Tafamidis (Vyndaqel / Vyndamax)**: First-in-class, first-in-disease oral small molecule for TTR amyloid polyneuropathy (ATTR-PN) and TTR amyloid cardiomyopathy (ATTR-CM). EU approval 2011 (ATTR-PN); US FDA approval 2019 (ATTR-CM as Vyndaqel and Vyndamax). $3.321B Pfizer revenue in 2023.

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2003 | Jeffery W. Kelly + Susan Lindquist; Cambridge, MA |
| Key investor | — | F-Prime Capital (Fidelity), others |
| Acquired by Pfizer | Sep 2010 | Undisclosed (Pfizer acquisition of pre-commercial stage biotech) |
| EU approval (ATTR-PN) | Nov 2011 | Vyndaqel EMA approval |
| FDA approval (ATTR-CM) | May 2019 | Vyndaqel + Vyndamax |
| Peak revenue | 2023 | $3.321B (Pfizer) |

---

## References

1. PRNewswire — Pfizer to acquire FoldRx Pharmaceuticals: [https://www.prnewswire.com/news-releases/pfizer-to-acquire-foldrx-pharmaceuticals-101963188.html](https://www.prnewswire.com/news-releases/pfizer-to-acquire-foldrx-pharmaceuticals-101963188.html)
2. Wikipedia — Tafamidis: [https://en.wikipedia.org/wiki/Tafamidis](https://en.wikipedia.org/wiki/Tafamidis)
