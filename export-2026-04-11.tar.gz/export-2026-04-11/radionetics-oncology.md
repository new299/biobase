# Radionetics Oncology

## Overview
Radionetics Oncology is a clinical-stage radiopharmaceutical company developing novel agents for oncology, with a focus on GPCR biology and small-molecule radiotherapeutics [[1]](https://radionetics.com/news/radionetics-oncology-raises-52-5m-series-a/) [[2]](https://radionetics.com/).

## Technology
Its platform targets GPCRs with small-molecule radiopharmaceuticals intended to expand treatment options across multiple solid-tumor settings [[1]](https://radionetics.com/news/radionetics-oncology-raises-52-5m-series-a/).

## Investors
The company's January 2024 Series A raised $52.5 million and was led by Frazier Life Sciences, 5AM Ventures, and DCVC Bio, with participation from Crinetics Pharmaceuticals and GordonMD Global Investments [[1]](https://radionetics.com/news/radionetics-oncology-raises-52-5m-series-a/).

## Acquisitions / Strategic Transactions
The most significant strategic transaction identified is the July 2024 Lilly agreement that gave Lilly exclusive option rights to acquire the company and included $140 million upfront economics [[3]](https://radionetics.com/news/radionetics-provides-lilly-access-to-proprietary-gpcr-targeting-small-molecule-radiopharmaceuticals/).

## References
[[1]](https://radionetics.com/news/radionetics-oncology-raises-52-5m-series-a/)
[[2]](https://radionetics.com/)
[[3]](https://radionetics.com/news/radionetics-provides-lilly-access-to-proprietary-gpcr-targeting-small-molecule-radiopharmaceuticals/)
