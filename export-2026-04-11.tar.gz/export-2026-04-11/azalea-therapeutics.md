# Azalea Therapeutics

## Overview
Azalea Therapeutics is a biotechnology company developing precision genomic medicines through in vivo cell engineering.[[1]](https://azaleatx.com/)[[2]](https://www.biospace.com/press-releases/azalea-therapeutics-launches-with-82-million-financing-to-redefine-precision-genomic-medicines-by-engineering-cells-directly-inside-each-patient) The company focuses on creating therapeutic cells directly inside the patient.

## Technology
Azalea says its Enveloped Delivery Vehicle platform enables cell-specific delivery of transient CRISPR-Cas9 cargo together with site-specific gene insertion using AAV-delivered repair templates.[[2]](https://www.biospace.com/press-releases/azalea-therapeutics-launches-with-82-million-financing-to-redefine-precision-genomic-medicines-by-engineering-cells-directly-inside-each-patient)[[1]](https://azaleatx.com/)

## Investors
Azalea launched in November 2025 with $82 million in combined seed and Series A financing led by Third Rock Ventures, with participation from RA Capital Management, Yosemite, Sozo Ventures, and select individual investors.[[2]](https://www.biospace.com/press-releases/azalea-therapeutics-launches-with-82-million-financing-to-redefine-precision-genomic-medicines-by-engineering-cells-directly-inside-each-patient)

## Acquisitions and Corporate Activity
No acquisition involving Azalea Therapeutics was identified in the reviewed public sources. The accessible public record centers on its 2025 launch and platform development.[[1]](https://azaleatx.com/)[[2]](https://www.biospace.com/press-releases/azalea-therapeutics-launches-with-82-million-financing-to-redefine-precision-genomic-medicines-by-engineering-cells-directly-inside-each-patient)
