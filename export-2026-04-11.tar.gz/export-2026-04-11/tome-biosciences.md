# Tome Biosciences

## Overview

Tome Biosciences is a genomic medicines company developing programmable genomic integration, or PGI, technologies for cell therapy and integrative gene therapy. The company describes itself as aiming to insert any genetic sequence of any size at programmed genomic locations with site-specific precision. [[1]](https://www.bio-itworld.com/pressreleases/2024/04/09/tome-biosciences-announces-us-patent-issued-for-integrase-mediated-programmable-genomic-integration) [[2]](https://pmc.ncbi.nlm.nih.gov/articles/PMC12808795/)

## Technology

Tome's core platform includes integrase-mediated PGI, or I-PGI, derived from PASTE technology, and more recently ligase-mediated PGI, or L-PGI. Public patent and paper disclosures indicate the company is building a toolkit for large, site-specific DNA insertion without conventional double-strand-break-dependent editing limitations. [[1]](https://www.bio-itworld.com/pressreleases/2024/04/09/tome-biosciences-announces-us-patent-issued-for-integrase-mediated-programmable-genomic-integration) [[2]](https://pmc.ncbi.nlm.nih.gov/articles/PMC12808795/)

## Investors

Secondary financing coverage reported that Tome launched from stealth in late 2023 with more than $213 million in Series A and B funding. Reported investors included a16z Bio + Health, ARCH Venture Partners, GV, Longwood Fund, Polaris Partners, Bruker, FUJIFILM, and Alexandria Venture Investments. Because this investor list comes from secondary reporting rather than a company press release in the sources reviewed here, it should be treated as such. [[3]](https://www.finsmes.com/2023/12/tome-biosciences-raises-over-213m-in-series-a-and-series-b.html) [[4]](https://www.labiotech.eu/podcast/programmable-genomic-integration/)

## Strategic Position

Tome is a platform-centric genomic medicines company rather than a single-program editor developer. Its value proposition is broad applicability across complex cell engineering and integrative gene therapies, with MIT-licensed foundational IP and growing patent coverage. [[1]](https://www.bio-itworld.com/pressreleases/2024/04/09/tome-biosciences-announces-us-patent-issued-for-integrase-mediated-programmable-genomic-integration) [[2]](https://pmc.ncbi.nlm.nih.gov/articles/PMC12808795/)
