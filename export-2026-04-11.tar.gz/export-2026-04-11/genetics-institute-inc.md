# Genetics Institute, Inc. — Research Notes

## Overview

Genetics Institute, Inc. (GI) was a Cambridge, MA-based biotechnology company founded in 1980 by Harvard molecular biologists Thomas Maniatis and Mark Ptashne, with Gabriel Schmergel joining as CEO. The company pioneered recombinant DNA and genetic technologies to develop pharmaceuticals for hemophilia (blood clotting factors), blood cell stimulators (erythropoietin, colony-stimulating factors), and bone growth proteins (BMPs). Venrock was an early investor. American Home Products (Wyeth) acquired a majority interest in GI in 1992 and full ownership at end of 1996; GI became the cornerstone of Wyeth Biotech, with Wyeth investing $3.5B+ to grow its combined biotech assets. [[1]](https://en.wikipedia.org/wiki/Genetics_Institute) [[2]](https://www.venrock.com/investment/genetics-institute-inc/) [[3]](https://www.encyclopedia.com/books/politics-and-business-magazines/genetics-institute-inc)

---

## Technology & Products

- **Recombinant Coagulation Factors**: Developed recombinant blood clotting proteins for hemophilia treatment, including recombinant Factor IX (BeneFIX). [[1]](https://en.wikipedia.org/wiki/Genetics_Institute)
- **Hematopoietic Growth Factors**: Recombinant proteins stimulating red blood cell (erythropoietin) and white blood cell production. [[3]](https://www.encyclopedia.com/books/politics-and-business-magazines/genetics-institute-inc)
- **Bone Morphogenetic Proteins (BMPs)**: Proteins that enhance bone and cartilage growth, including BMP-2 and BMP-7, with broad orthopedic and regenerative medicine applications. [[1]](https://en.wikipedia.org/wiki/Genetics_Institute)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 1980 | Cambridge, MA; Harvard spinout |
| Venrock investment | Early 1980s | Early-stage VC |
| Wyeth majority acquisition | 1992 | Wyeth (American Home Products) |
| Full Wyeth acquisition | End of 1996 | Became Wyeth Biotech |

**Venrock Investment**

[[1]](https://en.wikipedia.org/wiki/Genetics_Institute) [[2]](https://www.venrock.com/investment/genetics-institute-inc/)

---

## References

1. Wikipedia — Genetics Institute: [https://en.wikipedia.org/wiki/Genetics_Institute](https://en.wikipedia.org/wiki/Genetics_Institute)
2. Venrock — Genetics Institute portfolio page: [https://www.venrock.com/investment/genetics-institute-inc/](https://www.venrock.com/investment/genetics-institute-inc/)
3. Encyclopedia.com — Genetics Institute, Inc.: [https://www.encyclopedia.com/books/politics-and-business-magazines/genetics-institute-inc](https://www.encyclopedia.com/books/politics-and-business-magazines/genetics-institute-inc)
