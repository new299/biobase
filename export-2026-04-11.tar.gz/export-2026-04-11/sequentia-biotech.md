# Sequentia Biotech

## Overview
Sequentia Biotech is a Barcelona-based omics and bioinformatics company providing software and data analysis solutions for diagnostics, drug discovery, research, agriculture, and food technologies.[[1]](https://biovegen.org/en/members/sequentia-biotech-2/)[[2]](https://www.businesswire.com/news/home/20240930943100/en/Sequentia-Biotech-Secures-%E2%82%AC10million-Equity-Investment-from-Seventure-Partners-and-the-EIC-Fund-to-Boost-Bioinformatic-Solutions-for-Clinical-Industrial-and-Research-Applications)

## Technology
The company says it helps transform omics data into usable knowledge through bioinformatics platforms and services spanning genomics, transcriptomics, epigenetics, microbiomics, and related applied analytics.[[1]](https://biovegen.org/en/members/sequentia-biotech-2/)

## Investors
Sequentia announced a €10 million Series A in September 2024 led by Seventure Partners and co-invested by the European Innovation Council Fund.[[2]](https://www.businesswire.com/news/home/20240930943100/en/Sequentia-Biotech-Secures-%E2%82%AC10million-Equity-Investment-from-Seventure-Partners-and-the-EIC-Fund-to-Boost-Bioinformatic-Solutions-for-Clinical-Industrial-and-Research-Applications)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://biovegen.org/en/members/sequentia-biotech-2/)
