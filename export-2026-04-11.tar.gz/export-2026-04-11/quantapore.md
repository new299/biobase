# Quantapore

## Overview

Quantapore is a private sequencing-platform company based in South San Francisco / Menlo Park public listings, focused on genomic and proteomic analysis tools [[1]](https://quantapore.com/careers/) [[2]](https://www.gaebler.com/Funded-Company-F4D18D6D-DA7F-48F7-8612-2D33AB95B27D-Quantapore).

## Technology

Gaebler describes Quantapore as developing a nanopore-based nucleic-acid sequencing platform that uses an optical readout rather than electrical data acquisition [[2]](https://www.gaebler.com/Funded-Company-F4D18D6D-DA7F-48F7-8612-2D33AB95B27D-Quantapore). The company's careers page also indicates that its R&D work combines single-molecule detection systems, optical microscopy, nanopores, and microfluidics for next-generation genomic and proteomic platforms [[1]](https://quantapore.com/careers/).

## Investors

Quantapore's investor pages list Baidu Ventures, Cloudstone, Fusion Fund, Foothill Ventures, Sangel, and PBM Capital Group as backers [[3]](https://quantapore.com/category/investors/) [[4]](https://quantapore.com/baidu-ventures/). Gaebler reports at least two venture rounds totaling at least $50.6 million and names Baidu Venture Capital, Sangel Capital, Northern Light Venture Capital, Cloudstone Venture, and Foothill Ventures as investors [[2]](https://www.gaebler.com/Funded-Company-F4D18D6D-DA7F-48F7-8612-2D33AB95B27D-Quantapore).

## Acquisitions / Strategic Transactions

The reviewed public sources center on venture financing and platform development rather than disclosed M&A. Quantapore's most visible strategic activity in the available sources is its investor-backed buildout of an optical nanopore sequencing platform [[2]](https://www.gaebler.com/Funded-Company-F4D18D6D-DA7F-48F7-8612-2D33AB95B27D-Quantapore) [[3]](https://quantapore.com/category/investors/).

## References

[[1]](https://quantapore.com/careers/)
[[2]](https://www.gaebler.com/Funded-Company-F4D18D6D-DA7F-48F7-8612-2D33AB95B27D-Quantapore)
[[3]](https://quantapore.com/category/investors/)
[[4]](https://quantapore.com/baidu-ventures/)
