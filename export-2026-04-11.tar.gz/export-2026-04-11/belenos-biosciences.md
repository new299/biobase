# Belenos Biosciences — Research Notes

## Overview

Belenos Biosciences is a New York, NY-based biopharmaceutical company founded in 2024. Develops long-acting bispecific antibodies as "pipeline-in-a-product" therapies for chronic inflammatory diseases including COPD, asthma, and atopic dermatitis. Total raised: $48M. [[1]](https://belenosbio.com/) [[2]](https://www.crunchbase.com/organization/belenos-biosciences)

**OrbiMed Investment**.

---

## Technology

- **Long-Acting Bispecific Antibodies**: Engineers bispecific antibodies with half-life extension technology to provide deeper, more durable disease control in chronic inflammatory conditions. Pipeline-in-a-product approach allows a single molecule to address multiple disease mechanisms. [[1]](https://belenosbio.com/)
- Focus areas: COPD, asthma, atopic dermatitis.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | Jul 2024 | $48M | LongRiver Investments, OrbiMed, Acrew Capital |

Total raised: $48M. [[2]](https://www.crunchbase.com/organization/belenos-biosciences)

**OrbiMed Investment**.

---

## References

1. Belenos Biosciences — Website: [https://belenosbio.com/](https://belenosbio.com/)
2. Crunchbase — Belenos Biosciences: [https://www.crunchbase.com/organization/belenos-biosciences](https://www.crunchbase.com/organization/belenos-biosciences)
