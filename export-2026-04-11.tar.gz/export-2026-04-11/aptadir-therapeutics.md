# Aptadir Therapeutics — Research Notes

## Overview

Aptadir Therapeutics is a preclinical-stage RNA therapeutics company launched in September 2024, headquartered in Italy (linked to Italian research institutions). Develops DNMTs Interacting RNAs (DiRs) — a novel class of RNA inhibitors targeting aberrant DNA methylation in rare genetic disorders and cancers. First company to receive funding from Italy's EXTEND biopharmaceutical technology transfer hub. Total raised: $1.6M. [[1]](https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors)

---

## Technology

- **DiR (DNMTs Interacting RNA) Platform**: RNA inhibitors that block aberrant DNA methylation at a single-gene level, reactivating previously hypermethylated (silenced) genes. Distinct from gene editing — transient RNA-based epigenetic reprogramming. [[1]](https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors)
- **Lead candidate Aptadir Ce-49**: Targeting hypermethylation in:
  - **Fragile X Syndrome**: Reactivation of the silenced FMR1 gene. [[2]](https://fragilexnewstoday.com/news/new-biotech-aptadir-develop-gene-reactivator-fragile-x/)
  - **Myelodysplastic Neoplasms (MDS)**: Reprogramming methylation in cancer. [[1]](https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors)
- Founded by Dr. Annalisa Di Ruscio, Dr. Vittorio De Franciscis, Prof. Daniel Tenen, and Prof. Marcin Kortylewski.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-seed | Sep 2024 | $1.6M | EXTEND (Italian National Technology Transfer Hub), CDP Venture Capital SGR, Angelini Ventures, Evotec SE |

Total raised: $1.6M. [[1]](https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors)

---

## References

1. BusinessWire — Launch announcement (Sep 2024): [https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors](https://www.businesswire.com/news/home/20240924868386/en/Launch-of-Aptadir-Therapeutics-With-a-Novel-Class-of-RNA-Inhibitors)
2. Fragile X News Today — Aptadir/FXS: [https://fragilexnewstoday.com/news/new-biotech-aptadir-develop-gene-reactivator-fragile-x/](https://fragilexnewstoday.com/news/new-biotech-aptadir-develop-gene-reactivator-fragile-x/)
