# DP Bio — Research Notes

## Overview

DP Bio (also known as DPBIO, Inc.) is a Shenzhen, China-based biotechnology company founded in 2018 developing microdroplet-based technology for antibody analysis and high-performance analytical detection systems intended to accelerate and improve drug discovery and basic life science research. Limited public information is available about this company. [[1]](https://tracxn.com/d/companies/dp-bio/__Et8_ouz8pwuzn8_84yjGVFtJsqT82Mm0R5xpxtCTyrc)

---

## Technology

- **Microdroplet Antibody Analysis Platform**: DP Bio's technology uses microdroplet-based approaches for analytical detection of antibodies, aimed at accelerating drug discovery workflows and basic research. [[1]](https://tracxn.com/d/companies/dp-bio/__Et8_ouz8pwuzn8_84yjGVFtJsqT82Mm0R5xpxtCTyrc)

---

## Funding & Investors

No public funding information is available for DP Bio as of early 2026. The company appears to be privately held with no disclosed funding rounds. [[1]](https://tracxn.com/d/companies/dp-bio/__Et8_ouz8pwuzn8_84yjGVFtJsqT82Mm0R5xpxtCTyrc)

---

## References

1. Tracxn — DP Bio company profile: [https://tracxn.com/d/companies/dp-bio/__Et8_ouz8pwuzn8_84yjGVFtJsqT82Mm0R5xpxtCTyrc](https://tracxn.com/d/companies/dp-bio/__Et8_ouz8pwuzn8_84yjGVFtJsqT82Mm0R5xpxtCTyrc)
