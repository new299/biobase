# VYNE Therapeutics

## Overview

VYNE Therapeutics is a clinical-stage biopharmaceutical company focused on chronic inflammatory and immune-mediated diseases. The company has shifted from an earlier dermatology-centered commercial profile to a pipeline organized around BET inhibition and immunology. [[1]](https://vynetherapeutics.com/about-us/) [[2]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-reports-2025-first-quarter-financial-results-and-provides-business-update/)

## Technology And Pipeline

VYNE's public pipeline has included repibresib gel, or VYN201, for vitiligo and VYN202, an oral BD2-selective BET inhibitor for immune-mediated disease. The company has emphasized the potential of BET inhibitors to modulate inflammatory signaling with differentiated selectivity. [[2]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-reports-2025-first-quarter-financial-results-and-provides-business-update/) [[3]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-announces-fda-clearance-of-ind-application-for-vyn202-a-novel-bd2-selective-bet-inhibitor/) [[4]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-announces-granting-of-composition-of-matter-patent-for-vyn202-a-novel-bd2-selective-bet-inhibitor/)

## Investors And Financing

In 2023, VYNE announced and then closed an $88.2 million PIPE led by Access Biotechnology with participation from Eventide Asset Management, Cormorant Asset Management, Acorn Bioventures, Parkman Healthcare Partners, Surveyor Capital, Soleus Capital, Palo Alto Investors, and others. [[5]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-announces-private-placement-of-88-million/) [[6]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-announces-closing-of-previously-announced-private-placement-of-88-2-million/)

## Strategic Development

In December 2025, VYNE announced a merger agreement with Yarrow Bioscience together with pre-closing private financings totaling about $200 million. That marks a major corporate transition and suggests the public shell and capital structure are being repurposed around a new autoimmune program. [[7]](https://vynetherapeutics.com/press-releases/vyne-therapeutics-and-yarrow-bioscience-announce-merger-agreement/)
