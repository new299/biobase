# Erasca — Research Notes

## Overview

Erasca, Inc. (NASDAQ: ERAS) is a San Diego, CA-based clinical-stage precision oncology company singularly focused on discovering, developing, and commercializing therapies for patients with RAS/MAPK pathway-driven cancers. Founded in 2018 by Jonathan Lim, MD (CEO) — many team members have prior backgrounds at Ignyta and Roche/Genentech. Total raised: ~$887M+ including IPO proceeds. Key investors: **ARCH Venture Partners**, Cormorant Asset Management, and others. Current lead programs: ERAS-0015 (pan-RAS molecular glue, Phase 1) and ERAS-4001 (pan-KRAS inhibitor, Phase 1). Cash ~$386.7M as of June 30, 2025; runway into H2 2028. [[1]](https://investors.erasca.com/news-releases/news-release-details/erasca-reports-fourth-quarter-and-full-year-2025-business/) [[2]](https://www.globenewswire.com/news-release/2024/05/17/2883986/0/en/Erasca-Announces-Strategic-In-Licensing-of-RAS-Targeting-Franchise.html)

---

## Technology & Pipeline

- **RAS/MAPK Platform**: Comprehensive approach targeting the full RAS/MAPK pathway with multiple complementary mechanisms to overcome adaptive resistance. [[1]](https://investors.erasca.com/news-releases/news-release-details/erasca-reports-fourth-quarter-and-full-year-2025-business/)
- **ERAS-0015 (pan-RAS molecular glue)**: Potential best-in-class pan-RAS molecular glue for patients with RAS-mutant (RASm) solid tumors. IND cleared by FDA; Phase 1 monotherapy data expected 2026. [[2]](https://www.globenewswire.com/news-release/2024/05/17/2883986/0/en/Erasca-Announces-Strategic-In-Licensing-of-RAS-Targeting-Franchise.html)
- **ERAS-4001 (pan-KRAS inhibitor)**: Potential first-in-class pan-KRAS inhibitor for KRAS-mutant (KRASm) solid tumors. IND submitted; Phase 1 data expected 2026. [[2]](https://www.globenewswire.com/news-release/2024/05/17/2883986/0/en/Erasca-Announces-Strategic-In-Licensing-of-RAS-Targeting-Franchise.html)
- Both programs in-licensed May 2024 from external partners as part of strategic RAS franchise build-out.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2019 | $42M | Undisclosed |
| Series B | 2020 | $200M | **ARCH Venture Partners** (co-lead), Cormorant Asset Management (co-lead) |
| Series C | 2021 | $300M | Additional top-tier investors |
| IPO (NASDAQ: ERAS) | Jul 2021 | ~$345M | Public market |
| Private Placement | Mar 2024 | $45M (oversubscribed) | Healthcare-focused investors |
| Equity Offering | 2024 | $160M | High quality healthcare-focused investors |

Total raised: ~$887M+ (pre-IPO VC + IPO + subsequent offerings). [[3]](https://www.erasca.com/news/erasca-announces-45-million-oversubscribed-private-placement-financing/)

**ARCH Venture Partners Investment**

---

## References

1. Erasca — Q4 and Full Year 2025 Business Updates and Financial Results: [https://investors.erasca.com/news-releases/news-release-details/erasca-reports-fourth-quarter-and-full-year-2025-business/](https://investors.erasca.com/news-releases/news-release-details/erasca-reports-fourth-quarter-and-full-year-2025-business/)
2. GlobeNewswire — Erasca Strategic In-Licensing of RAS-Targeting Franchise (May 2024): [https://www.globenewswire.com/news-release/2024/05/17/2883986/0/en/Erasca-Announces-Strategic-In-Licensing-of-RAS-Targeting-Franchise.html](https://www.globenewswire.com/news-release/2024/05/17/2883986/0/en/Erasca-Announces-Strategic-In-Licensing-of-RAS-Targeting-Franchise.html)
3. Erasca — $45M oversubscribed private placement (Mar 2024): [https://www.erasca.com/news/erasca-announces-45-million-oversubscribed-private-placement-financing/](https://www.erasca.com/news/erasca-announces-45-million-oversubscribed-private-placement-financing/)
