# Novonesis

## Overview
Novonesis is a global biosolutions company formed by combining Novozymes and Chr. Hansen.[[1]](https://www.novonesis.com/en/about-us)[[2]](https://www.novonesis.com/en/news/news-archive/2024/01/novozymes-and-chr-hansen-have-successfully-completed-the-combination) The company focuses on industrial enzymes, microbial solutions, and broader biosolutions across food, agriculture, health, and industrial markets.[[1]](https://www.novonesis.com/en/about-us)

## Technology and Business
Novonesis describes itself as a pure-play biosolutions company using enzymes, microbes, and fermentation-based technologies to improve industrial and biological processes.[[1]](https://www.novonesis.com/en/about-us) This fits the local note's yeast and bio-based process angle, but the current company is broader than biofuels alone.[[1]](https://www.novonesis.com/en/about-us)

## Investors
Novonesis is a public company rather than a venture-backed startup, so ownership is through the public markets.[[2]](https://www.novonesis.com/en/news/news-archive/2024/01/novozymes-and-chr-hansen-have-successfully-completed-the-combination)

## Acquisitions and Corporate Activity
The defining corporate event was the completion of the Novozymes and Chr. Hansen combination in January 2024, after which the combined company adopted the Novonesis name.[[2]](https://www.novonesis.com/en/news/news-archive/2024/01/novozymes-and-chr-hansen-have-successfully-completed-the-combination) More recently, on April 8, 2026, Novonesis announced an agreement to acquire a production facility in Rayong, Thailand from Meihua for about USD 50 million to expand fermentation capacity in Southeast Asia.[[3]](https://www.globenewswire.com/news-release/2026/04/08/3269819/0/en/Novonesis-expands-global-footprint-with-acquisition-of-production-facility-in-Southeast-Asia.html)
