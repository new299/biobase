# N-NOSE

## Overview

N-NOSE is a urine-based cancer screening test commercialized by Hirotsu Bio Science in Japan.[[1]](https://hbio.jp/en/) The test uses nematodes as living biosensors to detect odor signatures associated with cancer in urine.[[1]](https://hbio.jp/en/)

## Technology

Hirotsu Bio Science says the test leverages the olfactory behavior of the nematode *C. elegans*, which can distinguish urine from cancer patients versus healthy individuals.[[1]](https://hbio.jp/en/) The company positions this as a low-burden, non-invasive early detection approach based on worm chemotaxis rather than molecular sequencing or conventional biomarker assays.[[1]](https://hbio.jp/en/)

## Investors

No clearly disclosed institutional financing round or investor syndicate was identified in the reviewed public sources for the N-NOSE product itself. The public site reviewed is product- and consumer-facing rather than financing-focused.[[1]](https://hbio.jp/en/)

## Acquisitions and Strategic Transactions

No acquisition involving N-NOSE as a product line or Hirotsu Bio Science was identified in the reviewed sources. The public footprint reviewed is centered on commercialization and product expansion rather than M&A.[[1]](https://hbio.jp/en/)
