# Receptos

## Overview
Receptos was a clinical-stage biopharmaceutical company developing therapies for immune and metabolic diseases [[1]](https://www.drugdiscoverynews.com/celgene-inks-definitive-agreement-to-acquire-receptos-inc-9761).

## Technology
Its lead asset was ozanimod, an oral selective S1P1 and S1P5 receptor modulator for inflammatory bowel disease and relapsing multiple sclerosis [[1]](https://www.drugdiscoverynews.com/celgene-inks-definitive-agreement-to-acquire-receptos-inc-9761).

## Investors
The reviewed sources for this note centered on the exit transaction rather than the private investor syndicate. I did not identify a primary-source financing announcement during this pass [[1]](https://www.drugdiscoverynews.com/celgene-inks-definitive-agreement-to-acquire-receptos-inc-9761).

## Acquisitions / Strategic Transactions
Celgene agreed in 2015 to acquire Receptos for approximately $7.2 billion in cash, principally to obtain ozanimod and expand its inflammation and immunology portfolio [[1]](https://www.drugdiscoverynews.com/celgene-inks-definitive-agreement-to-acquire-receptos-inc-9761).

## References
[[1]](https://www.drugdiscoverynews.com/celgene-inks-definitive-agreement-to-acquire-receptos-inc-9761)
