# Blueprint Medicines

## Overview
Blueprint Medicines was a biopharmaceutical company focused on rare immunological disease and KIT-driven cancers, best known for Ayvakit/Ayvakyt and its mast cell biology programs.[[1]](https://www.sanofi.com/en/media-room/press-releases/2025/2025-06-02-05-00-00-3091541)[[2]](https://www.blueprintmedicines.com/) It operated as a commercial-stage oncology and immunology biotech before acquisition by Sanofi.[[2]](https://www.blueprintmedicines.com/)

## Technology and Pipeline
Blueprint built its strategy around kinase-targeted precision medicines, particularly KIT inhibition in systemic mastocytosis and related diseases.[[1]](https://www.sanofi.com/en/media-room/press-releases/2025/2025-06-02-05-00-00-3091541) At acquisition, Sanofi highlighted Ayvakit/Ayvakyt, elenestinib, and BLU-808 as important assets.[[1]](https://www.sanofi.com/en/media-room/press-releases/2025/2025-06-02-05-00-00-3091541)

## Investors and Financing
The local note references Third Rock Ventures, reflecting Blueprint’s founding history. The reviewed primary sources here focused on the Sanofi acquisition rather than the company’s earlier venture syndicate.

## Acquisitions and Corporate Activity
Sanofi announced in June 2025 that it would acquire Blueprint for $129.00 per share in cash plus contingent value rights worth up to an additional $6 per share, implying a total equity value of about $9.5 billion on a fully diluted basis, and completed the acquisition in July 2025.[[1]](https://www.sanofi.com/en/media-room/press-releases/2025/2025-06-02-05-00-00-3091541)[[3]](https://www.sanofi.com/en/media-room/press-releases/2025/2025-07-18-05-00-00-3117709)
