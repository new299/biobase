# Enzene Biosciences — Research Notes

## Overview

Enzene Biosciences is a Pune, India-based biologics CDMO and subsidiary of Alkem Laboratories, Ltd., pioneering continuous bioprocessing manufacturing for biologics. The company developed EnzeneX™ — the first fully-connected continuous manufacturing (FCCM) platform validated for commercial biologics supply. Expanding globally: $50M New Jersey manufacturing facility under construction (~June 2024 operational), US expansion plans to hire 300. Launched Drug Discovery Division at BIO 2024. [[1]](https://www.enzene.com/) [[2]](https://www.fiercepharma.com/manufacturing/indias-enzene-biosciences-unveils-50m-nj-plant-plans-hire-300)

---

## Technology & Services

- **EnzeneX™ Platform**: First fully-connected continuous manufacturing (FCCM) platform validated for commercial biologics supply. Uses intensified perfusion with alternate tangential flow (ATF) filtration and automated multi-column chromatography for continuous, high-yield biologics production — reducing manufacturing footprint, cycle times, and costs vs. traditional batch bioprocessing. [[1]](https://www.enzene.com/cdmo-solutions/)
- **CDMO Services**: Biologics development from cell line development through process development, clinical and commercial manufacturing. Established sites in Pune (India) with expansion to Princeton, NJ (USA). [[2]](https://www.fiercepharma.com/manufacturing/indias-enzene-biosciences-unveils-50m-nj-plant-plans-hire-300)
- **Drug Discovery Division**: Launched May 2024 at BIO International Convention — providing early-stage drug discovery services from Pune facility. [[3]](https://www.enzene.com/news/enzene-launches-discovery-services-division/)

---

## Funding & Corporate Structure

Enzene Biosciences is a subsidiary of Alkem Laboratories, Ltd. (NSE: ALKEM), one of India's top 5 pharmaceutical companies. The New Jersey expansion involves $50M capital investment. [[2]](https://www.fiercepharma.com/manufacturing/indias-enzene-biosciences-unveils-50m-nj-plant-plans-hire-300)

---

## References

1. Enzene Biosciences — Homepage: [https://www.enzene.com/](https://www.enzene.com/)
2. Fierce Pharma — Enzene Biosciences $50M New Jersey manufacturing plant: [https://www.fiercepharma.com/manufacturing/indias-enzene-biosciences-unveils-50m-nj-plant-plans-hire-300](https://www.fiercepharma.com/manufacturing/indias-enzene-biosciences-unveils-50m-nj-plant-plans-hire-300)
3. Enzene Biosciences — Drug Discovery Division launch at BIO 2024: [https://www.enzene.com/news/enzene-launches-discovery-services-division/](https://www.enzene.com/news/enzene-launches-discovery-services-division/)
