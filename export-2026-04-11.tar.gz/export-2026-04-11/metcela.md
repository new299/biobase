# Metcela

## Overview

Metcela is a regenerative medicine company developing cell therapies, especially allogeneic cell products for cardiovascular diseases and related serious conditions.[[1]](https://metcela.com/en/company/) The company is based in Japan with global ambitions.[[1]](https://metcela.com/en/company/)

## Technology

Metcela's core programs include allogeneic cell therapies and regenerative medicine platforms for cardiac disease, with public materials highlighting a pipeline around ischemic cardiomyopathy and related indications.[[1]](https://metcela.com/en/company/) The company describes its work as applying novel cell technologies to areas of high unmet need in regenerative medicine.[[1]](https://metcela.com/en/company/)

## Investors

F-Prime Capital lists Metcela as a portfolio company.[[2]](https://www.fprimecapital.com/company/metcela/) The reviewed official company pages did not surface a single clean financing announcement with a full investor syndicate in text, so investor detail remains partial in this note.

## Acquisitions and Strategic Transactions

No acquisition involving Metcela was identified in the reviewed sources. The public record reviewed is centered on company development and regenerative medicine programs rather than M&A.[[1]](https://metcela.com/en/company/)
