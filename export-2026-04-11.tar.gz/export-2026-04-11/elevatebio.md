# ElevateBio — Research Notes

## Overview

ElevateBio is a Waltham, MA-based biotechnology company founded in 2019 developing and manufacturing cell and gene therapies through a vertically integrated model — combining BaseCamp (cGMP manufacturing/process development) and Life Edit (gene editing R&D) divisions. Total raised: ~$1.3B ($150M Series A + $525M Series C led by Matrix Capital + $401M Series D May 2023). Has established cGMP facilities in Waltham, MA and Pittsburgh, PA. ICMC-certified for viral gene delivery, non-viral gene delivery, and cell therapy manufacturing (Aug 2025). [[1]](https://www.businesswire.com/news/home/20210315005162/en/ElevateBio-Scales-Disruptive-Cell-and-Gene-Therapy-Business-Model-with-$525-Million-Series-C-Financing) [[2]](https://elevate.bio/)

---

## Technology & Divisions

- **BaseCamp**: End-to-end process development and cGMP manufacturing business for cell and gene therapy products — serving as a CDMO for external pharma/biotech clients as well as supporting ElevateBio's internal pipeline. ICMC-certified for three manufacturing modalities (Aug 2025). [[2]](https://elevate.bio/)
- **Life Edit**: Gene editing technologies and R&D division based in Durham, NC — developing proprietary gene editing approaches for therapeutic applications. [[2]](https://elevate.bio/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2019 | $150M | MPM Capital, others |
| Series C | Mar 2021 | $525M | Matrix Capital Management (lead), SoftBank Vision Fund 2, Fidelity |
| Series D | May 2023 | $401M | Undisclosed |

Total raised: ~$1.3B. [[1]](https://www.businesswire.com/news/home/20210315005162/en/ElevateBio-Scales-Disruptive-Cell-and-Gene-Therapy-Business-Model-with-$525-Million-Series-C-Financing)

---

## References

1. BusinessWire — ElevateBio $525M Series C (Mar 2021): [https://www.businesswire.com/news/home/20210315005162/en/ElevateBio-Scales-Disruptive-Cell-and-Gene-Therapy-Business-Model-with-$525-Million-Series-C-Financing](https://www.businesswire.com/news/home/20210315005162/en/ElevateBio-Scales-Disruptive-Cell-and-Gene-Therapy-Business-Model-with-$525-Million-Series-C-Financing)
2. ElevateBio — Homepage: [https://elevate.bio/](https://elevate.bio/)
