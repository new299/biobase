# Arcutis Biotherapeutics

## Overview
Arcutis Biotherapeutics is a commercial-stage biopharmaceutical company focused on medical dermatology and immune-mediated skin diseases.[[1]](https://investors.arcutis.com/) Its commercial and pipeline portfolio is built around advanced targeted therapies for inflammatory dermatologic conditions.[[1]](https://investors.arcutis.com/)

## Technology and Pipeline
Arcutis says it uses a dermatology-focused development platform to create differentiated therapies for inflammatory skin diseases.[[1]](https://investors.arcutis.com/) The company’s public profile emphasizes approved targeted topicals and a broader immuno-dermatology pipeline.[[1]](https://investors.arcutis.com/)

## Investors and Financing
As a public company, Arcutis is financed through public markets rather than recent venture rounds. The local note’s RA Capital reference reflects its institutional biotech shareholder base, though the reviewed primary source here was the public investor site rather than a specific financing announcement.

## Acquisitions and Corporate Activity
In September 2022, Arcutis announced the acquisition of privately held Ducentis BioTherapeutics Ltd. for upfront cash and stock plus contingent payments, adding DS-234, a CD200R agonist program for atopic dermatitis and other inflammatory diseases.[[2]](https://investors.arcutis.com/news-releases/news-release-details/arcutis-announces-acquisition-ducentis-biotherapeutics-ltd)
