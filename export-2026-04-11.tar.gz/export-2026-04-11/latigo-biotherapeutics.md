# Latigo Biotherapeutics

## Overview

Latigo Biotherapeutics is a clinical-stage biotechnology company developing non-opioid pain medicines, especially highly selective NaV1.8 inhibitors.[[1]](https://latigobio.com/latigo-biotherapeutics-debuts-with-135-million-series-a-financing-to-develop-non-opioid-pain-medicines/) The company emerged from stealth in February 2024.[[1]](https://latigobio.com/latigo-biotherapeutics-debuts-with-135-million-series-a-financing-to-develop-non-opioid-pain-medicines/)

## Technology

Latigo's core approach is selective inhibition of NaV1.8, a validated pain target, to develop non-addictive analgesics for acute and chronic pain.[[1]](https://latigobio.com/latigo-biotherapeutics-debuts-with-135-million-series-a-financing-to-develop-non-opioid-pain-medicines/) The company has advanced multiple NaV1.8 programs, and in March 2025 it announced FDA Fast Track designation for LTG-001 for acute pain.[[2]](https://latigobio.com/2025/03/)

## Investors

Latigo debuted with a $135 million Series A incubated by Westlake Village BioPartners and co-led by Westlake, 5AM Ventures, and Foresite Capital, with participation from Corner Ventures.[[1]](https://latigobio.com/latigo-biotherapeutics-debuts-with-135-million-series-a-financing-to-develop-non-opioid-pain-medicines/) In March 2025, it closed a $150 million Series B led by funds managed by Blue Owl Capital, with participation from Deep Track Capital, Access Biotechnology, Qatar Investment Authority, Cormorant Asset Management, Sanofi Ventures, Rock Springs Capital, UPMC Enterprises, Kern Capital, and existing investors Westlake, Foresite, 5AM, and Alexandria Venture Investments.[[3]](https://latigobio.com/latigo-biotherapeutics-closes-150-million-in-series-b-financing-to-advance-non-opioid-pain-therapeutics/)

## Acquisitions and Strategic Transactions

No acquisition involving Latigo Biotherapeutics was identified in the reviewed sources. The public story to date is centered on financing and clinical progress of its pain programs.[[3]](https://latigobio.com/latigo-biotherapeutics-closes-150-million-in-series-b-financing-to-advance-non-opioid-pain-therapeutics/) [[2]](https://latigobio.com/2025/03/)
