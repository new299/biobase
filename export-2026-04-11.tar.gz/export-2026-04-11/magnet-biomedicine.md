# Magnet Biomedicine

## Overview

Magnet Biomedicine is a biotechnology company developing molecular glue medicines for precision medicine applications.[[1]](https://magnetbio.com/)

## Technology

Magnet's core platform is `TrueGlue`, a discovery platform for rationally identifying and developing molecular glues.[[1]](https://magnetbio.com/) The company frames its science around targeted protein modulation using molecular glues, an area intended to expand the range of tractable disease targets beyond conventional small-molecule inhibition.[[1]](https://magnetbio.com/)

## Investors

Magnet emerged from stealth in September 2023 with $50 million in financing.[[2]](https://magnetbio.com/news/) The company site identifies investors including ARCH Venture Partners, Newpath Partners, Taiho Ventures, and Lilly.[[1]](https://magnetbio.com/)

## Acquisitions and Strategic Transactions

In February 2025, Magnet entered into a collaboration and license agreement with Lilly to discover and develop novel molecular glue medicines.[[3]](https://magnetbio.com/news/) No acquisition of Magnet itself was identified in the reviewed sources.
