# Aiolos Bio

## Overview
Aiolos Bio was a clinical-stage biopharmaceutical company focused on respiratory and inflammatory diseases.[[1]](https://www.gsk.com/en-gb/media/press-releases/gsk-enters-agreement-to-acquire-aiolos-bio/)[[2]](https://www.gsk.com/en-gb/media/press-releases/gsk-completes-acquisition-of-aiolos-bio/) Its lead asset was AIO-001, a long-acting anti-TSLP monoclonal antibody for asthma.[[1]](https://www.gsk.com/en-gb/media/press-releases/gsk-enters-agreement-to-acquire-aiolos-bio/)

## Technology and Pipeline
Aiolos built its strategy around AIO-001, a potentially best-in-class, long-acting anti-TSLP antibody with the potential for six-month dosing intervals.[[1]](https://www.gsk.com/en-gb/media/press-releases/gsk-enters-agreement-to-acquire-aiolos-bio/) GSK said the program could expand its respiratory biologics portfolio into lower-T2 asthma populations.[[1]](https://www.gsk.com/en-gb/media/press-releases/gsk-enters-agreement-to-acquire-aiolos-bio/)

## Investors
GSK’s acquisition release did not enumerate the full investor syndicate, but the local note’s Atlas Venture reference is directionally consistent with the strong private biotech financing environment around the company at launch. I am keeping the investor section narrow because the strongest primary source I reviewed was the acquisition announcement.

## Acquisitions and Corporate Activity
GSK announced in January 2024 that it would acquire Aiolos for a $1 billion upfront payment plus up to $400 million in success-based regulatory milestones, and completed the acquisition in February 2024.[[1]](https://www.gsk.com/en-gb/media/press-releases/gsk-enters-agreement-to-acquire-aiolos-bio/)[[2]](https://www.gsk.com/en-gb/media/press-releases/gsk-completes-acquisition-of-aiolos-bio/)
