# Caribou Biosciences — Research Notes

## Overview

Caribou Biosciences, Inc. (NASDAQ: CRBU) is a Berkeley, CA-based clinical-stage CRISPR genome-editing biopharmaceutical company developing allogeneic ("off-the-shelf") CAR-T cell therapies for hematologic malignancies. Co-founded by Jennifer Doudna (Nobel Laureate, CRISPR pioneer) and Rachel Haurwitz (CEO). As of September 30, 2025, held $159.2M in cash and marketable securities. [[1]](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-antler-phase-1-trial) [[2]](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-strategic-pipeline-prioritization/)

---

## Technology

- **chRDNA Genome Editing**: Proprietary CRISPR hybrid RNA-DNA (chRDNA) guides reduce off-target editing compared to standard sgRNA, enabling safer multiplex genome editing in allogeneic T cells. [[3]](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-reports-third-quarter-2025-financial-results)
- **Vispa-cel (CB-010)**: Allogeneic anti-CD19 CAR-T cell therapy for relapsed/refractory B cell non-Hodgkin lymphoma (r/r LBCL). Phase 1 ANTLER trial (Nov 2025 data): 82% ORR, 64% CR, 12-month PFS of 51% — on par with autologous CAR-T. FDA has recommended a randomized pivotal Phase 3 trial (~250 patients). [[1]](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-antler-phase-1-trial)
- **CB-011**: Allogeneic anti-BCMA CAR-T for relapsed/refractory multiple myeloma. Phase 1 CaMMouflage trial (Nov 2025 data): 92% ORR, 75% ≥CR, 91% MRD negativity in BCMA-naïve cohort at recommended dose for expansion. [[4]](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-cammouflage-phase-1)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2016 | $30M | 8VC, Lightspeed, Atlas |
| Series B | 2018 | $115M | Versant Ventures, 8VC, others |
| IPO (NASDAQ: CRBU) | Jul 2021 | ~$304M | Public markets |

Total raised (pre-IPO + IPO): ~$500M+. [[5]](https://www.crunchbase.com/organization/caribou-biosciences)

---

## References

1. Caribou Biosciences — ANTLER Phase 1 positive data (Nov 2025): [https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-antler-phase-1-trial](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-antler-phase-1-trial)
2. Caribou Biosciences — Strategic pipeline prioritization (focus on CB-010, CB-011): [https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-strategic-pipeline-prioritization/](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-strategic-pipeline-prioritization/)
3. Caribou Biosciences — Q3 2025 Financial Results: [https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-reports-third-quarter-2025-financial-results](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-reports-third-quarter-2025-financial-results)
4. Caribou Biosciences — CaMMouflage Phase 1 positive data (Nov 2025): [https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-cammouflage-phase-1](https://investor.cariboubio.com/news-releases/news-release-details/caribou-biosciences-announces-positive-data-cammouflage-phase-1)
5. Crunchbase — Caribou Biosciences: [https://www.crunchbase.com/organization/caribou-biosciences](https://www.crunchbase.com/organization/caribou-biosciences)
