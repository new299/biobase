# Agios Pharmaceuticals — Research Notes

## Overview

Agios Pharmaceuticals (NASDAQ: AGIO) is a commercial-stage biopharmaceutical company founded in 2007 in Cambridge, MA. Pioneered the field of **cancer metabolism** drugs targeting mutant IDH1/IDH2 enzymes. Sold its oncology business to Servier in 2021 for $1.8B; now focused on genetically defined diseases. [[1]](https://en.wikipedia.org/wiki/Agios_Pharmaceuticals)

---

## Technology

- **Cancer metabolism (IDH inhibitors)**: IDH1/IDH2 mutations cause cancer cells to produce oncometabolite 2-hydroxyglutarate (2-HG), blocking differentiation. Agios developed first-in-class small molecule inhibitors targeting these mutant enzymes.
- **TIBSOVO® (ivosidenib)**: First FDA-approved mutant IDH1 inhibitor. Approved for: relapsed/refractory AML with IDH1 mutation (Jul 2018); newly diagnosed AML unsuitable for standard therapy (May 2019); previously treated IDH1-mutant cholangiocarcinoma (Aug 2021). [[2]](https://www.cancer.gov/news-events/cancer-currents-blog/2018/ivosidenib-aml-fda-approval)
- **IDHIFA® (enasidenib)**: First FDA-approved mutant IDH2 inhibitor for relapsed/refractory AML (Aug 2017) — co-developed with Celgene (now BMS); rights sold to Servier 2021. [[3]](https://investor.agios.com/news-releases/news-release-details/fda-grants-approval-idhifar-first-oral-targeted-therapy-adult)
- **Post-oncology focus**: Pyruvokinase activators and other genetically-defined rare disease programs (e.g., pyruvate kinase deficiency, thalassemia).

---

## Funding & Key Deals

- **Celgene deal** (2010): $120M collaboration for cancer metabolism; licensed enasidenib.
- **IPO** (NASDAQ: AGIO): 2013.
- **Servier acquisition** (Apr 2021): Agios sold its oncology business (TIBSOVO + pipeline IDH programs) to Servier for **$1.8B**. [[1]](https://en.wikipedia.org/wiki/Agios_Pharmaceuticals)

---

## Key Patents

- IDH1 mutant inhibitor composition of matter and methods of use patents covering ivosidenib.
- IDH2 mutant inhibitor patents covering enasidenib.

---

## References

1. Wikipedia — Agios Pharmaceuticals: `https://en.wikipedia.org/wiki/Agios_Pharmaceuticals` | [https://en.wikipedia.org/wiki/Agios_Pharmaceuticals](https://en.wikipedia.org/wiki/Agios_Pharmaceuticals)
2. NCI — Ivosidenib AML approval: [https://www.cancer.gov/news-events/cancer-currents-blog/2018/ivosidenib-aml-fda-approval](https://www.cancer.gov/news-events/cancer-currents-blog/2018/ivosidenib-aml-fda-approval)
3. Agios IR — Enasidenib FDA approval: [https://investor.agios.com/news-releases/news-release-details/fda-grants-approval-idhifar-first-oral-targeted-therapy-adult](https://investor.agios.com/news-releases/news-release-details/fda-grants-approval-idhifar-first-oral-targeted-therapy-adult)
