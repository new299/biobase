# Lifordi Immunotherapeutics

## Overview

Lifordi Immunotherapeutics is a clinical-stage biotechnology company developing antibody-drug conjugates (`ADCs`) for autoimmune and inflammatory disorders.[[1]](https://www.lifordi.com/about-1) The company is applying ADC concepts used in oncology to immune-mediated disease.[[1]](https://www.lifordi.com/about-1)

## Technology

Lifordi's platform targets internalizing immune-cell surface proteins to deliver potent glucocorticoids or other payloads directly to disease-driving immune cells.[[1]](https://www.lifordi.com/about-1) Its lead program LFD-200 is described as an ADC delivering a glucocorticoid to immune cells in rheumatoid arthritis and related settings.[[2]](https://www.businesswire.com/news/home/20251118849111/en/Lifordi-Immunotherapeutics-Secures-Strategic-Investment-from-Sanofi-Ventures-and-Additional-Capital-from-Existing-Investors?feedref=JjAwJuNHiystnCoBq_hl-cs0-sVUkLQ-g1yfAQccGz6qcp-o_pnudlUwsb5apQ1S4gUE65BTfjH3-pSuqdv0gW3cb3F4oTIgUqCPafFkgu4cAX_50H1C39uqsv-NuMBU)

## Investors

Lifordi's about page lists ARCH Venture Partners, 5AM Ventures, Atlas Venture, and Sanofi Ventures as leading investors.[[1]](https://www.lifordi.com/about-1) In November 2025, the company announced a strategic investment from Sanofi Ventures plus additional capital from existing investors ARCH, 5AM, and Atlas, bringing total capital raised to $112 million.[[2]](https://www.businesswire.com/news/home/20251118849111/en/Lifordi-Immunotherapeutics-Secures-Strategic-Investment-from-Sanofi-Ventures-and-Additional-Capital-from-Existing-Investors?feedref=JjAwJuNHiystnCoBq_hl-cs0-sVUkLQ-g1yfAQccGz6qcp-o_pnudlUwsb5apQ1S4gUE65BTfjH3-pSuqdv0gW3cb3F4oTIgUqCPafFkgu4cAX_50H1C39uqsv-NuMBU)

## Acquisitions and Strategic Transactions

No acquisition involving Lifordi was identified in the reviewed sources. The key public transaction is the 2025 strategic investment round and continued Phase 1 clinical development rather than M&A.[[2]](https://www.businesswire.com/news/home/20251118849111/en/Lifordi-Immunotherapeutics-Secures-Strategic-Investment-from-Sanofi-Ventures-and-Additional-Capital-from-Existing-Investors?feedref=JjAwJuNHiystnCoBq_hl-cs0-sVUkLQ-g1yfAQccGz6qcp-o_pnudlUwsb5apQ1S4gUE65BTfjH3-pSuqdv0gW3cb3F4oTIgUqCPafFkgu4cAX_50H1C39uqsv-NuMBU)
