# Nucleix

## Overview
Nucleix is a liquid-biopsy company focused on cancer detection and monitoring using epigenetic biomarkers.[[1]](https://nucleix.com/us/company/)[[2]](https://nucleix.com/company/) The company says its EpiCheck platform uses PCR-based epigenetic assays to detect early-stage and recurrent cancer from non-invasive samples.[[1]](https://nucleix.com/us/company/)

## Technology
Nucleix's core technology is PCR-based methylation analysis for liquid biopsy and other minimally invasive cancer-testing workflows.[[1]](https://nucleix.com/us/company/) Its public materials emphasize assays such as Lung EpiCheck and the broader EpiCheck platform for earlier disease detection and recurrence monitoring.[[1]](https://nucleix.com/us/company/)

## Investors
In February 2024, Nucleix announced that it had secured $55 million in financing led by RA Capital Management, with participation from additional life-science investors to advance Lung EpiCheck for early lung-cancer detection.[[3]](https://nucleix.com/blog/news_and_events/nucleix-secures-55-million-funding-led-by-ra-capital-management-and-additional-prominent-life-science-investors-to-advance-lung-epicheck-for-early-detection-of-lung-cancer/) The company website also identifies OrbiMed Israel Limited Partnership and Sands Capital among its investors.[[1]](https://nucleix.com/us/company/)

## Acquisitions and Corporate Activity
No acquisition involving Nucleix was identified in the reviewed public sources. The clearest recent corporate milestone is the 2024 financing to support Lung EpiCheck development and commercialization.[[3]](https://nucleix.com/blog/news_and_events/nucleix-secures-55-million-funding-led-by-ra-capital-management-and-additional-prominent-life-science-investors-to-advance-lung-epicheck-for-early-detection-of-lung-cancer/)
