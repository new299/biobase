# Cellens Inc

## Overview
Cellens is a cancer diagnostics company developing non-invasive tests based on mechanobiology and AI, with early emphasis on bladder cancer detection from urine samples.[[1]](https://cellensinc.com/)[[2]](https://cellensinc.com/about-us/)[[3]](https://www.businesswire.com/news/home/20240625056154/en/Cellens-Announces-Collaboration-with-Bruker-BioAFM-to-Advance-Mechanobiology-Technology-for-Cancer-Detection)

## Technology
The company says its BioFeel platform uses atomic force microscopy-derived biophysical cell markers plus machine-learning analysis to identify cancer signatures at the single-cell level. It traces the underlying IP to Tufts University research.[[1]](https://cellensinc.com/)[[2]](https://cellensinc.com/about-us/)[[3]](https://www.businesswire.com/news/home/20240625056154/en/Cellens-Announces-Collaboration-with-Bruker-BioAFM-to-Advance-Mechanobiology-Technology-for-Cancer-Detection)

## Investors
Cellens announced a $6.5 million Series Seed in December 2025 led by SOSV, with participation from Labcorp Venture Fund, KOLON, Blackwood Healthcare Breakthroughs, Tufts University, American Cancer Society BrightEdge, Cancer Fund, TiE Boston Angels, and other strategic investors.[[4]](https://cellensinc.com/cellens-raises-6-5m-to-advance-its-ai-driven-mechanobiology-platform-for-non-invasive-bladder-cancer-diagnostics/)

## Acquisitions / Other
The company also announced a collaboration with Bruker BioAFM in 2024 to advance its mechanobiology-based cancer detection workflow.[[3]](https://www.businesswire.com/news/home/20240625056154/en/Cellens-Announces-Collaboration-with-Bruker-BioAFM-to-Advance-Mechanobiology-Technology-for-Cancer-Detection)
