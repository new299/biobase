# ABK Biomedical, Inc.

## Overview
ABK Biomedical is a clinical-stage medical device company developing advanced imageable embolic therapies for liver tumors and other hypervascular tumors.[[1]](https://abkbiomedical.com/)[[2]](https://abkbiomedical.com/about-us/history/) Its lead product is Eye90 microspheres for Y90 radioembolization.[[1]](https://abkbiomedical.com/)

## Technology
ABK’s platform is based on x-ray-visible glass microsphere technology originally developed at Dalhousie University and later adapted for Y90 radioembolization.[[2]](https://abkbiomedical.com/about-us/history/) The company says Eye90 microspheres are designed to improve control, visualization, and personalized dosimetry in unresectable liver tumors.[[3]](https://abkbiomedical.com/press-releases/)

## Investors
ABK’s October 2025 financing announcement states that it raised an oversubscribed US$35 million Series D led by J.P. Morgan Life Sciences Private Capital, with participation from existing investors F-Prime, Santé Ventures, Eight Roads Ventures, and an undisclosed medical device company.[[4]](https://www.biospace.com/press-releases/abk-biomedical-raises-us-35m-in-series-d-financing) The local note’s F-Prime reference is consistent with that investor syndicate.[[4]](https://www.biospace.com/press-releases/abk-biomedical-raises-us-35m-in-series-d-financing)

## Acquisitions and Corporate Activity
No acquisition involving ABK Biomedical was identified in the reviewed public sources. The most significant recent public milestones are FDA IDE progress in the ROUTE90 pivotal study and the 2025 Series D financing to support commercialization preparation.[[3]](https://abkbiomedical.com/press-releases/)[[4]](https://www.biospace.com/press-releases/abk-biomedical-raises-us-35m-in-series-d-financing)
