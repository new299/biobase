# 3EO Health — Research Notes

## Overview

3EO Health is a molecular point-of-care diagnostics company founded in 2021 in Beverly, Massachusetts. Develops the proprietary **3TR technology** to deliver PCR-grade molecular testing at dramatically lower cost and complexity than existing platforms. [[1]](https://www.cbinsights.com/company/3eo-health) [[2]](https://www.businesswire.com/news/home/20240117319680/en/3EO-Health-announces-the-U.S.-launch-of-the-first-High-Efficiency-Molecular-Platform)

**Founders:** Peng Yin, Thomas Schaus, Nikhil Gopalkrishnan. [[1]](https://www.cbinsights.com/company/3eo-health)

---

## Technology

- **3TR (Triple Trigger Reaction) Technology**: Proprietary isothermal amplification platform licensed from the Wyss Institute at Harvard University (August 2022). Eliminates sample preparation, pipetting, and expensive consumables — delivers up to 70% cost reduction vs. prevailing molecular diagnostics. [[2]](https://www.businesswire.com/news/home/20240117319680/en/3EO-Health-announces-the-U.S.-launch-of-the-first-High-Efficiency-Molecular-Platform) [[3]](https://www.businesswire.com/news/home/20240327647032/en/3EO-Health-Announces-the-First-Point-of-Care-Molecular-Test-Under-$15)
- **First point-of-care molecular test priced under $15** per test, announced March 2024. [[3]](https://www.businesswire.com/news/home/20240327647032/en/3EO-Health-Announces-the-First-Point-of-Care-Molecular-Test-Under-$15)
- **FDA EUA**: Received Emergency Use Authorization for COVID-19 molecular test using 3TR technology (Q4 2023). [[4]](https://www.linkedin.com/posts/3eohealth_unlockinghealthandcare-makingmolecularmatter-activity-7114500627832979456-dMsG)
- **Multiplex expansion**: NIH RADx Tech award (2023) to expand 3TR into multiplex format for respiratory and STI panels. [[5]](https://www.businesswire.com/news/home/20231016370507/en/3EO-Health-Receives-NIH-RADx-Tech-Award-to-Expand-Application-of-its-3TR-Point-of-Care-Technology)

---

## Funding & Investors

| Round | Date | Amount | Investors |
|-------|------|--------|-----------|
| Incubator/Accelerator | Jun 2023 | Undisclosed | MedTech Innovator, ARCH Venture Partners, Section 32, Taihill Venture |
| NIH RADx Tech Award | Oct 2023 | Undisclosed (govt grant) | NIH |

Total institutional investors: 5 (ARCH Venture Partners, Section 32, MedTech Innovator, Taihill Venture + NIH). Specific round sizes not publicly disclosed. [[1]](https://www.cbinsights.com/company/3eo-health) [[5]](https://www.businesswire.com/news/home/20231016370507/en/3EO-Health-Receives-NIH-RADx-Tech-Award-to-Expand-Application-of-its-3TR-Point-of-Care-Technology)

---

## References

1. CB Insights — 3EO Health profile: [https://www.cbinsights.com/company/3eo-health](https://www.cbinsights.com/company/3eo-health)
2. BusinessWire — "High Efficiency" platform launch (Jan 2024): [https://www.businesswire.com/news/home/20240117319680/en/3EO-Health-announces-the-U.S.-launch-of-the-first-High-Efficiency-Molecular-Platform](https://www.businesswire.com/news/home/20240117319680/en/3EO-Health-announces-the-U.S.-launch-of-the-first-High-Efficiency-Molecular-Platform)
3. BusinessWire — Sub-$15 test announcement (Mar 2024): [https://www.businesswire.com/news/home/20240327647032/en/3EO-Health-Announces-the-First-Point-of-Care-Molecular-Test-Under-$15](https://www.businesswire.com/news/home/20240327647032/en/3EO-Health-Announces-the-First-Point-of-Care-Molecular-Test-Under-$15)
4. LinkedIn — EUA announcement: [https://www.linkedin.com/posts/3eohealth_unlockinghealthandcare-makingmolecularmatter-activity-7114500627832979456-dMsG](https://www.linkedin.com/posts/3eohealth_unlockinghealthandcare-makingmolecularmatter-activity-7114500627832979456-dMsG)
5. BusinessWire — NIH RADx Award (Oct 2023): [https://www.businesswire.com/news/home/20231016370507/en/3EO-Health-Receives-NIH-RADx-Tech-Award-to-Expand-Application-of-its-3TR-Point-of-Care-Technology](https://www.businesswire.com/news/home/20231016370507/en/3EO-Health-Receives-NIH-RADx-Tech-Award-to-Expand-Application-of-its-3TR-Point-of-Care-Technology)
