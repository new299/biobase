# Vertex Pharmaceuticals

## Overview

Vertex is a global biotechnology company focused on transformative medicines for serious diseases. The company says it has approved therapies in cystic fibrosis, sickle cell disease, and transfusion-dependent beta thalassemia, while advancing a broad pipeline in pain, kidney disease, type 1 diabetes, myotonic dystrophy type 1, alpha-1 antitrypsin deficiency, and other indications. [[1]](https://www.vrtx.com/en-global/our-company/) [[2]](https://news.vrtx.com/news-releases/news-release-details/vertex-enters-agreement-acquire-alpine-immune-sciences) [[3]](https://investors.vrtx.com/news-releases/news-release-details/vertex-provides-pipeline-and-business-updates-advance-upcoming-1)

## Technology And Pipeline

Vertex is unusual among big biotechs because it spans multiple modalities, including small molecules, gene editing, cell therapy, and protein therapeutics. Public company materials emphasize a robust pipeline beyond cystic fibrosis, including renal disease, pain, diabetes, and immunology. [[1]](https://www.vrtx.com/en-global/our-company/) [[3]](https://investors.vrtx.com/news-releases/news-release-details/vertex-provides-pipeline-and-business-updates-advance-upcoming-1)

## Acquisitions

In 2024, Vertex agreed to acquire Alpine Immune Sciences for approximately $4.9 billion in cash, adding protein engineering and immunotherapy capabilities centered on povetacicept. The transaction highlights Vertex's continuing use of acquisitions to expand beyond its legacy franchises. [[2]](https://news.vrtx.com/news-releases/news-release-details/vertex-enters-agreement-acquire-alpine-immune-sciences)

## Strategic Position

Vertex is not a startup-style financing story but a mature biotech with significant commercial scale and an expanding specialty-medicine portfolio. Its strategy combines deep disease biology, internal innovation, and selective acquisitions to build multiple durable franchises. [[1]](https://www.vrtx.com/en-global/our-company/) [[3]](https://investors.vrtx.com/news-releases/news-release-details/vertex-provides-pipeline-and-business-updates-advance-upcoming-1)
