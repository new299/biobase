# EurekaBio (Shenzhen Eureka Biotechnology) — Research Notes

## Overview

EurekaBio (Shenzhen Eureka Biotechnology Co., Limited) is a Shenzhen, China-based cell and gene therapy (CGT) contract development and manufacturing company founded in 2014. The company specializes in comprehensive manufacturing solutions for cell therapy products, particularly lentiviral vectors (LVV) and adeno-associated virus (AAV) for CGT applications. Total raised: $40M+ (Series B+ Feb 2024). Key investor: YUEXIU Industrial Fund. [[1]](https://www.eurekabio.com/) [[2]](https://www.eurekabio.com/news-amp-events/news/299.html)

---

## Technology & Services

- **EuLV™ Lentiviral Vector Production System**: Proprietary cutting-edge technology enabling large-scale lentiviral vector (LVV) production using stable cell lines in a serum-free suspension system — enabling consistent, scalable LVV manufacturing for CAR-T and other cell therapies. [[1]](https://www.eurekabio.com/)
- **AAV Manufacturing**: Comprehensive solutions for adeno-associated virus (AAV) gene therapy vector production. [[1]](https://www.eurekabio.com/)
- **Cell Therapy Manufacturing**: End-to-end CGT contract manufacturing including process development and GMP production for in vivo CAR-T and other cell and gene therapy products.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series B+ | Feb 2024 | $40M+ | YUEXIU Industrial Fund (lead) |

Total raised: $40M+. [[2]](https://www.eurekabio.com/news-amp-events/news/299.html)

---

## References

1. EurekaBio — Homepage: [https://www.eurekabio.com/](https://www.eurekabio.com/)
2. EurekaBio — Series B+ financing completion announcement (Feb 2024): [https://www.eurekabio.com/news-amp-events/news/299.html](https://www.eurekabio.com/news-amp-events/news/299.html)
