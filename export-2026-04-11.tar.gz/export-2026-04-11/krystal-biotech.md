# Krystal Biotech

## Overview

Krystal Biotech is a biotechnology company developing and commercializing genetic medicines for rare diseases using its proprietary redosable HSV vector platform.[[1]](https://ir.krystalbio.com/investors) The company commercialized VYJUVEK for dystrophic epidermolysis bullosa and maintains a broader gene therapy pipeline.[[2]](https://ir.krystalbio.com/news-releases/news-release-details/krystal-biotech-announces-160-million-private-placement-equity)

## Technology

Krystal's core technology is its proprietary redosable HSV vector platform, which the company says supports viral vector design, optimization, manufacturing, and commercialization.[[1]](https://ir.krystalbio.com/investors) The platform is intended to enable repeat dosing and broaden genetic medicine applications across skin, respiratory, oncology, and ophthalmic settings.[[1]](https://ir.krystalbio.com/investors)

## Investors

Krystal is a public Nasdaq company, but it has continued to raise growth capital through private placements. In May 2023, it announced a $160 million PIPE led by Avoro Capital Advisors and Redmile Group, with participation from Braidwell and Frazier Life Sciences.[[2]](https://ir.krystalbio.com/news-releases/news-release-details/krystal-biotech-announces-160-million-private-placement-equity)

## Acquisitions and Strategic Transactions

No acquisition involving Krystal Biotech was identified in the reviewed sources. Its public strategic milestones in the reviewed record are commercialization of VYJUVEK and pipeline expansion rather than M&A.[[1]](https://ir.krystalbio.com/investors) [[2]](https://ir.krystalbio.com/news-releases/news-release-details/krystal-biotech-announces-160-million-private-placement-equity)
