# CiRC Biosciences — Research Notes

## Overview

CiRC Biosciences (also referred to as Circ Bio) is a Stanford University spinout developing circular RNA (circRNA) therapeutics. The company was acquired by Orbital Therapeutics, a Boston, MA-based company that raised $270M to advance RNA-based medicines using circular RNA platforms. [[1]](https://tracxn.com/d/companies/circ-biosciences/__g6XDbKGA19YxzNvVDLNEOeakCYVr82qyXHRR3Qi8UEw/funding-and-investors) [[2]](https://medcitynews.com/2023/04/orbital-therapeutics-raises-270m-to-bring-rna-based-medicines-to-new-heights/)

---

## Technology

- **Circular RNA Therapeutics**: Develops circRNA-based medicines that resist degradation compared to conventional linear mRNA, enabling longer-lasting protein expression or gene-silencing effects from a single dose. CiRC's technology, developed from Stanford research, was integrated into Orbital Therapeutics' platform following acquisition. [[1]](https://tracxn.com/d/companies/circ-biosciences/__g6XDbKGA19YxzNvVDLNEOeakCYVr82qyXHRR3Qi8UEw/funding-and-investors) [[2]](https://medcitynews.com/2023/04/orbital-therapeutics-raises-270m-to-bring-rna-based-medicines-to-new-heights/)

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2020–2021 | Stanford spinout |
| Acquired by Orbital Therapeutics | ~2022–2023 | Integrated into Orbital's $270M-backed circRNA platform |

[[1]](https://tracxn.com/d/companies/circ-biosciences/__g6XDbKGA19YxzNvVDLNEOeakCYVr82qyXHRR3Qi8UEw/funding-and-investors)

---

## References

1. Tracxn — CiRC Biosciences profile: [https://tracxn.com/d/companies/circ-biosciences/__g6XDbKGA19YxzNvVDLNEOeakCYVr82qyXHRR3Qi8UEw/funding-and-investors](https://tracxn.com/d/companies/circ-biosciences/__g6XDbKGA19YxzNvVDLNEOeakCYVr82qyXHRR3Qi8UEw/funding-and-investors)
2. MedCity News — Orbital Therapeutics $270M circular RNA (Apr 2023): [https://medcitynews.com/2023/04/orbital-therapeutics-raises-270m-to-bring-rna-based-medicines-to-new-heights/](https://medcitynews.com/2023/04/orbital-therapeutics-raises-270m-to-bring-rna-based-medicines-to-new-heights/)
