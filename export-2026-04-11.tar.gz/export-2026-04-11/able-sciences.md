# Able Sciences

## Overview
Able Sciences is an early-stage company developing RNA-based off-the-shelf immune-cell engineering for cell therapies.[[1]](https://sosv.com/company/able-sciences/) The company’s public profile is currently limited, and the clearest source I found is SOSV’s portfolio page.

## Technology
SOSV describes Able Sciences as having invented a self-amplifying RNA system that enables high transfection success and multi-protein delivery in immune cells, with proof-of-concept demonstrated in human natural killer cells.[[1]](https://sosv.com/company/able-sciences/) The company is therefore positioned around non-viral RNA engineering for cell therapy manufacturing and function.

## Investors
SOSV lists Able Sciences as one of its portfolio companies.[[1]](https://sosv.com/company/able-sciences/) I did not identify a fuller primary-source financing history during this pass.

## Acquisitions and Corporate Activity
No acquisition involving Able Sciences was identified in the reviewed public sources. Because the public footprint is still thin, this note remains intentionally narrow and based on the best available source.[[1]](https://sosv.com/company/able-sciences/)
