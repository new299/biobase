# Kala Pharmaceuticals

## Overview

Kala Pharmaceuticals is the earlier corporate identity of what later became KALA BIO, an ophthalmology-focused biopharmaceutical company known for EYSUVIS and INVELTYS.[[1]](https://investors.kalarx.com/news-releases/news-release-details/kala-pharmaceuticals-completes-sale-eysuvisr-and-inveltysr-alcon/) The local folder name reflects the historical branding.

## Technology

Under the Kala Pharmaceuticals identity, the company developed and commercialized ophthalmic products, including EYSUVIS for dry eye disease and INVELTYS for post-operative ocular inflammation and pain.[[1]](https://investors.kalarx.com/news-releases/news-release-details/kala-pharmaceuticals-completes-sale-eysuvisr-and-inveltysr-alcon/) These assets formed the core commercial portfolio before the company's later strategic reset.

## Investors

As a Nasdaq-listed public company, Kala Pharmaceuticals relied on public-market capital in its later years. Under the later KALA BIO name, the company raised private placements in 2024 and 2025, including rounds involving SR One, Cormorant Asset Management, and Woodline Partners.[[2]](https://investors.kalarx.com/news-releases/news-release-details/kala-bio-announces-10750000-private-placement) The local note referenced RA Capital, which is directionally consistent with Kala's public biotech investor base, but the reviewed sources here are stronger on the company's strategic transactions than its early venture syndicate.

## Acquisitions and Strategic Transactions

In July 2022, Kala Pharmaceuticals completed the sale of EYSUVIS, INVELTYS, and related intellectual property to Alcon for $60 million upfront, plus eligibility for commercial milestones.[[1]](https://investors.kalarx.com/news-releases/news-release-details/kala-pharmaceuticals-completes-sale-eysuvisr-and-inveltysr-alcon/) The company subsequently operated under the KALA BIO identity.[[2]](https://investors.kalarx.com/news-releases/news-release-details/kala-bio-announces-10750000-private-placement)
