# Indica Labs — Research Notes

## Overview

Indica Labs is an Albuquerque, NM-based digital pathology software company developing AI-powered image analysis tools for preclinical research and clinical pathology. Its flagship product HALO® is a widely used image analysis platform in pharmaceutical R&D; its clinical offering HALO AP® is an enterprise digital pathology image management and AI analysis system. The company has achieved 260% clinical revenue growth since 2023 and operates profitably without major venture capital funding — reinvesting organically in AI innovation. In January 2025, Leica Biosystems made a significant strategic investment in Indica Labs and partnered to launch a combined digital pathology platform pairing Leica's Aperio scanner portfolio with HALO AP®. Indica Labs received FDA clearance for its digital pathology platform. [[1]](https://indicalab.com/) [[2]](https://www.biospace.com/press-releases/leica-biosystems-and-indica-labs-announce-significant-strategic-investment-and-creation-of-digital-pathology-platform)

---

## Technology & Products

- **HALO® Image Analysis Platform**: Industry-leading whole slide image (WSI) analysis software for preclinical and translational research pathology — supporting biomarker quantification, multiplex IHC/IF, spatial biology, and AI-based tissue classification; widely adopted in pharmaceutical R&D. [[1]](https://indicalab.com/)
- **HALO AP® (Clinical Digital Pathology)**: Enterprise image management and AI-powered analysis system for clinical anatomic pathology departments; FDA-cleared; DICOM-compatible with Leica Biosystems Aperio scanner portfolio. [[1]](https://indicalab.com/)
- **AI Algorithms**: Proprietary deep learning and classical machine learning models for tissue classification, cell detection, and pathology interpretation. [[1]](https://indicalab.com/)

---

## Funding & Investors

| Event | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Leica Biosystems strategic investment | Jan 2025 | Undisclosed | Leica Biosystems (Danaher subsidiary) |

Indica Labs is primarily self-funded through organic revenue; no major VC rounds publicly disclosed. [[2]](https://www.biospace.com/press-releases/leica-biosystems-and-indica-labs-announce-significant-strategic-investment-and-creation-of-digital-pathology-platform)

---

## References

1. Indica Labs — Homepage: [https://indicalab.com/](https://indicalab.com/)
2. BioSpace — Leica Biosystems / Indica Labs partnership: [https://www.biospace.com/press-releases/leica-biosystems-and-indica-labs-announce-significant-strategic-investment-and-creation-of-digital-pathology-platform](https://www.biospace.com/press-releases/leica-biosystems-and-indica-labs-announce-significant-strategic-investment-and-creation-of-digital-pathology-platform)
