# Guangzhou MingCeler Biotech Co

## Overview
MingCeler is a Chinese biotech company specializing in rapid custom gene-edited mouse models for biopharma and academic research.[[1]](https://www.mingceler.com/)[[2]](https://www.mingceler.com/enabout/)

## Technology
The company's core platform is TurboMice, which it describes as an industrialized version of tetraploid complementation and precision stem-cell editing that can generate complex, fixed-gender engineered mouse models in a shortened time frame.[[1]](https://www.mingceler.com/)[[2]](https://www.mingceler.com/enabout/)

## Investors
I did not identify a clear public financing announcement in the reviewed source set. Public materials emphasize technology, service scale, and awards more than a disclosed investor syndicate.[[2]](https://www.mingceler.com/enabout/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.mingceler.com/)
