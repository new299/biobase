# Adcendo

## Overview
Adcendo is a biotechnology company developing first-in-class antibody-drug conjugates for cancer.[[1]](https://adcendo.com/adcendo/investors/our-investors/)[[2]](https://adcendo.com/adcendo-series-a-press-release/) Its pipeline focuses on novel cancer targets with high unmet need.[[2]](https://adcendo.com/adcendo-series-a-press-release/)

## Technology and Pipeline
Adcendo’s core strategy is building antibody-drug conjugates directed at novel targets such as uPARAP/Endo180 and Tissue Factor.[[2]](https://adcendo.com/adcendo-series-a-press-release/)[[3]](https://adcendo.com/adcendo-aps-completes-oversubscribed-135-million-series-b-financing-to-advance-first-in-class-adc-pipeline/) The company is asset-focused within ADCs rather than a broad multi-modality platform developer.

## Investors
Adcendo announced a EUR51 million Series A in April 2021 led by Novo Seeds and Ysios Capital, with participation from RA Capital Management, HealthCap, and Gilde Healthcare.[[2]](https://adcendo.com/adcendo-series-a-press-release/) In November 2024, it completed an oversubscribed $135 million Series B led by TCGX, with new investment from TPG, OrbiMed, Venrock Healthcare Capital Partners, Surveyor Capital, and Logos Capital plus support from existing investors.[[3]](https://adcendo.com/adcendo-aps-completes-oversubscribed-135-million-series-b-financing-to-advance-first-in-class-adc-pipeline/) A May 2024 extension brought the total Series A financing to EUR98 million with Dawn Biopharma joining as lead on the extension.[[4]](https://adcendo.com/adcendo-aps-announces-extension-of-series-a-financing-to-eur-98m-to/)

## Acquisitions and Corporate Activity
No acquisition involving Adcendo was identified in the reviewed public sources. The public record centers on financing and advancement of its ADC pipeline.[[1]](https://adcendo.com/adcendo/investors/our-investors/)[[3]](https://adcendo.com/adcendo-aps-completes-oversubscribed-135-million-series-b-financing-to-advance-first-in-class-adc-pipeline/)
