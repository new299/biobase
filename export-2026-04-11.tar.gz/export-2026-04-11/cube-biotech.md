# Cube Biotech

## Overview
Cube Biotech is a life-science tools company serving membrane protein and broader protein research, with products and services spanning expression, purification, characterization, stabilization, and assay support.[[1]](https://cube-biotech.com/about-us/about-cube/)[[2]](https://cube-biotech.com/)

## Technology
The company says it provides affinity chromatography reagents, detergents, nanodisc-related components, cell-free expression lysates, membrane protein crystallization plates, and service work for membrane and soluble protein projects.[[1]](https://cube-biotech.com/about-us/about-cube/)[[2]](https://cube-biotech.com/)

## Investors / Ownership
Current public materials show strong involvement from ARCHIMED representatives on the advisory board and leadership side, which indicates private-equity ownership or sponsorship. I did not identify a detailed venture-style financing history in the reviewed sources.[[1]](https://cube-biotech.com/about-us/about-cube/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[2]](https://cube-biotech.com/)
