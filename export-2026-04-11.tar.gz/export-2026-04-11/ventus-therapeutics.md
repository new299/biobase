# Ventus Therapeutics

## Overview

Ventus Therapeutics is a biotechnology company developing small-molecule medicines against historically difficult targets in immunology, inflammation, neurology, and related diseases. The company says it uses structural biology and computational tools to pursue targets that had been considered undruggable. [[1]](https://www.ventustx.com/ventus-therapeutics-launches-with-60-million-series-a-2/) [[2]](https://www.ventustx.com/ventus-therapeutics-closes-140-million-series-c-financing/)

## Technology

The company's technical foundation is its ReSOLVE platform, which combines structural biology, computational chemistry, and rational design to identify selective small molecules for high-value but elusive targets, including innate immune pathways. [[2]](https://www.ventustx.com/ventus-therapeutics-closes-140-million-series-c-financing/) [[1]](https://www.ventustx.com/ventus-therapeutics-launches-with-60-million-series-a-2/)

## Investors

Ventus launched in 2020 with a $60 million Series A led by Versant Ventures with GV participation. It then raised a $100 million Series B in 2021 led by RA Capital Management and a $140 million Series C in 2022 co-led by SoftBank Vision Fund 2 and RA Capital, with a broad crossover investor syndicate. [[1]](https://www.ventustx.com/ventus-therapeutics-launches-with-60-million-series-a-2/) [[3]](https://www.ventustx.com/ventus-therapeutics-closes-100-million-series-b-financing/) [[2]](https://www.ventustx.com/ventus-therapeutics-closes-140-million-series-c-financing/)

## Strategic Position

Ventus is a classic platform biotech built around a hard-target small-molecule discovery engine. Its value proposition is less about a single asset and more about repeatedly converting structural and computational insight into tractable programs. [[1]](https://www.ventustx.com/ventus-therapeutics-launches-with-60-million-series-a-2/) [[2]](https://www.ventustx.com/ventus-therapeutics-closes-140-million-series-c-financing/)
