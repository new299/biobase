# Wayfinder Biosciences

## Overview

Wayfinder Biosciences is a biotechnology company developing orally available small molecules that target RNA. The company says it aims to stop harmful proteins before they are made by binding the RNAs that encode them. [[1]](https://www.wayfinderbio.com/) [[2]](https://www.linkedin.com/company/wayfinder-biosciences)

## Technology

Wayfinder's platform combines RNA-based sensors, experimental screening, and AI/ML data generation to discover potent, selective RNA-targeting small molecules. The public pipeline page indicates an initial focus on oncology and neurodegeneration, including a c-MYC-directed program. [[1]](https://www.wayfinderbio.com/) [[2]](https://www.linkedin.com/company/wayfinder-biosciences)

## Investors

I did not find a clearly disclosed primary financing announcement on the company's public site. Secondary company databases indicate multiple rounds through 2023, but without a company-issued financing release I am not relying on those details beyond noting that the company appears venture-backed. [[1]](https://www.wayfinderbio.com/) [[3]](https://www.crunchbase.com/organization/wayfinder-biosciences/company_financials)

## Strategic Position

Wayfinder is a small-molecule RNA targeting company, distinct from oligonucleotide or RNA delivery players. Its strategic bet is that RNA itself can be drugged by orally available small molecules with sufficient selectivity. [[1]](https://www.wayfinderbio.com/)
