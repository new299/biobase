# Semprus Biosciences

## Overview
Semprus BioSciences was a medical device / biomaterials company focused on infection-resistant and anti-thrombotic surface technologies for implanted medical devices [[1]](https://www.5amventures.com/portfolio/semprus-biosciences/).

## Technology
5AM Ventures described Semprus as developing innovative device coatings intended to reduce infection and thrombosis risk on medical devices [[1]](https://www.5amventures.com/portfolio/semprus-biosciences/).

## Investors
5AM Ventures identifies itself as an investor in Semprus BioSciences [[1]](https://www.5amventures.com/portfolio/semprus-biosciences/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass [[1]](https://www.5amventures.com/portfolio/semprus-biosciences/).

## References
[[1]](https://www.5amventures.com/portfolio/semprus-biosciences/)
