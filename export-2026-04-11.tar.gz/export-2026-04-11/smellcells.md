# SmellCells

## Overview

SmellCells AG is a Switzerland-based sensing company focused on volatile organic compound, or VOC, detection across healthcare, security, environmental, food, and industrial settings. The company frames its business around digitizing smell-related signals from breath, liquids, and the environment. [[1]](https://www.smellcells.com/) [[2]](https://www.smellcells.com/about-us)

## Technology

Public company materials describe a combination of ion mobility spectrometry and graphene-based sensing for real-time VOC analysis. SmellCells presents this as a platform that can be adapted for breath analysis, explosives detection, drug and contraband screening, environmental monitoring, and industrial quality-control use cases. [[2]](https://www.smellcells.com/about-us) [[3]](https://www.smellcells.com/application)

## Investors

I did not find a clearly disclosed institutional investor list in the accessible public sources reviewed for this note. The company's own materials instead emphasize operating scale, stating that it works through 18 strategic locations worldwide with 125 employees and partners and two production facilities. [[4]](https://www.smellcells.com/aboutus1)

## Strategic Position

SmellCells appears to be commercializing a multi-application sensing platform rather than a single diagnostic product. Its public positioning leans heavily toward security and hazardous-substance detection, while also promoting healthcare applications such as breath-based disease detection. [[1]](https://www.smellcells.com/) [[3]](https://www.smellcells.com/application)
