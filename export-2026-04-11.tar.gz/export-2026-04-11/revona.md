# RevoNA

## Overview
RevoNA Bio is a pre-seed UK company developing tools and datasets for RNA-targeted drug discovery [[1]](https://www.revona.bio/).

## Technology
The company says its platform is a patented high-throughput RNA biology system that generates RNA datasets for machine-learning-driven RNA-targeted drug discovery, including mechanistic elucidation, hit identification, optimization, and safety assessment workflows [[1]](https://www.revona.bio/).

## Investors
The public company page reviewed in this pass emphasizes the platform and founding team but does not disclose a financing round or investor syndicate [[1]](https://www.revona.bio/).

## Acquisitions / Strategic Transactions
No acquisition or major strategic transaction was identified in the reviewed sources during this pass [[1]](https://www.revona.bio/).

## References
[[1]](https://www.revona.bio/)
