# Vor Bio

## Overview

Vor Bio is a clinical-stage cell and genome engineering company that originally focused on engineered hematopoietic stem cell therapies for blood cancers and later expanded toward autoimmune disease. The company's strategy has evolved, but its public history is defined by engineered donor cell therapies. [[1]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-completes-42-million-series-financing-round) [[2]](https://www.globenewswire.com/news-release/2025/06/25/3105467/0/en/Vor-Bio-Announces-175-Million-Private-Placement.html)

## Technology

Vor's original platform centered on engineered hematopoietic stem cells and targeted therapeutics such as VOR33, designed to protect healthy donor-derived cells from cancer-directed therapies. More recent company materials and financing announcements suggest broader platform repurposing and strategic reorientation. [[1]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-completes-42-million-series-financing-round) [[3]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-closes-110-million-series-b-financing)

## Investors And Financing

Vor announced a $42 million Series A in 2019 led by 5AM Ventures and RA Capital Management, a $110 million Series B in 2020 led by RA Capital, an IPO in 2021 raising about $176.9 million, and a $175 million private placement in 2025 backed by RA Capital, Mingxin Capital, Forbion, Venrock, Caligan, and NEXTBio. [[1]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-completes-42-million-series-financing-round) [[3]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-closes-110-million-series-b-financing) [[4]](https://ir.vorbio.com/news-releases/news-release-details/vor-biopharma-announces-pricing-initial-public-offering) [[2]](https://www.globenewswire.com/news-release/2025/06/25/3105467/0/en/Vor-Bio-Announces-175-Million-Private-Placement.html)

## Strategic Position

Vor's public history shows both deep investor support and substantial strategic course correction. It remains a useful example of a platform cell and genome engineering company trying to preserve value through evolution rather than simple continuation of its original thesis. [[2]](https://www.globenewswire.com/news-release/2025/06/25/3105467/0/en/Vor-Bio-Announces-175-Million-Private-Placement.html)
