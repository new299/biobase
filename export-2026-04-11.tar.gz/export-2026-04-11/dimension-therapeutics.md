# Dimension Therapeutics — Research Notes

## Overview

Dimension Therapeutics was a Cambridge, MA-based AAV gene therapy company founded in 2013 by Fidelity Biosciences and REGENXBIO. Developed AAV-based gene therapies for inherited metabolic liver diseases (OTC deficiency, glycogen storage disease type Ia / GSDIa) and a collaboration with Bayer in hemophilia A. Acquired by Ultragenyx Pharmaceutical (NASDAQ: RARE) in November 2017 at $6.00/share (~$138M–$152M, following a bidding contest with REGENXBIO). [[1]](https://ir.ultragenyx.com/news-releases/news-release-details/ultragenyx-acquire-dimension-therapeutics) [[2]](https://www.businesswire.com/news/home/20131031005150/en/Fidelity-Biosciences-REGENX-Biosciences-Launch-Dimension-Therapeutics)

---

## Technology

- **AAV Liver-Directed Gene Therapy**: Proprietary AAV gene delivery platform targeting hepatocytes for correction of inherited metabolic diseases. Programs in OTC deficiency (ornithine transcarbamylase deficiency) and GSDIa (glycogen storage disease type Ia). [[1]](https://ir.ultragenyx.com/news-releases/news-release-details/ultragenyx-acquire-dimension-therapeutics)
- **Bayer Hemophilia A Collaboration**: $252M deal with Bayer funding preclinical and Phase 1/IIa hemophilia A gene therapy development. [[3]](https://www.fiercebiotech.com/biotech/dimension-leaps-into-gene-therapy-action-252m-bayer-deal-30m-round)
- **REGENXBIO IP**: Founded with rights to REGENXBIO's NAV Technology Platform (proprietary AAV capsid library). [[2]](https://www.businesswire.com/news/home/20131031005150/en/Fidelity-Biosciences-REGENX-Biosciences-Launch-Dimension-Therapeutics)

---

## Funding & Corporate History

| Event | Date | Amount / Details |
|-------|------|-----------------|
| Founded | Oct 2013 | Fidelity Biosciences + REGENXBIO, Cambridge MA |
| Bayer collaboration | ~2015 | $252M deal value |
| Series A ($30M) | ~2015 | — |
| Acquisition | Nov 2017 | $6.00/share (~$138–152M) by Ultragenyx |

---

## References

1. Ultragenyx IR — Ultragenyx to acquire Dimension Therapeutics (2017): [https://ir.ultragenyx.com/news-releases/news-release-details/ultragenyx-acquire-dimension-therapeutics](https://ir.ultragenyx.com/news-releases/news-release-details/ultragenyx-acquire-dimension-therapeutics)
2. BusinessWire — Dimension Therapeutics launch (Oct 2013): [https://www.businesswire.com/news/home/20131031005150/en/Fidelity-Biosciences-REGENX-Biosciences-Launch-Dimension-Therapeutics](https://www.businesswire.com/news/home/20131031005150/en/Fidelity-Biosciences-REGENX-Biosciences-Launch-Dimension-Therapeutics)
3. FierceBiotech — Dimension + Bayer $252M deal: [https://www.fiercebiotech.com/biotech/dimension-leaps-into-gene-therapy-action-252m-bayer-deal-30m-round](https://www.fiercebiotech.com/biotech/dimension-leaps-into-gene-therapy-action-252m-bayer-deal-30m-round)
