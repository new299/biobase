# Parseq Lab

## Overview
Parseq Lab is a Czech genomics company developing and manufacturing next-generation sequencing diagnostic systems, reagents, and genomic data analysis infrastructure.[[1]](https://www.parseqlab.cz/about)

## Technology
The company says it develops high-throughput NGS-based diagnostic and scientific test systems, NGS library preparation reagents, and supporting data analysis and storage infrastructure, including OEM support for complex genomic testing solutions.[[1]](https://www.parseqlab.cz/about)

## Investors / Ownership
I did not identify a public financing announcement in the reviewed source set. The public footprint is focused on products and laboratory implementation rather than venture fundraising.[[1]](https://www.parseqlab.cz/about)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.parseqlab.cz/about)
