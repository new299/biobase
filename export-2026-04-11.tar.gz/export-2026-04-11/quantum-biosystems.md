# Quantum Biosystems

## Overview

Quantum Biosystems is a Japan-based private company founded in 2013 to develop single-molecule DNA / RNA sequencing systems based on electrical detection and quantum-mechanics-inspired approaches [[1]](https://www.ut-ec.co.jp/english/about_us/news/quantum_biosystems_02062015/) [[2]](https://www.healthtechalpha.com/venture/quantum-biosystems).

## Technology

UTEC described Quantum Biosystems' platform as "Quantum Sequencing" for single-molecule electrical DNA sequencing, combining silicon technology with electrical detection for label-free, low-cost, high-throughput, real-time analysis [[1]](https://www.ut-ec.co.jp/english/about_us/news/quantum_biosystems_02062015/). HealthTech Alpha similarly describes the company as developing single-molecule electrical sequencing on semiconductor-like nanochips [[2]](https://www.healthtechalpha.com/venture/quantum-biosystems).

## Investors

UTEC reported in February 2015 that Quantum Biosystems raised 2.4 billion yen in Series B funding from new investors INCJ and Mitsubishi UFJ Capital plus existing investors JAFCO, UTEC, and Mizuho Capital [[1]](https://www.ut-ec.co.jp/english/about_us/news/quantum_biosystems_02062015/). Later company-profile sources also identify SBI Investment as a Series C lead investor [[3]](https://www.crunchbase.com/organization/quantum-biosystems).

## Acquisitions / Strategic Transactions

The key strategic transaction identified in the reviewed sources is the 2015 Series B round, which the company said would accelerate DNA / RNA sequencer development [[1]](https://www.ut-ec.co.jp/english/about_us/news/quantum_biosystems_02062015/).

## References

[[1]](https://www.ut-ec.co.jp/english/about_us/news/quantum_biosystems_02062015/)
[[2]](https://www.healthtechalpha.com/venture/quantum-biosystems)
[[3]](https://www.crunchbase.com/organization/quantum-biosystems)
