# Rivus Pharmaceuticals

## Overview
Rivus is a clinical-stage biopharmaceutical company developing oral medicines for obesity and associated cardiometabolic diseases [[1]](https://www.rivuspharma.com/about/).

## Technology
The company says it is leveraging mechanisms including mitochondrial uncoupling and GLP-1 agonism, with HU6 positioned as a controlled metabolic accelerator for obesity and related disease [[1]](https://www.rivuspharma.com/about/) [[2]](https://www.rivuspharma.com/news/press-releases/092222/).

## Investors
Rivus closed a $132 million Series B in 2022 led by RA Capital Management, with participation from Bain Capital Life Sciences, BB Biotech AG, Longitude Capital, Medicxi, and RxCapital [[2]](https://www.rivuspharma.com/news/press-releases/092222/).

## Acquisitions / Strategic Transactions
The key strategic transaction identified in the reviewed sources is the 2022 Series B financing to advance HU6 [[2]](https://www.rivuspharma.com/news/press-releases/092222/).

## References
[[1]](https://www.rivuspharma.com/about/)
[[2]](https://www.rivuspharma.com/news/press-releases/092222/)
