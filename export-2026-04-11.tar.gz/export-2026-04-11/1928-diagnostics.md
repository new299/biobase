# 1928 Diagnostics

## Overview
1928 Diagnostics is a Swedish bioinformatics company focused on genomic analysis for infectious disease, antimicrobial resistance, and outbreak tracing.[[1]](https://www.1928diagnostics.com/about)[[2]](https://www.1928diagnostics.com/about-1) The company positions itself as turning complex sequencing data into actionable results through cloud-based software.[[1]](https://www.1928diagnostics.com/about)

## Technology
1928 says its platform combines biological expertise and advanced software technology to transform sequencing data into interpretable, actionable insights.[[1]](https://www.1928diagnostics.com/about) Its public materials emphasize applications in antimicrobial resistance and infectious-disease control rather than therapeutics development.[[2]](https://www.1928diagnostics.com/about-1)

## Investors
I did not identify a detailed company-issued financing history during this pass. Secondary databases indicate venture backing including Chalmers Ventures, but the strongest public sources I reviewed were company site pages rather than financing announcements.[[3]](https://www.crunchbase.com/organization/1928diagnostics)

## Acquisitions and Corporate Activity
No acquisition involving 1928 Diagnostics was identified in the reviewed public sources. The accessible public record centers on its bioinformatics platform and infectious-disease analytics mission.[[1]](https://www.1928diagnostics.com/about)[[2]](https://www.1928diagnostics.com/about-1)
