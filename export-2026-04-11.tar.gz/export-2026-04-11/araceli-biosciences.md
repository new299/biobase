# Araceli Biosciences — Research Notes

## Overview

Araceli Biosciences is a life sciences instrumentation company spun out of Phoseon Technology, headquartered in Beaverton, OR. Develops the **Endeavor® High Content Imaging System** and AI analysis software for ultra-high-throughput drug discovery. Total raised: $25.7M. [[1]](https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/)

---

## Technology

- **Endeavor® High Content Imaging System**: Ultra-high-throughput imaging platform delivering results up to 40× faster than traditional systems. Enables large-scale cellular phenotyping for drug discovery and personalized medicine. [[1]](https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/)
- **Clairvoyance AI Software**: Proprietary AI-driven image analysis system pairing with Endeavor for real-time, automated phenotypic analysis. [[1]](https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/)
- Applications: drug screening, personalized medicine, rare disease research.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | Apr 2025 | $11.2M total ($7.2M new equity + $4M SAFE conversions) | Fluke Venture Partners, Bill Cortelyou (lead), Phoseon |

Total raised: $25.7M across 3 rounds. [[1]](https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/)

---

## References

1. Araceli Biosciences — Seed round press release (Apr 2025): [https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/](https://www.aracelibio.com/press-release/araceli-biosciences-closes-11-2m-seed-financing-to-change-the-pace-of-drug-discovery/)
2. GeekWire — Coverage: [https://www.geekwire.com/2025/araceli-biosciences-raises-11-2m-for-imaging-and-ai-analysis-systems-to-help-speed-drug-discovery/](https://www.geekwire.com/2025/araceli-biosciences-raises-11-2m-for-imaging-and-ai-analysis-systems-to-help-speed-drug-discovery/)
