# Lilac Therapeutics

Lilac Therapeutics is a U.S.-based clinical-stage biopharmaceutical company focused on developing treatments to prevent recurrent kidney stones and related metabolic diseases ([Source 1](https://www.lilactx.com/), [Source 2](https://convention.bio.org/participating-companies/lilac-therapeutics)).

### Approach

Lilac’s approach targets the **underlying metabolic cause of kidney stone formation**, specifically excess oxalate production:

- Focuses on calcium oxalate kidney stones (most common type)  
- Targets **glycolate oxidase**, an enzyme involved in oxalate production  
- Aims to reduce urinary oxalate levels and prevent crystal formation  

The company’s lead program, **LLX-424**, is a small-molecule inhibitor designed to block liver synthesis of oxalate and reduce recurrence risk ([Source 1](https://www.lilactx.com/)).

### Technology & Pipeline

- **LLX-424** (lead asset)  
  - Small-molecule glycolate oxidase inhibitor  
  - Designed to prevent recurrent kidney stones  
  - Clinical-stage (Phase 2 development)  

The therapy may also have broader applications in diseases linked to oxalate metabolism, including chronic kidney disease and other metabolic conditions ([Source 2](https://convention.bio.org/participating-companies/lilac-therapeutics)).

### Market & Positioning

Lilac operates in the **renal disease and metabolic disorder therapeutics market**:

- Addresses a large unmet need (no approved therapies for preventing recurrence in many patients)  
- Targets a high-prevalence condition (~1 in 11 people in the U.S.)  
- Focus on reducing hospitalizations and long-term complications  

([Source 1](https://www.lilactx.com/)).

### Investors

- Backed by **ARCH Venture Partners** (venture capital firm)  

([Source 2](https://convention.bio.org/participating-companies/lilac-therapeutics)).

### Funding

- Venture-backed (ARCH portfolio company)  
- Specific funding amounts not publicly disclosed  

([Source 2](https://convention.bio.org/participating-companies/lilac-therapeutics)).

### Status

- Active  
- Clinical-stage biotech company  
- Privately held  
- Not acquired  

---

Overall, Lilac Therapeutics is a clinical-stage biotech company developing a targeted small-molecule therapy to prevent kidney stone recurrence by addressing oxalate metabolism, with its lead candidate currently in mid-stage clinical development.
