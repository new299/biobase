# Corvia Medical — Research Notes

## Overview

Corvia Medical, Inc. is a Tewksbury, MA-based medical device company (founded 2009 as DC Devices) developing the Corvia® Atrial Shunt — an interatrial shunt device (IASD) for treating heart failure with preserved ejection fraction (HFpEF) and mildly reduced ejection fraction (HFmrEF). Edwards Lifesciences has had a strategic option/interest since 2019. Total raised: ~$160M+. [[1]](https://www.prnewswire.com/news-releases/corvia-medical-closes-55-million-funding-round-to-complete-confirmatory-trial-and-pursue-fda-approval-of-corvia-atrial-shunt-302483297.html) [[2]](https://corviamedical.com/home/)

---

## Technology

- **Corvia® Atrial Shunt (IASD®)**: Transcatheter device implanted in the interatrial septum (between left and right atria) to create a controlled passage that decompresses elevated left atrial pressure in heart failure. Reduces HF symptoms, hospitalizations, and improves quality of life in HFpEF/HFmrEF patients. [[2]](https://corviamedical.com/home/)
- **FDA Breakthrough Device Designation**: Received 2019 for diastolic heart failure. [[3]](https://www.prnewswire.com/news-releases/corvia-medicals-interatrial-shunt-device-iasd-receives-breakthrough-device-designation-for-heart-failure-300934370.html)
- **RESPONDER-HF Trial**: Confirmatory pivotal trial ongoing; final data expected to support FDA approval submission. [[1]](https://www.prnewswire.com/news-releases/corvia-medical-closes-55-million-funding-round-to-complete-confirmatory-trial-and-pursue-fda-approval-of-corvia-atrial-shunt-302483297.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A–D (as DC Devices) | ~2009–2017 | ~$105M+ | Third Rock Ventures, General Catalyst, AccelMed, Lumira Ventures, Edwards Lifesciences (strategic) |
| Round (Jun 2025) | Jun 2025 | $55M | Third Rock Ventures, General Catalyst, AccelMed, Lumira Ventures + 2 strategic investors |

Total raised: ~$160M+. [[1]](https://www.prnewswire.com/news-releases/corvia-medical-closes-55-million-funding-round-to-complete-confirmatory-trial-and-pursue-fda-approval-of-corvia-atrial-shunt-302483297.html) [[4]](https://www.crunchbase.com/organization/dc-devices)

---

## References

1. PR Newswire — Corvia Medical $55M funding round (Jun 2025): [https://www.prnewswire.com/news-releases/corvia-medical-closes-55-million-funding-round-to-complete-confirmatory-trial-and-pursue-fda-approval-of-corvia-atrial-shunt-302483297.html](https://www.prnewswire.com/news-releases/corvia-medical-closes-55-million-funding-round-to-complete-confirmatory-trial-and-pursue-fda-approval-of-corvia-atrial-shunt-302483297.html)
2. Corvia Medical — Company website: [https://corviamedical.com/home/](https://corviamedical.com/home/)
3. PR Newswire — IASD Breakthrough Device Designation (2019): [https://www.prnewswire.com/news-releases/corvia-medicals-interatrial-shunt-device-iasd-receives-breakthrough-device-designation-for-heart-failure-300934370.html](https://www.prnewswire.com/news-releases/corvia-medicals-interatrial-shunt-device-iasd-receives-breakthrough-device-designation-for-heart-failure-300934370.html)
4. Crunchbase — Corvia Medical (DC Devices): [https://www.crunchbase.com/organization/dc-devices](https://www.crunchbase.com/organization/dc-devices)
