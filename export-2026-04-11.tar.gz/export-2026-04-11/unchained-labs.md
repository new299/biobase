# Unchained Labs

## Overview

Unchained Labs is a life science tools company focused on products for biologics, gene therapy, and formulation researchers. The company has grown through a mix of internal product development and serial acquisitions. [[1]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/Unchained-Press-Release-150212.pdf) [[2]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/The-Carlyle-Group-to-Acquire-Rapidly-Growing-Life-Sciences-Tools-Company-Unchained-Labs-21042650.pdf)

## Technology And Product Scope

Public company materials describe Unchained as helping researchers analyze and characterize complex biologics and gene therapy products. The company has expanded into protein stability, formulation automation, dynamic light scattering, and later lipid nanoparticle workflows through acquisitions and product-line integration. [[1]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/Unchained-Press-Release-150212.pdf) [[3]](https://www.unchainedlabs.com/wp-content/uploads/2022/01/Unchained-Labs-Acquires-Freeslate14.pdf) [[4]](https://www.unchainedlabs.com/wp-content/uploads/2023/07/Blacktrace-Holdings-Aquisition-Press-Release-20230717.pdf)

## Investors

Unchained launched in 2015 with a $25 million Series A led by Novo Ventures, Canaan Partners, and TPG Biotech. In 2016 it raised a $25 million Series B from the same syndicate. In 2021, Carlyle agreed to acquire the company for $435 million in partnership with management, buying it from Novo Holdings, Canaan Partners, and TPG Biotech. [[1]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/Unchained-Press-Release-150212.pdf) [[3]](https://www.unchainedlabs.com/wp-content/uploads/2022/01/Unchained-Labs-Acquires-Freeslate14.pdf) [[2]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/The-Carlyle-Group-to-Acquire-Rapidly-Growing-Life-Sciences-Tools-Company-Unchained-Labs-21042650.pdf)

## Acquisitions

Acquisitions are central to Unchained's business model. Early deals included Optim, Avid Nano, and Freeslate, while in 2023 the company acquired Blacktrace Holdings to expand into lipid nanoparticle development tools. [[1]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/Unchained-Press-Release-150212.pdf) [[5]](https://www.unchainedlabs.com/wp-content/uploads/2021/12/Unchained_Labs_Avid_Nano_Press_Release_150709.pdf) [[3]](https://www.unchainedlabs.com/wp-content/uploads/2022/01/Unchained-Labs-Acquires-Freeslate14.pdf) [[4]](https://www.unchainedlabs.com/wp-content/uploads/2023/07/Blacktrace-Holdings-Aquisition-Press-Release-20230717.pdf)
