# U.S. Genomics

## Overview

U.S. Genomics was a genomics technology company developing single-molecule DNA mapping and optical analysis systems. Historical public records place the company in Woburn, Massachusetts, and describe a platform aimed at rapid genome reading and microbial strain typing. [[1]](https://www.bioworld.com/articles/476513) [[2]](https://academic.oup.com/nar/article-abstract/33/18/5829/2401266) [[3]](https://academic.oup.com/clinchem/article/55/12/2121/5629436?itm_content=clinchem)

## Technology

The company's technology centered on single-molecule optical mapping of long DNA molecules in microfluidic systems. Published papers affiliated with U.S. Genomics describe rapid mapping of stretched DNA and fluorescent tag-based single-molecule DNA mapping in fluidic microchips for applications such as bacterial strain typing. [[2]](https://academic.oup.com/nar/article-abstract/33/18/5829/2401266) [[3]](https://academic.oup.com/clinchem/article/55/12/2121/5629436?itm_content=clinchem)

## Investors

BioWorld reported in 2001 that U.S. Genomics raised a $17 million Series B led by HealthCare Ventures, with participation from existing investors CB Health Ventures, Still River Fund, and private investors, bringing total funding at that time to $23 million. BioWorld later also reported grant and government contract support, including a U.S. Department of Homeland Security contract and NSF SBIR funding tied to its DNA analysis and genomic mapping technology. [[1]](https://www.bioworld.com/articles/476513) [[4]](https://www.bioworld.com/articles/462069)

## Historical Context

Publicly accessible recent operating information is limited, so this note should be read as a historical profile of an early genomics tools company rather than a current operating-company summary. [[1]](https://www.bioworld.com/articles/476513) [[2]](https://academic.oup.com/nar/article-abstract/33/18/5829/2401266)
