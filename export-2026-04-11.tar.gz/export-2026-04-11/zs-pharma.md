# ZS Pharma

## Overview

ZS Pharma was a publicly traded biopharmaceutical company focused on hyperkalemia and related kidney and liver disease applications. AstraZeneca described the company in 2015 as a biopharmaceutical business built around proprietary ion-trap technology, with lead asset ZS-9 for hyperkalemia.[[1]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-strengthens-Cardiovascular-and-Metabolic-disease-portfolio-with-acquisition-of-ZS-Pharma-06112015.html)

## Technology

ZS Pharma's core technology was its proprietary ion-trap platform. AstraZeneca's transaction materials state that the company used this platform to develop new treatments for kidney and liver diseases, especially ZS-9 (sodium zirconium cyclosilicate), a potassium-binding compound for hyperkalemia.[[1]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-strengthens-Cardiovascular-and-Metabolic-disease-portfolio-with-acquisition-of-ZS-Pharma-06112015.html) [[2]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-completes-acquisition-of-ZS-Pharma-17122015.html)

## Investors

ZS Pharma was a Nasdaq-listed public company under ticker `ZSPH`, so by the time of its sale it was financed through public-market ownership rather than only private venture backing.[[2]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-completes-acquisition-of-ZS-Pharma-17122015.html) The reviewed sources are strongest on its strategic sale and business model rather than on its early private-investor syndicate.

## Acquisitions and Strategic Transactions

In November 2015, AstraZeneca announced a definitive agreement to acquire ZS Pharma for $90 per share in cash, valuing the transaction at approximately $2.7 billion.[[1]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-strengthens-Cardiovascular-and-Metabolic-disease-portfolio-with-acquisition-of-ZS-Pharma-06112015.html) AstraZeneca completed the acquisition on December 17, 2015, after which ZS Pharma became a wholly owned subsidiary.[[2]](https://www.astrazeneca.com/media-centre/press-releases/2015/AstraZeneca-completes-acquisition-of-ZS-Pharma-17122015.html)
