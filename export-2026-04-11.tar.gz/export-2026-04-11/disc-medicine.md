# Disc Medicine — Research Notes

## Overview

Disc Medicine, Inc. (NASDAQ: IRON) is a Watertown, MA-based clinical-stage biopharmaceutical company developing treatments for serious hematologic diseases targeting heme biosynthesis and iron homeostasis. Founded ~2019; Series A $50M (Oct 2019) led by Novo Holdings. IPO in 2023. Cash ~$360M end of 2023. Pipeline: bitopertin (myelofibrosis anemia, erythropoietic porphyrias), DISC-0974 (anti-hepcidin antibody, anemia of myelofibrosis / CKD), DISC-3405 (polycythemia vera). [[1]](https://www.prnewswire.com/news-releases/disc-medicine-completes-50-million-series-a-financing-led-by-novo-holdings-a-s-to-advance-new-therapies-addressing-ineffective-red-blood-cell-production-300946714.html) [[2]](https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-reports-fourth-quarter-and-full-year-2023)

---

## Technology & Pipeline

- **Bitopertin**: Repurposed oral GlyT1 inhibitor (originally Roche/AbbVie-licensed) that reduces heme biosynthesis in erythroid progenitors — used to treat erythropoietic protoporphyria (EPP), X-linked protoporphyria, and Diamond-Blackfan anemia. NDA submitted for EPP accelerated approval September 29, 2025. Phase 2 BEACON study positive data presented. [[3]](https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-provides-update-hematology-portfolio-and-outlines)
- **DISC-0974**: Anti-hepcidin antibody that suppresses hepcidin to mobilize iron and stimulate erythropoiesis. Phase 1b trial in myelofibrosis anemia (RALLY-MF, positive data ASH 2023) and CKD anemia (positive Phase 1b data ASN Kidney Week 2024). [[4]](https://www.biospace.com/news/disc-medicine-presents-positive-data-from-sad-cohorts-of-a-phase-1b-trial-in-patients-with-chronic-kidney-disease-ckd-and-anemia-at-the-2024-american-society-of-nephrology-asn-kidney-week)
- **DISC-3405**: Pipeline candidate for polycythemia vera and other hematologic disorders. [[2]](https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-reports-fourth-quarter-and-full-year-2023)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | Oct 2019 | $50M | Novo Holdings A/S (lead), Access Biotechnology, Atlas Venture |
| IPO (NASDAQ: IRON) | 2023 | — | Public market |

Cash: ~$360M end of 2023. [[1]](https://www.prnewswire.com/news-releases/disc-medicine-completes-50-million-series-a-financing-led-by-novo-holdings-a-s-to-advance-new-therapies-addressing-ineffective-red-blood-cell-production-300946714.html)

---

## References

1. PRNewswire — Disc Medicine $50M Series A (Oct 2019): [https://www.prnewswire.com/news-releases/disc-medicine-completes-50-million-series-a-financing-led-by-novo-holdings-a-s-to-advance-new-therapies-addressing-ineffective-red-blood-cell-production-300946714.html](https://www.prnewswire.com/news-releases/disc-medicine-completes-50-million-series-a-financing-led-by-novo-holdings-a-s-to-advance-new-therapies-addressing-ineffective-red-blood-cell-production-300946714.html)
2. Disc Medicine IR — FY2023 financial results: [https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-reports-fourth-quarter-and-full-year-2023](https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-reports-fourth-quarter-and-full-year-2023)
3. Disc Medicine IR — Portfolio update and milestones: [https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-provides-update-hematology-portfolio-and-outlines](https://ir.discmedicine.com/news-releases/news-release-details/disc-medicine-provides-update-hematology-portfolio-and-outlines)
4. BioSpace — DISC-0974 positive Phase 1b CKD data (ASN 2024): [https://www.biospace.com/news/disc-medicine-presents-positive-data-from-sad-cohorts-of-a-phase-1b-trial-in-patients-with-chronic-kidney-disease-ckd-and-anemia-at-the-2024-american-society-of-nephrology-asn-kidney-week](https://www.biospace.com/news/disc-medicine-presents-positive-data-from-sad-cohorts-of-a-phase-1b-trial-in-patients-with-chronic-kidney-disease-ckd-and-anemia-at-the-2024-american-society-of-nephrology-asn-kidney-week)
