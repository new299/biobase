# Roswell Biotechnologies

## Overview
Roswell Biotechnologies is developing a molecular-electronics platform intended to transform biosensing and DNA sequencing [[1]](https://www.prnewswire.com/news-releases/roswell-biotechnologies-secures-32-million-series-a-financing-round-300772299.html).

## Technology
The company says its approach integrates molecules into electronic circuits and positions molecular electronics as a path toward highly scalable DNA sequencing and biosensing [[1]](https://www.prnewswire.com/news-releases/roswell-biotechnologies-secures-32-million-series-a-financing-round-300772299.html).

## Investors
Roswell announced a $32 million Series A in January 2019 backed by multiple investors, though the press release reviewed did not enumerate the full syndicate in the visible excerpt [[1]](https://www.prnewswire.com/news-releases/roswell-biotechnologies-secures-32-million-series-a-financing-round-300772299.html).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass; the most material strategic event publicly visible was the 2019 Series A financing [[1]](https://www.prnewswire.com/news-releases/roswell-biotechnologies-secures-32-million-series-a-financing-round-300772299.html).

## References
[[1]](https://www.prnewswire.com/news-releases/roswell-biotechnologies-secures-32-million-series-a-financing-round-300772299.html)
