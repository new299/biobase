# Sonoma Biotherapeutics

## Overview
Sonoma Biotherapeutics is a clinical-stage biotechnology company developing engineered regulatory T cell therapies for autoimmune and inflammatory diseases [[1]](https://sonomabio.com/about/) [[2]](https://sonomabio.com/).

## Technology
The company says its platform is built on regulatory T cell biology and cell therapy, with engineered Treg approaches intended to restore immune balance and potentially cure autoimmune disease [[1]](https://sonomabio.com/about/) [[3]](https://sonomabio.com/approach/) [[4]](https://sonomabio.com/platform-pipeline/).

## Investors
Sonoma launched in 2020 with $40 million in Series A funding [[5]](https://sonomabio.com/2020/02/sonoma-biotherapeutics-launches-with-40-million-in-series-a-funding-to-advance-regulatory-t-cell-therapy-in-autoimmune-and-degenerative-diseases/). Its investor page now lists a broad syndicate including 8VC, Alexandria Venture Investments, Ally Bridge Group, ARCH Venture Partners, Casdin Capital, Frazier Life Sciences, GV, Lilly Asia Ventures, T1D Fund, and Vertex Ventures HC among others [[6]](https://sonomabio.com/investors/). In 2023 it also announced a collaboration and license agreement with Regeneron, and later press coverage reported a $45 million Regeneron investment in 2024 [[7]](https://investor.regeneron.com/news-releases/news-release-details/regeneron-and-sonoma-biotherapeutics-announce-collaboration) [[8]](https://www.finsmes.com/2024/09/sonoma-biotherapeutics-receives-45m-investment-from-regeneron-pharmaceuticals.html).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The key strategic transaction was the 2023 Regeneron collaboration and license agreement for Treg cell therapies in inflammatory bowel disease and additional indications [[7]](https://investor.regeneron.com/news-releases/news-release-details/regeneron-and-sonoma-biotherapeutics-announce-collaboration).

## References
[[1]](https://sonomabio.com/about/)
[[2]](https://sonomabio.com/)
[[3]](https://sonomabio.com/approach/)
[[4]](https://sonomabio.com/platform-pipeline/)
[[5]](https://sonomabio.com/2020/02/sonoma-biotherapeutics-launches-with-40-million-in-series-a-funding-to-advance-regulatory-t-cell-therapy-in-autoimmune-and-degenerative-diseases/)
[[6]](https://sonomabio.com/investors/)
[[7]](https://investor.regeneron.com/news-releases/news-release-details/regeneron-and-sonoma-biotherapeutics-announce-collaboration)
[[8]](https://www.finsmes.com/2024/09/sonoma-biotherapeutics-receives-45m-investment-from-regeneron-pharmaceuticals.html)
