# Umoja Biopharma

## Overview

Umoja Biopharma is a clinical-stage biotechnology company focused on in vivo CAR-T therapies for oncology and autoimmunity. The company positions itself as the clinical-stage leader in in vivo cell therapies aimed at expanding the reach and accessibility of CAR-T treatment. [[1]](https://www.umoja-biopharma.com/) [[2]](https://www.umoja-biopharma.com/our-pipeline/)

## Technology

The company's flagship platform is VivoVec, which generates CAR-T cells directly in a patient's body using gene delivery technology. Umoja argues that this in vivo approach can remove major bottlenecks of traditional CAR-T, including ex vivo cell collection, centralized manufacturing delays, and the need for lymphodepletion. [[1]](https://www.umoja-biopharma.com/) [[3]](https://www.umoja-biopharma.com/news/abbvie-and-umoja-biopharma-announce-strategic-collaboration-to-develop-novel-in-situ-car-t-cell-therapies/)

## Investors

Umoja's disclosed financing history includes a $53 million Series A in 2020, a $210 million Series B in 2021, and a $100 million Series C in 2025. Major named backers across those rounds include MPM Capital, Qiming Venture Partners USA, DCVC Bio, SoftBank Vision Fund 2, Cormorant Asset Management, Double Point Ventures, ARK Invest, and others. [[4]](https://www.umoja-biopharma.com/news/https-www-umoja-biopharma-com-news-umoja-biopharma-launches-with-53m-series-a-financing-to-develop-fully-integrated-scalable-in-vivo-immunotherapy-platform/) [[5]](https://www.umoja-biopharma.com/news/umoja-biopharma-closes-an-oversubscribed-210-million-series-b-financing-to-expand-integrated-immunotherapy-platforms-and-advance-programs-to-the-clinic/) [[6]](https://www.umoja-biopharma.com/news/umoja-biopharma-announces-oversubscribed-100-million-series-c-financing-to-advance-in-vivo-car-t-pipeline-through-key-oncology-clinical-milestones/)

## Partnerships And Strategic Development

AbbVie is Umoja's most visible strategic partner, with a 2024 collaboration covering CD19 and additional in-situ CAR-T programs. The company has also partnered with IASO Bio and is advancing multiple VivoVec-driven programs toward the clinic. [[3]](https://www.umoja-biopharma.com/news/abbvie-and-umoja-biopharma-announce-strategic-collaboration-to-develop-novel-in-situ-car-t-cell-therapies/) [[7]](https://www.umoja-biopharma.com/news/iaso-bio-announces-new-development-partnership-with-umoja-biopharma-to-develop-ex-vivo-and-in-vivo-cell-and-gene-therapies/)
