# Pear Therapeutics

## Overview
Pear Therapeutics was a digital therapeutics company that developed prescription software-based treatments for conditions including substance use disorder, opioid use disorder, and chronic insomnia.[[1]](https://www.businesswire.com/news/home/20211203005571/en/Pear-Therapeutics-and-Thimble-Point-Announce-Closing-of-Business-Combination-to-Create-Publicly-Traded-Prescription-Digital-Therapeutics-Company) It was one of the earliest leaders in prescription digital therapeutics.[[2]](https://www.businesswire.com/news/home/20211216005587/en/Pear-Therapeutics-Announces-the-Acquisition-of-Two-Assets-Addressing-a-Comprehensive-Spectrum-of-Depression-Conditions)

## Technology and Products
Pear's core business was prescription digital therapeutics delivered as software products, including the FDA-authorized reSET and reSET-O platforms.[[1]](https://www.businesswire.com/news/home/20211203005571/en/Pear-Therapeutics-and-Thimble-Point-Announce-Closing-of-Business-Combination-to-Create-Publicly-Traded-Prescription-Digital-Therapeutics-Company) This was digital medicine rather than molecular therapeutics or diagnostics.

## Investors and Financing
Pear completed its business combination with Thimble Point Acquisition Corp. in December 2021, with total expected gross proceeds of approximately $175 million.[[1]](https://www.businesswire.com/news/home/20211203005571/en/Pear-Therapeutics-and-Thimble-Point-Announce-Closing-of-Business-Combination-to-Create-Publicly-Traded-Prescription-Digital-Therapeutics-Company) Earlier in its history, 5AM Ventures was among its investors, consistent with the local note, though this pass focused on later public-company sources.

## Acquisitions and Corporate Activity
In December 2021, Pear announced the acquisition of two depression-focused assets from NewYork-Presbyterian and Weill Cornell Medicine.[[2]](https://www.businesswire.com/news/home/20211216005587/en/Pear-Therapeutics-Announces-the-Acquisition-of-Two-Assets-Addressing-a-Comprehensive-Spectrum-of-Depression-Conditions) In April 2023, the company filed for Chapter 11 bankruptcy protection and began a process to sell the business or its assets.[[3]](https://www.techtarget.com/virtualhealthcare/news/366597112/Digital-Therapeutics-Provider-Files-for-Bankruptcy-Cuts-92-of-Workforce)
