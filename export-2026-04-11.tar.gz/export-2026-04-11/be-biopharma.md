# Be Biopharma — Research Notes

## Overview

Be Biopharma (be.bio) is a clinical-stage genetic medicine company founded in 2020, headquartered in Cambridge, MA. Develops engineered B Cell Medicines (BCMs) — autologous B cells precision-engineered to express therapeutic proteins — as a potentially durable and redosable approach to treating genetic diseases and cancer. Total raised: ~$274M. [[1]](https://be.bio/) [[2]](https://be.bio/be-biopharma-unveils-become-9-trial-and-presents-on-versatile-b-cell-medicines-platform-at-ash-2024/)

**ARCH Venture Partners Investment**.

---

## Technology

- **B Cell Medicines (BCM) Platform**: Uses precision genome engineering (CRISPR/Cas9-mediated HDR) to insert a therapeutic gene of interest into a defined chromosomal locus in autologous B cells. Engineered B cells are expanded and differentiated into plasma cells that migrate to bone marrow and constitutively secrete the desired therapeutic protein. Offers controlled and repeat dosing. [[3]](https://be.bio/our-science/our-platform/)
- **BE-101 (hemophilia B)**: Lead program; BCM engineered to express human Factor IX (hFIX). FDA-cleared IND (May 2024); Fast Track and Orphan designations granted. Phase 1/2 BeCoMe-9 trial open for enrollment. [[2]](https://be.bio/be-biopharma-unveils-become-9-trial-and-presents-on-versatile-b-cell-medicines-platform-at-ash-2024/)
- **BE-102 (hypophosphatasia)**: BCM engineered to produce tissue-nonspecific alkaline phosphatase (ALP); addresses enzyme deficiency in HPP. Preclinical development stage; IND submission planned. [[4]](https://crisprmedicinenews.com/press-release-service/card/be-biopharma-announces-new-preclinical-data-for-be-102-a-b-cell-medicine-for-the-potential-treatmen/)
- **Oncology**: BCM prototype expressing anti-CD3:CD19 bispecific T cell engager showed tumor reduction in ALL patient-derived xenograft model. [[3]](https://be.bio/our-science/our-platform/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Series A | ~2020–2023 | ~$234M | ARCH Venture Partners, Bristol-Myers Squibb, Nextech Invest, Pathway to Cures |
| Series C | Jan 2025 | $40M | BMS Foundation, others |
| Total | | ~$274M | |

[[1]](https://be.bio/)

**ARCH Venture Partners Investment**.

---

## References

1. Be Biopharma — Website: [https://be.bio/](https://be.bio/)
2. Be Biopharma — BeCoMe-9 trial / ASH 2024 presentation: [https://be.bio/be-biopharma-unveils-become-9-trial-and-presents-on-versatile-b-cell-medicines-platform-at-ash-2024/](https://be.bio/be-biopharma-unveils-become-9-trial-and-presents-on-versatile-b-cell-medicines-platform-at-ash-2024/)
3. Be Biopharma — Platform science: [https://be.bio/our-science/our-platform/](https://be.bio/our-science/our-platform/)
4. CRISPR Medicine News — BE-102 preclinical data: [https://crisprmedicinenews.com/press-release-service/card/be-biopharma-announces-new-preclinical-data-for-be-102-a-b-cell-medicine-for-the-potential-treatmen/](https://crisprmedicinenews.com/press-release-service/card/be-biopharma-announces-new-preclinical-data-for-be-102-a-b-cell-medicine-for-the-potential-treatmen/)
