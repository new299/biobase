# Inhibrx — Research Notes

## Overview

Inhibrx, Inc. (NASDAQ: INBX) is a La Jolla, CA-based clinical-stage biopharmaceutical company developing novel biologic therapeutics for oncology and rare diseases, with expertise in engineered proteins including multispecific antibodies and Fc fusion proteins. Its lead rare disease program INBRX-101 is a recombinant AAT-Fc fusion protein for alpha-1 antitrypsin deficiency (AATD); its oncology programs include multispecific antibody candidates. [[1]](https://inhibrx.com/) [[2]](https://www.crunchbase.com/organization/inhibrx)

---

## Technology & Products

- **INBRX-101 (AAT-Fc Fusion Protein)**: Recombinant human alpha-1 antitrypsin (AAT) engineered as an Fc fusion protein; designed to achieve normal functional AAT levels (≥21 µM threshold) in AATD patients with a less frequent dosing interval than existing weekly plasma-derived AAT infusions; FDA Fast Track designation (May 2023) + FDA Orphan Drug designation (Mar 2022); Phase 1 data support Q3W/Q4W dosing. [[1]](https://inhibrx.com/)
- **Oncology Multispecific Antibody Pipeline**: Multiple engineered biologic programs in oncology targeting apoptosis pathways and solid tumors. [[1]](https://inhibrx.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-IPO rounds | Pre-2020 | Undisclosed | Venture investors |
| IPO (NASDAQ:INBX) | Jul 2020 | ~$136M | Public market |
| Follow-on offerings | 2020–2024 | Various | Public market |

[[2]](https://www.crunchbase.com/organization/inhibrx)

---

## References

1. Inhibrx — Homepage: [https://inhibrx.com/](https://inhibrx.com/)
2. Crunchbase — Inhibrx: [https://www.crunchbase.com/organization/inhibrx](https://www.crunchbase.com/organization/inhibrx)
