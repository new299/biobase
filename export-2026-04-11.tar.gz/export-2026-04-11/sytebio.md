# SYTE.bio

## Overview

SYTE.bio describes itself as a clinical-stage synthetic biology company developing non-viral DNA- and RNA-based vaccines and gene therapies for human and animal health. Public company materials place the business in Buenos Aires and Boston and frame it around non-viral nucleic-acid therapeutics. [[1]](https://syte.bio/) [[2]](https://syte.bio/about-us/)

## Technology

The company says its platform includes linear DNA, circular DNA, linear RNA, and circular RNA systems. On the RNA side, it highlights circular RNA designed for stability and extended protein expression, and a linear RNA platform intended for high expression and re-dosing without conventional viral-vector limitations. [[3]](https://syte.bio/rna-platforms/) [[1]](https://syte.bio/)

## Investors

I did not find a detailed named institutional investor syndicate in the accessible public materials reviewed here. A third-party profile indicates SYTE.bio has been accelerator or incubator backed, including MassBioDrive, but public funding disclosure appears limited relative to the company's technology claims. [[4]](https://www.ventureradar.com/organisation/syte_%5Bdot%5D_bio/5a0b1908-a05a-4c7a-bcdf-d3969d2cc255)

## Pipeline And Strategic Position

SYTE.bio's public website presents both human-health and animal-health programs, including oncology-related animal-health candidates and broader vaccine and therapeutic applications. The strategic message is that non-viral nucleic-acid platforms can provide safer, more flexible, and more re-dosable alternatives to viral vectors. [[1]](https://syte.bio/) [[3]](https://syte.bio/rna-platforms/)
