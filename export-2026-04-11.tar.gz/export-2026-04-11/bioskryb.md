# BioSkryb Genomics — Research Notes

## Overview

BioSkryb Genomics is a Durham, NC-based single-cell genomics company founded in 2018. Develops the Primary Template-directed Amplification (PTA) platform for ultra-high-fidelity single-cell whole genome amplification, enabling simultaneous DNA and RNA analysis from a single cell. Total raised: ~$31.5M. [[1]](https://www.bioskryb.com/) [[2]](https://www.prnewswire.com/news-releases/single-cell-genome-sequencing-company-bioskryb-raises-11-5m-in-seed-funding-round-300983873.html)

---

## Technology

- **Primary Template-directed Amplification (PTA)**: Patented isothermal whole genome amplification method achieving >95% single-cell genome coverage with high uniformity and low error rates. Superior to DOP-PCR, MDA, and MALBAC in uniformity and accuracy. [[3]](https://www.bioskryb.com/technology/)
- **ResolveDNA®**: Whole genome sequencing workflow for single cells and low-input DNA. [[4]](https://www.bioskryb.com/resolvedna-single-cell-dna-sequencing-kits/)
- **ResolveOME™**: Multi-omic single-cell kit combining PTA-based WGA with full-length transcriptome sequencing — simultaneous genome + transcriptome from one cell in a single-day workflow. [[5]](https://www.bioskryb.com/resolveome/)
- Applications: cancer heterogeneity, rare variant detection, precision medicine, AI-driven diagnostics. [[1]](https://www.bioskryb.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | Jan 2020 | $11.5M | Anzu Partners (lead), Wilson Sonsini |
| Follow-on | ~2021–2023 | ~$20M | Seed Healthcare, others |
| Total | | ~$31.5M | |

[[2]](https://www.prnewswire.com/news-releases/single-cell-genome-sequencing-company-bioskryb-raises-11-5m-in-seed-funding-round-300983873.html)

---

## References

1. BioSkryb Genomics — Website: [https://www.bioskryb.com/](https://www.bioskryb.com/)
2. PR Newswire — $11.5M Seed round (Jan 2020): [https://www.prnewswire.com/news-releases/single-cell-genome-sequencing-company-bioskryb-raises-11-5m-in-seed-funding-round-300983873.html](https://www.prnewswire.com/news-releases/single-cell-genome-sequencing-company-bioskryb-raises-11-5m-in-seed-funding-round-300983873.html)
3. BioSkryb — Technology: [https://www.bioskryb.com/technology/](https://www.bioskryb.com/technology/)
4. BioSkryb — ResolveDNA: [https://www.bioskryb.com/resolvedna-single-cell-dna-sequencing-kits/](https://www.bioskryb.com/resolvedna-single-cell-dna-sequencing-kits/)
5. BioSkryb — ResolveOME: [https://www.bioskryb.com/resolveome/](https://www.bioskryb.com/resolveome/)
