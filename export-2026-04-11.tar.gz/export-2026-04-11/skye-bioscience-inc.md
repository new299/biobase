# Skye Bioscience, Inc.

## Overview
Skye Bioscience is a clinical-stage biotechnology company developing molecules that modulate G-protein-coupled receptors in obesity, metabolic disease, and ophthalmology [[1]](https://ir.skyebioscience.com/).

## Technology
The company's pipeline includes nimacimab, a negative allosteric modulating antibody for CB1, and SBI-100 OE, a small-molecule candidate for glaucoma and ocular hypertension [[1]](https://ir.skyebioscience.com/).

## Investors
As a public company, Skye is financed through public markets and institutional investors. The reviewed investor-relations materials focused on pipeline and corporate updates rather than named holders [[1]](https://ir.skyebioscience.com/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The public materials instead emphasize clinical development and capital-market financing typical of a listed biotech [[1]](https://ir.skyebioscience.com/).

## References
[[1]](https://ir.skyebioscience.com/)
