# Novogene

## Overview
Novogene is a global genomics-services company providing next-generation sequencing, proteomics, metabolomics, and bioinformatics solutions.[[1]](https://www.novogene.com/us-en/company/about-novogene/)[[2]](https://www.novogene.com/us-en) The company says it was founded in March 2011 and now supports researchers and organizations worldwide through a large global sequencing footprint.[[1]](https://www.novogene.com/us-en/company/about-novogene/)

## Technology and Services
Novogene positions itself as a pioneer in high-throughput genomics services with advanced NGS and bioinformatics capabilities.[[1]](https://www.novogene.com/us-en/company/about-novogene/)[[2]](https://www.novogene.com/us-en) Its public materials emphasize multi-omics services spanning whole-genome sequencing, single-cell sequencing, proteomics, and metabolomics, using platforms from Illumina, PacBio, Oxford Nanopore, Ultima, and 10x Genomics.[[2]](https://www.novogene.com/us-en)

## Investors and Ownership
I did not identify a venture-style financing history in the reviewed public materials. The company presents itself as an established independent global services provider rather than a recently funded startup.[[1]](https://www.novogene.com/us-en/company/about-novogene/)

## Acquisitions and Corporate Activity
No acquisition involving Novogene was identified in the reviewed public sources. The clearest corporate milestones in the accessible materials are continued international expansion, certifications, and additional sequencing-center launches.[[1]](https://www.novogene.com/us-en/company/about-novogene/)
