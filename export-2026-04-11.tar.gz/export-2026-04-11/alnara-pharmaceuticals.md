# Alnara Pharmaceuticals

## Overview
Alnara Pharmaceuticals was a biotechnology company developing protein therapeutics for metabolic diseases.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals)[[2]](https://investor.lilly.com/news-releases/news-release-details/lilly-announces-completion-alnara-acquisition) Its lead product was liprotamase, a non-porcine pancreatic enzyme replacement therapy.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals)

## Technology and Pipeline
Alnara focused on orally delivered protein therapeutics designed to act in the gastrointestinal tract without systemic absorption.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals) Liprotamase had completed Phase 3 development and was under FDA review for exocrine pancreatic insufficiency at the time Lilly agreed to acquire the company.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals)

## Investors
Lilly’s acquisition announcement explicitly states that Alnara was backed by Third Rock Ventures, Frazier Healthcare, MPM Capital, Bessemer Venture Partners, and Longwood Founders Fund.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals)

## Acquisitions and Corporate Activity
Lilly announced in July 2010 that it would acquire Alnara and completed the acquisition later that month for an upfront payment of $180 million, subject to cash adjustment at closing.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-alnara-pharmaceuticals)[[2]](https://investor.lilly.com/news-releases/news-release-details/lilly-announces-completion-alnara-acquisition)
