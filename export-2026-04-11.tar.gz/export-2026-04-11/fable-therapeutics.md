# Fable Therapeutics — Research Notes

## Overview

Fable Therapeutics is a Toronto-based AI-driven biotechnology company founded based on research by Professor Philip Kim (University of Toronto) developing novel therapeutics for obesity and metabolic diseases. The company integrates machine learning and advanced computation with large datasets of protein sequences and structures to engineer molecules with optimized potency, developability, and binding affinity. Total raised: $53.5M ($10M seed + $43.5M Series A). Key investors: Alexandria Venture Investments, DCVC Bio, Northleaf Capital Partners, Versant Ventures, University of Toronto. [[1]](https://www.dcvc.com/companies/fable-therapeutics/) [[2]](https://www.versantventures.com/portfolio/fable-therapeutics/)

---

## Technology & Pipeline

- **AI-Driven Drug Discovery Platform**: Combines machine learning with extensive datasets of billions of protein sequences and structures to engineer molecules with optimized potency, developability, and binding affinity — targeting molecular mechanisms underlying obesity and metabolic disease.
- **Obesity / Metabolic Disease**: Lead therapeutic focus area. Development candidates in multiple programs expected in 2025.
- **Philip Kim Research Foundation**: Platform built on research from Professor Philip Kim's laboratory at the University of Toronto, known for computational protein design and systems biology.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | ~2022–2023 | $10M | DCVC Bio, Versant Ventures, University of Toronto |
| Series A | ~2024 | $43.5M | Alexandria Venture Investments, DCVC Bio, Northleaf Capital Partners, Versant Ventures |

Total raised: $53.5M. [[1]](https://www.dcvc.com/companies/fable-therapeutics/)

---

## References

1. DCVC — Fable Therapeutics portfolio page: [https://www.dcvc.com/companies/fable-therapeutics/](https://www.dcvc.com/companies/fable-therapeutics/)
2. Versant Ventures — Fable Therapeutics portfolio page: [https://www.versantventures.com/portfolio/fable-therapeutics/](https://www.versantventures.com/portfolio/fable-therapeutics/)
