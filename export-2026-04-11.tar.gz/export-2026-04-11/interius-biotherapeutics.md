# Interius BioTherapeutics — Research Notes

## Overview

Interius BioTherapeutics was a Philadelphia, PA-based biotechnology company founded as a spinout from the University of Pennsylvania and Penn Medicine, developing in vivo CAR-T cell therapies — engineering immune cells (T cells) directly within the patient using a proprietary gene-delivery vector, eliminating the need for ex vivo cell manufacturing. Interius raised ~$170M and was acquired by Gilead's Kite Pharma for $350M in August 2025. Key investors included RA Capital Management, Cormorant Asset Management, Fairmount Funds, Bain Capital Life Sciences, and Pfizer Ventures. **RA Capital Investment.** [[1]](https://interiusbio.com/) [[2]](https://www.fiercebiotech.com/biotech/gileads-kite-sails-vivo-car-t-space-350m-interius-buyout)

---

## Technology & Products

- **In Vivo CAR-T Platform**: Proprietary gene-delivery vector targeting T cells directly in the patient — directing vectors to spleen, bone marrow, and lymph nodes to reprogram endogenous T cells into CAR-T cells in vivo without ex vivo cell manufacturing; designed to overcome the high cost, complexity, and manufacturing delays of autologous CAR-T therapies. [[1]](https://interiusbio.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2021 | $76M | Cormorant Asset Management (co-lead), Fairmount Funds (co-lead), Bain Capital Life Sciences, Pfizer Ventures, **RA Capital Investment**, Longwood Fund, Logos Capital, Osage University Partners, Quan Capital, Tellus BioVentures (lead founding), University of Pennsylvania/Penn Medicine, Agent Capital, Mark Foundation for Cancer Research |
| Series B | 2024 | $76M | Cormorant Asset Management, Fairmount Funds, **RA Capital Investment**, others |
| Total | — | ~$170M | — |
| Acquired by Kite/Gilead | Aug 2025 | $350M | Gilead Sciences (Kite) |

[[2]](https://www.fiercebiotech.com/biotech/gileads-kite-sails-vivo-car-t-space-350m-interius-buyout)

---

## References

1. Interius BioTherapeutics — Homepage: [https://interiusbio.com/](https://interiusbio.com/)
2. Fierce Biotech — Kite acquires Interius: [https://www.fiercebiotech.com/biotech/gileads-kite-sails-vivo-car-t-space-350m-interius-buyout](https://www.fiercebiotech.com/biotech/gileads-kite-sails-vivo-car-t-space-350m-interius-buyout)
