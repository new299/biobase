# Eilean Therapeutics — Research Notes

## Overview

Eilean Therapeutics LLC is a privately held biotechnology company founded in 2022 developing differentiated small molecule pan-variant therapies for hematologic malignancies — focusing on cancer resistance mechanisms including selective kinase inhibitors, molecular degraders, and novel anti-inflammatory mechanisms. Lead program: ZE74-0282, a first-in-class wild-type–sparing JAK2-JH2/V617F inhibitor (Phase 1 initiated December 2025, ASH 2025 data presentation). Eilean is also the parent company of Lomond Therapeutics, a spin-out conducting Phase 1 clinical studies of lonitoclax. No disclosed external funding rounds as of early 2026. [[1]](https://www.prnewswire.com/news-releases/eilean-therapeutics-to-present-first-in-class-wild-typesparing-jak2-jh2v617f-inhibitor-ze74-0282-at-ash-2025-and-initiate-clinical-studies-in-december-2025-302606899.html) [[2]](https://www.eileanther.com/)

---

## Technology & Pipeline

- **ZE74-0282 (JAK2-JH2/V617F Inhibitor)**: First-in-class selective JAK2 pseudokinase (JH2) domain inhibitor that spares wild-type JAK2 signaling while potently inhibiting the V617F oncogenic variant — targeting myeloproliferative neoplasms (MPNs) including polycythemia vera and myelofibrosis with improved safety profile vs. non-selective JAK2 inhibitors. Phase 1 first-in-human studies initiated December 2025. [[1]](https://www.prnewswire.com/news-releases/eilean-therapeutics-to-present-first-in-class-wild-typesparing-jak2-jh2v617f-inhibitor-ze74-0282-at-ash-2025-and-initiate-clinical-studies-in-december-2025-302606899.html)
- **Lomond Therapeutics (spin-out)**: Developing lonitoclax (BCL-2 family inhibitor) for hematologic malignancies; Phase 1 single ascending dose results reported December 2024. [[3]](https://www.cbinsights.com/investor/eilean-therapeutics)

---

## Funding & Investors

No publicly disclosed external funding rounds for Eilean Therapeutics LLC as of early 2026. [[3]](https://www.cbinsights.com/investor/eilean-therapeutics)

---

## References

1. PRNewswire — Eilean Therapeutics ZE74-0282 ASH 2025 presentation and Phase 1 initiation (Nov 2025): [https://www.prnewswire.com/news-releases/eilean-therapeutics-to-present-first-in-class-wild-typesparing-jak2-jh2v617f-inhibitor-ze74-0282-at-ash-2025-and-initiate-clinical-studies-in-december-2025-302606899.html](https://www.prnewswire.com/news-releases/eilean-therapeutics-to-present-first-in-class-wild-typesparing-jak2-jh2v617f-inhibitor-ze74-0282-at-ash-2025-and-initiate-clinical-studies-in-december-2025-302606899.html)
2. Eilean Therapeutics — Homepage: [https://www.eileanther.com/](https://www.eileanther.com/)
3. CB Insights — Eilean Therapeutics investor profile: [https://www.cbinsights.com/investor/eilean-therapeutics](https://www.cbinsights.com/investor/eilean-therapeutics)
