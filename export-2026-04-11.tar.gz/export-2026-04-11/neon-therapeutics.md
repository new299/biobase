# Neon Therapeutics

## Overview

Neon Therapeutics was a biotechnology company developing neoantigen-based cancer immunotherapies, including neoantigen-specific T cell therapies and personalized cancer vaccine concepts.[[1]](https://investors.biontech.de/news-releases/news-release-details/biontech-acquire-neon-strengthen-global-leadership-position-t)

## Technology

BioNTech's acquisition announcement described Neon as adding neoantigen-specific cell therapies, including a T cell therapy targeting shared RAS oncogenes, and expanding BioNTech's T cell therapy pipeline.[[1]](https://investors.biontech.de/news-releases/news-release-details/biontech-acquire-neon-strengthen-global-leadership-position-t)

## Investors

Neon was a public company by the time of its sale. The local note's Third Rock Ventures association is directionally consistent with the company's venture-backed origins, but the reviewed primary sources here are strongest on the acquisition process.

## Acquisitions and Strategic Transactions

In January 2020, BioNTech announced an all-stock acquisition of Neon valued at approximately $67 million.[[1]](https://investors.biontech.de/news-releases/news-release-details/biontech-acquire-neon-strengthen-global-leadership-position-t) BioNTech announced completion of the acquisition in May 2020, after which Neon became BioNTech's U.S. headquarters subsidiary.[[2]](https://investors.biontech.de/news-releases/news-release-details/biontech-completes-acquisition-neon-therapeutics)
