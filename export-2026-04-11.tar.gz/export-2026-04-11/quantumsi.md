# Quantum-Si

## Overview

Quantum-Si is a public proteomics company focused on bringing single-molecule protein analysis to the benchtop [[1]](https://ir.quantum-si.com/). The company describes its goal as making protein analysis simpler, faster, and more informative for broad lab use [[1]](https://ir.quantum-si.com/).

## Technology

Quantum-Si says its platform enables real-time kinetic-based single-molecule protein analysis [[1]](https://ir.quantum-si.com/). In 2026 it said the next-generation Proteus platform remained on track for year-end launch, while its first-generation Platinum Pro system continued to expand the installed base and consumables use [[2]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-reports-fourth-quarter-and-full-year-2025-financial).

## Investors

Quantum-Si became public through its merger with HighCape Capital Acquisition Corp., a transaction that the company later said added more than $511 million of cash to the balance sheet [[3]](https://www.globenewswire.com/news-release/2021/05/17/2230643/0/en/Quantum-Si-and-HighCape-Capital-Acquisition-Corp-Announce-Effectiveness-of-Registration-Statement-for-Proposed-Business-Combination.html) [[4]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-reports-second-quarter-2021-financial-results). In 2025, Quantum-Si also completed two registered direct financings of approximately $50 million each from institutional investors [[5]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-registered) [[6]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-0).

## Acquisitions / Strategic Transactions

The principal strategic transaction identified in the reviewed sources is the HighCape SPAC combination that took Quantum-Si public in 2021 [[3]](https://www.globenewswire.com/news-release/2021/05/17/2230643/0/en/Quantum-Si-and-HighCape-Capital-Acquisition-Corp-Announce-Effectiveness-of-Registration-Statement-for-Proposed-Business-Combination.html). The company has since relied on follow-on equity financings to fund platform development [[5]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-registered) [[6]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-0).

## References

[[1]](https://ir.quantum-si.com/)
[[2]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-reports-fourth-quarter-and-full-year-2025-financial)
[[3]](https://www.globenewswire.com/news-release/2021/05/17/2230643/0/en/Quantum-Si-and-HighCape-Capital-Acquisition-Corp-Announce-Effectiveness-of-Registration-Statement-for-Proposed-Business-Combination.html)
[[4]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-reports-second-quarter-2021-financial-results)
[[5]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-registered)
[[6]](https://ir.quantum-si.com/news-releases/news-release-details/quantum-si-incorporated-announces-pricing-50-million-0)

## ASeq Posts

- [Quantumsi Proteus Update](https://aseq.substack.com/p/quantumsi-proteus-update)
- [More Quantumsi Pondering](https://aseq.substack.com/p/more-quantumsi-pondering)
- [Quantumsi Raising More Money](https://aseq.substack.com/p/quantumsi-raising-more-money)
- [Quantumsi Raising 50M](https://aseq.substack.com/p/quantumsi-raising-50m)
- [Quantumsi Raises 50M](https://aseq.substack.com/p/quantumsi-raises-50m)
- [Quantumsi Routes Forward](https://aseq.substack.com/p/quantumsi-routes-forward)
- [Quantumsi Chips No More](https://aseq.substack.com/p/quantumsi-chips-no-more)
- [Quantumsi Prospectus Review](https://aseq.substack.com/p/quantumsi-prospectus-review)
