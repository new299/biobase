# Loto Biotech

## Overview

Loto Biotech is an Italian biotech startup developing siRNA-based therapeutics for rare genetic disorders, especially autosomal dominant diseases.[[1]](https://www.finsmes.com/2025/06/loto-biotech-platform-raises-e600k-in-funding.html)

## Technology

According to FinSMEs' financing coverage, Loto is developing a proprietary AI-driven platform to design siRNA-based pro-drugs for rare genetic disorders.[[1]](https://www.finsmes.com/2025/06/loto-biotech-platform-raises-e600k-in-funding.html) The local note's identification of the company as an RNAi/siRNA business is consistent with that description.

## Investors

In June 2025, Loto Biotech Platform raised EUR600,000 from Scientifica Venture Capital.[[1]](https://www.finsmes.com/2025/06/loto-biotech-platform-raises-e600k-in-funding.html)

## Acquisitions and Strategic Transactions

No acquisition involving Loto Biotech was identified in the reviewed sources. The current public record is that of a newly funded early-stage startup.[[1]](https://www.finsmes.com/2025/06/loto-biotech-platform-raises-e600k-in-funding.html)
