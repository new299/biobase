# Ollin Biosciences

## Overview
Ollin Biosciences is a clinical-stage biopharmaceutical company dedicated to acquiring and developing therapies for vision-threatening ophthalmic diseases.[[1]](https://ollin.bio/press-releases/ollin-biosciences-launches-with-mission-to-accelerate-best-in-class-therapies-in-ophthalmology/) The company publicly launched in September 2025 and said it was established in 2023.[[1]](https://ollin.bio/press-releases/ollin-biosciences-launches-with-mission-to-accelerate-best-in-class-therapies-in-ophthalmology/)

## Technology and Pipeline
Ollin describes itself as an asset-centric ophthalmology company rather than a platform-technology developer.[[1]](https://ollin.bio/press-releases/ollin-biosciences-launches-with-mission-to-accelerate-best-in-class-therapies-in-ophthalmology/) Its lead clinical-stage program is OLN324, a VEGF/Ang2 bispecific antibody in a head-to-head study versus faricimab in wet AMD and DME, and a second program, OLN102, is a TSHR/IGF-1R bispecific antibody for thyroid eye disease and Graves' disease.[[1]](https://ollin.bio/press-releases/ollin-biosciences-launches-with-mission-to-accelerate-best-in-class-therapies-in-ophthalmology/)

## Investors
At launch, Ollin announced an initial $100 million financing led by ARCH Venture Partners, Mubadala Capital, and Monograph Capital.[[1]](https://ollin.bio/press-releases/ollin-biosciences-launches-with-mission-to-accelerate-best-in-class-therapies-in-ophthalmology/)[[2]](https://www.goodwinlaw.com/en/news-and-events/news/2025/09/announcements-lifesciences-goodwin-advises-ollin-biosciences)

## Acquisitions and Corporate Activity
No acquisition involving Ollin Biosciences was identified in the reviewed public sources. A key corporate milestone at launch was its collaboration with Innovent Biologics to develop OLN324.[[2]](https://www.goodwinlaw.com/en/news-and-events/news/2025/09/announcements-lifesciences-goodwin-advises-ollin-biosciences)
