# Metagenomi

## Overview

Metagenomi is a genetic medicines company building CRISPR-based therapeutics from a large collection of novel genome editing systems mined from metagenomic data.[[1]](https://www.metagenomi.co/) The company focuses on in vivo gene editing and related modalities.[[1]](https://www.metagenomi.co/)

## Technology

Metagenomi's platform is based on discovery of CRISPR systems from nature and engineering them into therapeutic tools. The company says it has built a diverse library of novel gene editing systems intended to support nuclease editing, base editing, and other genetic medicine applications.[[1]](https://www.metagenomi.co/)

## Investors

The reviewed site highlights support from leading biotechnology investors, though the investor page content is image-heavy rather than a clean text list.[[1]](https://www.metagenomi.co/) The company also became public in 2024, indicating access to public capital markets beyond its earlier private rounds.

## Acquisitions and Strategic Transactions

Metagenomi has used partnerships as a major strategic lever. In May 2024, it announced a collaboration with Moderna to discover and develop in vivo gene editing therapeutics for five liver targets, with the potential for approximately $1.9 billion in milestone payments plus royalties.[[2]](https://www.metagenomi.co/news/metagenomi-announces-collaboration-with-moderna-to-discover-and-develop-in-vivo-gene-editing-therapeutics) No acquisition of Metagenomi itself was identified in the reviewed sources.
