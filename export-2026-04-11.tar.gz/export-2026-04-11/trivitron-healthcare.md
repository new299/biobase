# Trivitron Healthcare

## Overview

Trivitron Healthcare is a global medical technology company focused on making healthcare products more affordable and accessible. The company says it manufactures and distributes medical technology products across more than 180 countries through a broad portfolio spanning diagnostics, imaging, critical care, newborn screening, radiation protection, renal care, and operating room solutions. [[1]](https://www.trivitron.com/about-us)

## Technology And Business Scope

Trivitron is a diversified medtech platform rather than a single-product company. Its business is built around multiple product categories, in-house manufacturing, global distribution, and R&D tie-ups, including CE-certified and USFDA-linked manufacturing capabilities across several countries. [[1]](https://www.trivitron.com/about-us)

## Acquisitions

The company has used acquisitions to expand internationally. In March 2022, Trivitron acquired 100% of U.S.-based The Kennedy Company, a maker of radiation protection and acoustic barrier products. [[2]](https://www.trivitron.com/news/trivitron-healthcare-acquires-the-usa-based-the-kennedy-company)

## Strategic Position

Trivitron's strategy is to be a broad, affordable healthcare technology provider, especially for emerging and price-sensitive markets. The combination of manufacturing scale, international distribution, and targeted acquisitions suggests a medtech roll-up and expansion model more than a venture-stage biotech profile. [[1]](https://www.trivitron.com/about-us) [[2]](https://www.trivitron.com/news/trivitron-healthcare-acquires-the-usa-based-the-kennedy-company)
