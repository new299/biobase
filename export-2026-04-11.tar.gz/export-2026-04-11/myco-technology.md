# MycoTechnology

## Overview
MycoTechnology is a food technology company developing ingredients and processing solutions using mushroom mycelia and fermentation.[[1]](https://mycoiq.com/)[[2]](https://www.businesswire.com/news/home/20240229791543/en/MycoTechnology-Closes-Oversubscribed-85-Million-Series-E-Round-to-Bring-New-Products-to-Scale)

## Technology
The company says it has built a platform around fermentation and fungi to create food and beverage ingredients, including sweet proteins, flavor modulation solutions, and other functional ingredients.[[1]](https://mycoiq.com/)[[2]](https://www.businesswire.com/news/home/20240229791543/en/MycoTechnology-Closes-Oversubscribed-85-Million-Series-E-Round-to-Bring-New-Products-to-Scale)

## Investors
MycoTechnology announced an oversubscribed $85 million Series E round in February 2024 led by existing investors, bringing total capital raised to more than $200 million.[[2]](https://www.businesswire.com/news/home/20240229791543/en/MycoTechnology-Closes-Oversubscribed-85-Million-Series-E-Round-to-Bring-New-Products-to-Scale)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://mycoiq.com/)
