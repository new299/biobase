# Resolution Bioscience

## Overview
Resolution Bioscience was a precision-oncology diagnostics company focused on NGS-based liquid biopsy assays [[1]](https://www.agilent.com/about/newsroom/presrel/2021/02mar-gp21007.html).

## Technology
Its core platform was the ctDx liquid biopsy platform, which Agilent described as a comprehensive NGS-based blood-test workflow for detecting actionable cancer mutations [[2]](https://www.agilent.com/about/features/en/leading-liquid-biopsy-platform.html).

## Investors
The reviewed sources focused on the acquisition rather than financing history, and did not provide a detailed investor list in this pass [[1]](https://www.agilent.com/about/newsroom/presrel/2021/02mar-gp21007.html).

## Acquisitions / Strategic Transactions
Agilent announced the acquisition of Resolution Bioscience in March 2021 and completed it in April 2021 to strengthen Agilent's role in NGS-based cancer diagnostics [[1]](https://www.agilent.com/about/newsroom/presrel/2021/02mar-gp21007.html) [[3]](https://www.agilent.com/about/newsroom/presrel/2021/15apr-gp21013.html).

## References
[[1]](https://www.agilent.com/about/newsroom/presrel/2021/02mar-gp21007.html)
[[2]](https://www.agilent.com/about/features/en/leading-liquid-biopsy-platform.html)
[[3]](https://www.agilent.com/about/newsroom/presrel/2021/15apr-gp21013.html)
