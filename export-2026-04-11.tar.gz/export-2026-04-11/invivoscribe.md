# InVivoscribe — Research Notes

## Overview

InVivoscribe, Inc. is a San Diego, CA-based molecular diagnostics company with over 30 years of experience developing and manufacturing precision diagnostics for oncology — particularly leukemia and lymphoma testing. The company provides a comprehensive range of B- and T-cell clonality assays, NGS oncology panels, minimal residual disease (MRD) testing, BCR-ABL translocation assays, and bioinformatics software, all manufactured under ISO 13485 design control in a cGMP facility. InVivoscribe is privately held; no major public VC funding has been reported. [[1]](https://invivoscribe.com/) [[2]](https://invivoscribe.com/company/)

---

## Technology & Products

- **B/T-Cell Clonality Assays**: Gold-standard BIOMED-2 (EuroClonality) based clonality assays for diagnosis and MRD monitoring of B-cell and T-cell lymphomas and leukemias by PCR + capillary electrophoresis. [[1]](https://invivoscribe.com/)
- **BCR-ABL Testing**: Quantitative and qualitative assays for BCR-ABL1 translocation (p190, p210, p230) in CML and ALL; supports treatment monitoring and therapy response assessment. [[1]](https://invivoscribe.com/)
- **NGS Oncology Panels**: Next-generation sequencing gene panels for comprehensive somatic mutation profiling in hematologic malignancies. [[1]](https://invivoscribe.com/)
- **MRD Testing Solutions**: High-sensitivity minimal residual disease detection and monitoring assays for leukemias and lymphomas. [[1]](https://invivoscribe.com/)

---

## Funding & Investors

InVivoscribe is a privately held company. No public VC funding information found. [[2]](https://invivoscribe.com/company/)

---

## References

1. InVivoscribe — Homepage: [https://invivoscribe.com/](https://invivoscribe.com/)
2. InVivoscribe — Company Overview: [https://invivoscribe.com/company/](https://invivoscribe.com/company/)
