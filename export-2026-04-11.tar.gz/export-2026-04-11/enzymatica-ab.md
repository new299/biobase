# Enzymatica AB

## Overview
Enzymatica AB is a Swedish life science company developing and selling medical device products for infection-related conditions, centered on its ColdZyme mouth spray franchise.[[1]](https://www.enzymatica.com/media/press-releases/2026/year-end-report-2025-new-ceo-takes-the-helm-initiates-the-next-phase-of-enzymaticas-international-expansion/)[[2]](https://www.enzymatica.com/products/coldzyme/)

## Technology / Products
Its key product is ColdZyme, a mouth spray that forms a protective barrier in the mouth and throat intended to trap and inactivate cold viruses, reduce viral load, and shorten or lessen symptoms when used early.[[2]](https://www.enzymatica.com/products/coldzyme/)

## Investors / Financials
Enzymatica is a publicly listed Swedish company on Nasdaq First North Growth Market rather than a venture-backed startup. In its 2025 year-end report published on February 18, 2026, the company reported full-year 2025 net sales of SEK 53.9 million and year-end net cash of SEK 32.1 million.[[1]](https://www.enzymatica.com/media/press-releases/2026/year-end-report-2025-new-ceo-takes-the-helm-initiates-the-next-phase-of-enzymaticas-international-expansion/)[[3]](https://www.enzymatica.com/investors/financial-reports/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Recent public developments focus on international expansion, product launches such as ColdZyme Eucalyptus, and partnerships in elite sport rather than M&A.[[1]](https://www.enzymatica.com/media/press-releases/2026/year-end-report-2025-new-ceo-takes-the-helm-initiates-the-next-phase-of-enzymaticas-international-expansion/)[[4]](https://www.enzymatica.com/media/press-releases/2021/enzymatica-launches-coldzyme-on-amazon/)
