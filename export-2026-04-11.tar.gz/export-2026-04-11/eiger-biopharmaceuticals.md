# Eiger BioPharmaceuticals — Research Notes

## Overview

Eiger BioPharmaceuticals (NASDAQ: EIGR) was a Palo Alto, CA-based commercial-stage biopharmaceutical company focused on Hepatitis Delta Virus (HDV) — the most severe form of viral hepatitis. Programs included lonafarnib (Zokinvy®, FDA-approved for Hutchinson-Gilford Progeria Syndrome and Progeroid Laminopathies) and peginterferon lambda for HDV. The company filed for Chapter 11 bankruptcy protection in early 2024 and entered a Stalking Horse agreement for the sale of Zokinvy® (lonafarnib) in April 2024. [[1]](https://www.eigerbio.com/) [[2]](https://www.biopharmcatalyst.com/company/EIGR)

---

## Technology & Pipeline

- **Lonafarnib (Zokinvy®)**: Farnesyltransferase inhibitor — FDA-approved for Hutchinson-Gilford Progeria Syndrome (HGPS) and Progeroid Laminopathies (2020). Also studied in HDV. Stalking Horse agreement for Zokinvy sale announced April 2024 during bankruptcy proceedings. [[2]](https://www.biopharmcatalyst.com/company/EIGR)
- **Peginterferon Lambda (HDV)**: Antiviral for HDV treatment; pipeline program advancing toward Phase 3. [[1]](https://www.eigerbio.com/)
- **Avexitide**: GLP-1 receptor antagonist for post-bariatric hypoglycemia (PBH) and congenital hyperinsulinism (CHI). [[1]](https://www.eigerbio.com/)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2008 | Palo Alto, CA |
| IPO (NASDAQ: EIGR) | ~2015 | Public market |
| Chapter 11 filing | ~2024 | Bankruptcy proceedings |
| Stalking Horse (Zokinvy) | Apr 2024 | Asset sale process |

---

## References

1. Eiger BioPharmaceuticals — Homepage: [https://www.eigerbio.com/](https://www.eigerbio.com/)
2. BioPharma Catalyst — Eiger BioPharmaceuticals pipeline: [https://www.biopharmcatalyst.com/company/EIGR](https://www.biopharmcatalyst.com/company/EIGR)
