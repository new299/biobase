# Cotton Mouton Diagnostics — Research Notes

## Overview

Cotton Mouton Diagnostics (CMD) is a Cambridge, UK-based diagnostics company founded in 2015. Develops a magneto-optical detection platform (αBET) for pharmaceutical quality control testing — specifically as a rapid, sustainable alternative to traditional Limulus Amebocyte Lysate (LAL) endotoxin and pyrogen testing for biopharmaceutical manufacturing. Backed by Cambridge Angels and CPI Enterprises. [[1]](https://www.manufacturingmanagement.co.uk/content/news/cotton-mouton-diagnostics-disrupts-endotoxin-testing) [[2]](https://www.uk-cpi.com/news/uk-diagnostics-innovator-secures-investment-to-advance-pharmaceutical-testing)

---

## Technology

- **αBET (Alpha Bacterial Endotoxin Test) Platform**: Benchtop magneto-optical detection instrument using magnetic particle spectroscopy (MPS) to detect bacterial endotoxins and pyrogens in pharmaceutical products. Provides a more sustainable, efficient, and user-friendly alternative to conventional LAL assays — which depend on horseshoe crab blood harvesting. [[1]](https://www.manufacturingmanagement.co.uk/content/news/cotton-mouton-diagnostics-disrupts-endotoxin-testing)
- The platform's magneto-optical approach monitors clotting, agglutination, and coagulation processes for biomarker detection. [[3]](https://tracxn.com/d/companies/cotton-mouton-diagnostics/__Dmr4jYsbTbYucaPQmQhR7WFi2XHg2490jMH3-Kzfabg)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | ~2015–2022 | Undisclosed | Cambridge Angels |
| CPI Enterprises Grant | 2023 | £500K | CPI Enterprises (via Innovate UK Catapult Investment Pilot) |

Total raised: undisclosed (primarily early-stage). [[2]](https://www.uk-cpi.com/news/uk-diagnostics-innovator-secures-investment-to-advance-pharmaceutical-testing)

---

## References

1. Manufacturing Management — Cotton Mouton disrupts endotoxin testing: [https://www.manufacturingmanagement.co.uk/content/news/cotton-mouton-diagnostics-disrupts-endotoxin-testing](https://www.manufacturingmanagement.co.uk/content/news/cotton-mouton-diagnostics-disrupts-endotoxin-testing)
2. CPI — CMD secures investment for pharmaceutical testing: [https://www.uk-cpi.com/news/uk-diagnostics-innovator-secures-investment-to-advance-pharmaceutical-testing](https://www.uk-cpi.com/news/uk-diagnostics-innovator-secures-investment-to-advance-pharmaceutical-testing)
3. Tracxn — Cotton Mouton Diagnostics profile: [https://tracxn.com/d/companies/cotton-mouton-diagnostics/__Dmr4jYsbTbYucaPQmQhR7WFi2XHg2490jMH3-Kzfabg](https://tracxn.com/d/companies/cotton-mouton-diagnostics/__Dmr4jYsbTbYucaPQmQhR7WFi2XHg2490jMH3-Kzfabg)

## ASeq Posts

- [Cotton Mouton Diagnostics](https://aseq.substack.com/p/cotton-mouton-diagnostics)
