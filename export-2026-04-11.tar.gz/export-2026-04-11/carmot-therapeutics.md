# Carmot Therapeutics

## Overview
Carmot Therapeutics was a clinical-stage biotech focused on metabolic disease, especially obesity and diabetes, built around its Chemotype Evolution discovery platform and incretin-based pipeline.[[1]](https://www.roche.com/investors/updates/inv-update-2023-12-04)[[2]](https://www.globenewswire.com/news-release/2023/12/04/2789690/0/en/CarmotTherapeutics-Enters-into-Definitive-Merger-Agreement-with-Roche.html)

## Technology
Roche described Carmot's portfolio as including clinical-stage subcutaneous and oral incretins, including CT-388, CT-996, and CT-868, plus preclinical programs. Carmot also said its discovery engine was its proprietary Chemotype Evolution platform.[[1]](https://www.roche.com/investors/updates/inv-update-2023-12-04)[[3]](https://www.businesswire.com/news/home/20220726005070/en/Carmot-Therapeutics-closes-%24160-million-Series-D-financing-to-advance-clinical-pipeline-of-novel-incretin-receptor-modulators)

## Investors
In 2022 Carmot announced a $160 million Series D led by The Column Group, with significant participation from RA Capital and other institutional investors.[[3]](https://www.businesswire.com/news/home/20220726005070/en/Carmot-Therapeutics-closes-%24160-million-Series-D-financing-to-advance-clinical-pipeline-of-novel-incretin-receptor-modulators)

## Acquisitions / Other
Roche announced in December 2023 that it would acquire Carmot for $2.7 billion upfront plus up to $400 million in milestones, and said the transaction would give Roche access to Carmot's current R&D portfolio and discovery platform.[[1]](https://www.roche.com/investors/updates/inv-update-2023-12-04)[[2]](https://www.globenewswire.com/news-release/2023/12/04/2789690/0/en/CarmotTherapeutics-Enters-into-Definitive-Merger-Agreement-with-Roche.html)
