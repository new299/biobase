# AlphaGen Therapeutics

## Overview
AlphaGen Therapeutics is an early-stage biotechnology company developing therapeutics for severe genetic diseases.[[1]](https://fprimecapital.com/company/alphagen-therapeutics/) The public record reviewed in this pass is thin, and the clearest accessible source is F-Prime’s portfolio page.

## Technology and Pipeline
F-Prime’s company profile identifies AlphaGen as focused on severe genetic diseases but does not provide detailed platform or modality disclosure in the publicly accessible summary.[[1]](https://fprimecapital.com/company/alphagen-therapeutics/) Because I did not find a richer primary company source during this pass, the technical description remains narrow.

## Investors
F-Prime Capital lists AlphaGen Therapeutics as a portfolio company with an initial investment in 2023.[[1]](https://fprimecapital.com/company/alphagen-therapeutics/) I did not identify a fuller company-issued financing announcement during this pass.

## Acquisitions and Corporate Activity
No acquisition involving AlphaGen Therapeutics was identified in the reviewed public sources. The accessible public record is currently limited to portfolio-investor identification.[[1]](https://fprimecapital.com/company/alphagen-therapeutics/)
