# PanOptica

PanOptica, Inc. is a U.S.-based, venture-backed biopharmaceutical company focused on **licensing and developing innovative ophthalmology therapies**, particularly for retinal diseases such as age-related macular degeneration (AMD) ([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html)).

### Approach

PanOptica’s approach is based on **identifying, licensing, and repurposing promising drug candidates** and advancing them into ophthalmic indications:

- Sources assets from other therapeutic areas  
- Focuses on **early-stage compounds with clinical or preclinical data**  
- Advances selected candidates through **clinical proof-of-concept in ophthalmology**  

The company emphasizes building a **portfolio of innovative therapies** rather than relying on a single asset ([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html), :contentReference[oaicite:0]{index=0}).

### Technology & Pipeline

#### Lead Program: PAN-90806
- Small-molecule **VEGF (vascular endothelial growth factor) inhibitor**  
- Developed as a **topical (eye drop) treatment** for neovascular (wet) AMD  
- Designed to replace or reduce reliance on **intravitreal injections**  

Mechanism:

- VEGF drives abnormal blood vessel growth and leakage in AMD  
- PAN-90806 inhibits VEGF signaling  
- Topical delivery aims to reduce treatment burden and complications  

Preclinical and early clinical data showed:

- Suppression of abnormal blood vessel formation  
- Favorable pharmacokinetics and safety profile  

([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html), :contentReference[oaicite:1]{index=1}).

### Market & Positioning

PanOptica operates in the **ophthalmology therapeutics market**, specifically:

- Age-related macular degeneration (AMD)  
- Retinal vascular diseases  

Key positioning:

- Focus on **reducing treatment burden** of current therapies  
- Developing **non-invasive alternatives (eye drops)** to injection-based treatments  
- Leveraging repurposed assets to accelerate development timelines  

([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html), :contentReference[oaicite:2]{index=2}).

### Investors

- **SV Life Sciences** (lead investor)  
- **Third Rock Ventures**  

Both are prominent life sciences venture capital firms ([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html), :contentReference[oaicite:3]{index=3}).

### Funding

- **$30M Series A financing (2011)**  

Funding supported:

- Advancement of PAN-90806 into clinical trials  
- Expansion of pipeline (additional licensed assets)  

([Source 1](https://www.prnewswire.com/news-releases/panoptica-raises-30-million-in-series-a-financing-and-licenses-lead-compound-for-development-as-topical-treatment-of-amd-112858769.html), :contentReference[oaicite:4]{index=4}).

### Status

- Venture-backed  
- Focused on ophthalmology drug development  
- Built around a portfolio strategy of licensed assets  
- Current independent status unclear (based on older data)  

---

Overall, PanOptica was a venture-backed ophthalmology biotech focused on repurposing and developing innovative therapies—particularly a topical VEGF inhibitor for AMD—aimed at reducing the burden of existing injection-based treatments.
