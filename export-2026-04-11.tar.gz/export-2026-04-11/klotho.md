# Klotho

## Overview

The company most clearly matching the local note is Klotho Neurosciences, a public biotechnology company focused on therapeutics based on the anti-aging protein klotho and related longevity biology.[[1]](https://www.prnewswire.com/news-releases/klotho-neurosciences-signs-letter-of-intent-to-acquire-select-assets-from-turn-biotechnologies-anchored-by-300-million-global-pharma-partnership-302570344.html) The local note's reference to mRNA and Turn Biotechnologies corresponds to Klotho's 2025 transaction announcement around Turn's assets.[[1]](https://www.prnewswire.com/news-releases/klotho-neurosciences-signs-letter-of-intent-to-acquire-select-assets-from-turn-biotechnologies-anchored-by-300-million-global-pharma-partnership-302570344.html)

## Technology

Klotho's public positioning is centered on klotho biology and longevity-related therapeutics. In September 2025, Klotho announced a letter of intent to acquire select Turn Biotechnologies assets including the ERA cellular reprogramming platform and eTurna RNA delivery system, which would broaden the company's technical base into RNA-enabled rejuvenation technologies.[[1]](https://www.prnewswire.com/news-releases/klotho-neurosciences-signs-letter-of-intent-to-acquire-select-assets-from-turn-biotechnologies-anchored-by-300-million-global-pharma-partnership-302570344.html) In February 2026, a related company, Klothea Bio, announced a Phase 1b trial of an alpha klotho mRNA therapeutic, showing that klotho-associated mRNA development is active in the broader ecosystem, though it is a separate corporate entity from Klotho Neurosciences.[[2]](https://www.biospace.com/press-releases/klothea-bio-announces-the-launch-of-a-phase-1b-clinical-trial-of-akl003-an-alpha-klotho-mrna-therapeutic-for-the-extension-of-human-lifespan)

## Investors

The reviewed sources do not clearly surface a venture syndicate for Klotho Neurosciences, and the company appears in the public markets rather than as a privately financed venture-backed biotech in the sources reviewed. Investor detail is therefore limited in this note.

## Acquisitions and Strategic Transactions

On September 30, 2025, Klotho Neurosciences announced an LOI to acquire select assets from Turn Biotechnologies, including ERA and eTurna, in a proposed cash-and-stock transaction linked to a pharmaceutical partnership with stated value up to $300 million.[[1]](https://www.prnewswire.com/news-releases/klotho-neurosciences-signs-letter-of-intent-to-acquire-select-assets-from-turn-biotechnologies-anchored-by-300-million-global-pharma-partnership-302570344.html) The public reporting reviewed frames this as a signed LOI rather than a completed acquisition.[[3]](https://www.pharmaceutical-technology.com/news/klotho-turn-assets/)
