# SecureBio, Inc.

## Overview
SecureBio is a U.S. nonprofit research organization focused on tools, technologies, and policies to reduce catastrophic pandemic risk.[[1]](https://securebio.org/donate/)[[2]](https://securebio.org/team)

## Technology / Programs
Its public materials describe workstreams spanning NAO, AI, far-UVC, SecureDNA-related biosecurity, and policy initiatives rather than a standard commercial biotech pipeline.[[2]](https://securebio.org/team)

## Funding
SecureBio is a federally registered 501(c)(3) nonprofit. ProPublica's nonprofit records show $7.32 million in revenue and $8.47 million in total assets for 2024.[[1]](https://securebio.org/donate/)[[3]](https://projects.propublica.org/nonprofits/organizations/883068255)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. This note is intentionally framed as a nonprofit biosecurity organization, because that is what the public record supports.[[1]](https://securebio.org/donate/)
