# bluebird bio — Research Notes

## Overview

bluebird bio (formerly NASDAQ: BLUE) was a Cambridge, MA-based gene therapy pioneer founded in 1992. Developed lentiviral vector-based gene therapies for rare genetic diseases. **Acquired by Carlyle Group and SK Capital Partners in mid-2025 for less than ~$30M** — a dramatic fall from a peak market cap exceeding $9B. Had three FDA-approved lentiviral gene therapies. [[1]](https://en.wikipedia.org/wiki/Bluebird_bio) [[2]](https://www.nature.com/articles/d41573-025-00046-6)

---

## Technology & Products

- **Betibeglogene autotemcel (Zynteglo®)**: FDA-approved gene therapy for transfusion-dependent β-thalassemia (TDT). $2.8M list price. [[1]](https://en.wikipedia.org/wiki/Bluebird_bio)
- **Lovotibeglogene autotemcel (Lovo-cel)**: FDA-approved (Dec 2023) for sickle cell disease patients ≥12 years with history of vaso-occlusive events. $3.1M list price. [[3]](https://investor.bluebirdbio.com/news-releases/news-release-details/bluebird-bio-reports-third-quarter-2024-results-and-highlights)
- **Elivaldogene autotemcel (Skysona®)**: FDA-approved gene therapy for early cerebral adrenoleukodystrophy (CALD). [[1]](https://en.wikipedia.org/wiki/Bluebird_bio)
- Platform: Lentiviral vector (LVV)-based ex vivo hematopoietic stem cell gene therapy. [[1]](https://en.wikipedia.org/wiki/Bluebird_bio)

---

## Corporate History & Funding

| Event | Date | Details |
|-------|------|---------|
| Founded | 1992 | Cambridge, MA |
| IPO (NASDAQ: BLUE) | 2013 | ~$116M |
| Peak market cap | ~2018 | >$9B |
| CALD spinoff (2021) | 2021 | Bristol Myers Squibb acquired Jounce Therapeutics (separately); bluebird spun off oncology into 2seventy bio |
| Multiple layoffs | 2022, 2024 | 25-30% workforce each time |
| Acquired by Carlyle / SK Capital | 2025 | <$30M |

[[2]](https://www.nature.com/articles/d41573-025-00046-6)

---

## References

1. Wikipedia — bluebird bio: [https://en.wikipedia.org/wiki/Bluebird_bio](https://en.wikipedia.org/wiki/Bluebird_bio)
2. Nature — bluebird bio cut-price acquisition: [https://www.nature.com/articles/d41573-025-00046-6](https://www.nature.com/articles/d41573-025-00046-6)
3. bluebird bio — Q3 2024 Results: [https://investor.bluebirdbio.com/news-releases/news-release-details/bluebird-bio-reports-third-quarter-2024-results-and-highlights](https://investor.bluebirdbio.com/news-releases/news-release-details/bluebird-bio-reports-third-quarter-2024-results-and-highlights)
