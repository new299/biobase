# Lodo Therapeutics

## Overview

Lodo Therapeutics was a biotechnology company using metagenomics and synthetic biology to discover and develop novel natural product drugs from previously uncultured bacteria.[[1]](https://www.businesswire.com/news/home/20160106005389/en/Lodo-Therapeutics-Launches-with-a-Grounded-Approach-to-Natural-Product-Drug-Discovery)

## Technology

Lodo's platform combined metagenomics, genomics, synthetic biology, and machine learning to mine bacterial DNA directly from environmental samples and identify new natural product scaffolds.[[1]](https://www.businesswire.com/news/home/20160106005389/en/Lodo-Therapeutics-Launches-with-a-Grounded-Approach-to-Natural-Product-Drug-Discovery) The company was built around the work of co-founder Sean Brady and his eSNaPD natural products discovery approach.[[1]](https://www.businesswire.com/news/home/20160106005389/en/Lodo-Therapeutics-Launches-with-a-Grounded-Approach-to-Natural-Product-Drug-Discovery)

## Investors

Lodo launched in January 2016 with approximately $17 million in Series A financing. Investors included founding investor Avalon Ventures, along with ARCH Venture Partners and AbbVie Ventures.[[1]](https://www.businesswire.com/news/home/20160106005389/en/Lodo-Therapeutics-Launches-with-a-Grounded-Approach-to-Natural-Product-Drug-Discovery)

## Acquisitions and Strategic Transactions

In October 2019, Kyowa Kirin announced a definitive agreement to acquire Lodo Therapeutics for an upfront payment of $230 million plus potential development and commercial milestone payments up to about $425 million.[[2]](https://www.kyowakirin.com/media_center/news_releases/2019/e20191010_01.html)
