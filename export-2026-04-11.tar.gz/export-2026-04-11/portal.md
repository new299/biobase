# Portal 

## Overview
Portal  is a cell engineering and drug discovery platform company developing mechanical intracellular delivery technologies for research and clinical workflows.[[1]](https://portal.bio/)[[2]](https://www.businesswire.com/news/home/20241219003240/en/Portal-Biotec)

## Technology
The company says its platform enables delivery of diverse cargo into a wide range of cells using membrane technology and massively parallelized mechanical delivery, supporting both cell engineering and analytical applications.[[1]](https://portal.bio/)[[2]](https://www.businesswire.com/news/home/20241219003240/en/Portal-Biotec)

## Investors
Portal announced an oversubscribed $7 million seed round in December 2024 led by IA Ventures, with participation from Pear VC, Undeterred Ventures, Page One VC, IKJ Capital, and existing investors.[[2]](https://www.businesswire.com/news/home/20241219003240/en/Portal-Biotec)

## Acquisitions / Other
In 2025, Portal announced an $8 million DARPA contract related to a portable red blood cell engineering device. No acquisition was identified in the reviewed public sources.[[1]](https://portal.bio/)

