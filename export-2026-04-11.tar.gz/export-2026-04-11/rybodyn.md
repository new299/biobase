# RyboDyn

## Overview
RyboDyn is an immunotherapy company focused on hidden or "dark proteome" targets for cancer and other diseases [[1]](https://rybodyn.com/about) [[2]](https://sosv.com/company/rybodyn/).

## Technology
Its core technologies are the RyboCypher sequencing platform and CypherAtlas database, which the company says reveal previously overlooked RNA molecules and disease-specific protein fragments that can serve as immunotherapy targets [[1]](https://rybodyn.com/about) [[3]](https://sosv.com/rybodyn-discovers-cryptic-human-proteome-secures-4m-for-novel-cancer-immunotherapy-advancements/).

## Investors
SOSV reported in January 2025 that RyboDyn had secured a $4 million pre-seed round co-led by Genedant Capital and SeaX Ventures, with participation from SOSV and Swell VC [[3]](https://sosv.com/rybodyn-discovers-cryptic-human-proteome-secures-4m-for-novel-cancer-immunotherapy-advancements/). RyboDyn also announced an initial close of a $10 million seed financing in March 2026 [[4]](https://www.prnewswire.com/news-releases/rybodyn-announces-seed-financing-to-advance-ai-driven-discovery-of-hidden-cancer-targets-302722950.html).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The key strategic events visible publicly were the 2025 pre-seed round and 2026 seed financing to scale discovery and progress early programs [[3]](https://sosv.com/rybodyn-discovers-cryptic-human-proteome-secures-4m-for-novel-cancer-immunotherapy-advancements/) [[4]](https://www.prnewswire.com/news-releases/rybodyn-announces-seed-financing-to-advance-ai-driven-discovery-of-hidden-cancer-targets-302722950.html).

## References
[[1]](https://rybodyn.com/about)
[[2]](https://sosv.com/company/rybodyn/)
[[3]](https://sosv.com/rybodyn-discovers-cryptic-human-proteome-secures-4m-for-novel-cancer-immunotherapy-advancements/)
[[4]](https://www.prnewswire.com/news-releases/rybodyn-announces-seed-financing-to-advance-ai-driven-discovery-of-hidden-cancer-targets-302722950.html)
