# Alternative Bio

## Overview
Alternative Bio appears to be an early-stage Singapore-based biotech developing therapeutics against a previously untapped class of post-translational modifying enzymes in tumors.[[1]](https://www.cbinsights.com/company/alternative-bio) Public information is limited and largely database-based.

## Technology
CB Insights describes Alternative Bio as developing drugs for tumors and focusing on a previously untapped class of post-translational modifying enzymes.[[1]](https://www.cbinsights.com/company/alternative-bio) I did not identify a richer primary-source technical description during this pass, so this note remains intentionally narrow.

## Investors
CB Insights reports that Alternative Bio raised a $15 million seed round and identifies F-Prime Capital, HongShan, and Eight Roads Ventures as investors.[[1]](https://www.cbinsights.com/company/alternative-bio) Because this is database-derived rather than company-issued, the financing picture should be treated as partial.

## Acquisitions and Corporate Activity
No acquisition involving Alternative Bio was identified in the reviewed public sources. The accessible public record is limited to database descriptions of its early-stage financing and oncology focus.[[1]](https://www.cbinsights.com/company/alternative-bio)
