# Cellanome — Research Notes

## Overview

Cellanome is a South San Francisco, CA-based life sciences technology company developing a multimodal cellular analysis platform combining live-cell imaging, single-cell transcriptomics, and proteomics to observe cellular dynamics over time. Total raised: ~$213.75M. [[1]](https://app.fundz.net/fundings/cellanome-funding-round-04879a) [[2]](https://www.cellanome.com/)

---

## Technology

- **Multimodal Single-Cell Platform**: Integrates live-cell time-lapse imaging with single-cell RNA sequencing and proteomic readouts to capture both dynamic behavior and molecular state of individual cells. Enables researchers to observe cellular processes — movement, interaction, survival — in real time alongside transcriptomic profiling. [[2]](https://www.cellanome.com/)
- **Applications**: Neurobiology, immunology, aging and metabolic disease, cancer research. Positioned to reveal how cellular behavior relates to gene expression patterns in disease contexts. [[2]](https://www.cellanome.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2022 | ~$63.75M | Undisclosed |
| Series B | Jan 2024 | $150M | Premji Invest (lead), undisclosed others |

Total raised: ~$213.75M. [[1]](https://app.fundz.net/fundings/cellanome-funding-round-04879a)

---

## References

1. Fundz — Cellanome $150M Series B (Jan 2024): [https://app.fundz.net/fundings/cellanome-funding-round-04879a](https://app.fundz.net/fundings/cellanome-funding-round-04879a)
2. Cellanome — Company website: [https://www.cellanome.com/](https://www.cellanome.com/)
3. Silverwood Partners — Healthcare transactions review (Feb 2024): [https://silverwoodpartners.com/healthcare-private-placement-and-ma-transactions-review-week-ending-feb-4-2024/](https://silverwoodpartners.com/healthcare-private-placement-and-ma-transactions-review-week-ending-feb-4-2024/)

## ASeq Posts

- [Cellanome](https://aseq.substack.com/p/cellanome)
