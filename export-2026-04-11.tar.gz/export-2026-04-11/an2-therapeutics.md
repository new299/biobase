# AN2 Therapeutics

## Overview
AN2 Therapeutics is a biopharmaceutical company developing small-molecule therapeutics derived from a boron chemistry platform for infectious diseases and oncology.[[1]](https://www.an2therapeutics.com/about/)[[2]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-launches-12-million-series-funding-and/) Its current pipeline includes Chagas disease, melioidosis, nontuberculous mycobacterial lung disease, and oncology programs.[[1]](https://www.an2therapeutics.com/about/)

## Technology
AN2 says its core discovery engine is a boron chemistry platform that can generate differentiated small molecules for infectious disease and oncology targets.[[1]](https://www.an2therapeutics.com/about/) Recent public materials highlight oncology targets such as ENPP1 and PI3Kalpha alongside infectious-disease programs.[[3]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-reports-second-quarter-2025-financial-results)

## Investors
AN2 launched in November 2019 with a $12 million Series A led by Mountain Group Partners, joined by Adjuvant Capital, Brii Biosciences, and BioRock Ventures.[[2]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-launches-12-million-series-funding-and/) In August 2023, it announced a $70 million underwritten offering including RA Capital Management, TCGX, Frazier Life Sciences, Marshall Wace, Adage Capital Partners, Avidity Partners, Janus Henderson Investors, and Surveyor Capital.[[4]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-announces-pricing-700-million-underwritten) In March 2026 it announced another $40 million private placement involving Coastlands Capital, Commodore Capital, Vivo Capital, and other investors.[[5]](https://www.biospace.com/press-releases/an2-therapeutics-announces-40-million-private-placement-financing)

## Acquisitions and Corporate Activity
I did not identify an acquisition involving AN2 in the reviewed public sources. Notable corporate-development events include its 2019 strategic partnership with Brii Biosciences and later collaboration with DNDi on Chagas disease.[[2]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-launches-12-million-series-funding-and/)[[3]](https://investor.an2therapeutics.com/news-releases/news-release-details/an2-therapeutics-reports-second-quarter-2025-financial-results)
