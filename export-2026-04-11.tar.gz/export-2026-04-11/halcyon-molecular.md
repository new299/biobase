# Halcyon Molecular — Research Notes

## Overview

Halcyon Molecular was a Redwood City, CA-based DNA sequencing startup founded by brothers William and Michael Andregg, aiming to sequence a human genome for under $100 in under 10 minutes using electron microscope-based single-molecule sequencing (not nanopore). The company attracted investments from Peter Thiel's Founders Fund and Elon Musk, with Harvard genomics pioneer George Church as an adviser. Despite the ambitious vision, Halcyon's electron-microscopy-based approach failed to keep pace with competing technologies as companies like Pacific Biosciences and Oxford Nanopore brought new platforms to market. The company shut down (did not achieve an acquisition). [[1]](https://www.fiercebiotech.com/r-d/buzz-genomics-startup-halcyon-molecular-tanks)

---

## Technology

- **Electron Microscope DNA Sequencing**: Proposed reading DNA sequences by direct imaging of individual DNA molecules with a scanning electron or transmission electron microscope, identifying bases by their physical signatures — an approach distinct from optical single-molecule sequencing (PacBio) and nanopore methods. [[1]](https://www.fiercebiotech.com/r-d/buzz-genomics-startup-halcyon-molecular-tanks)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2009 | Redwood City, CA; William + Michael Andregg |
| Funding | ~2009–2012 | Founders Fund (Peter Thiel), Elon Musk; George Church adviser |
| Shut down | ~2012 | Failed to deliver on technical roadmap; competed out by PacBio and other platforms |

[[1]](https://www.fiercebiotech.com/r-d/buzz-genomics-startup-halcyon-molecular-tanks)

---

## References

1. Fierce Biotech — Halcyon Molecular tanks: [https://www.fiercebiotech.com/r-d/buzz-genomics-startup-halcyon-molecular-tanks](https://www.fiercebiotech.com/r-d/buzz-genomics-startup-halcyon-molecular-tanks)
