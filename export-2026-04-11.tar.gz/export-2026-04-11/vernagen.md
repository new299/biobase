# Vernagen

## Overview

Vernagen is an mRNA vaccine company based in Georgia, U.S., focused on vaccines for respiratory and emerging infectious diseases. The local note's pipeline claims are partly corroborated by a recent peer-reviewed RSV vaccine paper listing Vernagen, LLC as an affiliation. [[1]](https://pubmed.ncbi.nlm.nih.gov/41808349/)

## Technology

The strongest publicly accessible evidence points to an mRNA vaccine platform. A 2026 ImmunoHorizons paper involving Vernagen authors reported preclinical immunity and protection from an RSV mRNA vaccine in mice, supporting the local note that the company works on mRNA vaccines. [[1]](https://pubmed.ncbi.nlm.nih.gov/41808349/)

## Investors And Disclosure Limits

I did not find a clearly accessible company website, financing release, or formal investor disclosure in the public sources reviewed for this note. As a result, I cannot responsibly expand the pipeline or investor story beyond the directly supported affiliation and local note. [[1]](https://pubmed.ncbi.nlm.nih.gov/41808349/)

## Public Footprint

Vernagen currently has a very light public footprint. This note should therefore be read as a narrow, evidence-based snapshot rather than a full company profile. [[1]](https://pubmed.ncbi.nlm.nih.gov/41808349/)
