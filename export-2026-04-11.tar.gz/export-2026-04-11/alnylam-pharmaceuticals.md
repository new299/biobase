# Alnylam Pharmaceuticals — Research Notes

## Overview

Alnylam Pharmaceuticals is a publicly traded biopharmaceutical company (NASDAQ: ALNY) founded in 2002, headquartered in Cambridge, MA. Pioneer and global leader in RNA interference (RNAi) therapeutics. Has transitioned from a platform company to a commercial-stage enterprise with multiple FDA-approved medicines and revenues exceeding $1.5B in recent fiscal years. Total raised/partnered: billions across equity, debt, and strategic alliances. [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals) [[2]](https://www.alnylam.com/)

---

## Technology

- **RNAi Therapeutics Platform**: Uses synthetic small interfering RNA (siRNA) molecules delivered via GalNAc conjugate (subcutaneous) or lipid nanoparticle (LNP, IV) to selectively silence disease-causing genes by degrading target mRNA in the liver (and increasingly other tissues). [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals)
- **Approved Medicines (as of 2025)**:
  - **ONPATTRO® (patisiran)**: First-ever RNAi drug; LNP-delivered; transthyretin-mediated amyloidosis (hATTR). FDA approved 2018. [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals)
  - **GIVLAARI® (givosiran)**: GalNAc-siRNA; acute hepatic porphyria. FDA approved 2019.
  - **OXLUMO® (lumasiran)**: GalNAc-siRNA; primary hyperoxaluria type 1. FDA approved 2020.
  - **LEQVIO® (inclisiran)**: GalNAc-siRNA; hypercholesterolemia. Licensed to Novartis; approved 2021 (EU) / 2021 (US). [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals)
  - **AMVUTTRA® (vutrisiran)**: GalNAc-siRNA; ATTR amyloidosis. FDA approved 2022.
- Extensive pipeline across cardiovascular, neurological, hepatic, and ocular diseases.

---

## Funding & Investors

| Round / Event | Date | Amount | Details |
|-------|------|--------|---------|
| IPO (NASDAQ: ALNY) | 2004 | ~$36M | Public offering |
| Roche alliance | 2007 | $331M upfront | Non-exclusive platform access |
| Sanofi Genzyme investment | 2014 | $700M | 12% equity stake + drug rights |
| Blackstone Life Sciences | 2020 | $2B | Royalty monetization deal |

Total R&D investment through ~2017: $1.6B+. Annual revenue (2024): $1.5B+. [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals) [[3]](https://www.biopharmadive.com/news/a-drug-15-years-in-the-making-alnylams-quest-to-prove-rnai/505971/)

---

## Key Patents

- Core RNAi IP licensed from MIT (Fire & Mello Nobel Prize-winning work), Max Planck Institute, and Whitehead Institute. Foundational siRNA design patents give Alnylam a broad licensing position. [[1]](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals)

---

## References

1. Wikipedia — Alnylam Pharmaceuticals: [https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals](https://en.wikipedia.org/wiki/Alnylam_Pharmaceuticals)
2. Alnylam — Corporate website: [https://www.alnylam.com/](https://www.alnylam.com/)
3. BioPharma Dive — 15-year RNAi journey: [https://www.biopharmadive.com/news/a-drug-15-years-in-the-making-alnylams-quest-to-prove-rnai/505971/](https://www.biopharmadive.com/news/a-drug-15-years-in-the-making-alnylams-quest-to-prove-rnai/505971/)
