# Chrono Therapeutics

## Overview
Chrono Therapeutics was a digital therapeutics and drug-delivery company best known for SmartStop, a wearable nicotine replacement therapy system for smoking cessation.[[1]](https://www.wsj.com/articles/evgen-to-raise-up-to-2-4-mln-to-change-name-after-acquiring-chronos-therapeutics-48b2cf9b)[[2]](https://www.prnewswire.com/news-releases/chrono-therapeutics-raises-47-million-accelerating-the-quit-smoking-movement-and-development-of-smartstop-300103368.html)

## Technology
Its public materials described SmartStop as a connected transdermal nicotine patch system designed to personalize smoking-cessation treatment using wearable delivery and behavioral support.[[2]](https://www.prnewswire.com/news-releases/chrono-therapeutics-raises-47-million-accelerating-the-quit-smoking-movement-and-development-of-smartstop-300103368.html)

## Investors
Chrono announced a $47 million financing in 2015 led by 5AM Ventures and New Leaf Venture Partners, with participation from Kaiser Permanente Ventures, GE Ventures, and existing investors including Deerfield Management, GlaxoSmithKline, and Presidio Partners.[[2]](https://www.prnewswire.com/news-releases/chrono-therapeutics-raises-47-million-accelerating-the-quit-smoking-movement-and-development-of-smartstop-300103368.html)

## Acquisitions / Other
In 2023, Evgen Pharma announced plans to acquire Chronos Therapeutics and rebrand as TheraCryf. Public coverage indicates the Chronos assets were being folded into Evgen's pipeline strategy.[[1]](https://www.wsj.com/articles/evgen-to-raise-up-to-2-4-mln-to-change-name-after-acquiring-chronos-therapeutics-48b2cf9b)
