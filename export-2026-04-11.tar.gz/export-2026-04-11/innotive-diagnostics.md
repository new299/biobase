# Innotive Diagnostics

## Overview
Innotive Diagnostics, now branded publicly as InnotiveDx, is a UK diagnostics company developing a rapid point-of-care urinary tract infection test with integrated antimicrobial susceptibility testing.[[1]](https://www.innotivedx.com/)[[2]](https://www.prnewswire.com/news-releases/innotivedx-wins-1-million-grant-from-pace-302623527.html)

## Technology
The company says its platform can identify the causative bacteria and deliver antimicrobial susceptibility results in under 60 minutes. Public materials describe benchtop assay accuracy above 96% in blinded evaluations and position the product around better antimicrobial stewardship.[[1]](https://www.innotivedx.com/)[[2]](https://www.prnewswire.com/news-releases/innotivedx-wins-1-million-grant-from-pace-302623527.html)

## Investors / Funding
The clearest disclosed recent funding event is a £1 million grant from PACE announced in November 2025 to advance development of its UTI point-of-care diagnostics system and InnotiveUTI test.[[2]](https://www.prnewswire.com/news-releases/innotivedx-wins-1-million-grant-from-pace-302623527.html)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. A notable corporate event was its rebrand from PhenUtest Diagnostics to InnotiveDx in 2024.[[1]](https://www.innotivedx.com/)
