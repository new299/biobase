# BioNTech SE — Research Notes

## Overview

BioNTech SE (NASDAQ: BNTX) is a Mainz, Germany-based biopharmaceutical company co-founded in 2008 by Uğur Şahin, Özlem Türeci, and Christoph Huber. Pioneered individualized mRNA cancer immunotherapy; achieved global prominence as co-developer (with Pfizer) of the first approved mRNA COVID-19 vaccine (Comirnaty). 2025 revenue guidance: €2.6–2.8B (primarily COVID-19 vaccine revenue). Pivoting to oncology. [[1]](https://www.biontech.com/) [[2]](https://investors.biontech.de/)

---

## Technology & Pipeline

- **mRNA Platforms**: Multiple mRNA platforms including FixVac (shared antigen), iNeST (individualized neoantigen), and modified mRNA constructs. BNT111 (FixVac, melanoma), BNT122/autogene cevumeran (iNeST, in Genentech collaboration) in clinical trials. [[3]](https://www.biontech.com/int/en/home/pipeline-and-products/platforms/mrna-platforms.html)
- **Autogene Cevumeran (BNT122/RO7198457)**: Individualized neoantigen-specific mRNA cancer immunotherapy (iNeST) with Genentech/Roche. Phase 2/3 data expected 2025–2026. [[3]](https://www.biontech.com/int/en/home/pipeline-and-products/platforms/mrna-platforms.html)
- **BNT327/PM8002**: Bispecific antibody (PD-L1 × VEGF); Phase 3 in triple-negative breast cancer first-line planned 2025. [[4]](https://investors.biontech.de/news-releases/news-release-details/biontech-provides-strategic-business-update-and-outlines-2026/)
- **ADCs**: Multiple antibody-drug conjugates in development. [[3]](https://www.biontech.com/int/en/home/pipeline-and-products/pipeline.html)
- **CAR-T**: Innovative CAR-T cell therapy programs. [[3]](https://www.biontech.com/int/en/home/pipeline-and-products/pipeline.html)
- **COVID-19 Vaccine (Comirnaty)**: Co-developed with Pfizer; BNT162b2. Still primary revenue driver 2025. [[2]](https://investors.biontech.de/)

---

## Financials

| Metric | FY2025 |
|--------|--------|
| Revenue Guidance (Nov 2025 update) | €2.6–2.8B |
| Primary Driver | COVID-19 vaccine revenue |

[[2]](https://investors.biontech.de/)

---

## References

1. BioNTech — Website: [https://www.biontech.com/](https://www.biontech.com/)
2. BioNTech — Investor Relations: [https://investors.biontech.de/](https://investors.biontech.de/)
3. BioNTech — Pipeline: [https://www.biontech.com/int/en/home/pipeline-and-products/pipeline.html](https://www.biontech.com/int/en/home/pipeline-and-products/pipeline.html)
4. BioNTech — 2026 Strategic Update (J.P. Morgan 2026): [https://investors.biontech.de/news-releases/news-release-details/biontech-provides-strategic-business-update-and-outlines-2026/](https://investors.biontech.de/news-releases/news-release-details/biontech-provides-strategic-business-update-and-outlines-2026/)
