# Wave Life Sciences

## Overview

Wave Life Sciences is a clinical-stage company focused on RNA medicines. The company now spans RNA editing, RNAi, splicing, and allele-selective silencing, with a strategy of unlocking multiple modalities from a chemistry and delivery foundation. [[1]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-reports-fourth-quarter-and-full-year-2025) [[2]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-closes-18-million-series-financing-advance)

## Technology

Wave's public pipeline highlights its SpiRNA RNAi design, AIMer RNA editing platform, splicing programs, and allele-selective silencing work. By 2026, the company was pushing both obesity and liver disease programs alongside neuromuscular and CNS assets. [[1]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-reports-fourth-quarter-and-full-year-2025)

## Investors And Financing

Wave closed an $18 million Series A in 2015 led by RA Capital and Kagoshima Shinsangyo Sosei, followed by a $66 million Series B later that year led by Foresite Capital. More recently, it raised about $230 million in an upsized 2024 public offering after initially announcing a $175 million raise. [[2]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-closes-18-million-series-financing-advance) [[3]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-raises-66-million-series-b-financing) [[4]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-announces-closing-upsized-public-offering)

## Strategic Position

Wave is no longer just a stereopure oligonucleotide company. Its current identity is a multi-modality RNA platform company trying to translate chemistry and delivery capabilities across several large and rare disease categories. [[1]](https://ir.wavelifesciences.com/news-releases/news-release-details/wave-life-sciences-reports-fourth-quarter-and-full-year-2025)
