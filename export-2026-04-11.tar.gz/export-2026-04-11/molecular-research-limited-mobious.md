# Molecular Research Limited (Mobious)

## Overview

Molecular Research Limited (MRL), associated with Mobious Biosystems / Mobious Genomics, is a UK-based biotechnology effort founded by Daniel Densham to develop next-generation sequencing and molecular analysis platforms. The company builds on earlier ventures and intellectual property originating in the late 1990s ([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Origins & History

- **1997** – Daniel Densham founded Medical Biosystems and filed initial patents related to sequencing technologies  
- **1999** – Mobious Biosystems was founded with venture funding to develop these technologies  
- **University of Exeter** – Mobious Genomics established laboratory facilities and collaborations  
- **2011** – Molecular Research Limited (MRL) was founded to continue development of next-generation molecular platforms  

This progression reflects a long-term effort to commercialize novel sequencing technologies and molecular analysis systems ([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Approach

The core approach is based on **Molecular Resonance Sequencing**, a proprietary method combining biological systems with engineered nanostructures:

- Uses **immobilized polymerases within electromagnetic fields**  
- Enables **real-time monitoring of polymerase activity**  
- Produces sequencing data directly as DNA is synthesized  
- Designed to improve **signal-to-noise ratio** and detection sensitivity  

This approach differs from conventional sequencing by focusing on **real-time, long-read capabilities and enhanced biochemical signal detection** ([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Technology

MRL’s platform spans multiple generations of molecular technologies:

- Third, fourth, and fifth-generation sequencing systems  
- Labelled and label-free proteomics platforms  
- Single-molecule and multi-molecule analysis systems  

Key technical advantages described include:

- **Longer read lengths**, reducing computational assembly requirements  
- **Detection of modified bases** (e.g., DNA methylation)  
- Applicability to both labelled and label-free systems  
- Potential use in **precision medicine and genomics**  

These systems aim to unify **natural cellular replication mechanisms with artificial nanostructures**, forming a hybrid bio-nanotechnology platform ([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Market & Positioning

MRL operates in the **advanced genomics and molecular diagnostics technology space**, targeting:

- DNA sequencing and genomics  
- Proteomics and molecular analysis  
- Precision medicine applications  

Its positioning is as a **deep-tech, platform-based innovation** potentially competing with next-generation sequencing technologies, particularly in areas requiring long reads and epigenetic sensitivity ([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Investors

- Early venture funding supported Mobious Biosystems (1999)  
- No detailed or recent investor disclosures available  

([Source 1](https://web.archive.org/web/20210120152845/http://mobious.com/)).

### Funding

- Venture-backed at inception (Mobious Biosystems)  
- No publicly disclosed recent funding rounds for MRL  

### Status

- Unclear current operational status  
- No active modern web presence beyond archived site  
- Appears to be a long-running but low-visibility or inactive effort  

---

Overall, Molecular Research Limited (Mobious) represents a long-term attempt to develop novel sequencing technologies based on molecular resonance and real-time polymerase monitoring, with potential applications in genomics, proteomics, and precision medicine.
