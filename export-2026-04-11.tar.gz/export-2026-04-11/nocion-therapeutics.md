# Nocion Therapeutics

## Overview
Nocion Therapeutics is a private biopharmaceutical company developing a new class of therapies it calls "nocions" for cough, itch, pain, and inflammation.[[1]](https://www.nociontx.com/) The company says its lead indication is chronic cough driven by inflamed airway nociceptors.[[1]](https://www.nociontx.com/)

## Technology and Pipeline
Nocion's approach is to selectively affect activated nociceptors rather than broadly suppressing normal sensory signaling.[[1]](https://www.nociontx.com/) Its public materials and secondary financing coverage identify taplucainium, including a dry-powder inhaled formulation, as the lead program for chronic cough.[[1]](https://www.nociontx.com/)[[2]](https://www.oindpnews.com/2026/01/nocion-therapeutics-raises-23-million-for-continued-development-of-inhaled-dry-powder-taplucainium-for-chronic-cough/)

## Investors
Nocion's board composition publicly reflects investors from Monograph Capital, Canaan Partners, Morningside Technology Advisory, and Arkin Bio Capital.[[1]](https://www.nociontx.com/) Secondary financing coverage states that Nocion raised a $62 million Series B in 2024 and added $23 million in 2026 for continued development of taplucainium DPI, though I did not find the original company press release during this pass.[[2]](https://www.oindpnews.com/2026/01/nocion-therapeutics-raises-23-million-for-continued-development-of-inhaled-dry-powder-taplucainium-for-chronic-cough)

## Acquisitions and Corporate Activity
No acquisition involving Nocion Therapeutics was identified in the reviewed public sources. The clearest public record centers on its financing and ongoing chronic-cough program development.[[1]](https://www.nociontx.com/)[[2]](https://www.oindpnews.com/2026/01/nocion-therapeutics-raises-23-million-for-continued-development-of-inhaled-dry-powder-taplucainium-for-chronic-cough/)
