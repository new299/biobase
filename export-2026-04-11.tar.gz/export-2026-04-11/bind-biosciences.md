# BIND Biosciences — Research Notes

## Overview

BIND Biosciences (later renamed BIND Therapeutics) was a Cambridge, MA-based nanomedicine company founded in 2007 by Robert Langer (MIT) and Omid Farokhzad (Harvard Medical School). Developed ACCURINS® — proprietary targeted polymeric nanoparticles for drug delivery. Raised a ~$70M IPO in 2013 (NASDAQ: BIND). **Assets acquired by Pfizer in 2016 after company wound down.** [[1]](https://www.flagshippioneering.com/companies/bind-therapeutics) [[2]](https://www.cbinsights.com/company/bind-therapeutics)

---

## Technology

- **ACCURINS® (Medicinal Nanoengineering Platform)**: Engineered polymeric nanoparticles that combine targeting ligands, controlled release, and payload encapsulation to selectively deliver therapeutics to diseased tissues. Designed for precision delivery to tumor cells, minimizing off-target toxicity. [[3]](https://www.onclive.com/view/pharmaceutical-company-profile-bind-biosciences)
- **BIND-014**: Lead program — targeted nanoparticle containing docetaxel (active ingredient of Taxotere). Phase 1 clinical study initiated ~2012 in solid tumors. [[4]](https://www.fiercebiotech.com/biotech/bind-biosciences-initiates-phase-1-clinical-study-of-bind-014-a-first-class-targeted-nanoparticle-therapeutic-for-cancer)
- Focus areas: oncology, cardiovascular, inflammatory disease, RNAi. [[3]](https://www.onclive.com/view/pharmaceutical-company-profile-bind-biosciences)

---

## Funding & Corporate History

| Event | Date | Amount | Details |
|-------|------|--------|---------|
| Series A | ~2008 | Undisclosed | Flagship Pioneering (co-founder) |
| Series B | ~2010 | $12.4M | Various VCs |
| Series C | ~2012 | $11M | Flagship Pioneering led |
| IPO (NASDAQ: BIND) | 2013 | ~$70M | Public offering |
| Acquired by Pfizer | 2016 | Undisclosed | Asset acquisition |

[[1]](https://www.flagshippioneering.com/companies/bind-therapeutics) [[2]](https://www.cbinsights.com/company/bind-therapeutics)

---

## References

1. Flagship Pioneering — BIND Therapeutics: [https://www.flagshippioneering.com/companies/bind-therapeutics](https://www.flagshippioneering.com/companies/bind-therapeutics)
2. CBInsights — BIND Therapeutics: [https://www.cbinsights.com/company/bind-therapeutics](https://www.cbinsights.com/company/bind-therapeutics)
3. OncLive — BIND Biosciences company profile: [https://www.onclive.com/view/pharmaceutical-company-profile-bind-biosciences](https://www.onclive.com/view/pharmaceutical-company-profile-bind-biosciences)
4. Fierce Biotech — BIND-014 Phase 1 study: [https://www.fiercebiotech.com/biotech/bind-biosciences-initiates-phase-1-clinical-study-of-bind-014-a-first-class-targeted-nanoparticle-therapeutic-for-cancer](https://www.fiercebiotech.com/biotech/bind-biosciences-initiates-phase-1-clinical-study-of-bind-014-a-first-class-targeted-nanoparticle-therapeutic-for-cancer)
