# Helix Biotech

## Overview
The clearest public identity for this folder is Helix Biotech, a Tennessee-based CDMO and product company focused on RNA manufacturing and nanoparticle formulation.[[1]](https://www.helixbiotech.com/)[[2]](https://www.helixbiotech.com/our-story)

## Technology
Helix says it develops and manufactures nucleic acids, lipid nanoparticles, liposomes, polymer nanoparticles, and related delivery systems. Its public materials emphasize RNA construct optimization, formulation systems such as NOVA IJM, and GMP manufacturing services.[[1]](https://www.helixbiotech.com/)[[2]](https://www.helixbiotech.com/our-story)[[3]](https://www.helixbiotech.com/gmp-manufacturing)

## Investors
I did not identify a public financing announcement in the reviewed source set. The company presents itself as an operating CDMO and tools business rather than a venture-disclosure-focused therapeutics startup.[[2]](https://www.helixbiotech.com/our-story)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. This note uses the Helix Biotech CDMO identity because that was the clearest biotech company match on the open web.[[1]](https://www.helixbiotech.com/)
