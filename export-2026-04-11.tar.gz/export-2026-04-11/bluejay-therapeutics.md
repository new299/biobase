# Bluejay Therapeutics

## Overview
Bluejay Therapeutics was a private biotechnology company focused on viral and liver diseases, especially chronic hepatitis delta virus.[[1]](https://www.lw.com/en/news/2025/12/latham-advises-bluejay-therapeutics-acquisition-mirum-pharmaceuticals) Its lead asset was brelovitug, a fully human monoclonal antibody for chronic HDV.[[2]](https://www.cooley.com/news/coverage/2025/2025-12-08-mirum-pharmaceuticals-enters-into-definitive-agreement-to-acquire-bluejay-therapeutics)

## Technology and Pipeline
Bluejay’s pipeline centered on antibody therapeutics for rare liver and viral diseases rather than a broad technology platform.[[2]](https://www.cooley.com/news/coverage/2025/2025-12-08-mirum-pharmaceuticals-enters-into-definitive-agreement-to-acquire-bluejay-therapeutics) The acquisition coverage describes brelovitug as a late-stage program with Breakthrough Therapy and PRIME designations for chronic HDV.[[2]](https://www.cooley.com/news/coverage/2025/2025-12-08-mirum-pharmaceuticals-enters-into-definitive-agreement-to-acquire-bluejay-therapeutics)

## Investors
The local note references RA Capital. The reviewed acquisition coverage did not enumerate the full investor syndicate, so the financing history remains intentionally narrow in this note.

## Acquisitions and Corporate Activity
In December 2025, Mirum Pharmaceuticals entered into a definitive agreement to acquire Bluejay for $250 million in cash and $370 million in Mirum common stock, plus potential tiered sales-based milestones of up to $200 million in cash.[[1]](https://www.lw.com/en/news/2025/12/latham-advises-bluejay-therapeutics-acquisition-mirum-pharmaceuticals)[[2]](https://www.cooley.com/news/coverage/2025/2025-12-08-mirum-pharmaceuticals-enters-into-definitive-agreement-to-acquire-bluejay-therapeutics)
