# Moonwalk Biosciences

## Overview

Moonwalk Biosciences is a genomic medicine company developing precision epigenetic medicines.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/) The company says it aims to reprogram gene expression by modifying the epigenome rather than editing DNA sequence directly.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/)

## Technology

Moonwalk's platform combines epigenome profiling, AI-driven target prediction, and epigenetic engineering tools to create precision epigenetic medicines.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/) The company describes its work as using the epigenome as a programmable layer for therapeutic intervention.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/)

## Investors

Moonwalk launched in September 2023 with $57 million in seed and Series A financing led by Alpha Wave Ventures, with participation from ARCH Venture Partners, Future Ventures, GV, Khosla Ventures, and YK Bioventures.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/)

## Acquisitions and Strategic Transactions

No acquisition involving Moonwalk Biosciences was identified in the reviewed sources. The public record reviewed is centered on launch financing and platform development rather than M&A.[[1]](https://moonwalk.bio/news/moonwalk-biosciences-launches-with-57-million-in-financing-to-advance-a-new-class-of-precision-epigenetic-medicines/)
