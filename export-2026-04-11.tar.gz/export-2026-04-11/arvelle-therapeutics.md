# Arvelle Therapeutics

## Overview
Arvelle Therapeutics was a CNS-focused biopharmaceutical company created to commercialize cenobamate in Europe.[[1]](https://www.angelinipharma.com/media/press-releases/2019/angelini-group-and-arvelle-therapeutics-announce-exclusive-license-agreement-for-cenobamate-for-the-treatment-of-partial-onset-seizures-in-europe-excluding-latam/) It was launched in 2019 to build a European specialty pharma business around epilepsy therapeutics.[[2]](https://www.businesswire.com/news/home/20190416005707/en/Arvelle-Therapeutics-Launches-With-%24180-Million-in-Series-A-and-a-License-Agreement-With-SK-Biopharmaceuticals-for-Cenobamate-in-Europe)

## Technology and Products
Arvelle’s business model was centered on licensing, developing, and commercializing CNS therapies rather than discovery platform innovation.[[2]](https://www.businesswire.com/news/home/20190416005707/en/Arvelle-Therapeutics-Launches-With-%24180-Million-in-Series-A-and-a-License-Agreement-With-SK-Biopharmaceuticals-for-Cenobamate-in-Europe) Its key product was cenobamate for partial-onset seizures in Europe.[[2]](https://www.businesswire.com/news/home/20190416005707/en/Arvelle-Therapeutics-Launches-With-%24180-Million-in-Series-A-and-a-License-Agreement-With-SK-Biopharmaceuticals-for-Cenobamate-in-Europe)

## Investors
Arvelle launched with $180 million in Series A financing led by LSP, with participation from F-Prime Capital, Andera Partners, Kurma Partners, Hadean Ventures, and Omega Funds.[[2]](https://www.businesswire.com/news/home/20190416005707/en/Arvelle-Therapeutics-Launches-With-%24180-Million-in-Series-A-and-a-License-Agreement-With-SK-Biopharmaceuticals-for-Cenobamate-in-Europe)

## Acquisitions and Corporate Activity
Angelini Pharma announced in April 2021 that it would acquire Arvelle, and later that month announced completion of the acquisition, integrating Arvelle into its broader CNS strategy.[[3]](https://www.angelinipharma.com/media/press-releases/2021/angelini-pharma-announces-the-completion-of-the-acquisition-of-arvelle-therapeutics/) The acquisition was intended to strengthen Angelini’s European epilepsy franchise.[[3]](https://www.angelinipharma.com/media/press-releases/2021/angelini-pharma-announces-the-completion-of-the-acquisition-of-arvelle-therapeutics/)
