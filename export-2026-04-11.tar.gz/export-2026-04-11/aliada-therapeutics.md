# Aliada Therapeutics

## Overview
Aliada Therapeutics is a biotechnology company developing blood-brain barrier delivery technologies and CNS therapies.[[1]](https://www.aliadatx.com/)[[2]](https://www.aliadatx.com/aliada-therapeutics-announces-300-million-series-c-financing/) Its strategy centers on a BBB shuttle platform designed to improve brain delivery of biologics and oligonucleotides.[[1]](https://www.aliadatx.com/)

## Technology
Aliada says its proprietary blood-brain barrier crossing platform enables efficient delivery of diverse therapeutic cargoes into the central nervous system.[[1]](https://www.aliadatx.com/) The company also highlights an anti-pyroglutamate-amyloid-beta antibody, ALIA-1758, as a lead Alzheimer’s disease program.[[2]](https://www.aliadatx.com/aliada-therapeutics-announces-300-million-series-c-financing/)

## Investors
In February 2025, Aliada announced a $300 million Series C financing led by General Catalyst, Deep Track Capital, Foresite Capital, and OrbiMed, with participation from RA Capital Management, Wellington Management, Delos Capital, and existing investors including NEA, Cormorant, venBio, Samsara BioCapital, and DCVC Bio.[[2]](https://www.aliadatx.com/aliada-therapeutics-announces-300-million-series-c-financing/)

## Acquisitions and Corporate Activity
No acquisition involving Aliada Therapeutics was identified in the reviewed public sources. The public record centers on financing and advancement of its BBB-delivery-enabled CNS pipeline.[[1]](https://www.aliadatx.com/)[[2]](https://www.aliadatx.com/aliada-therapeutics-announces-300-million-series-c-financing/)
