# Protagonist Therapeutics

**Protagonist Therapeutics, Inc.** is a **clinical‑stage biopharmaceutical company** developing **peptide‑based drug therapies** for inflammatory, immunological, hematological, metabolic, and other diseases with high unmet medical need. The company has been **backed by institutional investors including RA Capital Management** both through private venture financings and as a publicly traded equity investor. [[turn0search1]](https://www.fiercebiotech.com/biotech/protagonist-therapeutics-raises-40-million-series-c-financing-to-advance-oral-peptide-drugs) [[turn0search5]](https://www.insidermonkey.com/blog/protagonist-therapeutics-inc-ptgx-ra-capital-management-acquires-6-8-stake-470612/)

## Basic Information
- **Founded:** ~2006 (early years, biotech platform build‑out). [[turn0search2]](https://www.linkedin.com/company/protagonist-therapeutics)  
- **Headquarters:** Newark, California, USA (with operations in Brisbane, Australia). [[turn0search2]](https://www.linkedin.com/company/protagonist-therapeutics)  
- **Public Listing:** **NASDAQ: PTGX** (listed in August 2016). [[turn0search5]](https://www.insidermonkey.com/blog/protagonist-therapeutics-inc-ptgx-ra-capital-management-acquires-6-8-stake-470612/)  
- **Industry:** Biotechnology / peptide therapeutics.  
- **Stage:** Clinical through late‑stage development of multiple peptide candidates. [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)  

## RA Capital Investment
Protagonist Therapeutics has **RA Capital Management** involvement:
- RA Capital participated in a **$40 M Series C financing** in **2015** alongside Canaan Partners, Adage Capital Management, and Foresite Capital to advance oral peptide drug candidates including PTG‑100 into the clinic. **RA Capital was explicitly listed as an investor in that round.** [[turn0search1]](https://www.fiercebiotech.com/biotech/protagonist-therapeutics-raises-40-million-series-c-financing-to-advance-oral-peptide-drugs)  
- RA Capital later appeared as an **institutional shareholder (~6.8 % stake)** per SEC filing after the company’s IPO and early public trading. [[turn0search5]](https://www.insidermonkey.com/blog/protagonist-therapeutics-inc-ptgx-ra-capital-management-acquires-6-8-stake-470612/)

## Technology & Therapeutic Focus
Protagonist’s proprietary platform centers on discovering and developing **engineered peptides** with **oral stability** and targeted biological activity, combining the specificity of biologics with small‑molecule pharmacology for accessible and potent therapeutics. [[turn0search2]](https://www.linkedin.com/company/protagonist-therapeutics)

Key therapeutic areas include:
- **Inflammation & Immunology:** Icotrokinra (formerly JNJ‑2113), an **oral IL‑23 receptor antagonist** developed with and licensed to **Janssen Biotech (Johnson & Johnson)**; NDA submitted. [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)  
- **Hematology:** **Rusfertide (PN‑300)**, a **hepcidin mimetic** in Phase 3 for **polycythemia vera** and other blood disorders (with Takeda collaboration). [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)  
- **Metabolic & Other Programs:** Additional oral peptide candidates (e.g., IL‑17 antagonist, multi‑agonists for obesity) are advancing toward clinical phases. [[turn0search6]](https://www.sec.gov/Archives/edgar/data/0001377121/000110465926019696/ptgx-20251231x10k.htm)

## Pipeline & Clinical Development
- **Icotrokinra (IL‑23R blocker):** First‑in‑class oral peptide blocking IL‑23 receptor implicated in psoriasis and other immune‑mediated diseases; NDA under review in 2025 with potential launch 2026. [[turn0search6]](https://www.sec.gov/Archives/edgar/data/0001377121/000110465926019696/ptgx-20251231x10k.htm)  
- **Rusfertide:** Hepcidin mimetic in Phase 3 for polycythemia vera (rare blood cancer). [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)  
- **Emerging Programs:** Oral integrin antagonists and other peptide modalities addressing GI autoimmune diseases, metabolic disorders, and more. [[turn0search2]](https://www.linkedin.com/company/protagonist-therapeutics)

## Market & Strategy
Protagonist sits in the broader **therapeutics peptide space**, aiming to replace or complement protein biologics and small molecules with **orally deliverable peptide therapeutics** that can:  
- Address **immune‑mediated diseases** more conveniently than injectable biologics.  
- Provide novel mechanisms for **blood disorders** and **metabolic diseases**.  
- Leverage **collaborations/licensing (e.g., J&J, Takeda)** to accelerate development and commercialization.

## Status & Outlook
- Protagonist is **active and publicly traded**, with a strong pipeline moving toward **late‑stage clinical and regulatory milestones**. [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)  
- The company has reported **NDA submissions for lead programs** and is positioning its oral peptide platform for broader therapeutic impact across immunology, hematology, and metabolic indications. [[turn0search6]](https://www.sec.gov/Archives/edgar/data/0001377121/000110465926019696/ptgx-20251231x10k.htm)  
- RA Capital’s historical and ongoing investment underscores institutional confidence in the **peptide therapeutic platform** and program potential.

## Headquarters
- **Newark, California, USA** (primary). [[turn0search2]](https://www.linkedin.com/company/protagonist-therapeutics)

## Summary
Protagonist Therapeutics is a public biotech innovating **oral peptide therapeutics** for inflammation, blood disorders, and metabolic diseases. It has attracted investment from **RA Capital Management** in both private financing rounds and public market share positions. Its lead candidates, including **icotrokinra** and **rusfertide**, are advancing through regulatory and late‑stage clinical pathways with strong strategic partnerships and potential market impact. [[turn0search1]](https://www.fiercebiotech.com/biotech/protagonist-therapeutics-raises-40-million-series-c-financing-to-advance-oral-peptide-drugs) [[turn0search4]](https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update)

## References
1. Protagonist Therapeutics Series C financing with RA Capital investor. https://www.fiercebiotech.com/biotech/protagonist-therapeutics-raises-40-million-series-c-financing-to-advance-oral-peptide-drugs turn0search1  
2. Protagonist Therapeutics LinkedIn — company profile. https://www.linkedin.com/company/protagonist-therapeutics turn0search2  
3. RA Capital stake in Protagonist after IPO (13G filing). https://www.insidermonkey.com/blog/protagonist-therapeutics-inc-ptgx-ra-capital-management-acquires-6-8-stake-470612/ turn0search5  
4. Protagonist Therapeutics 2025 corporate and pipeline update. https://www.biospace.com/press-releases/protagonist-reports-third-quarter-2025-financial-results-and-provides-corporate-update turn0search4  
5. Protagonist Therapeutics 2025 10‑K overview of pipeline and strategic development. https://www.sec.gov/Archives/edgar/data/0001377121/000110465926019696/ptgx-20251231x10k.htm turn0search6
