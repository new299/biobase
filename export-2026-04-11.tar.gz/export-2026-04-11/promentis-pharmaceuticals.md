# Promentis Pharmaceuticals

**Promentis Pharmaceuticals, Inc.** is a **privately‑held biopharmaceutical company** focused on developing **novel therapies for neuropsychiatric and related central nervous system (CNS) disorders**. It is backed by institutional investors including **F‑Prime Capital** as part of its venture financings. [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/) [[4]](https://www.gaebler.com/Funded-Company-8E7D3159-72E3-4CC7-96A7-224F42FEA572-Promentis-Pharmaceuticals)

## Overview

- **Founded:** 2006–2007 (early operations and licensing activity). [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/) [[4]](https://www.gaebler.com/Funded-Company-8E7D3159-72E3-4CC7-96A7-224F42FEA572-Promentis-Pharmaceuticals)  
- **Headquarters:** **Milwaukee, Wisconsin, USA**. [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)  
- **Industry:** Biopharmaceuticals / CNS therapeutics. [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)  
- **Stage:** Clinical drug development prior to latest updates. [[3]](https://promentispharma.com/about/)  
- **Employees:** Small biotech (~10–50). [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)

## Mission & Focus

Promentis is dedicated to discovering **first‑in‑class small‑molecule therapies** for **neuropsychiatric disorders** by targeting **glutamatergic neurotransmission imbalances and oxidative stress**, which are implicated in conditions with unmet therapeutic needs. [[3]](https://promentispharma.com/about/)

## Lead Programs & Science

### SXC‑2023 — Novel CNS Therapeutic Candidate

- **Mechanism:** A novel small molecule designed to modulate **System x<sub>c</sub>−**, an amino acid antiporter involved in **glutamate homeostasis** and oxidative balance in the brain. Dysregulation in these pathways is believed to contribute to multiple neuropsychiatric conditions. [[3]](https://promentispharma.com/about/)  
- **Indications Studied:** Clinical development has included Phase 1 and Phase 2 studies targeting conditions such as **trichotillomania**, obsessive‑compulsive and related disorders, substance use disorders, and other CNS impairments. [[7]](https://promentispharma.com/2017/promentis-pharmaceuticals-commences-phase-1-study-for-sxc-2023-targeting-neuropsychiatric-disorders)  
- **Clinical Progress:** SXC‑2023 advanced into Phase 1 studies; later work aimed at Phase 2 proof‑of‑concept before pipeline status shifted. [[7]](https://promentispharma.com/2017/promentis-pharmaceuticals-commences-phase-1-study-for-sxc-2023-targeting-neuropsychiatric-disorders)

## Technology & Therapeutic Approach

Promentis’s therapeutic strategy centers on **modulating glutamate signaling and oxidative stress pathways** in the central nervous system — mechanisms that differ from conventional monoamine or dopaminergic targets used in many psychiatric medications. This putative mechanism could address **underlying neurochemical imbalances** shared across multiple psychiatric and behavioral conditions. [[3]](https://promentispharma.com/about/)

## Investors & Financing (including F‑Prime)

Promentis has completed multiple rounds of venture financing with participation from key life science investors. Notably:

- **Series C (~$26 million, 2017):** Co‑led by **OrbiMed Advisors**, **F‑Prime Capital Partners**, and **Aisling Capital** — with F‑Prime’s partner Tom Beck joining the Promentis board as an investor representative. [[2]](https://promentispharma.com/2017/promentis-pharmaceuticals-inc-announces-26m-series-c-financing-and-elects-four-new-board-members-2) [[4]](https://www.gaebler.com/Funded-Company-8E7D3159-72E3-4CC7-96A7-224F42FEA572-Promentis-Pharmaceuticals)  
- Earlier rounds included seed and venture equity investors such as **Black Pearl GmbH**, **Golden Angels Investors**, and other private backers alongside F‑Prime participation. [[4]](https://www.gaebler.com/Funded-Company-8E7D3159-72E3-4CC7-96A7-224F42FEA572-Promentis-Pharmaceuticals)

F‑Prime Capital’s inclusion in the investor syndicate confirms its involvement in supporting Promentis’s development strategy. [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)

## Leadership & Team

Promentis’s leadership includes executives with industry and scientific experience:

- **Klaus Veitinger, M.D., Ph.D.** – Chairman and former CEO; experience in global pharma leadership. [[11]](https://promentispharma.com/about/board-of-directors/)  
- **Daniel Lawton** – CEO and President with broad pharmaceutical executive experience. [[11]](https://promentispharma.com/about/board-of-directors/)  
- **Tom Beck, M.D.** – Chief Medical Officer and board representative from F‑Prime. [[2]](https://promentispharma.com/2017/promentis-pharmaceuticals-inc-announces-26m-series-c-financing-and-elects-four-new-board-members-2)

## Status & Activity

- Historically, Promentis advanced **SXC‑2023** into early clinical testing and into Phase 2 exploratory studies for psychiatric/behavioral disorders. [[7]](https://promentispharma.com/2017/promentis-pharmaceuticals-commences-phase-1-study-for-sxc-2023-targeting-neuropsychiatric-disorders)  
- Current publicly available updates are limited; the company remains a **small private biotech** and its most recent clinical activities appear to have slowed or shifted focus since the late 2010s.  
- No new FDA approvals have been reported publicly; development status may be quiet or preclinical as of the last accessible updates.

## Headquarters

**Milwaukee, Wisconsin, USA** — based in the Midwest with ties to university research and startup life science ecosystems. [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)

## Summary

Promentis Pharmaceuticals is a privately held CNS‑focused biotech company developing **novel small‑molecule therapies** targeting glutamatergic imbalance and oxidative stress in neuropsychiatric disorders. Its lead candidate, **SXC‑2023**, entered early clinical trials, and the company raised significant venture capital including from **F‑Prime Capital** as part of its Series C financing. F‑Prime’s involvement is documented via board representation and investment syndication. [[2]](https://promentispharma.com/2017/promentis-pharmaceuticals-inc-announces-26m-series-c-financing-and-elects-four-new-board-members-2) [[1]](https://fprimecapital.com/company/promentis-pharmaceuticals/)

## References

1. F‑Prime Capital profile — Promentis Pharmaceuticals investment. https://fprimecapital.com/company/promentis-pharmaceuticals/ turn0search0  
2. Promentis Series C financing ($26M) with F‑Prime and partners. https://promentispharma.com/2017/promentis-pharmaceuticals-inc-announces-26m-series-c-financing-and-elects-four-new-board-members-2 turn0search2  
3. Company mission & therapeutic focus (lead compound & indications). https://promentispharma.com/about/ turn0search3  
4. Funding & investor profiles. https://www.gaebler.com/Funded-Company-8E7D3159-72E3-4CC7-96A7-224F42FEA572-Promentis-Pharmaceuticals turn0search4  
5. Phase 1 clinical program commencement (SXC‑2023). https://promentispharma.com/2017/promentis-pharmaceuticals-commences-phase-1-study-for-sxc-2023-targeting-neuropsychiatric-disorders turn0search7
