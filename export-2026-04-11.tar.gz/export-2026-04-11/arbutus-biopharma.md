# Arbutus Biopharma — Research Notes

## Overview

Arbutus Biopharma Corporation (NASDAQ: ABUS) is a clinical-stage biopharmaceutical company focused on developing a functional cure for chronic hepatitis B virus (cHBV) infection. Headquartered in Warminster, PA. Former name: Tekmira Pharmaceuticals (changed to Arbutus in 2015 after merger with OnCore Biopharma). Cash position: $123M (year-end 2024). [[1]](https://investor.arbutusbio.com/news-releases/news-release-details/arbutus-reports-fourth-quarter-and-year-end-2024-financial-results)

---

## Technology

- **Imdusiran (AB-729)**: Lead therapeutic — RNAi agent using GalNAc-conjugated delivery targeting hepatocytes to reduce all HBV viral proteins/antigens including HBsAg. Subcutaneous administration. Phase 2b planned for H1 2025. Phase 2a (IM-PROVE I) data showed **50% functional cure rate** (3/6 HBeAg-negative patients with low baseline HBsAg) when combined with pegylated interferon + nucleoside analogue (NA). [[1]](https://investor.arbutusbio.com/news-releases/news-release-details/arbutus-reports-fourth-quarter-and-year-end-2024-financial-results)
- **AB-101**: Oral PD-L1 inhibitor for controlled immune checkpoint modulation in HBV treatment, with improved safety over antibody-based checkpoint therapies. [[2]](https://arbutusbio.gcs-web.com/news-releases/news-release-details/arbutus-announces-2024-corporate-objectives-and-provides)
- **LNP IP Portfolio**: Arbutus holds foundational lipid nanoparticle delivery technology patents — licensed to Moderna, Pfizer/BioNTech (COVID-19 vaccines) and others; subject to ongoing IP disputes and royalty litigation.

---

## Funding & Investors

Public company (NASDAQ: ABUS). Cash: $123M at year-end 2024. Financed primarily through ATM equity program, LNP royalties/licensing, and dilutive equity raises. [[1]](https://investor.arbutusbio.com/news-releases/news-release-details/arbutus-reports-fourth-quarter-and-year-end-2024-financial-results)

---

## Key Patents

- Foundational LNP (lipid nanoparticle) delivery patents for nucleic acid therapeutics. Licensed to Moderna and Pfizer/BioNTech for COVID-19 mRNA vaccines. Ongoing royalty disputes with Moderna over these patents. [[3]](https://www.crunchbase.com/organization/arbutus-biopharma)

---

## References

1. Arbutus — Q4/Full-Year 2024 results: [https://investor.arbutusbio.com/news-releases/news-release-details/arbutus-reports-fourth-quarter-and-year-end-2024-financial-results](https://investor.arbutusbio.com/news-releases/news-release-details/arbutus-reports-fourth-quarter-and-year-end-2024-financial-results)
2. Arbutus — 2024 objectives: [https://arbutusbio.gcs-web.com/news-releases/news-release-details/arbutus-announces-2024-corporate-objectives-and-provides](https://arbutusbio.gcs-web.com/news-releases/news-release-details/arbutus-announces-2024-corporate-objectives-and-provides)
3. Crunchbase — Arbutus Biopharma: [https://www.crunchbase.com/organization/arbutus-biopharma](https://www.crunchbase.com/organization/arbutus-biopharma)
