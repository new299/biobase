# Tenaya Therapeutics

## Overview

Tenaya Therapeutics is a clinical-stage biotechnology company focused on potentially curative therapies for heart disease. The company says it works across gene therapy, cellular regeneration, and precision medicine to address underlying causes of cardiovascular disease. [[1]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-closes-92-million-series-b-financing/) [[2]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-reports-fourth-quarter-and-full-year-2025/)

## Technology

Tenaya has built a multi-platform cardiovascular strategy. Public company materials highlight gene therapy candidates such as TN-201 and TN-401, along with earlier cellular regeneration and precision medicine efforts. The company also announced a multi-target research collaboration with Alnylam in 2025, reinforcing its interest in broader cardiovascular modalities. [[2]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-reports-fourth-quarter-and-full-year-2025/) [[3]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-secures-106-million-series-c-funding/)

## Investors

Tenaya closed a $92 million Series B in 2019 led by Casdin Capital, with participation from GV, The Column Group, and others. In 2020, it secured $106 million in Series C funding led by RTW Investments, with new investors including RA Capital, Fidelity, and funds advised by T. Rowe Price, alongside existing investors such as The Column Group, Casdin, and GV. [[1]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-closes-92-million-series-b-financing/) [[3]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-secures-106-million-series-c-funding/)

## Financing And Strategic Development

Tenaya has continued to use both capital markets and non-dilutive funding. In December 2025 it priced a $60 million public offering, and in February 2025 it received an $8 million CIRM clinical grant to support its TN-401 study. [[4]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-announces-pricing-public-offering-1/) [[5]](https://investors.tenayatherapeutics.com/news-releases/news-release-details/tenaya-therapeutics-receives-8-million-clinical-grant-california/)
