# IRIS Medicine

Iris Medicine is an early-stage biotechnology company developing a novel class of RNA therapeutics based on its proprietary **small binding RNA (sbRNA™)** platform. The company focuses on selectively modulating gene expression at the mRNA level, particularly for diseases driven by repeat expansions ([Source 1](https://irismedicine.com)).

### Approach

Iris Medicine’s approach centers on **targeting mRNA—the cell’s molecular messenger—using synthetic RNA constructs that mimic natural biology**:

- Developed a new modality called **sbRNA™ (small binding RNA)**  
- Uses short (~20 nucleotide) RNA sequences  
- Mimics natural small RNA mechanisms rather than traditional RNAi  

Key features:

- **All-RNA (no protein expression required)** → reduced immunogenicity  
- **Non-viral delivery** → redosable and adjustable dosing  
- **Allele-selective targeting** → distinguishes mutant vs. healthy gene copies  
- **Pipeline-in-a-product** → one construct can address multiple diseases with shared repeat sequences  

([Source 1](https://irismedicine.com)).

### Technology

The sbRNA™ platform is designed to improve upon traditional RNAi approaches:

- Traditional RNAi → single siRNA cuts target mRNA  
- Natural biology → multiple small RNAs bind cooperatively  
- Iris approach → **multiple identical sbRNAs bind cooperatively to target mRNA**  

Mechanism:

- **Healthy (WT) transcripts**  
  - Limited binding → minimal inhibition → normal gene function preserved  

- **Mutant transcripts (expanded repeats)**  
  - Cooperative multi-binding → strong inhibition → selective suppression of disease-causing genes  

This enables **highly selective targeting of pathogenic RNA while preserving normal gene expression** ([Source 1](https://irismedicine.com)).

### Therapeutic Focus

Iris Medicine targets **repeat expansion disorders**, a class of genetic diseases with few treatment options:

- Huntington’s disease  
- C9orf72-related ALS  
- Spinocerebellar ataxias  

These diseases are driven by **expanded nucleotide repeat sequences**, which sbRNA™ directly targets at the RNA level ([Source 1](https://irismedicine.com)).

### Market & Positioning

Iris operates in the **RNA therapeutics and genetic medicine market**, positioning itself as:

- A developer of a **new RNA modality beyond traditional RNAi**  
- Focused on **allele-selective precision therapies**  
- Targeting historically difficult-to-treat neurodegenerative diseases  

Its approach is particularly differentiated by **broad applicability across multiple repeat expansion diseases** ([Source 1](https://irismedicine.com)).

### Investors

- Venrock  
- Altitude Life Science Ventures  
- UCB Ventures  
- Pandect Catalyst  

([Source 1](https://irismedicine.com)).

### Funding

- Venture-backed (exact funding amounts not disclosed)  

([Source 1](https://irismedicine.com)).

### Status

- Active  
- Early-stage biotech company  
- Privately held  
- Not acquired  

---

Overall, Iris Medicine is pioneering a new RNA therapeutic modality (sbRNA™) that enables highly selective targeting of disease-causing RNA, with a strong focus on repeat expansion disorders such as Huntington’s disease and ALS.
