# CB Therapeutics — Research Notes

## Overview

CB Therapeutics is a Carlsbad, CA-based synthetic biology company founded in 2015. Uses yeast-based precision fermentation to produce cannabinoids, tryptamines (psychedelic medicine precursors), and high-value molecules as alternatives to plant extraction or chemical synthesis. Total raised: ~$11.6M. [[1]](https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A) [[2]](https://www.cbthera.com/)

---

## Technology

- **Cellular Agriculture / Precision Fermentation Platform**: Engineered yeast strains biosynthesize cannabinoids (including rare cannabinoids), psilocybin and tryptamine analogs for psychedelic medicine research, and animal-free food ingredients. Proprietary bioinformatics and enzyme design enable efficient biosynthetic pathways. [[1]](https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A) [[2]](https://www.cbthera.com/)
- **Manufacturing Scale-Up**: Building a precision fermentation bio-manufacturing facility adjacent to its labs to achieve commercial-scale production. [[2]](https://www.cbthera.com/)
- Holds patents covering cellular agriculture inventions for cannabinoid production and precursors to various compounds. [[1]](https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Pre-Series A | ~2015–2020 | ~$2.5M | CONNECT San Diego, Beyond The Polaris, Metaplanet Holdings, Mystic Ventures |
| Series A | May 2021 | ~$9.1M | re.Mind Capital (Christian Angermayer / Apeiron family office, sole investor) |

Total raised: ~$11.6M. [[1]](https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A) [[3]](https://psychedelicalpha.com/news/cb-therapeutics-closes-on-oversubscribed-series-a)

---

## References

1. BusinessWire — CB Therapeutics closes oversubscribed Series A (May 2021): [https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A](https://www.businesswire.com/news/home/20210510005112/en/CB-Therapeutics-Closes-on-Oversubscribed-Series-A)
2. CB Therapeutics — Company website: [https://www.cbthera.com/](https://www.cbthera.com/)
3. Psychedelic Alpha — CB Therapeutics Series A: [https://psychedelicalpha.com/news/cb-therapeutics-closes-on-oversubscribed-series-a](https://psychedelicalpha.com/news/cb-therapeutics-closes-on-oversubscribed-series-a)
