# Recursion Pharmaceuticals

## Overview
Recursion is a public TechBio company that describes itself as decoding biology to industrialize drug discovery using large-scale experimental data and machine learning [[1]](https://ir.recursion.com/news-releases/news-release-details/recursion-secures-239-million-equity-financing-advance).

## Technology
The company says it operates an ultra-high-throughput wet-lab and machine-learning platform built around high-dimensional, multimodal cellular biology datasets [[1]](https://ir.recursion.com/news-releases/news-release-details/recursion-secures-239-million-equity-financing-advance). It has also highlighted foundation-model work in drug discovery through its NVIDIA collaboration [[2]](https://ir.recursion.com/news-releases/news-release-details/recursion-announces-collaboration-and-50-million-investment/).

## Investors
Recursion's 2020 Series D raised $239 million led by Leaps by Bayer, with participation from investors including Casdin Capital, Catalio Capital Management, Laurion Capital Management, Samsara BioCapital, Baillie Gifford, Mubadala, DCVC, Lux Capital, Obvious Ventures, Felicis Ventures, EPIC Ventures, Two Sigma Ventures, and others [[1]](https://ir.recursion.com/news-releases/news-release-details/recursion-secures-239-million-equity-financing-advance). In 2023, NVIDIA also made a $50 million PIPE investment in the company [[2]](https://ir.recursion.com/news-releases/news-release-details/recursion-announces-collaboration-and-50-million-investment/).

## Acquisitions / Strategic Transactions
Recursion acquired Vium in 2020 to add digital-vivarium and preclinical biomarker capabilities to its platform [[3]](https://ir.recursion.com/news-releases/news-release-details/recursion-acquires-vium-bolstering-its-efforts-industrialize).

## References
[[1]](https://ir.recursion.com/news-releases/news-release-details/recursion-secures-239-million-equity-financing-advance)
[[2]](https://ir.recursion.com/news-releases/news-release-details/recursion-announces-collaboration-and-50-million-investment/)
[[3]](https://ir.recursion.com/news-releases/news-release-details/recursion-acquires-vium-bolstering-its-efforts-industrialize)
