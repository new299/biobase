# Caliper Technologies (Caliper Life Sciences) — Research Notes

## Overview

Caliper Technologies was a Hopkinton, MA-based life sciences company founded in 1995. Developed microfluidic lab-on-chip technologies for drug discovery, genomics, proteomics, and molecular imaging. Renamed to Caliper Life Sciences. **Acquired by PerkinElmer for ~$600M in November 2011.** [[1]](https://en.wikipedia.org/wiki/Caliper_Life_Sciences) [[2]](https://www.businesswire.com/news/home/20110908005742/en/PerkinElmer-to-Acquire-Caliper-Life-Sciences-for-Approximately-600-Million)

---

## Technology

- **Microfluidics / Lab-on-Chip**: Pioneered commercial microfluidic platforms for DNA, RNA, and protein analysis. LabChip® systems automated size-based electrophoresis for nucleic acid and protein fragment analysis. [[1]](https://en.wikipedia.org/wiki/Caliper_Life_Sciences)
- **In Vivo Imaging**: IVIS® Lumina and Spectrum imaging systems for bioluminescence and fluorescence in small animal models. [[1]](https://en.wikipedia.org/wiki/Caliper_Life_Sciences)
- **Drug Discovery**: High-content screening platforms and microfluidic assay development services for pharma. [[1]](https://en.wikipedia.org/wiki/Caliper_Life_Sciences)

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded as Caliper Technologies | 1995 | Hopkinton, MA |
| IPO | 1999 | NASDAQ: CALP |
| Acquired Xenogen (IVIS imaging) | 2006 | |
| Renamed Caliper Life Sciences | ~2007 | |
| Acquired by PerkinElmer | Nov 2011 | ~$600M ($10.50/share) |

[[2]](https://www.businesswire.com/news/home/20110908005742/en/PerkinElmer-to-Acquire-Caliper-Life-Sciences-for-Approximately-600-Million)

---

## References

1. Wikipedia — Caliper Life Sciences: [https://en.wikipedia.org/wiki/Caliper_Life_Sciences](https://en.wikipedia.org/wiki/Caliper_Life_Sciences)
2. BusinessWire — PerkinElmer acquires Caliper for $600M: [https://www.businesswire.com/news/home/20110908005742/en/PerkinElmer-to-Acquire-Caliper-Life-Sciences-for-Approximately-600-Million](https://www.businesswire.com/news/home/20110908005742/en/PerkinElmer-to-Acquire-Caliper-Life-Sciences-for-Approximately-600-Million)
