# Immuneel Therapeutics — Research Notes

## Overview

Immuneel Therapeutics is a Bengaluru, India-based biotechnology company founded in 2018 by Kiran Mazumdar Shaw (Biocon founder), Dr. Siddhartha Mukherjee (oncologist and author), and Kush Parmar (5AM Ventures), focused on developing and commercializing CAR-T cell therapies for cancer patients in India. Immuneel has exclusive rights to ARI-0001/IMN-003A (a CD19 CAR-T cell therapy) from Hospital Clínic de Barcelona and Institut d'Investigacions Biomèdiques August Pi i Sunyer (IDIBAPS) in Spain, which it is developing and manufacturing locally for the Indian market. Total raised: $39.3M+. Key investors include F-Prime Capital, Khosla Ventures, and Eight Roads Ventures. [[1]](https://immuneel.com/) [[2]](https://www.crunchbase.com/organization/immuneel-therapeutics)

---

## Technology & Products

- **IMN-003A (ARI-0001, CD19 CAR-T)**: CD19-targeting CAR-T cell therapy licensed from Hospital Clínic de Barcelona / IDIBAPS for development, manufacturing, and commercialization in India; first industry-sponsored CAR-T trial in India; Phase 2 trial actively enrolling at Narayana Hrudayalaya, Bengaluru. [[1]](https://immuneel.com/)
- **Local Manufacturing**: Immuneel manufactures CAR-T cells locally in India — critical for reducing costs and improving patient access to cell therapy in the Indian healthcare system. [[1]](https://immuneel.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | 2019 | $11M | Khosla Ventures |
| Seed extension | 2020 | $1.4M | — |
| Series A | 2022 | $15M | F-Prime Capital, Khosla Ventures, Eight Roads Ventures |
| Series A extension | Apr 2024 | ~$15M | Eight Roads Ventures (co-lead), True North Fund VI (co-lead), F-Prime Capital |
| Total | — | $39.3M+ | — |

[[2]](https://www.crunchbase.com/organization/immuneel-therapeutics)

---

## References

1. Immuneel Therapeutics — Homepage: [https://immuneel.com/](https://immuneel.com/)
2. Crunchbase — Immuneel Therapeutics: [https://www.crunchbase.com/organization/immuneel-therapeutics](https://www.crunchbase.com/organization/immuneel-therapeutics)
