# SomaLogic

## Overview
SomaLogic is a proteomics company built around the SomaScan platform and large-scale protein biomarker analysis [[1]](https://investors.standardbio.com/news-releases/news-release-details/somalogic-closes-business-combination-and-will-begin-trading).

## Technology
The company's core technology is SomaScan, an aptamer-based proteomics platform that measures thousands of proteins from a single sample with high throughput and reproducibility [[1]](https://investors.standardbio.com/news-releases/news-release-details/somalogic-closes-business-combination-and-will-begin-trading).

## Investors
SomaLogic went public through a business combination with CM Life Sciences II in 2021, a transaction that delivered approximately $630 million in gross cash proceeds [[1]](https://investors.standardbio.com/news-releases/news-release-details/somalogic-closes-business-combination-and-will-begin-trading).

## Acquisitions / Strategic Transactions
Standard BioTools and SomaLogic agreed to an all-stock merger in 2023 and completed it in January 2024 [[2]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-and-somalogic-combine-all-stock-merger) [[3]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-completes-merger-somalogic-creating). Standard BioTools then sold the SomaLogic business to Illumina in January 2026 for $350 million upfront plus potential earnouts and royalties [[4]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-completes-sale-somalogic-illumina).

## References
[[1]](https://investors.standardbio.com/news-releases/news-release-details/somalogic-closes-business-combination-and-will-begin-trading)
[[2]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-and-somalogic-combine-all-stock-merger)
[[3]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-completes-merger-somalogic-creating)
[[4]](https://investors.standardbio.com/news-releases/news-release-details/standard-biotools-completes-sale-somalogic-illumina)

## ASeq Posts

- [Somalogic](https://aseq.substack.com/p/somalogic)
