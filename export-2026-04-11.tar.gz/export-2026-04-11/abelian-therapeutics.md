# Abelian Therapeutics — Research Notes

## Overview

Abelian Therapeutics was a neuroscience biotech founded in 2017, headquartered in Boston, MA. Focused on the role of glial cells in brain disease. **Acquired by Neumora Therapeutics in 2020**; now part of Neumora's neuroscience pipeline. [[1]](https://fprimecapital.com/company/abelian-therapeutics/) [[2]](https://cen.acs.org/pharmaceuticals/neuroscience/Neumora-launches-500-million-develop/99/i37)

---

## Technology

- **Glia biology**: Studied the role of glial cells (astrocytes, microglia, oligodendrocytes) in neurological and psychiatric disease pathogenesis. [[1]](https://fprimecapital.com/company/abelian-therapeutics/)
- Drug discovery focused on glial-derived drug targets for brain diseases.

---

## Funding & Investors

- **Seed round**: Funded by F-Prime Capital (Fidelity's life sciences venture arm). [[1]](https://fprimecapital.com/company/abelian-therapeutics/)
- **2020**: Acquired by Neumora Therapeutics; Neumora subsequently raised $500M to advance neuroscience programs including assets from Abelian. [[2]](https://cen.acs.org/pharmaceuticals/neuroscience/Neumora-launches-500-million-develop/99/i37)

---

## References

1. F-Prime Capital — Portfolio page: [https://fprimecapital.com/company/abelian-therapeutics/](https://fprimecapital.com/company/abelian-therapeutics/)
2. Chemical & Engineering News — Neumora launch: [https://cen.acs.org/pharmaceuticals/neuroscience/Neumora-launches-500-million-develop/99/i37](https://cen.acs.org/pharmaceuticals/neuroscience/Neumora-launches-500-million-develop/99/i37)
