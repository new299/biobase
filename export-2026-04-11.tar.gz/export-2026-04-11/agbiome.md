# AgBiome — Research Notes

## Overview

AgBiome is a agricultural biologicals company founded in 2012 in Research Triangle Park, NC. Uses its **Genesis** microbial discovery platform to develop biological fungicides, insecticides, and herbicides from crop microbiome diversity. Total raised: $233M. [[1]](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html)

---

## Technology

- **Genesis Platform**: Screens trillions of microbes, millions of gene sequences, and thousands of strains to identify agricultural actives. Discovered 3,500+ new insect control genes and 200+ active lead strains. [[1]](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html)
- **Products**: *Howler® Fungicide* — first commercial product; active against 300+ crop-disease combinations. Pipeline includes biological insecticides and herbicides; 11 products planned by 2025. [[1]](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html)
- **Market**: Biological crop protection projected to grow 14-fold by 2030. [[1]](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2013 | $14.5M | Polaris Partners |
| Series C | ~2018 | — | ARCH Venture Partners, Syngenta Ventures, Leaps by Bayer, Novozymes, Fidelity |
| Series D | Sep 2021 | $116M | Blue Horizon (co-lead), Novalis LifeSciences (co-lead), ARCH Venture Partners, UTIMCO, Pontifax AgTech, Innotech Advisors + existing |

Total raised: $233M. [[1]](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html) [[2]](https://www.ncbiotech.org/news/rtps-agbiome-lands-116m-scale-its-microbial-platform)

---

## References

1. PR Newswire — Series D: `https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html` | [https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html](https://www.prnewswire.com/news-releases/agbiome-raises-116-million-led-by-blue-horizon-and-novalis-lifesciences-301375552.html)
2. NC Biotech Center — Series D coverage: [https://www.ncbiotech.org/news/rtps-agbiome-lands-116m-scale-its-microbial-platform](https://www.ncbiotech.org/news/rtps-agbiome-lands-116m-scale-its-microbial-platform)
