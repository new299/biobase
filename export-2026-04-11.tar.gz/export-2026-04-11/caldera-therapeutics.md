# Caldera Therapeutics

## Overview
Caldera Therapeutics is a clinical-stage biotechnology company developing bispecific antibodies for inflammatory bowel disease and other immunologic diseases.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease) Its lead program is CLD-423, a bispecific antibody targeting IL-23p19 and TL1A.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease)

## Technology and Pipeline
Caldera’s scientific focus is a first-in-class bispecific biologic for IBD rather than a broad discovery platform.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease) The public launch materials position CLD-423 as an attempt to combine two clinically validated inflammatory pathways in one molecule.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease)

## Investors
Caldera launched in January 2026 with $112.5 million total capital raised, including an initial $75 million Series A from founding investors Atlas Venture, LAV, and venBio, followed by a $37.5 million Series A-1 led by Omega Funds with participation from Wellington Management and Janus Henderson Investors.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease)

## Acquisitions and Corporate Activity
No acquisition involving Caldera Therapeutics was identified in the reviewed public sources. The public record centers on its January 2026 launch and early Phase 1 development.[[1]](https://www.biospace.com/press-releases/caldera-therapeutics-launches-with-112-5-million-and-announces-first-subjects-dosed-in-phase-1-trial-of-first-in-class-bispecific-antibody-cld-423-for-inflammatory-bowel-disease)
