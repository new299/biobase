# AION Labs

## Overview
AION Labs is a venture studio and innovation lab focused on building AI-enabled companies for drug discovery and pharmaceutical R&D.[[1]](https://aionlabs.com/)[[2]](https://aionlabs.com/about/) It is not a single-product therapeutics company, but rather a company-building platform for pharma innovation.

## Model and Technology Focus
AION says it connects pharma R&D with AI, computational science, and emerging technology to create new ventures aligned with real-world drug-discovery challenges.[[1]](https://aionlabs.com/)[[2]](https://aionlabs.com/about/) Its model is based on co-development with large pharma partners and venture support rather than in-house pipeline ownership.[[2]](https://aionlabs.com/about/)

## Investors and Partners
AION states that it was founded by AstraZeneca, Merck, Pfizer, and Teva together with AWS and leading venture capital partners, including the Israel Biotech Fund and Amiti Ventures.[[1]](https://aionlabs.com/)[[3]](https://bmedx.com/newsroom/press-releases/aion-labs-biotech-innovation-lab-launched-by-top-pharma-tech-and-investment-leaders/)

## Acquisitions and Corporate Activity
No acquisition involving AION Labs was identified in the reviewed public sources. The accessible public record centers on venture creation, partner ecosystem building, and launch of spinout companies.[[1]](https://aionlabs.com/)[[2]](https://aionlabs.com/about/)
