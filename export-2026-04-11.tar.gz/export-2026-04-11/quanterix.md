# Quanterix

## Overview

Quanterix is a public diagnostics and life-science tools company focused on digitizing biomarker analysis to support precision health and earlier disease detection [[1]](https://ir.quanterix.com/). The company says its technologies are used across neurology, oncology, cardiology, inflammation, and infectious-disease research [[1]](https://ir.quanterix.com/).

## Technology

Quanterix's core platform is Simoa, an ultra-sensitive biomarker detection technology for measuring proteins in blood and other fluids at concentrations below traditional assay limits [[2]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-releases-financial-results-fourth-quarter-and-full). Following the Akoya transaction, Quanterix added multiplexed tissue imaging with single-cell resolution to connect blood- and tissue-based biomarker analysis [[2]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-releases-financial-results-fourth-quarter-and-full) [[3]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-completes-acquisition-akoya-biosciences-creating-first).

## Investors

Company-profile sources describe Quanterix as having been backed by investors including T. Rowe Price, Alzheimer's Drug Discovery Foundation, ARCH Venture Partners, Bain Capital Ventures, Cormorant Asset Management, Trinitas Capital, and bioMerieux before and around its IPO period [[4]](https://www.crunchbase.com/organization/quanterix/financial_details) [[5]](https://www.cbinsights.com/company/quanterix/financials).

## Acquisitions / Strategic Transactions

In July 2025, Quanterix completed its acquisition of Akoya Biosciences, combining ultra-sensitive blood biomarker detection with tissue-based spatial biology capabilities [[3]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-completes-acquisition-akoya-biosciences-creating-first). Company-profile sources also list earlier acquisitions including UmanDiagnostics and Emission iNC [[4]](https://www.crunchbase.com/organization/quanterix/financial_details).

## References

[[1]](https://ir.quanterix.com/)
[[2]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-releases-financial-results-fourth-quarter-and-full)
[[3]](https://ir.quanterix.com/news-releases/news-release-details/quanterix-completes-acquisition-akoya-biosciences-creating-first)
[[4]](https://www.crunchbase.com/organization/quanterix/financial_details)
[[5]](https://www.cbinsights.com/company/quanterix/financials)

## ASeq Posts

- [Further Thoughts On Quanterix](https://aseq.substack.com/p/further-thoughts-on-quanterix)
- [Quanterix](https://aseq.substack.com/p/quanterix)
