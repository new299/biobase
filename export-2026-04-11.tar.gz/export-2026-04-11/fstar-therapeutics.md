# F-star Therapeutics — Research Notes

## Overview

F-star Therapeutics was a Cambridge, UK-based biopharmaceutical company (originally founded in Vienna, Austria in 2006) developing next-generation bispecific antibodies using its proprietary Modular Antibody Technology (fcαb™ — Fc-antigen binding fragments). The company was listed on NASDAQ (FSTX) before being acquired by invoX Pharma (a subsidiary of Sino Biopharmaceutical) for $161 million, with the deal completed in March 2023 following regulatory review. F-star had established major partnerships with Merck KGaA (up to €1B), Janssen, Takeda (~$1B in biobucks), and Denali Therapeutics. [[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next) [[2]](https://www.sinobiopharm.com/news-center/dynamic/24313.html)

---

## Technology & Pipeline

- **Modular Antibody Technology (fcαb™)**: Proprietary platform introducing additional antigen-binding sites into the constant (Fc) region of standard antibodies — enabling rapid generation of bispecific antibodies without disrupting normal antibody architecture. Creates a "two-in-one" antibody with independent binding domains for two different targets. [[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next)
- **FS118 (PD-L1 × LAG-3 bispecific)**: Lead clinical asset; Phase 2 trials in head and neck cancer (acquired resistance to checkpoint inhibitors) and NSCLC/DLBCL. [[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next)
- **FS222 (CD137 × PD-L1 bispecific)**: Dual immune checkpoint agonist/antagonist; Phase 1 trial. [[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next)
- **FS120 (OX40 × CD137 bispecific)**: Dual T cell costimulatory agonist; Phase 1 trial. [[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next)
- **Partnerships**: Merck KGaA (up to €1B for 5 bispecific anticancer antibodies); Janssen (multiple next-gen bispecifics license); Takeda (~$1B biobucks); Denali Therapeutics (CNS bispecific collaboration). [[3]](https://www.genengnews.com/topics/drug-discovery/f-star-merck-agree-up-to-e1b-deal-to-develop-five-bispecific-anticancer-antibodies)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2006 | Vienna, Austria (later Cambridge, UK) |
| VC investors | 2006–2021 | Aescap Venture, Atlas Venture, Novo Ventures, TVM Capital, Merck Serono Ventures, SR One, MP Healthcare |
| IPO (NASDAQ: FSTX) | 2020 | ~$107M |
| Acquired by invoX Pharma | Jun 2022–Mar 2023 | $161M |

[[1]](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next) [[2]](https://www.sinobiopharm.com/news-center/dynamic/24313.html)

---

## References

1. F-star Therapeutics — invoX Pharma acquisition announcement: [https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next](https://investors.f-star.com/news-releases/news-release-details/invox-pharma-acquire-f-star-therapeutics-inc-pioneering-next)
2. Sino Biopharmaceutical — invoX completes F-star acquisition: [https://www.sinobiopharm.com/news-center/dynamic/24313.html](https://www.sinobiopharm.com/news-center/dynamic/24313.html)
3. GEN — F-star, Merck KGaA up to €1B bispecific deal: [https://www.genengnews.com/topics/drug-discovery/f-star-merck-agree-up-to-e1b-deal-to-develop-five-bispecific-anticancer-antibodies/](https://www.genengnews.com/topics/drug-discovery/f-star-merck-agree-up-to-e1b-deal-to-develop-five-bispecific-anticancer-antibodies/)
