# Reborna Biosciences

## Overview
Reborna Biosciences is a Japan-based drug discovery company established in 2018 that develops small-molecule drugs targeting RNA for rare genetic diseases [[1]](https://rebornabiosciences.com/en/company) [[2]](https://rebornabiosciences.com/en/about).

## Technology
The company focuses on orally administered small-molecule drugs targeting RNA, positioning this as a lower-burden therapeutic approach for long-term treatment in rare disease [[2]](https://rebornabiosciences.com/en/about).

## Investors
Reborna's corporate history lists multiple financing events including a seed round in 2018, Class B financing in 2019, Class C financing in 2021, and Class D financing in 2023 [[1]](https://rebornabiosciences.com/en/company).

## Acquisitions / Strategic Transactions
The company's history also highlights a 2021 research collaboration, option, and license agreement with Biogen MA, Inc. as a notable strategic transaction [[1]](https://rebornabiosciences.com/en/company).

## References
[[1]](https://rebornabiosciences.com/en/company)
[[2]](https://rebornabiosciences.com/en/about)
