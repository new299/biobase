# Proof Diagnostics

**Proof Diagnostics, Inc.** was a **CRISPR‑based rapid diagnostics company** focused on developing **portable, point‑of‑care (POC) molecular tests** using **CRISPR‑enabled nucleic acid detection** for infectious disease — most notably COVID‑19. The company was **acquired by Ginkgo Bioworks in 2024** and its technology and assets were integrated into Ginkgo’s broader offerings. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/) [[turn0search3]](https://www.contractpharma.com/breaking-news/ginkgo-bioworks-acquires-proof-diagnostics/)

## Overview
- **Founded:** May 2020, by pioneers in CRISPR diagnostics including **Feng Zhang, Omar Abudayyeh, Jonathan Gootenberg**, and **Sid Shenai (CEO)**. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/)  
- **Headquarters:** Cambridge, Massachusetts, USA. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/)  
- **Industry:** Molecular diagnostics, point‑of‑care testing platforms.  
- **Acquired by:** **Ginkgo Bioworks** (completed February 28, 2024). [[turn0search3]](https://www.contractpharma.com/breaking-news/ginkgo-bioworks-acquires-proof-diagnostics/)

## Technology & Products
Proof Diagnostics developed a diagnostic system built around **CRISPR‑based nucleic acid detection**, with a platform targeting rapid, sensitive, and low‑cost testing outside centralized laboratories:  
- **Proof Lab Test System:** A **portable, CRISPR‑based molecular diagnostic device** designed to deliver **lab‑quality results in ~18 minutes** using CRISPR detection chemistry derived from the **STOPCovid** approach licensed from the Broad Institute. [[turn0search2]](https://www.prnewswire.com/news-releases/proof-diagnostics-submits-request-for-emergency-use-authorization-seeking-first-approval-of-crispr-based-molecular-point-of-care-covid-19-test-301520209.html)  
- The company submitted a **U.S. FDA Emergency Use Authorization (EUA) application** for its COVID‑19 test in 2022, aiming to enable rapid, point‑of‑care detection with high sensitivity and specificity. [[turn0search6]](https://www.medicaldevice-network.com/news/proof-diagnostics-eua-covid-19-molecular-diagnostic-test/)

Proof’s diagnostic platform leveraged **CRISPR‑Cas technologies** — programmable nucleic acid recognition — to provide rapid, scalable testing without the need for complex laboratory infrastructure. Such CRISPR‑based diagnostics have been explored broadly as alternatives to traditional PCR tests that require thermocyclers and trained technicians. [[turn0search7]](https://www.nature.com/articles/s41551-021-00760-7)

## Founders & Leadership
The company was co‑founded by several **leaders in CRISPR and diagnostics research**:  
- **Feng Zhang, PhD** – CRISPR pioneer and co‑founder of multiple genome engineering and diagnostics ventures. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/)  
- **Omar Abudayyeh, PhD** and **Jonathan Gootenberg, PhD** – researchers with foundational contributions to CRISPR diagnostics platforms such as SHERLOCK and STOPCovid. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/)  
- **Sid Shenai – CEO** – led the company into development of its rapid test systems and regulatory submissions. [[turn0search2]](https://www.prnewswire.com/news-releases/proof-diagnostics-submits-request-for-emergency-use-authorization-seeking-first-approval-of-crispr-based-molecular-point-of-care-covid-19-test-301520209.html)

## Funding & Investors
Before its acquisition, Proof Diagnostics had raised significant venture capital — approximately **$45 million total** — from investors including **ARCH Venture Partners, F‑Prime Capital, and Madrona Venture Group**. [[turn0search6]](https://www.medicaldevice-network.com/news/proof-diagnostics-eua-covid-19-molecular-diagnostic-test/)

## Acquisition & Current Status
- In **February 2024**, **Ginkgo Bioworks completed the acquisition of Proof Diagnostics** and its intellectual property, integrating its CRISPR diagnostic technologies and enzyme libraries (including novel programmable enzymes beyond Cas9/Cas12) to bolster Ginkgo’s gene editing and molecular services. [[turn0search3]](https://www.contractpharma.com/breaking-news/ginkgo-bioworks-acquires-proof-diagnostics/)  
- Post‑acquisition, Proof’s standalone operations ceased, and its technology now contributes to Ginkgo’s broader biological infrastructure offerings.

## Market & Applications
Proof’s technology targeted **rapid infectious disease diagnostics** with potential applications across pandemics and beyond, leveraging CRISPR’s specificity and programmability to detect viral nucleic acids at point of care — a category that aims to reduce reliance on centralized lab PCR testing and increase accessibility of molecular diagnostics. [[turn0search7]](https://www.nature.com/articles/s41551-021-00760-7)

## Summary
**Proof Diagnostics** was a CRISPR‑based diagnostic startup focused on rapid, point‑of‑care nucleic acid tests leveraging CRISPR Cas technologies. Founded by CRISPR leaders, it developed the **Proof Lab Test System** and pursued FDA EUA for its COVID‑19 test. The company raised venture capital including from **F‑Prime Capital** and was acquired by **Ginkgo Bioworks in 2024**, with its technology now integrated into Ginkgo’s diagnostics and gene engineering ecosystem. [[turn0search0]](https://crisprmedicinenews.com/company/card/proof-diagnostics/) [[turn0search3]](https://www.contractpharma.com/breaking-news/ginkgo-bioworks-acquires-proof-diagnostics/)

## References

1. Proof Diagnostics profile on CRISPR Medicine News. https://crisprmedicinenews.com/company/card/proof-diagnostics/ turn0search0  
2. Proof Diagnostics submits EUA for CRISPR‑based molecular test. https://www.prnewswire.com/news-releases/proof-diagnostics-submits-request-for-emergency-use-authorization-seeking-first-approval-of-crispr-based-molecular-point-of-care-covid-19-test-301520209.html turn0search2  
3. Ginkgo Bioworks acquires Proof Diagnostics. https://www.contractpharma.com/breaking-news/ginkgo-bioworks-acquires-proof-diagnostics/ turn0search3  
4. MedTech Network coverage of Proof Diagnostics EUA submission. https://www.medicaldevice-network.com/news/proof-diagnostics-eua-covid-19-molecular-diagnostic-test/ turn0search6
