# Proxima — Company Overview

## Basic Information
**Name:** Proxima (formerly VantAI)  
**Founded:** ~2019 (est.) according to business profiles :contentReference[oaicite:0]{index=0}  
**Headquarters:** New York, NY, USA; also reported presence in Palo Alto & San Francisco, CA :contentReference[oaicite:1]{index=1}  
**Industry:** Biotechnology / AI‑driven drug discovery :contentReference[oaicite:2]{index=2}  
**Website:** https://proximabio.com/ :contentReference[oaicite:3]{index=3}  
**Stage:** Private, seed‑funded :contentReference[oaicite:4]{index=4}  

## Mission & Focus
Proxima aims to **unlock programmable control of protein‑protein interactions (PPIs)** to discover and design novel therapeutics that can *induce, modulate, or block* these interactions across disease areas like oncology, immunology, and potentially beyond. This strategy goes beyond traditional single‑target inhibition by focusing on *proximity‑based modalities* such as molecular glues and related small molecules. :contentReference[oaicite:5]{index=5}

## Technology & Platform
Proxima’s approach combines three major elements:

### Structural Proteomics Data Generation
The company builds a **proteome‑scale atlas of protein interactions** using cross‑linking mass spectrometry (XLMS) data, capturing how proteins assemble into complexes in real biological contexts. This structural information expands far beyond traditional static structure prediction. :contentReference[oaicite:6]{index=6}

### Frontier AI & Generative Models
Proxima develops *foundation AI models* such as the **Neo series**, particularly **Neo‑1**, which can **simultaneously predict protein co‑folding and design small molecules** that influence those interactions. This represents an effort to make protein interaction modulation systematic and scalable rather than serendipitous. :contentReference[oaicite:7]{index=7}

### Proximity‑Modulating Molecules
The company focuses on designing *molecular glues*, *PROTAC‑like agents*, and next‑generation proximity modulators — small molecules that alter how proteins interact to create therapeutic effects, potentially accessing previously “undruggable” targets. :contentReference[oaicite:8]{index=8}

## Products / Pipeline
Proxima is primarily a **drug discovery technology platform** and **therapy design engine** rather than a product manufacturer. It does not have marketed drugs yet. Its output is:

- AI models and structural datasets for PPI design
- Discovery projects for proximity‑based therapeutics
- Collaborative/co‑development programs with external partners :contentReference[oaicite:9]{index=9}

Proxima reports that several *co‑developed drug programs* are advancing toward clinical stages with partners, with expectations that the first could begin clinical trials as early as 2026. :contentReference[oaicite:10]{index=10}

## Market & Strategy
Protein‑protein interactions govern *nearly all biological processes*, but fewer than ~5% of human PPIs are structurally understood, leaving most of the proteome unexplored from a therapeutic standpoint. Proxima’s strategy is to map this space and design molecules that *reprogram* how proteins interact, opening new disease targets and mechanisms. :contentReference[oaicite:11]{index=11}

Applications include:
- *Oncology* (cancer treatments using molecular glues or proximity modulators)
- *Immunology / autoimmune disorders*
- Other complex diseases linked to dysregulated protein networks :contentReference[oaicite:12]{index=12}

## Funding & Investors
Proxima has raised a **$80 million seed round led by DCVC** (Data Collective), making it one of the largest early TechBio investments to date. Additional investors include NVIDIA’s venture arm, Braidwell, Roivant, AIX Ventures, Yosemite, Magnetic Ventures, Alexandria Venture Investments, and others. :contentReference[oaicite:13]{index=13}

## Leadership & Advisors
- **Zachary Carpenter — Co‑Founder & CEO** :contentReference[oaicite:14]{index=14}  
- **Luca Naef — Co‑Founder & CTO** :contentReference[oaicite:15]{index=15}  
- A scientific advisory board includes senior figures like Dr. Raymond Deshaies, Dr. Lyn Jones, and Dr. Juri Rappsilber. :contentReference[oaicite:16]{index=16}

## Status / Active?
Proxima is active and scaling its platform, with substantial seed funding and multiple research collaborations with major pharmaceutical groups including Johnson & Johnson, Bristol‑Myers Squibb, and Blueprint Medicines (now part of Sanofi). :contentReference[oaicite:17]{index=17} Future milestones include advancing internal and partnered drug discovery programs toward clinical testing.

## Where It’s Based
- **New York, NY** (primary business address) :contentReference[oaicite:18]{index=18}  
- Also reported presence in **Palo Alto and San Francisco, CA** research/office locations. :contentReference[oaicite:19]{index=19}

## Key Concepts
- **Proximity Modulation / Molecular Glues:** small molecules that promote or inhibit protein interactions to alter cellular behavior. :contentReference[oaicite:20]{index=20}  
- **PROTACs & Modulators:** classes of proximity‑based therapeutics that degrade or rewire protein function via induced proximity. :contentReference[oaicite:21]{index=21}

## Relevant Publications / Science Context
While Proxima’s work is proprietary, it builds on broader research into PPI modulation and molecular glue discovery, an emerging therapeutic field where computational and AI tools are increasingly crucial. :contentReference[oaicite:22]{index=22}

## Sources
- Proxima company site: https://proximabio.com/ :contentReference[oaicite:23]{index=23}  
- DCVC investment overview (Proxima): https://www.dcvc.com/companies/proxima :contentReference[oaicite:24]{index=24}  
- $80M seed financing announcement: https://www.dcvc.com/news-insights/proxima-raises-80m‑to‑reprogram‑protein‑protein‑interactions/ :contentReference[oaicite:25]{index=25}  
- Business profile & products: https://www.cbinsights.com/company/vantai :contentReference[oaicite:26]{index=26}  
- BioSpace press release: https://www.biospace.com/press-releases/proxima‑raises‑80‑million‑led‑by‑dcvc‑to‑power‑the‑next‑generation‑of‑proximity‑based‑medicines/ :contentReference[oaicite:27]{index=27}  
- Funding/market trend summary: https://longevity.technology/news/proxima‑lands‑80m‑to‑make‑protein‑interactions‑programmable/ :contentReference[oaicite:28]{index=28}
