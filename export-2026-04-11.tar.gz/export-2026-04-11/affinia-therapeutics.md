# Affinia Therapeutics

## Overview
Affinia Therapeutics is a biotechnology company focused on next-generation gene therapies enabled by rationally engineered adeno-associated virus vectors.[[1]](https://affiniatx.com/about/) The company says it is building transformative in vivo gene therapies with tissue-targeted delivery.[[1]](https://affiniatx.com/about/)

## Technology
Affinia’s core technology is a rational capsid-engineering platform for AAV vectors designed to improve tissue specificity and gene delivery performance.[[1]](https://affiniatx.com/about/) Public materials describe this as a route to differentiated gene therapies across multiple organs and disease areas.[[1]](https://affiniatx.com/about/)

## Investors
Affinia announced in January 2025 that it raised an oversubscribed $110 million Series C led by new investor Wellington Management, with participation from existing investors including Atlas Venture, F-Prime Capital, and Newpath Partners.[[2]](https://www.businesswire.com/news/home/20250107090018/en/Affinia-Therapeutics-Closes-Oversubscribed-110-Million-Series-C-Financing) The local Atlas reference is consistent with that disclosed investor base.

## Acquisitions and Corporate Activity
I did not identify an acquisition involving Affinia in the reviewed public sources. The public record centers on financing and continued gene-therapy platform development.[[1]](https://affiniatx.com/about/)[[2]](https://www.businesswire.com/news/home/20250107090018/en/Affinia-Therapeutics-Closes-Oversubscribed-110-Million-Series-C-Financing)
