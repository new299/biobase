# Legend Biotech

## Overview

Legend Biotech is a global biotechnology company developing, manufacturing, and commercializing cell therapies, especially CAR-T therapies for oncology.[[1]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-reports-fourth-quarter-and-full-year-2025-results) Its lead commercial product is CARVYKTI (ciltacabtagene autoleucel) for multiple myeloma.[[1]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-reports-fourth-quarter-and-full-year-2025-results)

## Technology

Legend's technology base centers on cell therapy platforms including autologous and allogeneic CAR-T, TCR-T, and NK-cell approaches.[[2]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-corporation-announces-closing-initial-public) The company's most visible program is the BCMA-targeted CAR-T therapy cilta-cel/CARVYKTI, which it developed with Janssen.[[3]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-announces-closing-global-strategic-lcar-b38m-car)

## Investors

Legend is a Nasdaq-listed public company (`LEGN`).[[2]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-corporation-announces-closing-initial-public) By the end of 2025 it reported approximately $949 million in cash, cash equivalents, and time deposits.[[1]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-reports-fourth-quarter-and-full-year-2025-results)

## Acquisitions and Strategic Transactions

In December 2017, Legend announced the closing of a global strategic collaboration with Janssen for BCMA CAR-T therapy.[[3]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-announces-closing-global-strategic-lcar-b38m-car) Under the agreement, Legend received a $350 million upfront payment and became eligible for milestone payments, with profit sharing outside Greater China under the collaboration framework.[[4]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-achieves-milestone-under-collaboration-agreement/) [[5]](https://investors.legendbiotech.com/news-releases/news-release-details/legend-biotech-achieves-milestone-payments-bcma-car-t)
