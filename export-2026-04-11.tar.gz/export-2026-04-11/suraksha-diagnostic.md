# Suraksha Diagnostic

## Overview

Suraksha Diagnostic is an Indian diagnostic-services company that provides pathology testing, radiology testing, and medical consultation services through a large network concentrated in eastern and northeastern India. The company says the Suraksha brand was established in 1992 and positions itself as an integrated diagnostics chain. [[1]](https://www.surakshanet.com/company-overview.php) [[2]](https://www.surakshanet.com/about-us)

## Technology And Service Platform

Suraksha's operating model combines pathology, radiology, and specialist consultation services under one roof, supported by equipment from major diagnostics and imaging suppliers such as Siemens Healthineers, Roche Diagnostics India, Beckman Coulter, bioMerieux, and GE/Wipro GE. Its disclosed menu includes molecular biology, cytogenetics, histopathology, cardiology, gastroenterology, and neurology testing. [[1]](https://www.surakshanet.com/company-overview.php) [[2]](https://www.surakshanet.com/about-us)

## Investors

Accessible public-market materials identify OrbiMed as a major investor. In July 2024, Moneycontrol reported that OrbiMed-backed Suraksha filed IPO papers with SEBI, and in November 2024 it reported that investor OrbiMed Asia II Mauritius planned to sell 1.06 crore shares in the IPO offer for sale. [[3]](https://www.moneycontrol.com/news/business/ipo/global-investment-firm-orbimed-backed-suraksha-diagnostic-files-ipo-papers-with-sebi-12777387.html) [[4]](https://www.moneycontrol.com/news/business/ipo/orbimed-backed-suraksha-diagnostic-files-rhp-ipo-to-hit-dalal-street-on-november-29-12875631.html)

## IPO And Strategic Development

Suraksha's 2024 IPO was structured entirely as an offer for sale rather than a fresh issuance, meaning proceeds went to existing shareholders rather than the company. That transaction marked the major recent strategic financing event visible in public sources. [[4]](https://www.moneycontrol.com/news/business/ipo/orbimed-backed-suraksha-diagnostic-files-rhp-ipo-to-hit-dalal-street-on-november-29-12875631.html)
