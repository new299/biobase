# Argo Biopharma — Research Notes

## Overview

Argo Biopharma (Shanghai Argo Biopharma Co., Ltd.) is a clinical-stage RNAi therapeutics company founded in 2021, headquartered in Shanghai, China. Develops next-generation siRNA therapeutics using its proprietary RADS™ platform for cardiovascular, rare, hepatic, autoimmune, and neurological diseases. Total raised: $104M. Major Novartis partnership announced 2025. [[1]](https://www.argobiopharma.com/about/index.html)

---

## Technology

- **RADS™ Platform (RNA molecules with superior Activity, Durability, and Safety)**: Proprietary siRNA design and chemical modification platform optimizing potency, tissue distribution, half-life, and safety. Six siRNA drug candidates in clinical development across China, USA, and Australia. [[1]](https://www.argobiopharma.com/about/index.html)
- Key programs include cardiovascular disease siRNA candidates (licensed to Novartis), hepatitis B, rare diseases, autoimmune diseases, and CNS indications.
- **Novartis deal (Sep 2025)**: Multi-asset license for cardiovascular candidates — $160M upfront + up to $5.2B milestones. [[2]](https://www.argobiopharma.com/news/153.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Angel | ~2021 | ~$5M | APRICOT Capital |
| Series A | ~2022 | $63M | Loyal Valley Capital (lead), CPE, TAO Capital, Trinity Innovation Fund, GSR United Capital |
| Series A+ | ~2023 | $40M+ | CS Capital (lead), Huagai Capital, OneHealth Haihe Capital, Trinity Innovation Fund |

Total raised: $104M equity + $160M Novartis upfront. [[3]](https://www.argobiopharma.com/news/94.html)

---

## References

1. Argo Biopharma — About: [https://www.argobiopharma.com/about/index.html](https://www.argobiopharma.com/about/index.html)
2. Argo Biopharma — Novartis licensing deal: [https://www.argobiopharma.com/news/153.html](https://www.argobiopharma.com/news/153.html)
3. Argo Biopharma — Series A+ close: [https://www.argobiopharma.com/news/94.html](https://www.argobiopharma.com/news/94.html)
