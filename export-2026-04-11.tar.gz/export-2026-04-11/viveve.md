# Viveve

## Overview

Viveve Medical was a women's health medical device company built around the Viveve System for vaginal laxity and related quality-of-life indications. The public SEC record shows the company came into being through a 2014 reverse merger with PLC Systems. [[1]](https://www.sec.gov/Archives/edgar/data/879682/000143774916029627/vive20160414_s1.htm) [[2]](https://www.sec.gov/Archives/edgar/data/879682/000143774914021265/R6.htm)

## Technology

The company's public filings described the Viveve System as a device intended to improve women's sexual well-being and quality of life by addressing vaginal laxity. This was a medtech and women's health device story, not a therapeutics platform. [[1]](https://www.sec.gov/Archives/edgar/data/879682/000143774916029627/vive20160414_s1.htm) [[2]](https://www.sec.gov/Archives/edgar/data/879682/000143774914021265/R6.htm)

## Financing And Corporate Structure

The SEC filings show that, concurrent with the 2014 reverse merger, Viveve completed a private placement for gross proceeds of about $6 million and also put in place a $5 million term loan. Those filings also make clear that Viveve, Inc. was treated as the accounting acquirer in the merger. [[1]](https://www.sec.gov/Archives/edgar/data/879682/000143774916029627/vive20160414_s1.htm) [[2]](https://www.sec.gov/Archives/edgar/data/879682/000143774914021265/R6.htm)

## Historical Context

This note is intentionally historical because the accessible public record I reviewed is dominated by SEC filings from the company's earlier public life rather than a current operating-company site or active investor materials. [[1]](https://www.sec.gov/Archives/edgar/data/879682/000143774916029627/vive20160414_s1.htm) [[2]](https://www.sec.gov/Archives/edgar/data/879682/000143774914021265/R6.htm)
