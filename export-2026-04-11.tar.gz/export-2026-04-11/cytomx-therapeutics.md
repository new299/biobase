# CytomX Therapeutics — Research Notes

## Overview

CytomX Therapeutics, Inc. (NASDAQ: CTMX) is a South San Francisco, CA-based clinical-stage oncology biopharmaceutical company. Pioneers conditionally activated, tumor-localized biologics using its proprietary PROBODY® therapeutic platform. Pipeline spans ADCs, T-cell engagers, and immune modulators. Lead program: varseta-M (CX-2051), a Probody ADC targeting EpCAM in colorectal cancer. Completed $100M offering Q2 2025; cash $143.6M as of Q3 2025 (runway to Q2 2027). Partnerships with Amgen, Astellas, Bristol Myers Squibb, Moderna, and Regeneron. [[1]](https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities) [[2]](https://www.stocktitan.net/news/CTMX/cytom-x-therapeutics-announces-second-quarter-2025-financial-results-1rz9dcrd106e.html)

---

## Technology

- **PROBODY® Platform**: Proprietary masking technology that attaches a proprietary "mask" peptide to biologics (antibodies, ADCs, T-cell engagers, cytokines) that blocks activity in healthy tissue but is proteolytically cleaved in the tumor microenvironment (TME) — enabling tumor-localized drug activation and reduced systemic toxicity. [[1]](https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities)
- **Varseta-M (CX-2051)**: PROBODY ADC targeting EpCAM for advanced colorectal cancer. Phase 1 dose-escalation; positive interim data reported May 2025; additional data anticipated Q1 2026. [[2]](https://www.stocktitan.net/news/CTMX/cytom-x-therapeutics-announces-second-quarter-2025-financial-results-1rz9dcrd106e.html)
- **CX-801**: Phase 1 dose escalation in metastatic melanoma. [[1]](https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities)
- **Partnerships**: CX-904 and other programs partnered with Amgen, Astellas, Bristol Myers Squibb, Moderna, and Regeneron. [[1]](https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Public offering | Q2 2025 | $100M | Public market |

Cash: $143.6M as of Q3 2025 (runway to Q2 2027). Listed NASDAQ: CTMX. [[2]](https://www.stocktitan.net/news/CTMX/cytom-x-therapeutics-announces-second-quarter-2025-financial-results-1rz9dcrd106e.html)

---

## References

1. CytomX IR — 2025 strategic pipeline priorities and corporate update (Jan 2025): [https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities](https://ir.cytomx.com/news-releases/news-release-details/cytomx-therapeutics-announces-2025-strategic-pipeline-priorities)
2. StockTitan — CytomX Q2 2025 financial results, $100M offering, Phase 1 data: [https://www.stocktitan.net/news/CTMX/cytom-x-therapeutics-announces-second-quarter-2025-financial-results-1rz9dcrd106e.html](https://www.stocktitan.net/news/CTMX/cytom-x-therapeutics-announces-second-quarter-2025-financial-results-1rz9dcrd106e.html)
