# Aera Therapeutics — Research Notes

## Overview

Aera Therapeutics is a gene therapy delivery company co-founded by CRISPR pioneer Feng Zhang (Broad Institute/MIT), launched in 2022. Develops protein nanoparticle (PNP) delivery platforms for genetic medicines. Total raised: $193M (Series A + B). [[1]](https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/)

**Leadership:** Akin Akinc (CEO; ex-Alnylam); John Maraganore (Chairman; ex-Alnylam). Co-founded by Feng Zhang. [[2]](https://www.biopharmadive.com/news/feng-zhang-aera-gene-therapy-alnylam/642901/)

---

## Technology

- **Protein Nanoparticles (PNPs)**: Novel delivery system based on endogenous human proteins (e.g., PEG10) identified by Zhang's Broad Institute lab in 2021. These proteins naturally form capsid-like structures that can be engineered to package, secrete, and deliver specific RNA cargo in vivo — a "virus-like particle" made from human proteins. [[2]](https://www.biopharmadive.com/news/feng-zhang-aera-gene-therapy-alnylam/642901/)
- **Multi-modality platform**: Also developing targeted lipid nanoparticles (tLNPs) and antibody-oligonucleotide conjugates (AOCs) for broader tissue reach (CNS, heart, lungs). [[1]](https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/)
- Aim: overcome limitations of AAV (immunogenicity, manufacturing, one-time dosing) and LNP (liver-tropism) for extrahepatic genetic medicine delivery.

---

## Funding & Investors

| Round | Date | Amount | Investors |
|-------|------|--------|-----------|
| Series A | 2022 | — | ARCH Venture Partners, GV, Lux Capital, F-Prime Capital, Altitude Life Science Ventures |
| Series B | — | — | Existing investors |
| **Combined total** | — | **$193M** | ARCH Venture Partners, GV, Lux Capital, F-Prime Capital, Altitude Life Science Ventures (7 total) |

Source: [[1]](https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/)

---

## References

1. Aera Therapeutics — Launch press release: `https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/` | [https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/](https://aeratx.com/aera-therapeutics-launches-with-193-million-in-financing-to-enable-and-advance-the-next-generation-of-transformative-genetic-medicines/)
2. BioPharma Dive — Feng Zhang/Aera coverage: [https://www.biopharmadive.com/news/feng-zhang-aera-gene-therapy-alnylam/642901/](https://www.biopharmadive.com/news/feng-zhang-aera-gene-therapy-alnylam/642901/)
