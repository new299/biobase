# Cepheid — Research Notes

## Overview

Cepheid is a Sunnyvale, CA-based molecular diagnostics company, wholly owned by Danaher Corporation (acquired 2016 for ~$4B). Develops and manufactures the GeneXpert® system — the world's leading decentralized molecular diagnostic platform for rapid, near-patient nucleic acid testing. Part of Danaher's Diagnostics segment (~$9.94B FY2025 revenue), with Cepheid respiratory revenue alone ~$500M in 2025. [[1]](https://www.cepheid.com/) [[2]](https://www.360dx.com/business-news/cepheid-growth-drives-danaher-q4-dx-revs-3-percent-firm-forecasts-single-digit-total)

---

## Technology & Products

- **GeneXpert® System**: Closed cartridge-based real-time PCR platform enabling sample-to-answer molecular testing at point-of-care or decentralized lab settings. Single cartridge performs all extraction, amplification, and detection steps. Deployed in >180 countries. [[3]](https://en.wikipedia.org/wiki/Cepheid_(company))
- **GeneXpert Menu**: 300+ FDA-cleared and CE-marked assays including: Xpert MTB/RIF (TB + rifampicin resistance), Xpert Xpress SARS-CoV-2/Flu/RSV, Xpert MRSA/SA, Xpert CT/NG (chlamydia/gonorrhea), Xpert HPV, Xpert HIV-1, and oncology/hematology assays. [[1]](https://www.cepheid.com/)
- Installed base: ~50,000+ GeneXpert systems globally. [[3]](https://en.wikipedia.org/wiki/Cepheid_(company))

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 1996 | Sunnyvale, CA |
| NASDAQ IPO | 2000 | NASDAQ: CPHD |
| Acquired by Danaher | Nov 2016 | ~$4B (~$53/share) |

[[4]](https://investors.danaher.com/2016-09-06-Danaher-To-Acquire-Cepheid-For-53-00-Per-Share-Or-Approximately-4-Billion)

---

## Financial Performance (as Danaher subsidiary)

- Danaher Diagnostics segment FY2025: ~$9.94B revenue (+2% core growth). [[2]](https://www.360dx.com/business-news/cepheid-growth-drives-danaher-q4-dx-revs-3-percent-firm-forecasts-single-digit-total)
- Cepheid respiratory testing revenue FY2025: ~$500M. [[2]](https://www.360dx.com/business-news/cepheid-growth-drives-danaher-q4-dx-revs-3-percent-firm-forecasts-single-digit-total)

---

## References

1. Cepheid — Company website: [https://www.cepheid.com/](https://www.cepheid.com/)
2. 360Dx — Cepheid growth drives Danaher Q4 diagnostics (2025): [https://www.360dx.com/business-news/cepheid-growth-drives-danaher-q4-dx-revs-3-percent-firm-forecasts-single-digit-total](https://www.360dx.com/business-news/cepheid-growth-drives-danaher-q4-dx-revs-3-percent-firm-forecasts-single-digit-total)
3. Wikipedia — Cepheid: [https://en.wikipedia.org/wiki/Cepheid_(company)](https://en.wikipedia.org/wiki/Cepheid_(company))
4. Danaher — Acquisition of Cepheid announcement (Sep 2016): [https://investors.danaher.com/2016-09-06-Danaher-To-Acquire-Cepheid-For-53-00-Per-Share-Or-Approximately-4-Billion](https://investors.danaher.com/2016-09-06-Danaher-To-Acquire-Cepheid-For-53-00-Per-Share-Or-Approximately-4-Billion)

## ASeq Posts

- [Ont Cepheid](https://aseq.substack.com/p/ont-cepheid)
- [Cepheid And Anthrax](https://aseq.substack.com/p/cepheid-and-anthrax)
- [Inside A Cepheid Genexpert Cartridge](https://aseq.substack.com/p/inside-a-cepheid-genexpert-cartridge)
- [Cepheids And Sequencing](https://aseq.substack.com/p/cepheids-and-sequencing)
