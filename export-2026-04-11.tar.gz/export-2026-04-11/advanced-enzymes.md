# Advanced Enzymes — Research Notes

## Overview

Advanced Enzyme Technologies Ltd (NSE: ADVENZYMES) is a publicly traded Indian enzyme company founded in 1989 in Thane (Mumbai), India by Chandrakant Laxminarayan Rathi. Manufactures specialty enzymes for human nutrition, food processing, animal feed, pharma, and industrial applications. [[1]](https://www.advancedenzymes.com/) [[2]](https://pitchbook.com/profiles/company/125978-14)

---

## Technology / Products

- **Enzyme manufacturing**: 7 R&D units (5 India, 1 US, 1 Germany); 9 manufacturing facilities. Fermentation capacity expanded from 360m³ to ~500m³ over 5 years. [[3]](https://www.advancedenzymes.com/wp-content/uploads/2024/07/Integrated-Annual-Report-2023-24.pdf)
- **Product segments**: Human nutrition/nutraceuticals, food & beverages, animal nutrition, bio-catalysis.
- **Pipeline (2023–24)**: 25+ products in development; focus on sugar management, weight loss (human nutrition) and bio-catalysis. [[3]](https://www.advancedenzymes.com/wp-content/uploads/2024/07/Integrated-Annual-Report-2023-24.pdf)

---

## Funding / Investors

- Listed on NSE/BSE (ADVENZYMES). Post-IPO financing in Sep 2020 with Nalanda Capital participation. [[2]](https://pitchbook.com/profiles/company/125978-14)

---

## References

1. Advanced Enzymes — Corporate website: [https://www.advancedenzymes.com/](https://www.advancedenzymes.com/)
2. PitchBook — Company profile: [https://pitchbook.com/profiles/company/125978-14](https://pitchbook.com/profiles/company/125978-14)
3. Advanced Enzymes — Annual Report 2023–24: [https://www.advancedenzymes.com/wp-content/uploads/2024/07/Integrated-Annual-Report-2023-24.pdf](https://www.advancedenzymes.com/wp-content/uploads/2024/07/Integrated-Annual-Report-2023-24.pdf)
