# Metsera

## Overview

Metsera is a biotechnology company building oral and injectable medicines for obesity and metabolic diseases.[[1]](https://investors.metsera.com/news-releases/news-release-details/metsera-launches-lead-next-generation-medicines-obesity-and) The company launched publicly in 2024 and rapidly assembled a broad clinical-stage pipeline.[[1]](https://investors.metsera.com/news-releases/news-release-details/metsera-launches-lead-next-generation-medicines-obesity-and)

## Technology

Metsera's platform is centered on peptide engineering and a large library of nutrient-stimulated hormone analogs (`NuSH` analog peptides), spanning oral and injectable incretin, non-incretin, and combination therapies.[[1]](https://investors.metsera.com/news-releases/news-release-details/metsera-launches-lead-next-generation-medicines-obesity-and) [[2]](https://investors.metsera.com/news-releases/news-release-details/metsera-secures-215-million-series-b-financing-further)

## Investors

At launch in April 2024, Metsera said it had raised $290 million in financing led by ARCH Venture Partners with participation from investors including F-Prime Capital, GV, Mubadala Capital, Newpath Partners, and SoftBank Vision Fund 2.[[1]](https://investors.metsera.com/news-releases/news-release-details/metsera-launches-lead-next-generation-medicines-obesity-and) In November 2024, it announced a $215 million Series B led by Wellington Management and Venrock Healthcare Capital Partners, with participation from Fidelity, T. Rowe Price, Janus Henderson, and others.[[2]](https://investors.metsera.com/news-releases/news-release-details/metsera-secures-215-million-series-b-financing-further)

## Acquisitions and Strategic Transactions

No source-backed primary announcement of a completed acquisition was used in this note. The reviewed official materials are strongest on Metsera's launch and financing rounds.[[1]](https://investors.metsera.com/news-releases/news-release-details/metsera-launches-lead-next-generation-medicines-obesity-and) [[2]](https://investors.metsera.com/news-releases/news-release-details/metsera-secures-215-million-series-b-financing-further)
