# Corxel

## Overview
CORXEL Pharmaceuticals is a clinical-stage biopharmaceutical company developing therapies for cardiometabolic conditions globally.[[1]](https://www.corxelbio.com/en/)[[2]](https://www.corxelbio.com/en/press-releases/corxel-announces-287-million-series-d1-financing-to-further-advance-its-cardiometabolic-pipeline-including-oral-small-molecule-glp-1-receptor-agonist/)

## Technology
The company says its pipeline includes CX11, an oral small-molecule GLP-1 receptor agonist, JX10 for acute ischemic stroke, and JX09, an aldosterone synthase inhibitor for hypertension, along with other obesity-focused programs.[[1]](https://www.corxelbio.com/en/)[[2]](https://www.corxelbio.com/en/press-releases/corxel-announces-287-million-series-d1-financing-to-further-advance-its-cardiometabolic-pipeline-including-oral-small-molecule-glp-1-receptor-agonist/)

## Investors
CORXEL announced a Series D1 financing of up to $287 million in January 2026 with participation from RTW Investments, SR One, TCGX, RA Capital, HBM Healthcare Investments, SymBiosis, Adage, Invus, and SilverArc Capital. Secondary reporting also describes a 2024 Series D round backed by RTW and Bayer-related capital.[[2]](https://www.corxelbio.com/en/press-releases/corxel-announces-287-million-series-d1-financing-to-further-advance-its-cardiometabolic-pipeline-including-oral-small-molecule-glp-1-receptor-agonist/)[[3]](https://www.vcbeathealth.com/article/2389)

## Acquisitions / Other
In March 2026, CORXEL announced an asset purchase agreement with Everest Medicines covering development and commercialization of CARDAMYST in Greater China. Secondary reporting also states CORXEL in-licensed ex-China rights to CX11 from Vincentage in late 2024.[[1]](https://www.corxelbio.com/en/)[[3]](https://www.vcbeathealth.com/article/2389)
