# TransCode Therapeutics

## Overview

TransCode Therapeutics is a clinical-stage RNA oncology company focused on improving delivery of RNA therapeutics to metastatic cancer. The company says its mission is to use targeted RNA therapeutics to treat high-risk and advanced cancers more effectively. [[1]](https://www.transcodetherapeutics.com/mission.html) [[2]](https://www.transcodetherapeutics.com/)

## Technology

Its core platform is TTX, a proprietary nanoparticle delivery system built to transport RNA payloads to tumors and metastases. The lead candidate, TTX-MC138, targets microRNA-10b, which TransCode describes as a master regulator of metastatic cell viability. The platform also supports other programs including siPDL1, RIG-I agonism, CRISPR, and mRNA approaches. [[1]](https://www.transcodetherapeutics.com/mission.html) [[3]](https://www.transcodetherapeutics.com/science.html) [[4]](https://www.transcodetherapeutics.com/pipeline.html)

## Clinical Development

In August 2023, TransCode announced first-subject dosing in a Phase 0 trial with radiolabeled TTX-MC138 to assess delivery to metastatic lesions. In 2025, the company reported dosing progress in Phase 1 and later presented preliminary Phase 1a data at ESMO showing the primary safety endpoint had been achieved and a Phase 2a dose established. [[5]](https://ir.transcodetherapeutics.com/2023-08-23-TransCode-Therapeutics-Announces-First-Subject-Dosed-with-Radiolabeled-TTX-MC138-in-First-In-Human-Clinical-Trial) [[6]](https://ir.transcodetherapeutics.com/2025-03-27-TransCode-Therapeutics-Announces-Initial-Dosing-in-Fourth-Cohort-of-Phase-1-Clinical-Trial-with-TTX-MC138) [[7]](https://ir.transcodetherapeutics.com/2025-10-14-TransCode-Therapeutics-presents-preliminary-data-from-its-completed-Phase-1a-study-with-TTX-MC138-in-metastatic-disease-at-ESMO)

## Strategic Position

TransCode is differentiated by focusing on RNA delivery to metastatic disease, especially through a theranostic nanoparticle approach that can be both imaged and used therapeutically. Public materials reviewed here did not surface a major acquisition, so the company's current strategic identity remains platform-plus-pipeline execution. [[3]](https://www.transcodetherapeutics.com/science.html) [[4]](https://www.transcodetherapeutics.com/pipeline.html)
