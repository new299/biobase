# GeneCopoeia — Research Notes

## Overview

GeneCopoeia is a Rockville, MD-based genomics research tools company providing a broad range of molecular biology products and services including gene expression clones, ORF clones, promoter reporter clones, shRNA/siRNA, CRISPR gene editing tools, and custom gene synthesis. The company is a major supplier of human, mouse, and rat expression-ready ORF clones, lentiviral vectors, and viral particles for gene function research and drug discovery. GeneCopoeia is a private company with no disclosed funding information. [[1]](https://www.genecopoeia.com/)

---

## Products & Services

- **ORF Clone Libraries**: One of the largest collections of human, mouse, and rat full-length ORF expression clones in multiple vector systems (pcDNA, lentiviral, adenoviral).
- **CRISPR Gene Editing Tools**: sgRNA libraries, Cas9 expression systems, HDR donor templates for gene knockout and knockin.
- **Reporter Systems**: Promoter-reporter constructs for transcription factor assays and pathway analysis.
- **Custom Gene Synthesis**: DNA synthesis and cloning services.
- **Viral Particles**: Lentiviral and adenoviral packaging services for stable cell line generation.

---

## Funding

No public funding disclosures found. GeneCopoeia appears to be a privately held, revenue-generating genomics tools company. [[1]](https://www.genecopoeia.com/)

---

## References

1. GeneCopoeia — Homepage: [https://www.genecopoeia.com/](https://www.genecopoeia.com/)
