# Dovetail Genomics — Research Notes

## Overview

Dovetail Genomics was a Santa Cruz, CA-based genomics company founded in 2013 specializing in proximity ligation-based library preparation technologies for chromatin conformation capture (Hi-C) and complex genome assembly. In June 2022, Dovetail Genomics merged with its sibling company Arc Bio to form Cantata Bio — combining chromatin conformation and metagenomic sequencing platforms under a single company. Dovetail's products are now marketed under the Cantata Bio brand. [[1]](https://www.genomeweb.com/sequencing/dovetail-genomics-merges-sibling-firm-arc-bio-form-cantata-bio) [[2]](https://cantatabio.com/)

---

## Technology & Products

- **LinkPrep / Hi-C**: Dovetail's proximity ligation platform for chromatin conformation capture (Hi-C), enabling single-day Hi-C library preparation (vs. 2–3 days for standard Hi-C) for haplotype-resolved genome assembly, structural variant detection, and 3D chromatin architecture analysis. [[3]](https://www.genomeweb.com/sequencing/dovetail-genomics-launch-structural-variant-assay-based-linkprep-chromatin-conformation)
- **VariLink**: Structural variant detection assay based on LinkPrep that enables simultaneous genetic and epigenetic data analysis from the same library. [[3]](https://www.genomeweb.com/sequencing/dovetail-genomics-launch-structural-variant-assay-based-linkprep-chromatin-conformation)
- **Element Biosciences Partnership**: Validated Dovetail's proximity ligation-based NGS library prep solutions for epigenetics on the Element AVITI sequencing system. [[4]](https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system)

---

## Funding & Corporate History

| Event | Date | Amount / Details |
|-------|------|-----------------|
| Founded | 2013 | Santa Cruz, CA |
| NHGRI Grant | Sep 2015 | $1.5M |
| NHGRI Grant | Nov 2024 | $2M (high-throughput Hi-C platform) |
| Merger with Arc Bio → Cantata Bio | Jun 2022 | — |

Total grant funding: ~$3.5M. [[5]](https://www.genomeweb.com/sequencing/dovetail-genomics-gets-2m-nhgri-grant-develop-high-throughput-hi-c-platform)

---

## References

1. GenomeWeb — Dovetail Genomics merges with Arc Bio to form Cantata Bio (Jun 2022): [https://www.genomeweb.com/sequencing/dovetail-genomics-merges-sibling-firm-arc-bio-form-cantata-bio](https://www.genomeweb.com/sequencing/dovetail-genomics-merges-sibling-firm-arc-bio-form-cantata-bio)
2. Cantata Bio — Dovetail Genomics (product page): [https://cantatabio.com/dovetail-genomics](https://cantatabio.com/dovetail-genomics)
3. GenomeWeb — Dovetail VariLink/LinkPrep structural variant assay: [https://www.genomeweb.com/sequencing/dovetail-genomics-launch-structural-variant-assay-based-linkprep-chromatin-conformation](https://www.genomeweb.com/sequencing/dovetail-genomics-launch-structural-variant-assay-based-linkprep-chromatin-conformation)
4. Element Biosciences — Partnership with Dovetail Genomics: [https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system](https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system)
5. GenomeWeb — Dovetail $2M NHGRI grant for high-throughput Hi-C: [https://www.genomeweb.com/sequencing/dovetail-genomics-gets-2m-nhgri-grant-develop-high-throughput-hi-c-platform](https://www.genomeweb.com/sequencing/dovetail-genomics-gets-2m-nhgri-grant-develop-high-throughput-hi-c-platform)
