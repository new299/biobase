# Datar Cancer Genetics — Research Notes

## Overview

Datar Cancer Genetics Private Limited is a Nashik, India-based liquid biopsy company founded in 1992 by Rajan Datar. Develops non-invasive blood-based cancer diagnostic and monitoring tests. Notable: three U.S. FDA Breakthrough Device Designations for liquid biopsy tests (breast cancer, prostate cancer, and brain tumor detection). CE mark obtained for liquid biopsy test. Valuation: ~₹650 Cr. Total raised: ~$2.98M. [[1]](https://datarpgx.com/) [[2]](https://www.prnewswire.com/in/news-releases/us-fda-grants-breakthrough-designation-for-blood-test-to-help-diagnose-inaccessible-brain-tumors-301711882.html)

---

## Technology & Products

- **TruBlood**: Non-invasive liquid biopsy for detection of malignancy in blood. [[1]](https://datarpgx.com/)
- **CellDx**: Genome analysis of circulating tumor cells for cancer characterization. [[1]](https://datarpgx.com/)
- **Exacta**: Personalized cancer treatment guidance based on tumor molecular analysis. [[1]](https://datarpgx.com/)
- **ChemoScale**: In vitro analysis evaluating tumor resistance to specific chemotherapy drugs. [[1]](https://datarpgx.com/)
- **FDA Breakthrough Designations**: Three U.S. FDA Breakthrough Device Designations for blood-based tests for breast cancer, prostate cancer, and inaccessible brain tumor diagnosis (glioma). CE mark obtained for liquid biopsy. [[2]](https://www.prnewswire.com/in/news-releases/us-fda-grants-breakthrough-designation-for-blood-test-to-help-diagnose-inaccessible-brain-tumors-301711882.html) [[3]](https://www.genomeweb.com/cancer/datar-cancer-genetics-obtains-ce-mark-liquid-biopsy-cancer-test)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Unattributed round | Aug 2024 | ₹25 Cr (~$3M) | Alkemi Growth Capital |

Total raised: ~$2.98M from 16 investors (including Alkemi Growth Capital). Valuation ~₹650 Cr (~$78M). [[4]](https://tracxn.com/d/companies/datar-genetics/__YZ9IA2mgPBKc_6ve3d0d9sdIc_Bi_TiZQjdaMxhrpOE)

---

## References

1. Datar Cancer Genetics — Company website: [https://datarpgx.com/](https://datarpgx.com/)
2. PRNewswire India — FDA Breakthrough Designation for blood test for brain tumors: [https://www.prnewswire.com/in/news-releases/us-fda-grants-breakthrough-designation-for-blood-test-to-help-diagnose-inaccessible-brain-tumors-301711882.html](https://www.prnewswire.com/in/news-releases/us-fda-grants-breakthrough-designation-for-blood-test-to-help-diagnose-inaccessible-brain-tumors-301711882.html)
3. GenomeWeb — Datar Cancer Genetics obtains CE mark for liquid biopsy: [https://www.genomeweb.com/cancer/datar-cancer-genetics-obtains-ce-mark-liquid-biopsy-cancer-test](https://www.genomeweb.com/cancer/datar-cancer-genetics-obtains-ce-mark-liquid-biopsy-cancer-test)
4. Tracxn — Datar Genetics funding profile: [https://tracxn.com/d/companies/datar-genetics/__YZ9IA2mgPBKc_6ve3d0d9sdIc_Bi_TiZQjdaMxhrpOE](https://tracxn.com/d/companies/datar-genetics/__YZ9IA2mgPBKc_6ve3d0d9sdIc_Bi_TiZQjdaMxhrpOE)
