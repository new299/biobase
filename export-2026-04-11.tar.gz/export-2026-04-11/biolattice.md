# BioLattice

## Overview
BioLattice is an early-stage regenerative medicine company developing vascularized scaffolds and tissue-engineering technologies.[[1]](https://sosv.com/company/biolattice/) It is part of the SOSV ecosystem and operates at the intersection of biomaterials and regenerative medicine.

## Technology
SOSV describes BioLattice as using a swelling gelatin scaffold to open pores in a stable and scalable way, enabling rapid vascularization for tissue engineering and cell delivery applications.[[1]](https://sosv.com/company/biolattice/) This is a biomaterials and tissue-engineering platform rather than a traditional therapeutics company.

## Investors
SOSV lists BioLattice as a portfolio company.[[1]](https://sosv.com/company/biolattice/) I did not identify a fuller company-issued financing history during this pass.

## Acquisitions and Corporate Activity
No acquisition involving BioLattice was identified in the reviewed public sources. The accessible public record is currently limited and centered on the SOSV profile and regenerative-scaffold concept.[[1]](https://sosv.com/company/biolattice/)
