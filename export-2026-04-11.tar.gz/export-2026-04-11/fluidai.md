# FluidAI Medical — Research Notes

## Overview

FluidAI Medical is a Kitchener, Ontario, Canada-based medical device startup founded in 2014, developing an AI-powered wireless sensor for postoperative monitoring — specifically for real-time detection of gastrointestinal anastomotic leaks following abdominal surgery, one of the most serious and costly post-surgical complications. Total raised: ~$18.5M (Series A $15M, Oct 2023) + $25M manufacturing investment (Jan 2024). Key investors: SOSV (lead), Graphene Ventures, Accelerator Centre, HAX. [[1]](https://www.crunchbase.com/organization/nerv-technology-inc) [[2]](https://pitchbook.com/profiles/company/178295-59)

---

## Technology & Products

- **AI-Powered Postoperative Monitor**: Wireless intra-abdominal sensor placed at the surgical site during bowel surgery that continuously monitors fluid chemistry and uses AI algorithms to detect early signs of anastomotic leaks — before they become life-threatening. Enables early intervention that reduces ICU stays, readmissions, and mortality.
- **GI Leak Detection**: Primary initial indication for anastomotic leak detection after colorectal, bariatric, and upper GI surgery.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed + early rounds | ~2014–2022 | ~$3.5M | Accelerator Centre, HAX, SOSV |
| Series A | Oct 2023 | $15M | SOSV (lead), Graphene Ventures |
| Manufacturing investment | Jan 2024 | $25M | Ontario manufacturing facility |

Total raised: ~$18.5M (equity) + $25M manufacturing. [[1]](https://www.crunchbase.com/organization/nerv-technology-inc)

---

## References

1. Crunchbase — FluidAI Medical profile: [https://www.crunchbase.com/organization/nerv-technology-inc](https://www.crunchbase.com/organization/nerv-technology-inc)
2. PitchBook — FluidAI profile: [https://pitchbook.com/profiles/company/178295-59](https://pitchbook.com/profiles/company/178295-59)
