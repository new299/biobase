# GlowDx — Research Notes

## Overview

GlowDx is a Cork, Ireland-based molecular diagnostics company founded in 2015 by Aisling Finn and Blaine Doyle, developing point-of-care molecular tests using proprietary AI-powered diagnostics technology for decentralized testing. Initial focus on tropical/mosquito-borne infectious diseases (dengue fever, chikungunya, Zika virus) and COVID-19 saliva-based diagnostics. The company operates a facility in Mexico City (30+ employees). Total raised: ~$1.65M–$7.21M. Key investors: SOSV/IndieBio, Randox, Amplifica Capital. [[1]](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)

---

## Technology

- **Point-of-Care Molecular Testing**: Novel molecular diagnostic technology enabling decentralized, local-access pathogen detection for mosquito-borne diseases (dengue, chikungunya, Zika) — reducing disease and economic burden through faster diagnosis outside central labs. [[1]](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)
- **AI/ML Integration**: Machine learning used to enhance test sensitivity and interpretation. [[1]](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)
- **Saliva-Based COVID-19 Testing**: PandemicTech fellowship for saliva-based COVID-19 diagnostics. [[1]](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)

---

## Funding & Investors

| Source | Amount | Notes |
|--------|--------|-------|
| SOSV / IndieBio | Undisclosed | Accelerator |
| Angel investors | €1.1M (~$1.3M) | Led by John Tuohy |
| Randox, Amplifica Capital | Undisclosed | Investors |
| Total | ~$1.65M–$7.21M | Multiple rounds |

[[1]](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)

---

## References

1. Irish Times — GlowDx raises €1.1M: [https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986](https://www.irishtimes.com/business/health-pharma/irish-molecular-diagnostics-company-glowdx-raises-1-1-m-1.4315986)
