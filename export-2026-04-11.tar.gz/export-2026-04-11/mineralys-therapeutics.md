# Mineralys Therapeutics

## Overview

Mineralys Therapeutics is a clinical-stage biopharmaceutical company developing medicines for hypertension and other diseases driven by dysregulated aldosterone, including chronic kidney disease and obstructive sleep apnea.[[1]](https://ir.mineralystx.com/news-events/press-releases/detail/78/mineralys-therapeutics-announces-pricing-of-upsized-250-0)

## Technology

Mineralys' lead program is lorundrostat, a selective aldosterone synthase inhibitor intended to treat uncontrolled or resistant hypertension and related cardio-renal diseases.[[1]](https://ir.mineralystx.com/news-events/press-releases/detail/78/mineralys-therapeutics-announces-pricing-of-upsized-250-0) The company is focused on endocrine drivers of hypertension rather than a broad platform model.[[1]](https://ir.mineralystx.com/news-events/press-releases/detail/78/mineralys-therapeutics-announces-pricing-of-upsized-250-0)

## Investors

Mineralys is a public Nasdaq company, but it has continued to raise substantial follow-on capital. In March 2025, it announced a proposed $250 million public offering, and in September 2025 it priced an upsized $250 million underwritten public offering of common stock.[[2]](https://ir.mineralystx.com/news-events/press-releases/detail/61/mineralys-therapeutics-announces-proposed-public-offering) [[1]](https://ir.mineralystx.com/news-events/press-releases/detail/78/mineralys-therapeutics-announces-pricing-of-upsized-250-0)

## Acquisitions and Strategic Transactions

No acquisition involving Mineralys Therapeutics was identified in the reviewed sources. The public record reviewed is centered on financing and late-stage development of lorundrostat rather than M&A.[[1]](https://ir.mineralystx.com/news-events/press-releases/detail/78/mineralys-therapeutics-announces-pricing-of-upsized-250-0)
