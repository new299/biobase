# NorthShore Bio

## Overview
NorthShore Bio appears to have been an early-stage sequencing-tools company developing a silicon-chip molecular detection and sequencing platform based on proprietary hybrid nanopore technology.[[1]](https://gust.com/companies/northshorebio)[[2]](https://www.mapquest.com/us/washington/northshore-bio-379395305) Public information is limited and mostly third-party, so this note remains intentionally narrow.

## Technology
Gust describes NorthShore Bio as using synthetic solid-state tunable nanopores in a semiconductor-based platform for direct DNA and RNA sequencing and other molecular detection applications.[[1]](https://gust.com/companies/northshorebio) The company was presented as pursuing low-cost, high-resolution sequencing with long-read ambitions using a direct-to-digital electronic approach.[[1]](https://gust.com/companies/northshorebio)

## Investors
Dealroom indicates NorthShore Bio raised early funding and lists Keiretsu Forum Northwest as a 2015 Series A investor, but the publicly accessible details are limited.[[3]](https://app.dealroom.co/companies/lux_bio_group) I did not identify an official company financing release during this pass.

## Acquisitions and Corporate Activity
No acquisition involving NorthShore Bio was identified in the reviewed public sources. The public footprint reviewed here suggests an early-stage private company with limited recent disclosed activity.[[1]](https://gust.com/companies/northshorebio)[[3]](https://app.dealroom.co/companies/lux_bio_group)
