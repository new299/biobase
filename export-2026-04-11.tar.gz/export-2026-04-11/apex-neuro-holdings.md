# Apex Neuro Holdings — Research Notes

## Overview

Apex Neuro Holdings was a life sciences company developing wearable neuromodulation devices, with offices in Cambridge, MA and New York City. Founded based on science from Harvard Medical School. **Permanently closed** as of the time of available records. [[1]](https://www.crunchbase.com/organization/apex-neuro)

---

## Technology

- **Neurostimulation Wearables**: Developed personal and medical wearable devices for neuromodulation — targeted at improving neurological function and wellbeing. [[1]](https://www.crunchbase.com/organization/apex-neuro)

---

## Funding & Investors

- Backed by major VC firms (specific investors not publicly detailed). Company has since permanently closed. [[1]](https://www.crunchbase.com/organization/apex-neuro)

---

## References

1. Crunchbase — Apex Neuro profile: [https://www.crunchbase.com/organization/apex-neuro](https://www.crunchbase.com/organization/apex-neuro)
