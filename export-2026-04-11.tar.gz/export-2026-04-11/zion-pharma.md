# Zion Pharma

## Overview

Zion Pharma is a China-based clinical-stage biotechnology company developing small-molecule oncology drugs. OrbiMed's portfolio page describes the company as focused on proprietary `best-in-class` and `first-in-class` anti-tumoral agents, with research teams in Shanghai and Suzhou.[[1]](https://www.orbimed.com/portfolio/) Public transaction coverage also describes Zion as focused on brain-penetrable compounds and oncology development.[[2]](https://www.businesswire.com/news/home/20230508005468/en/Zion-Pharma-Announces-Global-Agreement-with-Roche-to-Develop-and-Commercialize-a-Blood-Brain-Barrier-Penetrant-Oral-HER2-Tyrosine-Kinase-Inhibitor)

## Technology

According to OrbiMed and other company profiles, Zion's platform is built around medicinal chemistry and DMPK expertise to discover differentiated small molecules for oncology targets.[[1]](https://www.orbimed.com/portfolio/) Public profiles identify programs against targets including ATM, KRAS G12D, and SMARCA2, and the Roche transaction highlighted ZN-A-1041, an orally administered HER2 tyrosine kinase inhibitor designed to cross the blood-brain barrier.[[2]](https://www.businesswire.com/news/home/20230508005468/en/Zion-Pharma-Announces-Global-Agreement-with-Roche-to-Develop-and-Commercialize-a-Blood-Brain-Barrier-Penetrant-Oral-HER2-Tyrosine-Kinase-Inhibitor) [[3]](https://www.life-sciences-europe.com/organisation/zion-pharma-ltd-2018-suzhou-jiangsu-kiangsu-province-2001-51475.html)

## Investors

OrbiMed lists Zion Pharma as a portfolio company.[[1]](https://www.orbimed.com/portfolio/) VCBeat reported in 2021 that Zion completed a $40 million Series B led by OrbiMed, with participation from existing investors including Qiming Venture Partners, Sherpa Venture Capital, Ming BioVentures, and Med-Fine Capital.[[4]](https://www.vcbeathealth.com/article/645) CB Insights also identifies Zion as venture-backed and places total disclosed funding in the low-$70 million range, though database totals should be treated as directional rather than definitive.[[5]](https://www.cbinsights.com/company/zion-pharma)

## Acquisitions and Strategic Transactions

In May 2023, Zion announced a global agreement with Roche under which Roche acquired global rights to Zion's lead program ZN-A-1041, a brain-penetrant oral HER2 inhibitor. The announcement said Zion was eligible for a $70 million upfront payment plus additional milestone payments and royalties.[[2]](https://www.businesswire.com/news/home/20230508005468/en/Zion-Pharma-Announces-Global-Agreement-with-Roche-to-Develop-and-Commercialize-a-Blood-Brain-Barrier-Penetrant-Oral-HER2-Tyrosine-Kinase-Inhibitor)
