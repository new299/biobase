# Vilya

## Overview

Vilya is a biotechnology company developing de novo macrocycle therapeutics using AI-driven computational design. The company says it is building orally bioavailable macrocycles inspired by biology but designed from first principles to go beyond what evolution produced. [[1]](https://vilyatx.com/) [[2]](https://vilyatx.com/about)

## Technology

Vilya's platform is focused on computational macrocycle design. The company says it generates, predicts, and validates entirely new macrocycles in silico, with the goal of combining the selectivity of biologics with the convenience of pills. Its public pipeline page highlights programs in oncology and immunology, including an integrin alpha4beta7 program for inflammatory bowel disease. [[1]](https://vilyatx.com/) [[2]](https://vilyatx.com/about)

## Investors

Vilya's public site shows support from a small group of investors, and secondary coverage in the company's news section refers to a 2022 financing led by ARCH Venture Partners. Because the currently accessible official pages focus more on science and team than on financing detail, this investor summary should be treated as high-level and incomplete. [[1]](https://vilyatx.com/) [[2]](https://vilyatx.com/about)

## Strategic Position

Vilya is part of the newer wave of AI-enabled design-first therapeutics companies. Its core bet is that de novo designed macrocycles can unlock targets and properties that are difficult for traditional small molecules and biologics to reach simultaneously. [[1]](https://vilyatx.com/) [[2]](https://vilyatx.com/about)
