# Icagen Inc

## Overview
Icagen was a biopharmaceutical company focused on orally administered small-molecule drugs that modulate ion channel targets, with programs in pain, epilepsy, and inflammation.[[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_to_acquire_icagen)[[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_icagen)

## Technology
Pfizer described Icagen as a leader in ion channel drug discovery, including sodium channel programs developed through a Pfizer-Icagen collaboration targeting pain and related disorders.[[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_to_acquire_icagen)[[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_icagen)

## Investors
By the time of its sale, Icagen was a Nasdaq-listed public company rather than a private venture-stage biotech. The reviewed source set is strongest on the strategic collaboration and acquisition rather than early financing rounds.[[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_to_acquire_icagen)

## Acquisitions / Other
Pfizer announced in July 2011 that it would acquire Icagen for about $56 million, and completed the transaction on October 27, 2011 at $6.00 per share in cash.[[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_to_acquire_icagen)[[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer_completes_acquisition_of_icagen)
