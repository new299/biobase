# Shoreline Biosciences

## Overview
Shoreline Biosciences is a cell therapy company developing allogeneic NK-cell and macrophage immunotherapies derived from induced pluripotent stem cells [[1]](https://shorelinebio.com/about-us/).

## Technology
The company says it develops intelligently engineered iPSC-derived cell therapies intended for cancer and autoimmune disease, with emphasis on the right cell and right edits for the right indications [[1]](https://shorelinebio.com/about-us/).

## Investors
Shoreline announced a $43 million financing in April 2021 led by Boxer Capital with participation from BVF Partners, Commodore Capital, Cormorant Capital, Janus Henderson Investors, Logos Capital, Kite, Wedbush Healthcare Partners, Stork Capital, and others [[2]](https://shorelinebio.com/shoreline-biosciences-announces-43m-financing-to-advance-pipeline-of-allogeneic-natural-killer-and-macrophage-cellular-immunotherapies-derived-from-pluripotent-stem-cells/). In November 2021 it announced a $140 million financing led by Ally Bridge Group with broad follow-on participation from new and existing investors [[3]](https://shorelinebio.com/test-article/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources. The major strategic events were the 2021 financings and corporate partnerships referenced by the company, including relationships with Kite and BeiGene in connection with platform expansion [[3]](https://shorelinebio.com/test-article/).

## References
[[1]](https://shorelinebio.com/about-us/)
[[2]](https://shorelinebio.com/shoreline-biosciences-announces-43m-financing-to-advance-pipeline-of-allogeneic-natural-killer-and-macrophage-cellular-immunotherapies-derived-from-pluripotent-stem-cells/)
[[3]](https://shorelinebio.com/test-article/)
