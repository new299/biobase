# EvodiaBio — Research Notes

## Overview

EvodiaBio is a Copenhagen, Denmark-based synthetic biology company founded in 2021, developing fermentation-based sustainable aroma and flavor ingredients for the food and beverage industry. The company uses engineered microorganisms to produce natural scent and flavor compounds — particularly targeting the fast-growing non-alcoholic beverage market (e.g., beer aroma compounds). Total raised: ~$14M. Key investors: Nordic Foodtech VC, Symrise (German flavor house), PINC (Paulig venture arm), EIFO (Export & Investment Fund of Denmark), Thia Ventures, Newtree Impact, Novo Nordisk Foundation (via Danish BioInnovation Institute). [[1]](https://evodiabio.com/article/biotech-company-secures-multi-million-investment-to-revolutionize-the-market-for-sustainable-aroma-with-a-groundbreaking-new-technology/) [[2]](https://techfundingnews.com/evodiabio-secures-e7m-to-produce-sustainable-non-alcoholic-beer-aromas/)

---

## Technology & Products

- **Fermentation-Derived Aroma Compounds**: Uses precision fermentation with engineered microorganisms to produce complex natural flavor and aroma compounds at commercial scale — replacing petrochemical or land-intensive extraction methods.
- **Non-Alcoholic Beer Aromas**: Lead commercial application producing hop-derived aroma compounds for the growing non-alcoholic beer market.
- **Early-Stage Grant (Novo Nordisk Foundation / Danish BioInnovation Institute)**: €2M early-stage support.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | ~2022–2023 | ~€6M | Nordic Foodtech VC, Symrise, PINC (Paulig), Thia Ventures, Newtree Impact, Ananke Ventures |
| Series B (first close) | Jun 2024 | €7M (~$7.6M) | EIFO (Export & Investment Fund of Denmark), The March Group + existing investors |
| Early-stage grant | ~2021 | €2M | Danish BioInnovation Institute (Novo Nordisk Foundation) |

Total raised: ~$14M. [[2]](https://techfundingnews.com/evodiabio-secures-e7m-to-produce-sustainable-non-alcoholic-beer-aromas/)

---

## References

1. EvodiaBio — Multi-million investment announcement: [https://evodiabio.com/article/biotech-company-secures-multi-million-investment-to-revolutionize-the-market-for-sustainable-aroma-with-a-groundbreaking-new-technology/](https://evodiabio.com/article/biotech-company-secures-multi-million-investment-to-revolutionize-the-market-for-sustainable-aroma-with-a-groundbreaking-new-technology/)
2. TechFundingNews — EvodiaBio secures €7M for non-alcoholic beer aromas (Jun 2024): [https://techfundingnews.com/evodiabio-secures-e7m-to-produce-sustainable-non-alcoholic-beer-aromas/](https://techfundingnews.com/evodiabio-secures-e7m-to-produce-sustainable-non-alcoholic-beer-aromas/)
