# Volition

## Overview

Volition is a multi-national epigenetics company developing and commercializing blood tests based on nucleosome and NETs biomarkers. The company says its Nu.Q product portfolio is aimed at earlier detection and monitoring of diseases in humans and animals. [[1]](https://ir.volition.com/news-events/press-releases/detail/882/volitionrx-limited-announces-full-fiscal-year-2025-financial-results-and-business-update)

## Technology

Volition's core platform is based on epigenetic and nucleosome-related biomarkers. Public company materials highlight Nu.Q Cancer assays, Nu.Q NETs for sepsis-related and NETosis-associated conditions, and lateral flow formats for lower-resource settings. [[1]](https://ir.volition.com/news-events/press-releases/detail/882/volitionrx-limited-announces-full-fiscal-year-2025-financial-results-and-business-update) [[2]](https://ir.volition.com/news-events/press-releases/detail/881/volitionrx-secures-eur-2-0-million-of-non-dilutive-funding-from-regional-government-agencies-in-belgium)

## Financing And Acquisitions

Volition has relied heavily on both public financings and non-dilutive regional funding. Recent examples include a $6.0 million underwritten public offering in October 2025, $2.0 million in structured financing in January 2026, and EUR2.0 million in additional non-dilutive funding in March 2026. It also acquired Octamer GmbH in 2020 to secure a key reagent component for its Nu.Q tests. [[3]](https://ir.volition.com/news-events/press-releases/detail/856/volitionrx-limited-announces-pricing-of-6-0-million-underwritten-public-offering-of-common-stock-and-common-stock-warrants) [[4]](https://ir.volition.com/news-events/press-releases/detail/866/volitionrx-secures-2-0-million-in-funding) [[2]](https://ir.volition.com/news-events/press-releases/detail/881/volitionrx-secures-eur-2-0-million-of-non-dilutive-funding-from-regional-government-agencies-in-belgium) [[5]](https://ir.volition.com/news-events/press-releases/detail/684/volitionrx-completes-acquisition-of-octamer-gmbh)

## Strategic Position

Volition is best seen as a diagnostics platform company trying to commercialize epigenetic biomarker testing across multiple disease areas and geographies. Its pattern of financing and grant support reflects the long commercialization cycles typical in diagnostics. [[1]](https://ir.volition.com/news-events/press-releases/detail/882/volitionrx-limited-announces-full-fiscal-year-2025-financial-results-and-business-update) [[5]](https://ir.volition.com/news-events/press-releases/detail/684/volitionrx-completes-acquisition-of-octamer-gmbh)
