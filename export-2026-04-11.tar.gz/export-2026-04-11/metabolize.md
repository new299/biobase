# Metabolize

## Overview

Metabolize is a consumer health and metabolic wellness startup developing non-drug products to support people using or discontinuing GLP-1 therapies.[[1]](https://sosv.com/company/metabolize/)

## Technology

SOSV describes Metabolize as commercializing science-backed oral products aimed at preventing muscle mass loss during GLP-1 use and helping maintain weight loss after discontinuation.[[1]](https://sosv.com/company/metabolize/) The company frames its approach around metabolic pathways distinct from GLP-1 agonism and positions its products as supplements or nutritional ingredients rather than prescription drugs.[[1]](https://sosv.com/company/metabolize/)

## Investors

Metabolize is an SOSV portfolio company.[[1]](https://sosv.com/company/metabolize/) The reviewed public sources did not surface a fuller financing announcement with round size or a broader syndicate.

## Acquisitions and Strategic Transactions

No acquisition involving Metabolize was identified in the reviewed sources. The public footprint reviewed is early-stage and commercialization-oriented rather than M&A-focused.[[1]](https://sosv.com/company/metabolize/)
