# Aivok Biopore — Research Notes

## Overview

Only a single Youtube video is available referencing this company as developing a Nanopore DNA sequecning platform in Russia.

https://aseq.substack.com/p/russian-maybe-nanopore-real-miseq

## ASeq Posts

- [Russian Maybe Nanopore Real Miseq](https://aseq.substack.com/p/russian-maybe-nanopore-real-miseq)
