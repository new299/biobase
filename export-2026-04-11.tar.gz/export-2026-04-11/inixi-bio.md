# Inixi Bio — Research Notes

## Overview

Inixi Bio is a St. Louis, MO-based biotechnology company founded in 2024 and a SOSV/IndieBio portfolio company. No detailed public information is available about the company's technology, pipeline, or funding beyond its SOSV affiliation. [[1]](https://sosv.com/)

---

## Funding & Investors

SOSV / IndieBio portfolio company. No additional public funding information found.

---

## References

1. SOSV — Homepage: [https://sosv.com/](https://sosv.com/)
