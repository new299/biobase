# Single Technologies

## Overview
Single Technologies is a Stockholm-based deep-tech sequencing company developing a 3-D Sequencing platform intended to increase throughput and connect sequencing with spatial biology [[1]](https://www.singletechnologies.com/) [[2]](https://www.singletechnologies.com/about).

## Technology
The company says its 3-D Sequencing technology uses a cube-style, multi-story infrastructure to dramatically increase parallel DNA reading and support both in situ and solution-based sequencing. Its upcoming Theta platform is positioned as the world's first 3-D sequencer [[1]](https://www.singletechnologies.com/).

## Investors
The reviewed public company pages emphasize platform vision and team rather than financing history, and I did not locate a primary-source investor press release during this pass [[1]](https://www.singletechnologies.com/) [[2]](https://www.singletechnologies.com/about).

## Acquisitions / Strategic Transactions
No acquisition or major strategic transaction was identified in the reviewed sources during this pass [[1]](https://www.singletechnologies.com/).

## References
[[1]](https://www.singletechnologies.com/)
[[2]](https://www.singletechnologies.com/about)
