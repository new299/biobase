# OliX Pharmaceuticals

## Overview
OliX Pharmaceuticals is a clinical-stage pharmaceutical company developing RNA interference therapeutics.[[1]](https://stockanalysis.com/quote/kosdaq/226950/company/)[[2]](https://www.linkedin.com/company/olix) The company is based in South Korea and focuses on dermal, ophthalmic, pulmonary, liver, and CNS indications using multiple siRNA delivery approaches.[[1]](https://stockanalysis.com/quote/kosdaq/226950/company/)[[2]](https://www.linkedin.com/company/olix)

## Technology and Pipeline
OliX says it has developed core RNAi platforms including asymmetric siRNA, cell-penetrating asymmetric siRNA, and GalNAc-asiRNA for locally administered and liver-targeted diseases.[[2]](https://www.linkedin.com/company/olix) Public company descriptions list programs for hypertrophic scars, androgenic alopecia, age-related macular degeneration, MASH, hepatitis, and CNS diseases.[[1]](https://stockanalysis.com/quote/kosdaq/226950/company/)[[3]](https://www.businesswire.com/news/home/20220504005406/en/OliX-Pharmaceuticals-Identifies-Effective-Inhibition-of-Target-Gene-Expression-and-Delivery-of-Candidate-to-Brain-for-CNS-Therapeutics)

## Investors
In May 2022, OliX announced completion of a KRW57 billion, approximately USD45 million, capital raise through a third-party allotment involving eight local institutional investors, including KB Investment, IMM Investment Corp., Company K Partners, Solidus Investment, Susung Asset Management, Welcome Asset Management, Focus Asset Management, and Shinhan Capital.[[4]](https://www.businesswire.com/news/home/20220525005373/en/OliX-Announces-Completion-of-USD-45-Million-Capital-Raise-for-RD-and-Financial-Structure-Improvement)

## Acquisitions and Corporate Activity
I did not identify a source-backed acquisition of OliX itself in the reviewed official materials. A notable recent business-development event reported in February 2025 was a large technology transfer or licensing deal for OLX702A with Eli Lilly, but the result I found was a secondary news article rather than an official primary release, so I am not treating it as a fully sourced acquisition event here.[[5]](https://biz.chosun.com/en/en-science/2025/02/10/RQQE5VZJQFBKLOKM7LY7GYUH6Q/)
