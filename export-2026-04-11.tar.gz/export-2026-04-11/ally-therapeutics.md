# Ally Therapeutics — Research Notes

## Overview

Ally Therapeutics is a biotechnology company founded in 2018, headquartered in Cambridge, MA. Focuses on engineering viral vectors that can evade pre-existing immune responses, solving a key barrier to in vivo gene therapy. Founded with backing from ARCH Venture Partners, Alta Partners, and UCB Ventures. [[1]](https://www.fiercebiotech.com/research/george-church-s-new-gene-therapy-project-shields-viral-vectors-from-problematic-immune) [[2]](https://www.crunchbase.com/organization/ally-therapeutics)

---

## Technology

- **Immune-Evasive Viral Vectors**: Engineering AAV (adeno-associated virus) and other viral vectors to avoid recognition and neutralization by pre-existing antibodies (NAbs) and T-cell responses in patients who have previously been exposed to natural AAV or prior gene therapy doses. This enables repeat dosing and expands eligibility of gene therapy to patients with high antibody titers. [[1]](https://www.fiercebiotech.com/research/george-church-s-new-gene-therapy-project-shields-viral-vectors-from-problematic-immune)
- Research associated with George Church's lab at Harvard.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | ~2018–2020 | Undisclosed | ARCH Venture Partners, Alta Partners, UCB Ventures |

Total raised: undisclosed. [[2]](https://www.crunchbase.com/organization/ally-therapeutics)

---

## References

1. Fierce Biotech — George Church gene therapy vectors: [https://www.fiercebiotech.com/research/george-church-s-new-gene-therapy-project-shields-viral-vectors-from-problematic-immune](https://www.fiercebiotech.com/research/george-church-s-new-gene-therapy-project-shields-viral-vectors-from-problematic-immune)
2. Crunchbase — Ally Therapeutics profile: [https://www.crunchbase.com/organization/ally-therapeutics](https://www.crunchbase.com/organization/ally-therapeutics)
