# Electra Therapeutics — Research Notes

## Overview

Electra Therapeutics is a clinical-stage biotechnology company spun out of Star Therapeutics, developing first-in-class SIRP (Signal-regulatory protein) family-targeted therapies for immune disorders and cancer. Lead program: ELA026 (anti-SIRPβ1 antibody) for secondary hemophagocytic lymphohistiocytosis (sHLH) — advancing to a global pivotal Phase 2/3 trial. Total raised: ~$267M+ ($84M Series B 2022 + $183M Series C Oct 2025, co-led by EQT Life Sciences and Nextech). [[1]](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/) [[2]](https://electra-therapeutics.com/electra-series-b/)

---

## Technology & Pipeline

- **SIRP Platform**: SIRP (Signal-regulatory protein) is a family of cell surface receptors expressed on diverse immune cell types. Electra targets specific SIRP proteins to deplete pathological immune cell populations — a first-in-class approach extending beyond current SIRPα/CD47 checkpoint programs. [[1]](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/)
- **ELA026**: Anti-SIRPβ1 antibody depleting pathological macrophage populations; frontline treatment for secondary HLH (sHLH), a life-threatening hyperinflammatory syndrome. Phase 2/3 pivotal trial funded by Series C. Also being evaluated in hematologic cancers. [[1]](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/)
- **ELA822**: Second pipeline program for immunology and inflammation indications; IND-enabling stage, advancing to clinic with Series C funding. [[1]](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2018–2021 | Undisclosed | Star Therapeutics |
| Series B | Feb 2022 | $84M | Undisclosed (Star Therapeutics spinout) |
| Series C | Oct 2025 | $183M | EQT Life Sciences (co-lead), Nextech (co-lead), Sanofi, HBM Healthcare Investments, Mubadala Capital |

Total raised: ~$267M+. [[1]](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/)

---

## References

1. Electra Therapeutics — $183M Series C announcement (Oct 2025): [https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/](https://electra-therapeutics.com/electra-therapeutics-announces-183-million-series-c-financing-to-advance-first-in-class-sirp-targeted-therapies-for-immune-disorders-and-cancer/)
2. Electra Therapeutics — $84M Series B announcement (Feb 2022): [https://electra-therapeutics.com/electra-series-b/](https://electra-therapeutics.com/electra-series-b/)
