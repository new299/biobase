# Esperovax — Research Notes

## Overview

Esperovax is an Ann Arbor, MI-based biotechnology company (University of Michigan spinout) developing oral RNA-based vaccines and therapeutics using a proprietary bioengineered probiotic yeast delivery platform. The company's approach delivers vaccine antigens and therapeutic payloads to the gut mucosa via enveloped virus-like particles expressed in engineered yeast, enabling oral delivery of mRNA and circular RNA (circRNA) medicines. Total raised: ~$8.8M. Key investors: Johnson & Johnson Innovation JLABS, Ann Arbor SPARK, Innovation Partnerships (UMich), Michigan Rise, Northern Michigan Angels. The company also received a $1.5M DoD subcontract (Dec 2024) for oral H5N1 influenza RNA vaccine development. [[1]](https://innovationpartnerships.umich.edu/company/esperovax/) [[2]](https://www.nasdaq.com/articles/esperovax-ginkgo-bioworks-join-hands-to-develop-circular-rna-based-therapeutics)

---

## Technology & Pipeline

- **Oral mRNA Vaccine Platform**: Bioengineered probiotic yeast expressing vaccine antigens in enveloped virus-like particles (VLPs) — delivered orally and targeting gut-mucosal immune activation. [[1]](https://innovationpartnerships.umich.edu/company/esperovax/)
- **EsperoFlu (H5N1 Influenza vaccine)**: Oral influenza vaccine using the platform. Awarded a $1.5M DoD DTRA Medical CBRN Defense Consortium subcontract (Dec 2024) via DynPort Vaccine Company LLC for preclinical development of an oral H5N1 RNA vaccine. [[2]](https://www.nasdaq.com/articles/esperovax-ginkgo-bioworks-join-hands-to-develop-circular-rna-based-therapeutics)
- **Circular RNA (circRNA) Therapeutics (Ginkgo Bioworks collaboration)**: Partnership with Ginkgo Bioworks to develop circRNAs for therapeutic applications — initial focus on circRNAs targeting colorectal cancer by inducing selective cell death in cancerous cells. [[2]](https://www.nasdaq.com/articles/esperovax-ginkgo-bioworks-join-hands-to-develop-circular-rna-based-therapeutics)

---

## Funding & Investors

| Source | Amount | Notes |
|--------|--------|-------|
| JLABS, Ann Arbor SPARK, Michigan Rise, Northern Michigan Angels, UMich Innovation Partnerships | $8.8M total | Multiple early-stage grants and investors |
| DoD/DTRA (DynPort subcontract) | $1.5M | Dec 2024; pre-clinical H5N1 oral RNA vaccine |

Total raised: ~$8.8M + $1.5M government subcontract. [[1]](https://innovationpartnerships.umich.edu/company/esperovax/)

---

## References

1. University of Michigan Innovation Partnerships — Esperovax company page: [https://innovationpartnerships.umich.edu/company/esperovax/](https://innovationpartnerships.umich.edu/company/esperovax/)
2. Nasdaq — Esperovax + Ginkgo Bioworks circular RNA therapeutics partnership: [https://www.nasdaq.com/articles/esperovax-ginkgo-bioworks-join-hands-to-develop-circular-rna-based-therapeutics](https://www.nasdaq.com/articles/esperovax-ginkgo-bioworks-join-hands-to-develop-circular-rna-based-therapeutics)
