# SiSaf

## Overview
SiSaf is a biopharmaceutical company developing nucleic acid medicines and delivery technologies for rare and genetically defined diseases [[1]](https://sisaf.com/about-us/).

## Technology
The company says its proprietary Bio-Courier platform is a non-viral hybrid carrier system for targeted delivery and transfection of siRNA and related nucleic acid therapeutics [[1]](https://sisaf.com/about-us/) [[2]](https://sisaf.com/news/sisaf-ltd-announces-us13-2-million-series-b-financing/).

## Investors
SiSaf announced a $13.2 million Series B financing in November 2020 led by Vickers Venture Partners and matched by the UK government's Future Fund [[2]](https://sisaf.com/news/sisaf-ltd-announces-us13-2-million-series-b-financing/). Its company history also states that it secured Series A financing in 2016 to pivot from a university-based pre-seed company to an emerging commercial biopharma [[1]](https://sisaf.com/about-us/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The main strategic milestones were the Series A and Series B financings plus research and licensing agreements supporting rare-disease RNA programs [[1]](https://sisaf.com/about-us/) [[2]](https://sisaf.com/news/sisaf-ltd-announces-us13-2-million-series-b-financing/).

## References
[[1]](https://sisaf.com/about-us/)
[[2]](https://sisaf.com/news/sisaf-ltd-announces-us13-2-million-series-b-financing/)
