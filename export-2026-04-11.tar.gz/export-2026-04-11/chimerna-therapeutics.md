# Chimerna Therapeutics — Research Notes

## Overview

Chimerna Therapeutics, Inc. is a New York, NY-based RNA therapeutics company founded in 2020. Develops circular RNA therapeutics using its Tornado technology platform, designed to overcome stability and abundance limitations of conventional linear RNA therapeutics. Primarily NIH SBIR grant-funded. [[1]](https://www.chimerna.com/) [[2]](https://www.cbinsights.com/company/chimerna-therapeutics)

---

## Technology

- **Circular RNA Platform (Tornado Technology)**: Produces circular RNA molecules that resist exonucleolytic degradation and accumulate to higher levels than linear RNA, addressing the major stability limitation of RNA-based medicines. [[1]](https://www.chimerna.com/)
- **Therapeutic Focus**: Developing circular RNA-based treatments for autosomal-dominant polycystic kidney disease (ADPKD), Alzheimer's disease, Parkinson's disease, ALS, and NASH. [[1]](https://www.chimerna.com/)

---

## Funding

| Round | Date | Amount | Source |
|-------|------|--------|--------|
| NIH SBIR | 2020 | $450K | NIH |

Total raised: ~$450K (NIH grant-funded; no disclosed venture rounds). [[3]](https://grantome.com/grant/NIH/R43-HG011214-01)

---

## References

1. Chimerna Therapeutics — Company website: [https://www.chimerna.com/](https://www.chimerna.com/)
2. CBInsights — Chimerna Therapeutics profile: [https://www.cbinsights.com/company/chimerna-therapeutics](https://www.cbinsights.com/company/chimerna-therapeutics)
3. Grantome — NIH SBIR grant (circular RNA platform): [https://grantome.com/grant/NIH/R43-HG011214-01](https://grantome.com/grant/NIH/R43-HG011214-01)
