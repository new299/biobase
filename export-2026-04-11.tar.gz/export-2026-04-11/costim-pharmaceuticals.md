# CoStim Pharmaceuticals — Research Notes

## Overview

CoStim Pharmaceuticals was a Cambridge, MA-based cancer immunotherapy company founded in 2011. Developed antibody drugs targeting immune checkpoint inhibitors (including PD-1) to harness the immune system against cancer. **Acquired by Novartis in February 2014** — just 12 months after its Series A, on only ~$10M of invested capital. [[1]](https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim) [[2]](https://lifescivc.com/2014/02/immuno-oncology-startup-costim-pharmaceuticals-acquired-by-novartis/)

---

## Technology

- **Immune Checkpoint Antibody Programs**: Developed antibody therapeutics targeting PD-1 and other immune checkpoint proteins to block cancer immune evasion signals. Late discovery-stage programs across several targets. [[1]](https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim)
- Novartis acquired CoStim to enter the PD-1 race and complement its CAR-T cell therapy program (CTL019/tisagenlecleucel) with immune checkpoint inhibitors. Programs intended to act as standalone agents or in combination with Novartis CAR-T. [[1]](https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2011 | Cambridge, MA |
| Series A | ~2013 | ~$10M |
| Acquired by Novartis | Feb 2014 | Terms undisclosed; ~12 months after Series A |

[[1]](https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim) [[2]](https://lifescivc.com/2014/02/immuno-oncology-startup-costim-pharmaceuticals-acquired-by-novartis/)

---

## References

1. FierceBiotech — Novartis acquires CoStim (Feb 2014): [https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim](https://www.fiercebiotech.com/biotech/novartis-expands-cancer-immunotherapy-research-program-acquisition-of-costim)
2. LifeSciVC — CoStim acquired by Novartis: [https://lifescivc.com/2014/02/immuno-oncology-startup-costim-pharmaceuticals-acquired-by-novartis/](https://lifescivc.com/2014/02/immuno-oncology-startup-costim-pharmaceuticals-acquired-by-novartis/)
