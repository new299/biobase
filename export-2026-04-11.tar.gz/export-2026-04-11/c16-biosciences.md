# C16 Biosciences

**Website:** https://www.c16bio.com

---

# Executive summary

C16 Biosciences is a biotechnology company developing **fermentation-derived alternatives to palm oil** using engineered yeast and industrial fermentation.

The company’s goal is to replace conventional palm oil supply chains with **deforestation-free, sustainable oils**.

Sources:
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/
https://www.employbl.com/companies/C16-Biosciences/funding-rounds

---

# Company overview

- **Founded:** 2017  
- **Headquarters:** New York, USA  
- **Sector:** Industrial biotech / synthetic biology / food & ingredients  

C16 Biosciences focuses on producing **lipids via microbial fermentation** as a sustainable replacement for palm oil.

Sources:
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/
https://www.employbl.com/companies/C16-Biosciences/funding-rounds

---

# Problem: Palm oil sustainability

Palm oil is one of the most widely used vegetable oils globally and is linked to:

- Tropical deforestation  
- Biodiversity loss  
- Greenhouse gas emissions  

C16 aims to produce **drop-in compatible oils without agricultural land use**.

Source:
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/

---

# Technology platform

## Yeast-based fermentation oils

C16 engineers **oleaginous yeast** to produce oils via fermentation.

Key features of the platform:

- Uses sugar feedstocks instead of palm plantations  
- Produces lipids molecularly similar to palm oil  
- Designed as drop-in replacements for existing supply chains  

The oils are produced through **precision fermentation**, similar to brewing.

Sources:
https://www.c16bio.com
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/

---

# First product: Palmless™

C16’s first commercial ingredient is **Palmless™**, a fermentation-derived palm oil alternative.

Applications:

- Beauty and personal care products  
- Consumer packaged goods  
- Food ingredients (future roadmap)

Source:
https://www.c16bio.com

---

# Commercialization strategy

C16 initially targets **cosmetics and personal care** markets because:

- Lower regulatory barriers than food
- High demand for sustainable ingredients
- Premium pricing supports early scaling

Source:
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/

---

# Funding and investors

C16 Biosciences has raised **~$24M+ in venture funding**.

Key investors include:

- Bill Gates (Breakthrough Energy Ventures)
- DCVC
- True Ventures
- Fifty Years

Sources:
https://www.greenqueen.com.hk/lab-grown-oil-bill-gates-invests-in-deforestation-free-palm-oil-startup-c16-biosciences/
https://www.employbl.com/companies/C16-Biosciences/funding-rounds

---

# Intellectual property and moat

Evidence of proprietary platform:

- Engineered yeast strains for lipid production  
- Fermentation and downstream processing know-how  
- Drop-in oil composition matching palm oil functionality  

Source:
https://www.c16bio.com

---

# Strategic positioning

C16 Biosciences sits at the intersection of:

- Synthetic biology  
- Sustainable ingredients  
- Fermentation manufacturing  
- Deforestation-free supply chains  

The company aims to build a **microbial replacement for agricultural oils**, starting with palm oil.

---
