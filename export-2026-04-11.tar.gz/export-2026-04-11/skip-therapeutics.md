# Skip Therapeutics

## Overview

Skip Therapeutics is an Israel-based RNA therapeutics company developing RNA-based therapies for rare genetic disorders and broader disease pathways. The company says it uses a proprietary computational discovery engine to optimize target selection and therapeutic design. [[1]](https://www.skiptx.com/)

## Technology

According to its website, Skip focuses on antisense oligonucleotide medicines designed either to restore function of mutated genes in rare disorders or to modulate key genes in broader disease pathways. The company frames its approach as computationally guided RNA therapeutic development rather than a single-asset program. [[1]](https://www.skiptx.com/)

## Investors

Skip says it was founded by the FutuRx incubator based on research from Bar-Ilan University. Its listed backers include Takeda Ventures, JJDC, OrbiMed Partners, LEAPS by Bayer, and RMG, with additional support from the Israel Innovation Authority. [[1]](https://www.skiptx.com/)

## Strategic Position

Because the company emphasizes a platform approach, its strategic differentiation appears to be the combination of computational design, academic founding science, and backing from a mix of pharma venture groups and specialist healthcare investors. [[1]](https://www.skiptx.com/)
