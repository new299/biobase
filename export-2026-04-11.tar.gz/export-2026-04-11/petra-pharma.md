# Petra Pharma

## Overview
Petra Pharma was launched in New York to develop small-molecule inhibitors for cancer and metabolic diseases, building on research from Lewis Cantley and Nathanael Gray.[[1]](https://www.gaebler.com/VC-Funding-326836F8-36CC-491F-A7B5-E4653C19DB63-Petra-Pharma-01-07-2016)[[2]](https://www.prnewswire.com/news-releases/petra-pharma-appoints-executive-and-scientific-leadership-teams-300495042.html)

## Technology
Public descriptions say Petra targeted enzymes involved in cell division, growth, trafficking, and signaling, with therapeutic ambitions in oncology and metabolic disease. Later reporting connected Petra to PIP4K2-related drug development through a Sprint Bioscience partnership.[[1]](https://www.gaebler.com/VC-Funding-326836F8-36CC-491F-A7B5-E4653C19DB63-Petra-Pharma-01-07-2016)[[3]](https://www.inderes.se/releases/sprint-biosciences-partner-petra-pharma-tar-viktigt-steg-mot-klinisk-fas-i-lakemedelsprojektet-pip4k2)

## Investors
Petra launched with a $48 million Series A in January 2016. Public financing records list investors including AbbVie Biotech Ventures, Arch Venture Partners, Accelerator Ventures, Johnson & Johnson Development Corporation, Pfizer Venture Investments, and private investors associated with Eli Lilly.[[1]](https://www.gaebler.com/VC-Funding-326836F8-36CC-491F-A7B5-E4653C19DB63-Petra-Pharma-01-07-2016)[[4]](https://www.acceleratorlsp.com/about/)

## Acquisitions / Other
I did not identify a company-level acquisition in the reviewed public sources. Public updates instead focused on executive build-out and partnered program progress.[[2]](https://www.prnewswire.com/news-releases/petra-pharma-appoints-executive-and-scientific-leadership-teams-300495042.html)[[3]](https://www.inderes.se/releases/sprint-biosciences-partner-petra-pharma-tar-viktigt-steg-mot-klinisk-fas-i-lakemedelsprojektet-pip4k2)
