# Panomics

## Overview
Panomics was a molecular-biology tools company that offered low- to mid-plex assay products for genetic, protein, and cellular analysis applications.[[1]](https://www.fiercebiotech.com/biotech/affymetrix-to-acquire-panomics) It focused on tools for what it called Parallel Quantitative Biology.[[2]](https://www.gaebler.com/Funded-Company-A9FCA146-B6D5-4145-8DC3-29420C9C6A00-Panomics)

## Technology and Products
Affymetrix's acquisition materials described Panomics as providing assay products for low- to mid-plex validation and routine testing across genes and proteins.[[1]](https://www.fiercebiotech.com/biotech/affymetrix-to-acquire-panomics) This was a tools-and-assays business rather than a therapeutics company.

## Investors
Secondary transaction and funding databases report Panomics raised at least $36.6 million from investors including HBM Healthcare Investments, Novartis BioVenture Fund, Battelle Ventures, Bay City Capital, Frazier Healthcare Partners, Comerica Bank, and 5AM Ventures.[[2]](https://www.gaebler.com/Funded-Company-A9FCA146-B6D5-4145-8DC3-29420C9C6A00-Panomics)

## Acquisitions and Corporate Activity
Affymetrix announced in November 2008 that it had entered into a definitive agreement to acquire Panomics, and the transaction closed in December 2008 for approximately $73 million in cash.[[1]](https://www.fiercebiotech.com/biotech/affymetrix-to-acquire-panomics)[[3]](https://www.technologynetworks.com/cell-science/news/affymetrix-completes-acquisition-of-panomics-185371)
