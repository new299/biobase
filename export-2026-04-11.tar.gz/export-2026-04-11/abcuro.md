# Abcuro

## Overview
Abcuro is a clinical-stage biotechnology company developing therapies for autoimmune diseases and cancer through selective modulation of highly cytotoxic T cells.[[1]](https://abcuro.com/about/)[[2]](https://abcuro.com/uncategorized/abcuro-announces-200-million-series-c-financing-to-advance-its-first-in-class-medicine-in-development-for-inclusion-body-myositis/) Its lead product candidate is ulviprubart.[[1]](https://abcuro.com/about/)

## Technology and Pipeline
Abcuro says ulviprubart is a monoclonal antibody targeting KLRG1 to selectively deplete highly cytotoxic T cells implicated in inclusion body myositis, T-LGLL, and certain T and NK cell lymphomas.[[1]](https://abcuro.com/about/) This is a targeted immunology and oncology strategy centered on cytotoxic-cell biology rather than broad immune suppression.[[1]](https://abcuro.com/about/)

## Investors
Abcuro announced in February 2025 that it closed a $200 million Series C led by NEA, with Foresite Capital joining the round and participation from RA Capital Management, Bain Capital Life Sciences, Redmile Group, Samsara BioCapital, Sanofi Ventures, Pontifax, Mass General Brigham Ventures, New Leaf Ventures, abrdn, BlackRock, Eurofarma Ventures, and Soleus Capital.[[2]](https://abcuro.com/uncategorized/abcuro-announces-200-million-series-c-financing-to-advance-its-first-in-class-medicine-in-development-for-inclusion-body-myositis/) The company’s investor page is consistent with RA Capital’s earlier involvement noted in the local note.[[3]](https://abcuro.com/about/investors/)

## Acquisitions and Corporate Activity
No acquisition involving Abcuro was identified in the reviewed public sources. The public record centers on financing and development of ulviprubart, particularly in inclusion body myositis.[[1]](https://abcuro.com/about/)[[2]](https://abcuro.com/uncategorized/abcuro-announces-200-million-series-c-financing-to-advance-its-first-in-class-medicine-in-development-for-inclusion-body-myositis/)
