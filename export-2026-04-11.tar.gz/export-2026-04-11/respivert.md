# RespiVert

## Overview
RespiVert was a drug discovery and development company focused on inhaled therapies for severe respiratory disease [[1]](https://fprimecapital.com/company/respivert/).

## Technology
F-Prime's portfolio description highlights innovative inhaled therapies for severe respiratory diseases as the company's core technological focus [[1]](https://fprimecapital.com/company/respivert/).

## Investors
F-Prime identifies itself as an investor and lists an initial investment date of 2007 [[1]](https://fprimecapital.com/company/respivert/).

## Acquisitions / Strategic Transactions
F-Prime states that RespiVert was acquired by Centocor Ortho Biotech, a division of Johnson & Johnson [[1]](https://fprimecapital.com/company/respivert/).

## References
[[1]](https://fprimecapital.com/company/respivert/)
