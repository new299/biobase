# Rheos Medicines

## Overview
Rheos Medicines is a biopharmaceutical company developing precision medicines for autoimmune and inflammatory diseases by targeting immunometabolism [[1]](https://www.businesswire.com/news/home/20220720005156/en/Rheos-Medicines-Receives-FDA-Study-May-Proceed-Letter-to-Initiate-Phase-1-Clinical-Study-Under-its-Investigational-New-Drug-Application-for-RHX-317-for-Treatment-of-Autoimmune-and-Inflammatory-Diseases) [[2]](https://www.businesswire.com/news/home/20220414005175/en/Rheos-Medicines-Announces-New-Scientific-Advisory-Board-Members).

## Technology
Its MetPM platform integrates genetic, transcriptomic, epigenomic, and metabolomic data to identify targets, biomarkers, and stratified patient populations in immune-mediated disease [[1]](https://www.businesswire.com/news/home/20220720005156/en/Rheos-Medicines-Receives-FDA-Study-May-Proceed-Letter-to-Initiate-Phase-1-Clinical-Study-Under-its-Investigational-New-Drug-Application-for-RHX-317-for-Treatment-of-Autoimmune-and-Inflammatory-Diseases).

## Investors
Rheos was founded by Third Rock Ventures [[1]](https://www.businesswire.com/news/home/20220720005156/en/Rheos-Medicines-Receives-FDA-Study-May-Proceed-Letter-to-Initiate-Phase-1-Clinical-Study-Under-its-Investigational-New-Drug-Application-for-RHX-317-for-Treatment-of-Autoimmune-and-Inflammatory-Diseases). Gaebler reports a $60 million venture-equity round in 2018 with Third Rock as investor [[3]](https://www.gaebler.com/Funded-Company-653F0535-1769-40D6-87EC-1275F58B9D7C-Rheos-Medicines).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass; the most notable public strategic milestone was Rheos receiving FDA clearance in 2022 to begin a Phase 1 study of RHX-317 [[1]](https://www.businesswire.com/news/home/20220720005156/en/Rheos-Medicines-Receives-FDA-Study-May-Proceed-Letter-to-Initiate-Phase-1-Clinical-Study-Under-its-Investigational-New-Drug-Application-for-RHX-317-for-Treatment-of-Autoimmune-and-Inflammatory-Diseases).

## References
[[1]](https://www.businesswire.com/news/home/20220720005156/en/Rheos-Medicines-Receives-FDA-Study-May-Proceed-Letter-to-Initiate-Phase-1-Clinical-Study-Under-its-Investigational-New-Drug-Application-for-RHX-317-for-Treatment-of-Autoimmune-and-Inflammatory-Diseases)
[[2]](https://www.businesswire.com/news/home/20220414005175/en/Rheos-Medicines-Announces-New-Scientific-Advisory-Board-Members)
[[3]](https://www.gaebler.com/Funded-Company-653F0535-1769-40D6-87EC-1275F58B9D7C-Rheos-Medicines)
