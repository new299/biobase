# Genomics plc (Genomics Ltd) — Research Notes

## Overview

Genomics plc (trading as "Genomics Ltd" on LinkedIn) is an Oxford, UK-based genomics company founded in 2014 by a team of world-leading statistical and human geneticists at the University of Oxford, including Professor Sir Peter Donnelly and Professor Gil McVean. The company is pioneering "genomic prevention" — using large-scale genetic data to generate personalized polygenic risk scores (PRS) for common diseases well before symptoms manifest, enabling proactive preventive care. Total raised: ~$142M+. Key investors: F-Prime Capital, Foresite Capital, ARCH Venture Partners, Lux Capital, Molten Ventures, Mubadala, General Catalyst, Oxford Sciences Innovation. [[1]](https://www.fprimecapital.com/company/genomics-plc/) [[2]](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)

---

## Technology

- **Genomic Prevention**: Paradigm-shifting approach to healthcare — using large-scale genomic data to estimate individualized lifetime disease risk for common conditions (e.g., heart disease, cancer, diabetes, Alzheimer's) well ahead of onset, enabling targeted preventive interventions. [[2]](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)
- **Genomics Analysis Engine**: Proprietary PRS engine — one of the largest of its kind globally, containing 100+ billion data points. Uses statistical genetics to understand human biology and predict drug efficacy and safety for novel medicines. [[2]](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)
- **Drug Discovery**: Genetics-based target identification and validation for pharmaceutical partners — applying statistical genomics to understand disease mechanisms and likely drug response. [[2]](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Early | ~2014–2019 | — | Oxford Sciences Innovation, ARCH Venture Partners |
| Series B | — | £33M (~$42M) | Foresite Capital, F-Prime Capital, Lansdowne Partners, Oxford Sciences Innovation |
| Series C | — | $30M oversubscribed | Foresite Capital (co-lead), F-Prime Capital (co-lead) |
| Total | — | ~$142M+ | — |

**F-Prime Capital Investment**

[[1]](https://www.fprimecapital.com/company/genomics-plc/) [[2]](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)

---

## References

1. F-Prime Capital — Genomics Ltd portfolio page: [https://www.fprimecapital.com/company/genomics-plc/](https://www.fprimecapital.com/company/genomics-plc/)
2. Genomics plc — $30M Series C announcement: [https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round](https://www.genomics.com/newsroom/genomics-plc-completes-oversubscribed-30m-funding-round)
3. Genomics plc — Series B second close £33M: [https://www.genomics.com/newsroom/genomics-plc-today-announces-second-close-of-its-series-b-financing-raising-a-further-ps8-million-bringing-the-total-round-to-ps33-million](https://www.genomics.com/newsroom/genomics-plc-today-announces-second-close-of-its-series-b-financing-raising-a-further-ps8-million-bringing-the-total-round-to-ps33-million)
