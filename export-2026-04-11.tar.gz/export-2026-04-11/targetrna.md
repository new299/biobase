# TargetRNA

## Overview

TargetRNA is a biotechnology company developing small-molecule drugs that act directly on disease-causing RNA. The company says it is focused on discovering and developing medicines that bind RNA and alter its structure and function. [[1]](https://www.targetrna.com/)

## Technology

Its platform is anchored by NMR-guided biophysics and computation. TargetRNA says it uses NMR-derived ligand binding data to guide molecular dynamics simulations and build structural models of RNA-ligand interactions, with the goal of improving the success rate of lead compounds entering preclinical testing. [[1]](https://www.targetrna.com/)

## Investors And Funding

I did not find a clearly disclosed financing history in the accessible public sources reviewed for this note. The public website is highly technology-focused and does not list investors or named financing rounds. [[1]](https://www.targetrna.com/)

## Strategic Position

TargetRNA is best understood as an RNA-targeting small molecule platform company rather than an RNA therapeutics delivery or oligonucleotide business. The combination of structural biology, NMR, and computational modeling is its clearest stated differentiator. [[1]](https://www.targetrna.com/)
