# InFocus Therapeutics

## Overview
InFocus Therapeutics is a startup focused on sustained ocular drug delivery using lens-based technology.[[1]](https://www.infocustherapeutics.com/)

## Technology
The company says it is developing a lens-based platform to provide sustained drug delivery to the eye, with applications across ophthalmic disease.[[1]](https://www.infocustherapeutics.com/)

## Investors
I did not identify a detailed financing announcement in the reviewed public sources. The visible public footprint is still minimal.[[1]](https://www.infocustherapeutics.com/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.infocustherapeutics.com/)
