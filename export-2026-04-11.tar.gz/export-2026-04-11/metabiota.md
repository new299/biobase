# Metabiota

## Overview

Metabiota was an infectious disease intelligence and epidemic risk analytics company serving public health, insurers, and governments.[[1]](https://www.ginkgobioworks.com/2022/08/31/ginkgo-bioworks-announces-the-acquisition-of-key-biological-threat-detection-intelligence-assets-from-metabiota-inc/)

## Technology

Metabiota's capabilities combined epidemiology, data science, and disease intelligence to assess outbreak risk and biological threats.[[1]](https://www.ginkgobioworks.com/2022/08/31/ginkgo-bioworks-announces-the-acquisition-of-key-biological-threat-detection-intelligence-assets-from-metabiota-inc/) The business was more data/analytics-driven than therapeutics-focused.

## Investors

The reviewed public sources in this pass are strongest on the company's asset sale rather than its earlier financing history, so this note does not attempt to reconstruct the full investor syndicate.

## Acquisitions and Strategic Transactions

In August 2022, Ginkgo Bioworks announced acquisition of key biological threat detection and intelligence assets from Metabiota, including specific programs, software, biological databases, and the technical staff team.[[1]](https://www.ginkgobioworks.com/2022/08/31/ginkgo-bioworks-announces-the-acquisition-of-key-biological-threat-detection-intelligence-assets-from-metabiota-inc/) The asset deal followed Metabiota's financial distress and effectively represented the public endpoint of the standalone company in the reviewed sources.[[1]](https://www.ginkgobioworks.com/2022/08/31/ginkgo-bioworks-announces-the-acquisition-of-key-biological-threat-detection-intelligence-assets-from-metabiota-inc/)
