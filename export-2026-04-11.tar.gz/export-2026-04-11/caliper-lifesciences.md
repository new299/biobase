# Caliper Lifesciences

## Overview
Caliper Life Sciences was a life-science tools company producing instruments, software, reagents, automation tools, and services for life-science research and drug development.[[1]](https://www.perkinelmer.com/news-media/2011/perkinelmer-acquires-caliper-life-sciences) It operated in research tools rather than therapeutics.

## Technology and Products
PerkinElmer’s acquisition release described Caliper as providing products and services in life sciences, diagnostics, and laboratory automation, including imaging technologies and microfluidics-related solutions.[[1]](https://www.perkinelmer.com/news-media/2011/perkinelmer-acquires-caliper-life-sciences) Caliper also divested Xenogen Biosciences in 2009, illustrating its portfolio of research services and in vivo technologies.[[2]](https://www.taconic.com/resources/taconic-acquires-xenogen-biosciences-subsidiary-of-caliper-life-sciences)

## Investors
The local note references Venrock, which aligns with Caliper’s historical venture-backed origins. The strongest reviewed primary sources for this pass focused on later strategic transactions rather than early financing.

## Acquisitions and Corporate Activity
PerkinElmer completed its acquisition of Caliper Life Sciences in November 2011 in a transaction valued at approximately $600 million.[[1]](https://www.perkinelmer.com/news-media/2011/perkinelmer-acquires-caliper-life-sciences) Earlier, Taconic acquired Caliper’s Xenogen Biosciences subsidiary in December 2009.[[2]](https://www.taconic.com/resources/taconic-acquires-xenogen-biosciences-subsidiary-of-caliper-life-sciences)
