# Kinnate Biopharma

## Overview

Kinnate Biopharma was a clinical-stage precision oncology company developing targeted therapies against oncogenic drivers lacking satisfactory treatment options.[[1]](https://investors.xoma.com/news-events/press-releases/detail/447/xoma-enters-into-agreement-to-acquire-kinnate) Its lead programs included exarafenib, a pan-RAF inhibitor, and KIN-3248, an FGFR inhibitor.[[1]](https://investors.xoma.com/news-events/press-releases/detail/447/xoma-enters-into-agreement-to-acquire-kinnate)

## Technology

Kinnate focused on small-molecule precision oncology. XOMA's acquisition announcement described the company as addressing oncogenic drivers with no approved targeted therapies and overcoming non-responsiveness and acquired or intrinsic resistance.[[1]](https://investors.xoma.com/news-events/press-releases/detail/447/xoma-enters-into-agreement-to-acquire-kinnate)

## Investors

Kinnate was a Nasdaq-listed public company by the time of its sale. The local note referenced RA Capital, which is directionally consistent with Kinnate's biotech shareholder base, but the strongest reviewed sources here focus on the public-company endgame rather than early private financings.[[1]](https://investors.xoma.com/news-events/press-releases/detail/447/xoma-enters-into-agreement-to-acquire-kinnate)

## Acquisitions and Strategic Transactions

XOMA announced in February 2024 that it would acquire Kinnate for $2.3352 to $2.5879 in cash per share plus a contingent value right, and closed the tender offer on April 3, 2024.[[1]](https://investors.xoma.com/news-events/press-releases/detail/447/xoma-enters-into-agreement-to-acquire-kinnate) [[2]](https://investors.xoma.com/news-events/press-releases/detail/452/xoma-corporation-announces-closing-of-tender-offer) In April 2025, XOMA said it had sold all five Kinnate pipeline assets for up to $270 million in upfront and milestone payments plus royalties.[[3]](https://investors.xoma.com/news-events/press-releases/detail/472/xoma-royalty-completes-sale-of-kinnate-pipeline-assets)
