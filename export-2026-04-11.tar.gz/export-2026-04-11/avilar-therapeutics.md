# Avilar Therapeutics

## Overview
Avilar Therapeutics is a biotechnology company developing extracellular protein degraders for autoimmune, neurological, and other diseases.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/) The company positions itself as extending the logic of targeted protein degradation beyond intracellular proteins.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/)

## Technology
Avilar’s ATAC platform is designed to degrade extracellular proteins using bifunctional molecules that bring target proteins to asialoglycoprotein receptors for lysosomal clearance.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/) This creates a distinct approach to degrading secreted or extracellular disease-driving proteins.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/)

## Investors
Avilar announced in February 2023 that it upsized its seed financing to $75 million. Founder RA Capital Management remained part of the syndicate, joined by Sanofi Ventures, Medical Excellence Capital, and Astellas Venture Management.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/)

## Acquisitions and Corporate Activity
No acquisition involving Avilar was identified in the reviewed public sources. The public record centers on its seed financing and early pipeline advancement in extracellular protein degradation.[[1]](https://avilar-tx.com/news/avilar-therapeutics-increases-financing-to-75-million-to-advance-pipeline-of-novel-extracellular-protein-degraders/)
