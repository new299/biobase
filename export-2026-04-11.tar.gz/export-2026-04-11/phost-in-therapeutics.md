# Phost'in Therapeutics

## Overview
Phost’in Therapeutics is a clinical-stage French biotech developing first-in-class N-glycosylation inhibitors for cancer and fibrotic diseases.[[1]](https://www.phostin.com/phostin-therapeutics-raises-e10-3m-to-develop-first-in-class-n-glycosylation-inhibitors-for-cancer-treatment/)[[2]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-announce-first-patients-dosed/)[[3]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-to-present-first-clinical-data-on-phox430-a-first-in-class-gnt-v-inhibitor-at-esmo-2025/)

## Technology
The company’s lead program is PhOx430, a selective GnT-V/N-glycosylation inhibitor. Public materials position the platform around glycosylation-targeting therapeutics and a broader Phost’screen discovery engine.[[2]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-announce-first-patients-dosed/)[[3]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-to-present-first-clinical-data-on-phox430-a-first-in-class-gnt-v-inhibitor-at-esmo-2025/)

## Investors
Phost’in announced a €10.3 million Series A in April 2020 led by Remiges Ventures with participation from ANRI and IrdiSoridec Gestion. In September 2020, it also announced €2.5 million in non-dilutive funding from Bpifrance.[[1]](https://www.phostin.com/phostin-therapeutics-raises-e10-3m-to-develop-first-in-class-n-glycosylation-inhibitors-for-cancer-treatment/)[[4]](https://www.phostin.com/phostin-therapeutics-announces-e2-5m-funding-from-bpifrance-to-support-regulatory-and-early-clinical-development-of-its-first-in-class-n-glycosylation-inhibitor/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Public updates indicate first-in-human dosing began in 2022 and first clinical data were presented in 2025.[[2]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-announce-first-patients-dosed/)[[3]](https://www.phostin.com/phostin-therapeutics-and-the-gianni-bonadonna-foundation-to-present-first-clinical-data-on-phox430-a-first-in-class-gnt-v-inhibitor-at-esmo-2025/)
