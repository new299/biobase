# Eyconis — Research Notes

## Overview

Eyconis, Inc. is a Redwood City, CA-based ophthalmology biopharmaceutical company formed in January 2024 to develop, manufacture, and commercialize Ascendis Pharma's TransCon ophthalmology assets globally. The company launched with a $150M commitment from external investors including Frazier Life Sciences, RA Capital Management, venBio, and HealthQuest Capital. Ascendis Pharma retains an equity position in Eyconis and is eligible to receive development, regulatory, and sales milestones up to $248M plus royalties. [[1]](https://www.globenewswire.com/news-release/2024/01/29/2818910/0/en/New-Company-Eyconis-Formed-to-Develop-Ascendis-Pharma-Ophthalmology-Assets-with-150-Million-Commitment-from-External-Investors.html)

---

## Technology & Pipeline

- **TransCon Ophthalmology Platform**: Licensed exclusively from Ascendis Pharma. TransCon (Transient Conjugation) technology links active drugs to a carrier molecule that gradually releases the active compound over time — enabling sustained release and reduced injection frequency for retinal diseases.
- **Target Indications**: Wet age-related macular degeneration (AMD), diabetic macular edema (DME), retinal vein occlusion (RVO), and geographic atrophy (GA).

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Founding/Series A | Jan 2024 | $150M committed | Frazier Life Sciences (lead), RA Capital Management, venBio, HealthQuest Capital |

Total committed: $150M. Ascendis Pharma holds equity stake + up to $248M in milestones + royalties. [[1]](https://www.globenewswire.com/news-release/2024/01/29/2818910/0/en/New-Company-Eyconis-Formed-to-Develop-Ascendis-Pharma-Ophthalmology-Assets-with-150-Million-Commitment-from-External-Investors.html)

---

## References

1. GlobeNewswire — New company Eyconis formed with $150M commitment (Jan 2024): [https://www.globenewswire.com/news-release/2024/01/29/2818910/0/en/New-Company-Eyconis-Formed-to-Develop-Ascendis-Pharma-Ophthalmology-Assets-with-150-Million-Commitment-from-External-Investors.html](https://www.globenewswire.com/news-release/2024/01/29/2818910/0/en/New-Company-Eyconis-Formed-to-Develop-Ascendis-Pharma-Ophthalmology-Assets-with-150-Million-Commitment-from-External-Investors.html)
2. Fierce Biotech — Ascendis spins out Eyconis with $150M: [https://www.fiercebiotech.com/biotech/ascendis-spins-out-new-ophthalmology-biotech-eyconis-gaining-equity-and-biobucks](https://www.fiercebiotech.com/biotech/ascendis-spins-out-new-ophthalmology-biotech-eyconis-gaining-equity-and-biobucks)
