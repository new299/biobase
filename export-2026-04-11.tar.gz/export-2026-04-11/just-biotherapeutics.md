# JUST Biotherapeutics

## Overview

JUST Biotherapeutics (`Just.Bio`) was a Seattle-based technology company focused on the design, development, and manufacturing of biologics using machine learning and modular manufacturing systems.[[1]](https://www.evotec.com/en/news/evotec-jump-starts-biologics-with-acquisition-of-just-biotherapeutics) [[2]](https://www.evotec.com/news/evotec-completes-acquisition-of-just-biotherapeutics)

## Technology

Evotec described Just.Bio's integrated technology platform as `J.DESIGN`, which included J.MD for machine-learning-assisted molecule selection and process development, JP3 for rapid development of high-yield manufacturing processes, and J.POD for flexible and modular manufacturing at larger scale.[[2]](https://www.evotec.com/news/evotec-completes-acquisition-of-just-biotherapeutics)

## Investors

When Evotec completed its acquisition in July 2019, it said the cash consideration for 100% of the company would be paid to a syndicate of institutional investors consisting of ARCH Venture Partners, Merck & Co., Lilly Asia Ventures, and the Bill & Melinda Gates Foundation.[[2]](https://www.evotec.com/news/evotec-completes-acquisition-of-just-biotherapeutics) GeekWire separately reported that the Gates Foundation had led a $14 million financing round in 2016.[[3]](https://www.geekwire.com/2019/just-biotherapeutics-backed-gates-foundation-snapped-german-biotech-firm-90m/)

## Acquisitions and Strategic Transactions

Evotec signed a definitive agreement in May 2019 to acquire Just.Bio for up to $90 million including earn-outs and completed the acquisition in July 2019.[[1]](https://www.evotec.com/en/news/evotec-jump-starts-biologics-with-acquisition-of-just-biotherapeutics) [[2]](https://www.evotec.com/news/evotec-completes-acquisition-of-just-biotherapeutics)
