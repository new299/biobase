# Kilobaser

## Overview

Kilobaser is an Austrian life science tools company developing benchtop DNA and RNA synthesizers for on-demand oligonucleotide production.[[1]](https://kilobaser.com/) The company markets its system as a personal synthesizer designed to give laboratories faster, more independent access to custom nucleic acids.[[1]](https://kilobaser.com/)

## Technology

Kilobaser's core product is a microfluidic chip and cartridge-based DNA/RNA synthesizer. The company says the platform supports standard DNA as well as modified DNA and RNA depending on system configuration, with a small benchtop form factor and guided workflows for lab users.[[2]](https://kilobaser.com/dna-and-rna-synthesizer) The firm also highlights applications in probes, modified RNA, data storage-related DNA applications, and related oligonucleotide workflows.[[1]](https://kilobaser.com/)

## Investors

No clearly disclosed institutional financing round or investor syndicate was identified in the reviewed public sources. The current public footprint is heavily product- and customer-facing rather than finance-facing.[[1]](https://kilobaser.com/) [[2]](https://kilobaser.com/dna-and-rna-synthesizer)

## Acquisitions and Strategic Transactions

No acquisition involving Kilobaser was identified in the reviewed sources. Based on the public materials reviewed, the company appears focused on commercial expansion of its synthesis instrument platform.[[1]](https://kilobaser.com/)
