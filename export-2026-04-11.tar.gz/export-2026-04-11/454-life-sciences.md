# 454 Life Sciences — Research Notes

## Overview

454 Life Sciences was a DNA sequencing company founded by Jonathan Rothberg, based in Branford, Connecticut. Originally a subsidiary of CuraGen Corporation. Pioneered next-generation sequencing (NGS) with massively parallel pyrosequencing. Acquired by Roche Diagnostics in 2007 for $154.9M; platform discontinued 2013–2016. [[1]](https://en.wikipedia.org/wiki/454_Life_Sciences) [[2]](https://www.genengnews.com/news/roche-buys-454-for-154-9m/)

**Founder:** Jonathan Rothberg (motivated by genomic research challenges following his infant son's hospitalization in 1999). [[1]](https://en.wikipedia.org/wiki/454_Life_Sciences)

---

## Technology

- **Pyrosequencing / Sequencing-by-Synthesis**: Array-based massively parallel bead-amplification sequencing using luciferase light signal detection. Licensed from pyrosequencing IP. [[1]](https://en.wikipedia.org/wiki/454_Life_Sciences)
- **GS20 Sequencer** (2005): First commercial next-generation DNA sequencer; produced ~200bp reads at ~20Mb per run. [[3]](https://pmc.ncbi.nlm.nih.gov/articles/PMC2347365/)
- **GS FLX / Titanium series**: Subsequent instruments extending read lengths to ~700bp, enabling de novo assembly and metagenomics.
- Key advantage: long reads compared to early Illumina. Key weaknesses: homopolymer errors and higher per-base cost eventually ceded market to Illumina. [[4]](https://www.bio-itworld.com/news/2013/10/16/six-years-after-acquisition-roche-quietly-shutters-454)

---

## Funding & Investors / Acquisition

- **May 2005**: Roche Diagnostics signed exclusive worldwide distribution agreement with 454.
- **March 2007**: Roche Diagnostics acquired 454 Life Sciences for **$154.9 million**. [[2]](https://www.genengnews.com/news/roche-buys-454-for-154-9m/) [[5]](https://www.bioprocessonline.com/doc/454-life-sciences-announces-the-completion-of-0001)
- **October 2013**: Roche announced shutdown of 454 sequencing business; support ceased mid-2016. [[4]](https://www.bio-itworld.com/news/2013/10/16/six-years-after-acquisition-roche-quietly-shutters-454)

---

## Key Patents

454 Life Sciences held foundational NGS patents on emulsion PCR bead amplification and pyrosequencing array readout. These were licensed broadly and were central to Roche's genomics portfolio post-acquisition. [[1]](https://en.wikipedia.org/wiki/454_Life_Sciences)

---

## References

1. Wikipedia — 454 Life Sciences: `https://en.wikipedia.org/wiki/454_Life_Sciences` | [https://en.wikipedia.org/wiki/454_Life_Sciences](https://en.wikipedia.org/wiki/454_Life_Sciences)
2. Genetic Engineering News — Roche acquisition: [https://www.genengnews.com/news/roche-buys-454-for-154-9m/](https://www.genengnews.com/news/roche-buys-454-for-154-9m/)
3. PMC — 454 Life Sciences overview: [https://pmc.ncbi.nlm.nih.gov/articles/PMC2347365/](https://pmc.ncbi.nlm.nih.gov/articles/PMC2347365/)
4. Bio-IT World — Shutdown: [https://www.bio-itworld.com/news/2013/10/16/six-years-after-acquisition-roche-quietly-shutters-454](https://www.bio-itworld.com/news/2013/10/16/six-years-after-acquisition-roche-quietly-shutters-454)
5. BioProcess Online — Acquisition completion: [https://www.bioprocessonline.com/doc/454-life-sciences-announces-the-completion-of-0001](https://www.bioprocessonline.com/doc/454-life-sciences-announces-the-completion-of-0001)
