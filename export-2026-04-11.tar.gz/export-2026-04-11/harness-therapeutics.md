# Harness Therapeutics — Research Notes

## Overview

Harness Therapeutics (formerly Transine Therapeutics) is a Cambridge, UK-based biotechnology company developing miRNA site-blocking constructs to drive controlled upregulation of target proteins in neurodegenerative diseases. The company's MISBA® (miRNA Site-Blocking Antisense) and MISBA® Duo platforms selectively block endogenous miRNA suppression of disease-relevant genes — enabling physiological increases in protective protein levels without overexpression. Lead program targets FAN1 nuclease in Huntington's Disease, with additional programs in ALS, Alzheimer's Disease, and Parkinson's Disease. Total raised: ~$23M. Key investors: SV Health Investors, Epidarex Capital, Takeda Ventures, Ono Venture Investment; collaboration with Ono Pharmaceutical. [[1]](https://www.harnesstx.com/) [[2]](https://svhealthinvestors.com/news/harness-therapeutics-secures-additional-4-million-funding-to-pursue-physiological-upregulation-approach-to-treat-neurodegenerative-diseases) [[3]](https://svhealthinvestors.com/news/harness-therapeutics-announces-launch-of-misba-duo-platform-and-research-collaboration-with-ono-venture-investment)

---

## Technology & Pipeline

- **MISBA® Platform (miRNA Site-Blocking Antisense)**: DNA-based oligonucleotides that specifically block the binding of endogenous miRNAs to their target mRNAs — enabling controlled, physiological upregulation of target proteins rather than knockdown, addressing loss-of-function neurodegenerative pathologies. [[1]](https://www.harnesstx.com/)
- **MISBA® Duo**: Next-generation bispecific platform targeting two miRNA binding sites on a target mRNA simultaneously for enhanced upregulation. [[3]](https://svhealthinvestors.com/news/harness-therapeutics-announces-launch-of-misba-duo-platform-and-research-collaboration-with-ono-venture-investment)
- **Lead Program (Huntington's Disease — FAN1)**: Targets FAN1 nuclease; FAN1 levels modify somatic CAG repeat expansion and neuroprotection in HD; MISBA upregulates FAN1 to slow disease progression. [[1]](https://www.harnesstx.com/)
- **Additional Programs**: Nuclear import receptors for ALS and Alzheimer's Disease; Parkinson's Disease program in development. [[2]](https://svhealthinvestors.com/news/harness-therapeutics-secures-additional-4-million-funding-to-pursue-physiological-upregulation-approach-to-treat-neurodegenerative-diseases)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Early rounds | — | — | SV Health Investors, Epidarex Capital, Takeda Ventures, Dementia Discovery Fund |
| Series A | Jan 2025 | — | Ono Venture Investment (new), Takeda Ventures, SV Health Investors |
| Total | — | ~$23M | — |

[[2]](https://svhealthinvestors.com/news/harness-therapeutics-secures-additional-4-million-funding-to-pursue-physiological-upregulation-approach-to-treat-neurodegenerative-diseases)

---

## References

1. Harness Therapeutics — Homepage: [https://www.harnesstx.com/](https://www.harnesstx.com/)
2. SV Health Investors — Harness additional £4M funding: [https://svhealthinvestors.com/news/harness-therapeutics-secures-additional-4-million-funding-to-pursue-physiological-upregulation-approach-to-treat-neurodegenerative-diseases](https://svhealthinvestors.com/news/harness-therapeutics-secures-additional-4-million-funding-to-pursue-physiological-upregulation-approach-to-treat-neurodegenerative-diseases)
3. SV Health Investors — Harness MISBA Duo + Ono collaboration: [https://svhealthinvestors.com/news/harness-therapeutics-announces-launch-of-misba-duo-platform-and-research-collaboration-with-ono-venture-investment](https://svhealthinvestors.com/news/harness-therapeutics-announces-launch-of-misba-duo-platform-and-research-collaboration-with-ono-venture-investment)
