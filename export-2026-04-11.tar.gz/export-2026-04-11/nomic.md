# Nomic

## Overview
Nomic is a proteomics company focused on high-throughput, lower-cost protein profiling.[[1]](https://nomic.bio/)[[2]](https://www.nomic.bio/resources/nomic-closes-17-million-series-a-to-develop-and-commercialize-the-worlds-highest-throughput-proteomic-platform) The company markets an end-to-end service built around its nELISA platform and, more recently, the Omni 1000 product line.[[1]](https://nomic.bio/)[[3]](https://www.nomic.bio/resources/nomic-debuts-50-proteome)

## Technology
Nomic says its core technology re-engineers the sandwich immunoassay using DNA as a flexible programmable linker, enabling multiplexed protein measurement at scale.[[1]](https://nomic.bio/) The company positions nELISA and Omni 1000 as platforms for broad, quantitative proteomic profiling with high throughput and lower cost per sample.[[1]](https://nomic.bio/)[[3]](https://www.nomic.bio/resources/nomic-debuts-50-proteome)

## Investors
In December 2021, Nomic announced a $17 million Series A led by Lux Capital, joined by SR One and Casdin Capital, with participation from prior institutional investors.[[2]](https://www.nomic.bio/resources/nomic-closes-17-million-series-a-to-develop-and-commercialize-the-worlds-highest-throughput-proteomic-platform) In September 2024, it announced a $42 million oversubscribed Series B with participation from Amplitude Ventures, AVANT BIO, Lux Capital, Real Ventures, and SR One, bringing total capital raised to more than $60 million.[[4]](https://info.nomic.bio/news/nomic-secures-42m-series-b)[[5]](https://www.nomic.bio/resources/nomic-r-secures-42m-in-oversubscribed-series-b-to-expand-access-to-protein-profiling)

## Acquisitions and Corporate Activity
No acquisition involving Nomic was identified in the reviewed public sources. The clearest public corporate milestones are its financings and commercial launch of Omni 1000 in May 2025.[[3]](https://www.nomic.bio/resources/nomic-debuts-50-proteome)
