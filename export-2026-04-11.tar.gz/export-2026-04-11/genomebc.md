# Genome BC — Research Notes

## Overview

Genome BC (Genome British Columbia) is a Vancouver-based not-for-profit organization founded in 2000, supporting world-class genomics research and innovation to grow British Columbia's life sciences sector and deliver benefits for BC, Canada, and beyond. The organization is primarily funded by the Province of British Columbia and the Government of Canada (through Genome Canada and Western Economic Diversification Canada). Over its 25-year history, Genome BC has attracted over C$1.1 billion in direct co-investment to the province and funded 600+ genomics research and innovation projects. In April 2025, Genome BC secured >C$49M for genomics research and 5 precision health projects. [[1]](https://www.genomebc.ca/) [[2]](https://www.newswire.ca/news-releases/genome-bc-20-years-putting-bc-at-the-forefront-of-global-life-sciences-812475896.html) [[3]](https://www.bctechnology.com/news/2025/4/2/Genome-BC-Secures-More-Than-49M-for-Genomics-Research-and-5-Precision-Health-Projects-to-Be-Conducted-in-British-Columbia.cfm)

---

## Focus Areas & Programs

- **Precision Health**: Genomics-driven precision medicine programs for BC's population, including rare disease, cancer genomics, and pharmacogenomics. [[1]](https://www.genomebc.ca/)
- **Natural Resources Genomics**: Applications in forestry, fisheries & aquaculture, agrifood, energy, mining, and environment — supporting BC's primary resource sectors. [[1]](https://www.genomebc.ca/)
- **Research Funding & Partnerships**: Funds multi-year collaborative research projects through competitive grants, co-investing alongside federal, academic, and industry partners. [[2]](https://www.newswire.ca/news-releases/genome-bc-20-years-putting-bc-at-the-forefront-of-global-life-sciences-812475896.html)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2000 | Vancouver, BC; not-for-profit |
| Provincial/Federal funding | Ongoing | Province of BC, Genome Canada, Western Economic Diversification |
| BC Budget genomics allocation | 2022 | C$78M provincial allocation |
| Total co-investment attracted | 2000–2025 | >C$1.1B |
| 2025 funding announcement | Apr 2025 | >C$49M for genomics + 5 precision health projects |

[[3]](https://www.bctechnology.com/news/2025/4/2/Genome-BC-Secures-More-Than-49M-for-Genomics-Research-and-5-Precision-Health-Projects-to-Be-Conducted-in-British-Columbia.cfm)

---

## References

1. Genome BC — Homepage: [https://www.genomebc.ca/](https://www.genomebc.ca/)
2. Newswire — Genome BC 20 years: [https://www.newswire.ca/news-releases/genome-bc-20-years-putting-bc-at-the-forefront-of-global-life-sciences-812475896.html](https://www.newswire.ca/news-releases/genome-bc-20-years-putting-bc-at-the-forefront-of-global-life-sciences-812475896.html)
3. BC Technology — Genome BC $49M Apr 2025: [https://www.bctechnology.com/news/2025/4/2/Genome-BC-Secures-More-Than-49M-for-Genomics-Research-and-5-Precision-Health-Projects-to-Be-Conducted-in-British-Columbia.cfm](https://www.bctechnology.com/news/2025/4/2/Genome-BC-Secures-More-Than-49M-for-Genomics-Research-and-5-Precision-Health-Projects-to-Be-Conducted-in-British-Columbia.cfm)
