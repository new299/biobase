# Reactive Biosciences

## Overview
Reactive Biosciences is a drug-discovery company developing medicines based on boron chemistry and targeting historically hard-to-drug biology [[1]](https://www.reactivebio.com/) [[2]](https://www.reactivebio.com/about/).

## Technology
The company says it uses a boron-based discovery platform to access novel binding sites and advance therapeutics in areas previously considered undruggable [[2]](https://www.reactivebio.com/about/).

## Investors
Public funding databases indicate the company has raised private capital and debt financing, with CB Insights reporting approximately $43.18 million raised across multiple rounds and The Company Check reporting $23.5 million across two named rounds [[3]](https://www.cbinsights.com/company/reactive-biosciences/financials) [[4]](https://www.thecompanycheck.com/company/b/reactive-biosciences/fd8en6kimad4vqfqx).

## Acquisitions / Strategic Transactions
The reviewed public materials did not surface a major acquisition. The main strategic developments visible were financing rounds and the company's repositioning from Boragen to Reactive Biosciences in profile databases [[3]](https://www.cbinsights.com/company/reactive-biosciences/financials) [[5]](https://www.cbinsights.com/company/reactive-biosciences).

## References
[[1]](https://www.reactivebio.com/)
[[2]](https://www.reactivebio.com/about/)
[[3]](https://www.cbinsights.com/company/reactive-biosciences/financials)
[[4]](https://www.thecompanycheck.com/company/b/reactive-biosciences/fd8en6kimad4vqfqx)
[[5]](https://www.cbinsights.com/company/reactive-biosciences)
