# Biomics Biotechnology — Research Notes

## Overview

Biomics Biotechnologies (Nantong) Co., Ltd. is a Nantong, Jiangsu, China-based RNAi therapeutics company founded in 2006 by Dr. York Zhu (returnee from the US). Focuses on R&D and industrialization of small nucleic acid drugs (siRNA-based therapeutics). Has a 10,000 sq m pilot facility on 100 acres of industrial land in Nantong. [[1]](https://www.bionity.com/en/companies/24037/biomics-biotechnologies-nantong-co-ltd.html) [[2]](https://www.biospectrumasia.com/influencers/44/7986/biomics-turns-rnai-into-therapeutics.html)

---

## Technology

- **RNAi Therapeutics (siRNA)**: Platform for development of siRNA-based drugs targeting disease-causing genes. Capabilities include large-scale RNA chemical synthesis (up to 100g), RNA modification and labeling. [[2]](https://www.biospectrumasia.com/influencers/44/7986/biomics-turns-rnai-into-therapeutics.html)
- **Drug Discovery Platform**: Combined platform for drug target screening and identification, siRNA structure modification, and drug delivery system development. [[2]](https://www.biospectrumasia.com/influencers/44/7986/biomics-turns-rnai-into-therapeutics.html)
- ~100 employees; 10,000 sq m GMP-capable pilot facility. [[1]](https://www.bionity.com/en/companies/24037/biomics-biotechnologies-nantong-co-ltd.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Various | ~2006–present | Undisclosed | Chinese government grants, private |

Limited public funding information available. [[1]](https://www.bionity.com/en/companies/24037/biomics-biotechnologies-nantong-co-ltd.html)

---

## References

1. Bionity — Biomics Biotechnologies (Nantong) profile: [https://www.bionity.com/en/companies/24037/biomics-biotechnologies-nantong-co-ltd.html](https://www.bionity.com/en/companies/24037/biomics-biotechnologies-nantong-co-ltd.html)
2. BioSpectrum Asia — Biomics turns RNAi into therapeutics: [https://www.biospectrumasia.com/influencers/44/7986/biomics-turns-rnai-into-therapeutics.html](https://www.biospectrumasia.com/influencers/44/7986/biomics-turns-rnai-into-therapeutics.html)
