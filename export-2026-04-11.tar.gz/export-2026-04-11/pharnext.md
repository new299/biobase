# Pharnext

## Overview
Pharnext was a late-clinical-stage biopharmaceutical company developing new drug combinations for neurodegenerative diseases using genomics- and AI-enabled discovery approaches, especially its PXT3003 program for Charcot-Marie-Tooth disease type 1A.[[1]](https://www.businesswire.com/news/home/20210610005530/en/Alpha-Blue-Ocean-Pharnext-Announce-the-Signing-of-a-Financing-Agreement-for-up-to-81-Million-Euros)[[2]](https://live.euronext.com/en/products/equities/company-news/2024-01-17-pharnext-commits-drastic-cost-cutting-plan-and-receives)

## Technology
The company described its model as combining genomics big data and AI to create innovative drug combinations, branded around its PLEOTHERAPY approach. Public financing and exchange notices centered heavily on PXT3003 for CMT1A.[[1]](https://www.businesswire.com/news/home/20210610005530/en/Alpha-Blue-Ocean-Pharnext-Announce-the-Signing-of-a-Financing-Agreement-for-up-to-81-Million-Euros)[[2]](https://live.euronext.com/en/products/equities/company-news/2024-01-17-pharnext-commits-drastic-cost-cutting-plan-and-receives)

## Investors / Financing
Pharnext announced an €11 million financing in February 2021 through a capital raise and convertible bonds, then an additional financing agreement with Alpha Blue Ocean in June 2021 for up to €81 million. In January 2024 it disclosed a drastic cost-cutting plan and support from financial partners to continue development of PXT3003.[[3]](https://www.biospace.com/pharnext-announces-financing-of-11-million-through-a-capital-raise-subscribed-by-existing-shareholders-and-a-convertible-bonds-issued-to-european-investors)[[1]](https://www.businesswire.com/news/home/20210610005530/en/Alpha-Blue-Ocean-Pharnext-Announce-the-Signing-of-a-Financing-Agreement-for-up-to-81-Million-Euros)[[2]](https://live.euronext.com/en/products/equities/company-news/2024-01-17-pharnext-commits-drastic-cost-cutting-plan-and-receives)

## Acquisitions / Other
I did not identify a company-level acquisition in the reviewed public sources. Later public updates focused on restructuring and financing support rather than M&A.[[2]](https://live.euronext.com/en/products/equities/company-news/2024-01-17-pharnext-commits-drastic-cost-cutting-plan-and-receives)
