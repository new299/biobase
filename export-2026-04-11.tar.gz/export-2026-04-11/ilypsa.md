# Ilypsa

## Overview
Ilypsa was a private biotechnology company developing non-absorbed polymeric drugs for renal disorders, especially hyperphosphatemia in chronic kidney disease.[[1]](https://www.amgen.com/newsroom/press-releases/2007/06/amgen-to-acquire-ilypsa-a-private-san-francisco-bay-area-biotechnology-company-focused-on-kidney-disease-care)

## Technology
Its lead candidate was ILY101, a late-stage selective phosphate binder for CKD patients on hemodialysis. The broader platform was based on polymeric drugs for kidney disease care.[[1]](https://www.amgen.com/newsroom/press-releases/2007/06/amgen-to-acquire-ilypsa-a-private-san-francisco-bay-area-biotechnology-company-focused-on-kidney-disease-care)[[2]](https://www.amgen.com/newsroom/press-releases/2007/07/amgen-completes-acquisition-of-ilypsa)

## Investors
The reviewed primary source set is stronger on the exit than on the earlier investor syndicate. A later spinout, Relypsa, was formed after the acquisition and separately financed, but that is a distinct company.[[3]](https://www.fiercebiotech.com/biotech/press-release-relypsa-formed-33-million-series-a-funding-to-discover-and-develop-polymeric)

## Acquisitions / Other
Amgen announced in June 2007 that it would acquire Ilypsa for $420 million in cash and completed the acquisition in July 2007.[[1]](https://www.amgen.com/newsroom/press-releases/2007/06/amgen-to-acquire-ilypsa-a-private-san-francisco-bay-area-biotechnology-company-focused-on-kidney-disease-care)[[2]](https://www.amgen.com/newsroom/press-releases/2007/07/amgen-completes-acquisition-of-ilypsa)
