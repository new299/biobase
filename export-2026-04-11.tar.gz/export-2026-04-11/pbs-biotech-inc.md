# PBS Biotech, Inc.

## Overview
PBS Biotech is a cell-therapy manufacturing tools company providing single-use bioreactor systems and process-development services.[[1]](https://www.pbsbiotech.com/company) It focuses on scalable manufacturing infrastructure for cell therapies, including iPSC and MSC processes.[[1]](https://www.pbsbiotech.com/company)

## Technology
PBS Biotech's core technology is the Vertical-Wheel bioreactor platform, which it says is optimized for cell-therapy manufacturing and process scalability.[[1]](https://www.pbsbiotech.com/company) The company positions itself as a manufacturing-enablement platform for regenerative medicine rather than a therapeutics developer.[[1]](https://www.pbsbiotech.com/company)

## Investors
PBS states on its company page that early in 2023 it secured a substantial funding round led by Avego Management and BroadOak Capital Partners.[[1]](https://www.pbsbiotech.com/company) In January 2025, company-issued coverage reported an additional $17 million in follow-on growth capital from Avego and BroadOak.[[2]](https://www.pharmaceutical-era.com/press-releases/pbs-biotech-secures-17m-and-expands-leadership-to-accelerate-next-gen-cell-therapies?highlight=WzIwMjUsIjIwMjUtMDMtMTgiLCJtaWQtMjAyNSIsIjIwMjQtMjAyNSIsImZ5MjAyNSIsIjFoLTIwMjUiLCIyaC0yMDI1IiwiMjAyNS4xIiwiMjAyNS0wNi0yMyIsIjIwMjUtMDgtMzEiXQ%3D%3D)

## Acquisitions and Corporate Activity
No acquisition involving PBS Biotech was identified in the reviewed public sources. The clearest public milestones are financing and capacity expansion to support growing cell-therapy manufacturing demand.[[1]](https://www.pbsbiotech.com/company)[[2]](https://www.pharmaceutical-era.com/press-releases/pbs-biotech-secures-17m-and-expands-leadership-to-accelerate-next-gen-cell-therapies?highlight=WzIwMjUsIjIwMjUtMDMtMTgiLCJtaWQtMjAyNSIsIjIwMjQtMjAyNSIsImZ5MjAyNSIsIjFoLTIwMjUiLCIyaC0yMDI1IiwiMjAyNS4xIiwiMjAyNS0wNi0yMyIsIjIwMjUtMDgtMzEiXQ%3D%3D)
