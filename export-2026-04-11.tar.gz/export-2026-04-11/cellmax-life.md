# CellMax Life — Research Notes

## Overview

CellMax Life is a Sunnyvale, CA-based liquid biopsy company (with operations in Taiwan) developing non-invasive blood tests for early cancer detection and management using circulating tumor cell (CTC) technology and ctDNA. Developed the FirstSight™ colorectal cancer screening test and the CMx platform. Holds multiple U.S. patents covering the CTC detection workflow. [[1]](https://cellmaxlife.com/cellmax-life-blood-testing-platform-granted-six-us-patents/) [[2]](https://cellmaxlife.com/)

---

## Technology

- **CMx Platform**: Biomimetic microfluidic chip that captures rare CTCs from blood (≥5 CTCs per billion normal cells). Chip surface uses a biomimetic coating mimicking the human cell surface membrane with custom monoclonal antibodies for selective CTC capture and intact release for downstream analysis. Validated in PubMed-published clinical studies. [[3]](https://pubmed.ncbi.nlm.nih.gov/31921364/)
- **FirstSight™ CRC Test**: Colorectal cancer (CRC) screening test with 92% sensitivity for CRC and 53% sensitivity for advanced adenomas in external validation — outperforming stool tests and first-generation liquid biopsy approaches. [[4]](https://www.genomeweb.com/cancer/cellmax-life-highlights-liquid-biopsy-platforms-ability-detect-pre-cancer-cancer)
- **Product Portfolio**: CellMax-DNA Hereditary Cancer Risk Test, CellMax-CRC, CellMax-Prostate, CellMax-LBx (liquid biopsy for therapy selection), CellMax-PanCa Monitoring Test. [[2]](https://cellmaxlife.com/)
- **Partnership**: Joint marketing/development agreement with IncellDx for CTC-based liquid biopsy diagnostics. [[5]](https://www.insideprecisionmedicine.com/news-and-features/cellmax-life-incelldx-to-jointly-market-and-develop-ctc-based-liquid-biopsy-diagnostics/)

---

## Funding & Investors

| Round | Date | Amount | Source |
|-------|------|--------|--------|
| Taiwan IDB Government Grant | Jun 2017 | NT$23M (~$770K) | Taiwan Ministry of Economic Affairs IDB |
| Undisclosed private rounds | Various | Undisclosed | Private investors |

Specific venture funding amounts not publicly disclosed. [[6]](https://cellmaxlife.com/cellmax-life-receives-grant-taiwan-government-ctc-cancer-early-detection-system/)

---

## References

1. CellMax Life — Six U.S. patents granted: [https://cellmaxlife.com/cellmax-life-blood-testing-platform-granted-six-us-patents/](https://cellmaxlife.com/cellmax-life-blood-testing-platform-granted-six-us-patents/)
2. CellMax Life — Company website: [https://cellmaxlife.com/](https://cellmaxlife.com/)
3. PubMed — CMx platform analytical validation (2020): [https://pubmed.ncbi.nlm.nih.gov/31921364/](https://pubmed.ncbi.nlm.nih.gov/31921364/)
4. GenomeWeb — CellMax liquid biopsy for pre-cancer/cancer: [https://www.genomeweb.com/cancer/cellmax-life-highlights-liquid-biopsy-platforms-ability-detect-pre-cancer-cancer](https://www.genomeweb.com/cancer/cellmax-life-highlights-liquid-biopsy-platforms-ability-detect-pre-cancer-cancer)
5. Inside Precision Medicine — CellMax + IncellDx partnership: [https://www.insideprecisionmedicine.com/news-and-features/cellmax-life-incelldx-to-jointly-market-and-develop-ctc-based-liquid-biopsy-diagnostics/](https://www.insideprecisionmedicine.com/news-and-features/cellmax-life-incelldx-to-jointly-market-and-develop-ctc-based-liquid-biopsy-diagnostics/)
6. CellMax Life — Taiwan IDB grant: [https://cellmaxlife.com/cellmax-life-receives-grant-taiwan-government-ctc-cancer-early-detection-system/](https://cellmaxlife.com/cellmax-life-receives-grant-taiwan-government-ctc-cancer-early-detection-system/)
