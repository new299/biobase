# Vortex Biosciences

## Overview

Vortex Biosciences is a liquid biopsy tools company focused on isolating and characterizing circulating tumor cells from whole blood. The company says its vision is to drive innovation in rare cell detection to enable new drug and diagnostic development. [[1]](https://vortexbiosciences.com/)

## Technology

Its core platform is the VTX-1 Liquid Biopsy System, which automates label-free capture and collection of viable CTCs directly from whole blood. The company positions the system as a way to simplify and standardize rare-cell isolation for oncology research and translational development. [[1]](https://vortexbiosciences.com/)

## Investors

I did not find a detailed company-issued financing history in the accessible public sources reviewed here. Secondary company databases indicate venture financing and EMV Capital involvement, but I am treating that as secondary reporting because the official site does not present a financing archive. [[2]](https://www.crunchbase.com/organization/vortex-biosciences)

## Strategic Position

Vortex is an oncology tools and diagnostics-enablement company rather than a therapeutics developer. Its value lies in sample preparation and rare-cell enrichment, especially for downstream CTC biology and assay development. [[1]](https://vortexbiosciences.com/)
