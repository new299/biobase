# Agilent Technologies — Research Notes

## Overview

Agilent Technologies (NYSE: A) is a global life science, diagnostics, and applied markets instruments company headquartered in Santa Clara, CA. Spun out of Hewlett-Packard in 1999 via a $2.1B IPO (record at time). Separated its electronic measurement division as Keysight Technologies in 2014. Market cap ~$31B (2026). [[1]](https://en.wikipedia.org/wiki/Agilent_Technologies)

---

## Technology / Business

- **Life Sciences**: Chromatography (HPLC/UHPLC), mass spectrometry (LC-MS, GC-MS), microarrays, NGS library prep reagents, cell analysis instruments.
- **Genomics**: Expanded via acquisitions: Halo Genomics (NGS), SureSelect target enrichment (proprietary hybridization-based NGS library prep), FISH probes.
- **Diagnostics**: Acquired Dako (cancer diagnostics, IHC, FISH) for $2.2B in 2012. [[1]](https://en.wikipedia.org/wiki/Agilent_Technologies)
- **Key products**: 1260/1290 Infinity HPLC, 6000-series LC-MS, SurePrint CGH arrays, SureSelect NGS panels, Seahorse XF (metabolic flux).

---

## Financial Performance

| Fiscal Year | Revenue |
|-------------|---------|
| FY2022 | ~$6.8B |
| FY2024 | $6.51B |
| TTM Jan 2026 | $7.07B (+8.1% YoY) |

NYSE: A | Market cap ~$31.2B (Mar 2026). [[2]](https://stockanalysis.com/stocks/a/revenue/)

---

## History

- **1999**: Spun out of HP with $2.1B IPO.
- **2012**: Acquired Dako (cancer diagnostics) for $2.2B.
- **2014**: Separated Keysight Technologies (electronic measurement).
- **2018**: Acquired Multiplicom (genetic testing) and ACEA Biosciences (cell analysis).

Source: [[1]](https://en.wikipedia.org/wiki/Agilent_Technologies)

---

## References

1. Wikipedia — Agilent Technologies: `https://en.wikipedia.org/wiki/Agilent_Technologies` | [https://en.wikipedia.org/wiki/Agilent_Technologies](https://en.wikipedia.org/wiki/Agilent_Technologies)
2. Stock Analysis — Revenue history: [https://stockanalysis.com/stocks/a/revenue/](https://stockanalysis.com/stocks/a/revenue/)
