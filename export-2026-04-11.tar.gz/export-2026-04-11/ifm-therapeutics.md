# IFM Therapeutics — Research Notes

## Overview

IFM Therapeutics was a Boston, MA-based biotechnology company founded in 2015 and co-founded/incubated by Atlas Venture, focusing on innate immune pathways — specifically STING and NLRP3 agonists — for cancer immunotherapy. Bristol-Myers Squibb (BMS) acquired IFM Therapeutics in August 2017 for $300 million upfront plus up to $1.01 billion in milestones per program, one of the earliest and largest innate immunity acquisitions. Following the acquisition, a subsidiary — IFM Due — was spun out to develop STING antagonists for autoimmune diseases. **Atlas Venture Investment.** [[1]](https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf) [[2]](https://www.crunchbase.com/organization/ifm-therapeutics)

---

## Technology & Products

- **STING Agonists**: Small molecule agonists of the cGAS-STING innate immune pathway for cancer immunotherapy — stimulating innate immune sensing of tumor DNA to drive anti-tumor immune responses. [[1]](https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf)
- **NLRP3 Agonists**: Inflammasome activation program for combination cancer immunotherapy. [[1]](https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf)
- **IFM Due (spin-out)**: Post-acquisition spin-out retained by founders; focused on STING antagonists for autoimmune/inflammatory diseases, where STING inhibition rather than activation is therapeutically relevant. [[2]](https://www.crunchbase.com/organization/ifm-therapeutics)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed / Series A | 2015–2016 | Undisclosed | **Atlas Venture Investment** (co-founder), Abingworth, Novartis Venture Fund |
| Acquired by BMS | Aug 2017 | $300M upfront + up to $1.01B/program milestones | Bristol-Myers Squibb |

[[2]](https://www.crunchbase.com/organization/ifm-therapeutics)

---

## Corporate History

- **2015**: Founded; co-founded and incubated by Atlas Venture with Abingworth and Novartis Venture Fund. [[2]](https://www.crunchbase.com/organization/ifm-therapeutics)
- **Aug 2017**: Acquired by Bristol-Myers Squibb for $300M upfront + up to $1.01B per program in milestones — among the largest early-stage biotech acquisitions in innate immunity. [[1]](https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf)
- **Post-acquisition**: IFM Due spun out as independent company to pursue STING antagonists for autoimmune diseases. [[2]](https://www.crunchbase.com/organization/ifm-therapeutics)

---

## References

1. BMS — IFM Therapeutics acquisition: [https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf](https://www.bms.com/assets/bms/us/en-us/pdf/ifm-therapeutics-acquisition.pdf)
2. Crunchbase — IFM Therapeutics: [https://www.crunchbase.com/organization/ifm-therapeutics](https://www.crunchbase.com/organization/ifm-therapeutics)
