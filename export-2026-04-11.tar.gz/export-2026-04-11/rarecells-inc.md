# Rarecells, Inc.

## Overview
Rarecells is a liquid-biopsy diagnostics company focused on early cancer detection and recurrence monitoring [[1]](https://www.rarecells.com/) [[2]](https://www.leadsontrees.com/organization/rarecells).

## Technology
Its core platform is ISET, a proprietary technology for isolating circulating tumor cells from blood, and the company also highlights combined CTC-DNA and ctDNA analysis for higher-sensitivity detection [[1]](https://www.rarecells.com/) [[2]](https://www.leadsontrees.com/organization/rarecells).

## Investors
The reviewed public sources were stronger on technology and commercialization than on financing history; I did not locate a clear investor list in this pass [[1]](https://www.rarecells.com/).

## Acquisitions / Strategic Transactions
No acquisition or major disclosed strategic transaction was identified in the reviewed sources during this pass [[1]](https://www.rarecells.com/).

## References
[[1]](https://www.rarecells.com/)
[[2]](https://www.leadsontrees.com/organization/rarecells)
