# Stoke Therapeutics

## Overview
Stoke Therapeutics is a biotechnology company developing RNA-based medicines for diseases caused by haploinsufficiency [[1]](https://investor.stoketherapeutics.com/investor-relations/).

## Technology
Its core approach is TANGO, or Targeted Augmentation of Nuclear Gene Output, which uses antisense oligonucleotides to restore protein expression [[1]](https://investor.stoketherapeutics.com/investor-relations/).

## Investors
As a public company, Stoke is financed through public markets and partnerships. The reviewed materials emphasize its collaboration with Biogen and public-company status rather than a named current-holder list [[1]](https://investor.stoketherapeutics.com/investor-relations/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The most material strategic development visible publicly is its collaboration with Biogen around zorevunersen for Dravet syndrome [[1]](https://investor.stoketherapeutics.com/investor-relations/).

## References
[[1]](https://investor.stoketherapeutics.com/investor-relations/)
