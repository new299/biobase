# SeqLL

## Overview
SeqLL is a life-science instrumentation and research services company built around True Single Molecule Sequencing (tSMS) technology and related scientific assets across multiple omics fields [[1]](https://seqll.com/investor-relations/).

## Technology
The company says it leverages tSMS technology to help researchers and clinicians better understand molecular mechanisms of disease and biological processes [[1]](https://seqll.com/investor-relations/).

## Investors
As a public company, SeqLL has been financed through public markets. The reviewed investor-relations source focuses on current public-company status rather than named institutional holders [[1]](https://seqll.com/investor-relations/).

## Acquisitions / Strategic Transactions
SeqLL entered a definitive merger agreement in May 2025 to acquire Lyneer Staffing Solutions and Atlantic Acquisition Corp. in a transaction involving cash plus newly issued stock [[2]](https://seqll.com/investors-sub/news-releases/news-release-details/seqll-inc-enters-definitive-merger-agreement-lyneer-staffing/). MarketWatch coverage of the associated 8-K filings also reports that SeqLL changed its name to Atlantic International Corp. in June 2024 as part of the broader merger process [[3]](https://www.marketwatch.com/story/atlantic-international-corp-files-8k-changes-to-articles-24216680).

## References
[[1]](https://seqll.com/investor-relations/)
[[2]](https://seqll.com/investors-sub/news-releases/news-release-details/seqll-inc-enters-definitive-merger-agreement-lyneer-staffing/)
[[3]](https://www.marketwatch.com/story/atlantic-international-corp-files-8k-changes-to-articles-24216680)
