# NextRNA Therapeutics

## Overview
NextRNA Therapeutics was a biotechnology company focused on developing medicines directed at non-coding RNAs, especially long non-coding RNAs and their interacting proteins.[[1]](https://www.nextrnatx.com/nextrna-launches-with-56-million-in-funding-to-bring-transformative-non-coding-rna-directed-medicines-to-patients/) The company announced in 2025 that it had ceased operations.[[2]](https://www.nextrnatx.com/)

## Technology and Pipeline
NextRNA's platform was built to identify disease-relevant non-coding RNAs and then develop selective small molecules against the interactions between those RNAs and proteins.[[1]](https://www.nextrnatx.com/nextrna-launches-with-56-million-in-funding-to-bring-transformative-non-coding-rna-directed-medicines-to-patients/) At launch, it said it was advancing lead programs in oncology and immunology.[[1]](https://www.nextrnatx.com/nextrna-launches-with-56-million-in-funding-to-bring-transformative-non-coding-rna-directed-medicines-to-patients/)

## Investors
In March 2022, NextRNA announced its launch with $56 million in funding, consisting of $9.3 million in seed financing and a $46.8 million Series A led by Cobro Ventures and Lightchain Capital, with additional participation from Circle Alternative Investments, Evans Capital, Jefferies, Rivas Capital, and Willett Advisors.[[1]](https://www.nextrnatx.com/nextrna-launches-with-56-million-in-funding-to-bring-transformative-non-coding-rna-directed-medicines-to-patients/)

## Acquisitions and Corporate Activity
I did not identify an acquisition involving NextRNA in the reviewed sources. The most important later corporate event in the public record is its August 2025 shutdown notice, in which the company stated it had ceased operations after being founded in 2021.[[2]](https://www.nextrnatx.com/)
