# mFluiDX

## Overview

mFluiDX is a diagnostics company developing low-cost, point-of-care molecular testing using microfluidics.[[1]](https://www.mfluidx.com/) SOSV describes the company as building field-ready DNA-based outbreak diagnostics for dangerous diseases.[[2]](https://sosv.com/company/mfluidx/)

## Technology

Its `SIMPLE CHIP` platform is designed to provide PCR-equivalent molecular test results with a rapid, low-cost microfluidic cartridge and reader system.[[1]](https://www.mfluidx.com/) The company says the technology can test multiple bacterial or viral targets simultaneously and was initially funded around rapid diagnostics for Zika virus.[[1]](https://www.mfluidx.com/) [[2]](https://sosv.com/company/mfluidx/)

## Investors

mFluiDX is an SOSV / IndieBio portfolio company.[[2]](https://sosv.com/company/mfluidx/) SOSV's profile also notes Gates Foundation and DARPA support for early prototypes, but the reviewed sources did not surface a fuller private financing syndicate.[[2]](https://sosv.com/company/mfluidx/)

## Acquisitions and Strategic Transactions

No acquisition involving mFluiDX was identified in the reviewed sources. The public record reviewed is centered on product development, grant support, and startup acceleration rather than M&A.[[1]](https://www.mfluidx.com/) [[2]](https://sosv.com/company/mfluidx/)
