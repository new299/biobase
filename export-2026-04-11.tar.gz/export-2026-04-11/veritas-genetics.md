# Veritas Genetics

## Overview

Veritas Genetics is a genomics company focused on whole genome sequencing and interpretation for individuals and families. Public-facing ordering materials show the company still offers its `myGenome` whole genome sequencing product. [[1]](https://secure.veritasgenetics.com/external-ordering.php) [[2]](https://secure.veritasgenetics.com/pgp/)

## Technology

The company's public product is centered on whole genome sequencing paired with interpretation, physician review, and online result delivery. Its consumer and clinical positioning has historically emphasized broad genomic risk, carrier status, and pharmacogenomic interpretation from whole genome data. [[1]](https://secure.veritasgenetics.com/external-ordering.php) [[2]](https://secure.veritasgenetics.com/pgp/)

## Strategic Development

Veritas historically used M&A to deepen its computational genomics capabilities. Public reporting in 2017 described its acquisition of Curoverse, an AI and genomic data infrastructure company spun out of the same George Church ecosystem. [[3]](https://www.wired.com/story/veritas-genomics-scoops-up-an-ai-company-to-sort-out-its-dna/)

## Disclosure Limits

The accessible public web footprint is now dominated by product ordering flows rather than a clean corporate site or active investor relations archive. As a result, this note stays focused on the currently visible whole genome business and the best-documented historical strategic event. [[1]](https://secure.veritasgenetics.com/external-ordering.php) [[3]](https://www.wired.com/story/veritas-genomics-scoops-up-an-ai-company-to-sort-out-its-dna/)
