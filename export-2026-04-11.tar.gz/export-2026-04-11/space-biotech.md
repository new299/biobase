# Space.Biotech

## Overview
The clearest public record for this folder is an Indian private company registry entry for Space Biotech Private Limited, a small unlisted company established in 2021 in Tamil Nadu.[[1]](https://www.thecompanycheck.com/company/space-biotech-private-limited/U24239TN2021PTC144902)

## Technology / Business
The reviewed public sources did not provide a company website or detailed technical profile, so I cannot reliably characterize a distinct technology platform without overreaching.

## Investors / Ownership
Registry data indicate the company is privately held and unlisted, with minimal paid-up capital and two listed directors. I did not identify a public venture financing announcement.[[1]](https://www.thecompanycheck.com/company/space-biotech-private-limited/U24239TN2021PTC144902)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. This note stays intentionally narrow because the public operating footprint is limited.[[1]](https://www.thecompanycheck.com/company/space-biotech-private-limited/U24239TN2021PTC144902)
