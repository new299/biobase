# MouSensor, Inc.

## Overview

MouSensor is a biotechnology company developing an `odoromics` platform to digitize smell and build sensing systems based on olfactory biology.[[1]](https://mousensor.com/news/mousensor-inc-closes-a-3-3m-seed-round-to-digitize-the-sense-of-smell/)

## Technology

MouSensor's core technology is based on engineered olfactory biology and chip integration to digitize scent and create a `human-nose-on-a-chip` style sensing platform.[[1]](https://mousensor.com/news/mousensor-inc-closes-a-3-3m-seed-round-to-digitize-the-sense-of-smell/) The company says it is establishing a digital database of scent and integrating its biology with silicon chip technology through collaboration with imec.[[1]](https://mousensor.com/news/mousensor-inc-closes-a-3-3m-seed-round-to-digitize-the-sense-of-smell/)

## Investors

In September 2018, MouSensor announced a $3.3 million seed round co-led by imec.xpand and Alexandria Venture Investments, with participation from New York Ventures and Elma Hawkins, Ph.D.[[1]](https://mousensor.com/news/mousensor-inc-closes-a-3-3m-seed-round-to-digitize-the-sense-of-smell/)

## Acquisitions and Strategic Transactions

No acquisition involving MouSensor was identified in the reviewed sources. The reviewed public footprint is centered on seed financing and R&D partnerships rather than M&A.[[1]](https://mousensor.com/news/mousensor-inc-closes-a-3-3m-seed-round-to-digitize-the-sense-of-smell/)
