# Mahzi Therapeutics

## Overview

Mahzi Therapeutics is a biotechnology company developing therapies for underdiagnosed and underserved rare genetic neurodevelopmental disorders.[[1]](https://mahzi.com/about/)

## Technology

Mahzi's public materials describe an integrated development effort spanning research, development, and manufacturing for rare neurodevelopmental disease therapeutics, but they do not present a single branded platform technology on the reviewed pages.[[1]](https://mahzi.com/about/) The company's strategy appears to center on rare disease-focused therapeutic development built in collaboration with patient groups, researchers, and industry partners.[[1]](https://mahzi.com/about/)

## Investors

Mahzi's website identifies investors including Venrock, HealthCap, Droia Ventures, HBM Healthcare Investments, ArrowMark Partners, Ultragenyx, and Mitsui Global.[[1]](https://mahzi.com/about/)

## Acquisitions and Strategic Transactions

No acquisition involving Mahzi Therapeutics was identified in the reviewed sources. The public footprint reviewed is focused on company building and rare disease therapeutic development rather than M&A.[[1]](https://mahzi.com/about/)
