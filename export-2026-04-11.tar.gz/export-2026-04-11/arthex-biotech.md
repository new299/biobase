# ARTHEx Biotech — Research Notes

## Overview

ARTHEx Biotech is a clinical-stage RNA therapeutics company founded in 2018 by Ruben Artero and Beatriz Llamusi, headquartered in Valencia, Spain. Develops targeted oligonucleotide medicines for rare neuromuscular, CNS, cardiac, and pulmonary diseases. Lead program ATX-01 is in Phase I/IIa for myotonic dystrophy type 1 (DM1). Total raised: $93.6M. [[1]](https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m-to-advance-lead-program-atx-01-in-myotonic-dystrophy-type-1-and-expand-pipeline-of-targeted-rna-medicines)

---

## Technology

- **Targeted RNA Medicine Platform**: Pairs selective oligonucleotides (ASOs) with tissue-specific delivery to reach skeletal muscle, heart, and brain — enabling precise modulation of aberrant RNA in tissues affected by neuromuscular and CNS diseases. [[1]](https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m)
- **ATX-01**: Lead ASO for **myotonic dystrophy type 1 (DM1)** — targets the toxic CUG-repeat RNA expansion in DMPK to correct downstream splicing defects. Phase I/IIa (ArthemiR™ trial); first clinical data expected 2026. [[1]](https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m)
- Pipeline in DM1 plus additional rare muscular, CNS, cardiac, and pulmonary disease targets.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | ~2018–2022 | ~$6.6M | Columbus Venture Partners, Hadean Ventures, CriteriaCaixa, Caixa Capital Risc |
| Series B (initial) | 2023 | €42M (~$46M) | AdBio Partners, CDTI Innovación, Columbus Venture Partners, EIC (European Innovation Council), Hadean Ventures, Invivo Partners, Sound Bioventures |
| Series B upsized | Sep 2025 | $87M total | Bpifrance (new lead) + all existing Series B investors |

Total raised: $93.6M. [[1]](https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m-to-advance-lead-program-atx-01-in-myotonic-dystrophy-type-1-and-expand-pipeline-of-targeted-rna-medicines)

---

## References

1. ARTHEx Biotech — Series B upsizing (Sep 2025): [https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m-to-advance-lead-program-atx-01-in-myotonic-dystrophy-type-1-and-expand-pipeline-of-targeted-rna-medicines](https://www.arthexbiotech.com/post/arthex-biotech-upsizes-series-b-financing-round-to-87m-to-advance-lead-program-atx-01-in-myotonic-dystrophy-type-1-and-expand-pipeline-of-targeted-rna-medicines)
