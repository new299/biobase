# Marcadia

## Overview

Marcadia Biotech was a diabetes and obesity therapeutics company developing peptide-based medicines for metabolic disease.[[1]](https://www.biocentury.com/article/13305/ftc-clears-roche-acquisition-of-marcadia)

## Technology

The reviewed public sources in this pass are strongest on Marcadia's acquisition process rather than a detailed platform description, but industry coverage at the time characterized the company as focused on diabetes and obesity therapeutics.[[1]](https://www.biocentury.com/article/13305/ftc-clears-roche-acquisition-of-marcadia)

## Investors

The local note associates Marcadia with 5AM Ventures, which is consistent with the company's venture-backed profile, but the reviewed public source here does not enumerate the full financing syndicate. Investor detail is therefore left intentionally narrow.

## Acquisitions and Strategic Transactions

BioCentury reported in December 2010 that the FTC had cleared Roche's proposed acquisition of Marcadia Biotech.[[1]](https://www.biocentury.com/article/13305/ftc-clears-roche-acquisition-of-marcadia) The reviewed source did not provide further transaction economics.
