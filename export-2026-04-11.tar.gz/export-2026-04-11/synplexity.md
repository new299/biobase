# SynPlexity

## Overview
SynPlexity is a synthetic biology tools company commercializing large-scale custom DNA and gene library synthesis [[1]](https://synplexity.com/) [[2]](https://sosv.com/company/synplexity/).

## Technology
The company says it uses DropSynth technology and microreactor-based assembly to print large custom-sequence DNA libraries at lower cost and higher scale than conventional methods [[1]](https://synplexity.com/) [[2]](https://sosv.com/company/synplexity/).

## Investors
SOSV lists SynPlexity as a seed-stage IndieBio portfolio company and describes its commercial positioning around synthetic gene library printing [[2]](https://sosv.com/company/synplexity/).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The primary public milestones are commercialization of the platform and the connection to the DropSynth ecosystem [[1]](https://synplexity.com/) [[3]](https://dropsynth.org/).

## References
[[1]](https://synplexity.com/)
[[2]](https://sosv.com/company/synplexity/)
[[3]](https://dropsynth.org/)
