# Kanvas Biosciences

## Overview

Kanvas Biosciences is a microbiome therapeutics and spatial biology company aiming to translate host-microbiome interaction data into microbial medicines.[[1]](https://www.kanvasbio.com/about) The company says it uses advanced imaging and analysis to illuminate microbial life and build novel microbial therapeutics.[[1]](https://www.kanvasbio.com/about)

## Technology

Kanvas describes a spatial biology platform for mapping host-microbiome interactions and using those insights to design live biotherapeutic products (`LBPs`).[[2]](https://www.kanvasbio.com/news/with-12-5m-in-new-funding-kanvas-bio-is-advancing-its-novel-microbiome-based-immuno-oncology-drug-candidates) The company also offers fully anaerobic microbial fermentation CDMO services for LBP manufacturing, process development, and analytics.[[3]](https://www.kanvasbio.com/services)

## Investors

In July 2024, Kanvas announced $12.5 million in additional funding co-led by DCVC and Lions Capital, bringing total funding to $29.5 million.[[2]](https://www.kanvasbio.com/news/with-12-5m-in-new-funding-kanvas-bio-is-advancing-its-novel-microbiome-based-immuno-oncology-drug-candidates)

## Acquisitions and Strategic Transactions

No acquisition involving Kanvas Biosciences was identified in the reviewed sources. Its recent strategic progress has focused on advancing KAN-001, launching KAN-003, and building out its spatial biology and manufacturing capabilities.[[2]](https://www.kanvasbio.com/news/with-12-5m-in-new-funding-kanvas-bio-is-advancing-its-novel-microbiome-based-immuno-oncology-drug-candidates)
