# Encoded Therapeutics — Research Notes

## Overview

Encoded Therapeutics (formerly Encoded Genomics) is a South San Francisco, CA-based clinical-stage gene therapy company founded in 2014 by Stephanie Tagliatela and Kartik Ramamoorthi. Developing precision gene therapies using engineered regulatory elements (synthetic gene control switches) to achieve cell-type-specific gene expression in AAV-delivered therapeutics. Lead program: ETX101 (SCN1A+ Dravet syndrome, Phase 1/2). Pipeline: ETX201 (Angelman syndrome, IND-enabling). Total raised: ~$299M ($40M Series A/B + $104M Series C + $135M Series D). **ARCH Venture Partners** investor. [[1]](https://encoded.com/press-releases/encoded-therapeutics-announces-135-million-series-d-financing-to-support-first-clinical-trials-in-scna1-dravet-syndrome-and-advance-preclinical-pipeline-of-gene-therapies-for-debilitating-neurologic/) [[2]](https://www.prnewswire.com/news-releases/encoded-therapeutics-inc-announces-104-million-series-c-financing-to-advance-lead-gene-therapy-program-in-dravet-syndrome-and-unveils-its-precision-gene-therapy-platform-300874993.html)

---

## Technology & Pipeline

- **Precision Gene Therapy Platform**: Genomics and computational technologies to identify and optimize regulatory elements (promoters, enhancers) from the human genome that precisely recapitulate natural, cell-type-specific gene expression patterns when packaged in AAV vectors — enabling precise therapeutic gene expression in specific neuronal subtypes. [[2]](https://www.prnewswire.com/news-releases/encoded-therapeutics-inc-announces-104-million-series-c-financing-to-advance-lead-gene-therapy-program-in-dravet-syndrome-and-unveils-its-precision-gene-therapy-platform-300874993.html)
- **ETX101 (SCN1A+ Dravet Syndrome)**: AAV-based gene therapy using precision regulatory elements to upregulate SCN1A expression specifically in inhibitory interneurons for patients with SCN1A haploinsufficiency. Phase 1/2 clinical trials ongoing; clinical progress reported Feb 2025. Collaboration with Prevail Therapeutics (Eli Lilly subsidiary) for regulatory element licensing. [[3]](https://www.businesswire.com/news/home/20250213028144/en/Encoded-Therapeutics-Reports-Clinical-Progress-of-ETX101-Gene-Therapy-for-Dravet-Syndrome-Recaps-2024-Corporate-Achievements-and-Provides-2025-Outlook)
- **ETX201 (Angelman Syndrome)**: Vectorized miRNA-based AAV9 gene therapy designed to unsilence the paternal UBE3A copy. Positive NHP data (widespread UBE3A upregulation) presented FAST Summit Nov 2024; IND-enabling studies initiated for 2026 IND filing. [[4]](https://www.businesswire.com/news/home/20241107185885/en/Encoded-Demonstrates-Therapeutic-Potential-of-a-Vectorized-miRNA-based-Approach-for-Angelman-Syndrome-at-the-FAST-Annual-Global-Science-Summit)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A/B | 2014–2018 | ~$60M | ARCH Venture Partners, GV (Google Ventures), Menlo Ventures |
| Series C | 2019 | $104M | GV (lead), ARCH Venture Partners, Illumina Ventures, HBM Genomics, Meritech Capital, Menlo Ventures |
| Series D | ~2021 | $135M | GV (lead), Matrix Capital Management, ARCH Venture Partners, Illumina Ventures, RTW Investments, Boxer Capital, Nolan Capital, HBM Genomics, Menlo Ventures, Meritech Capital, Farallon Capital, SoftBank Vision Fund 2 |

Total raised: ~$299M. [[1]](https://encoded.com/press-releases/encoded-therapeutics-announces-135-million-series-d-financing-to-support-first-clinical-trials-in-scna1-dravet-syndrome-and-advance-preclinical-pipeline-of-gene-therapies-for-debilitating-neurologic/)

**ARCH Venture Partners Investment**

---

## References

1. Encoded Therapeutics — $135M Series D announcement: [https://encoded.com/press-releases/encoded-therapeutics-announces-135-million-series-d-financing-to-support-first-clinical-trials-in-scna1-dravet-syndrome-and-advance-preclinical-pipeline-of-gene-therapies-for-debilitating-neurologic/](https://encoded.com/press-releases/encoded-therapeutics-announces-135-million-series-d-financing-to-support-first-clinical-trials-in-scna1-dravet-syndrome-and-advance-preclinical-pipeline-of-gene-therapies-for-debilitating-neurologic/)
2. PRNewswire — Encoded Therapeutics $104M Series C and precision gene therapy platform: [https://www.prnewswire.com/news-releases/encoded-therapeutics-inc-announces-104-million-series-c-financing-to-advance-lead-gene-therapy-program-in-dravet-syndrome-and-unveils-its-precision-gene-therapy-platform-300874993.html](https://www.prnewswire.com/news-releases/encoded-therapeutics-inc-announces-104-million-series-c-financing-to-advance-lead-gene-therapy-program-in-dravet-syndrome-and-unveils-its-precision-gene-therapy-platform-300874993.html)
3. BusinessWire — Encoded Therapeutics ETX101 clinical progress and 2025 outlook (Feb 2025): [https://www.businesswire.com/news/home/20250213028144/en/Encoded-Therapeutics-Reports-Clinical-Progress-of-ETX101-Gene-Therapy-for-Dravet-Syndrome-Recaps-2024-Corporate-Achievements-and-Provides-2025-Outlook](https://www.businesswire.com/news/home/20250213028144/en/Encoded-Therapeutics-Reports-Clinical-Progress-of-ETX101-Gene-Therapy-for-Dravet-Syndrome-Recaps-2024-Corporate-Achievements-and-Provides-2025-Outlook)
4. BusinessWire — Encoded ETX201 Angelman syndrome miRNA approach FAST Summit (Nov 2024): [https://www.businesswire.com/news/home/20241107185885/en/Encoded-Demonstrates-Therapeutic-Potential-of-a-Vectorized-miRNA-based-Approach-for-Angelman-Syndrome-at-the-FAST-Annual-Global-Science-Summit](https://www.businesswire.com/news/home/20241107185885/en/Encoded-Demonstrates-Therapeutic-Potential-of-a-Vectorized-miRNA-based-Approach-for-Angelman-Syndrome-at-the-FAST-Annual-Global-Science-Summit)
