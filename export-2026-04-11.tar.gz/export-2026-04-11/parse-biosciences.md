# Parse Biosciences

## Overview
Parse Biosciences is a life-science tools company providing scalable, instrument-free single-cell sequencing solutions.[[1]](https://www.parsebiosciences.com/company/about-parse/)[[2]](https://corporate.qiagen.com/English/newsroom/press-releases/press-release-details/2025/QIAGEN-to-acquire-Parse-Biosciences-expanding-its-Sample-technologies-portfolio-into-highly-scalable-single-cell-solutions) The company was founded on University of Washington split-pool barcoding technology.[[1]](https://www.parsebiosciences.com/company/about-parse/)

## Technology
Parse says its Evercode combinatorial barcoding platform enables large-scale single-cell experiments ranging up to millions and billions of cells, without requiring proprietary instrumentation.[[2]](https://corporate.qiagen.com/English/newsroom/press-releases/press-release-details/2025/QIAGEN-to-acquire-Parse-Biosciences-expanding-its-Sample-technologies-portfolio-into-highly-scalable-single-cell-solutions)[[1]](https://www.parsebiosciences.com/company/about-parse/) The company also expanded its data-analysis capabilities through its 2024 Biomage acquisition.[[3]](https://www.parsebiosciences.com/news/parse-biosciences-acquires-biomage/)

## Investors
Parse's public materials state that it has raised over $100 million in capital.[[4]](https://www.parsebiosciences.com/news/parse-biosciences-invalidates-scale-biosciences-now-10x-genomics-patent/) The reviewed sources did not provide a full company-issued investor roster during this pass, so the financing picture here is intentionally partial.

## Acquisitions and Corporate Activity
Parse announced in January 2024 that it acquired Biomage, a single-cell data-analysis software company.[[3]](https://www.parsebiosciences.com/news/parse-biosciences-acquires-biomage/) On November 4, 2025, QIAGEN announced that it would fully acquire Parse for approximately $225 million upfront in cash plus up to $55 million in milestone payments.[[2]](https://corporate.qiagen.com/English/newsroom/press-releases/press-release-details/2025/QIAGEN-to-acquire-Parse-Biosciences-expanding-its-Sample-technologies-portfolio-into-highly-scalable-single-cell-solutions)

## ASeq Posts

- [Scalebio And Parsebio](https://aseq.substack.com/p/scalebio-and-parsebio)
