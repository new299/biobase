# InnoSIGN — Research Notes

## Overview

InnoSIGN is a Leiden, Netherlands-based oncology diagnostics company developing the OncoSIGNal™ pathway activity profiling platform — translating mRNA expression levels into quantitative activity scores for canonical cancer signaling pathways (Notch, WNT, Hedgehog, PI3K, MAPK, TGFβ, AR, ER) using RT-qPCR. The platform is designed to guide treatment selection by characterizing which cancer-driving pathways are active in individual patient tumors. [[1]](https://www.biospace.com/innosign-launches-new-suite-products-for-pharmaceutical-research-and-clinical-studies) [[2]](https://www.crunchbase.com/organization/innosign)

---

## Technology & Products

- **OncoSIGNal™ Test**: RT-qPCR-based assay measuring mRNA levels of specific target genes that are direct readouts of pathway transcription factor activity for canonical oncogenic pathways including Notch, WNT/β-catenin, Hedgehog, PI3K, MAPK/RAS, TGFβ, AR, and ER; cloud-based analysis platform converts raw mRNA measurements into calibrated pathway activity scores comparable across tumor types. [[1]](https://www.biospace.com/innosign-launches-new-suite-products-for-pharmaceutical-research-and-clinical-studies)

---

## Funding & Investors

No major venture funding publicly disclosed. Revenue model based on kit sales and cloud platform subscriptions. [[2]](https://www.crunchbase.com/organization/innosign)

---

## References

1. BioSpace — InnoSIGN product launch: [https://www.biospace.com/innosign-launches-new-suite-products-for-pharmaceutical-research-and-clinical-studies](https://www.biospace.com/innosign-launches-new-suite-products-for-pharmaceutical-research-and-clinical-studies)
2. Crunchbase — InnoSIGN: [https://www.crunchbase.com/organization/innosign](https://www.crunchbase.com/organization/innosign)
