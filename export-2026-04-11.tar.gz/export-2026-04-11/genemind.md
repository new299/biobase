# GeneMind Biosciences — Research Notes

## Overview

GeneMind Biosciences is a Shenzhen, China-based DNA sequencing company founded in 2012, developing a portfolio of benchtop and high-throughput DNA sequencing platforms using its proprietary SURF-seq (surface-restricted fluorescent sequencing) technology. GeneMind offers half a dozen sequencing instruments and is expanding into international markets. Total raised: ~$253M including a ~RMB 400M Series C (led by KingMed Diagnostics and Guoxin Investment) and RMB 280M (~$39M) Series C+ (May 2025). [[1]](https://en.genemind.com/news/3456.html) [[2]](https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms)

---

## Technology & Products

- **SURF-seq (Surface-Restricted Fluorescent Sequencing)**: Proprietary sequencing-by-synthesis technology using total internal reflection fluorescence (TIRF) microscopy and surface amplification to achieve high signal-to-noise DNA sequencing. [[2]](https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms)
- **Sequencing Platform Portfolio**: Multiple platforms including high-throughput clinical/research sequencers and benchtop instruments for diverse applications (clinical genomics, oncology, pathogen detection, agricultural). [[2]](https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms)
- **International Expansion**: Targeting European and broader global markets; IVDR CE certification activities underway. [[1]](https://en.genemind.com/news/3456.html)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A–B | 2012–2021 | ~$100M | Early investors |
| Series C | ~2023 | ~RMB 400M (~$55M) | KingMed Diagnostics (lead), Guoxin Investment, Shenzhen HTI Group, National Medtech Odyssey Ventures |
| Series C+ | May 2025 | RMB 280M (~$39M) | Existing and new investors |

Total raised: ~$253M. [[1]](https://en.genemind.com/news/3456.html) [[2]](https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms)

---

## References

1. GeneMind Biosciences — Series C funding announcement: [https://en.genemind.com/news/3456.html](https://en.genemind.com/news/3456.html)
2. GenomeWeb — GeneMind eyes international market: [https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms](https://www.genomeweb.com/sequencing/chinas-genemind-eyes-international-market-fleet-sequencing-platforms)
