# Typewriter Therapeutics

## Overview

Typewriter Therapeutics is a Tokyo University spinout developing next-generation gene writing therapies. The company says it aims to precisely write therapeutic genes into the genome using transposon-based technology to create treatments for severe inherited diseases. [[1]](https://www.typewritertx.com/jp/)

## Technology

Typewriter describes its platform as "Gene Writing," a next-generation genome editing approach based on advanced transposon application technologies. The public materials position this as a precise genomic insertion technology rather than a nuclease-only editing approach. [[1]](https://www.typewritertx.com/jp/)

## Investors And Partners

The company publicly lists RA Capital Management, AN Venture Partners, ANRI, and Bayer Co.Lab as investors or partners. I did not find a more detailed financing press release in the accessible public sources reviewed for this note. [[1]](https://www.typewritertx.com/jp/)

## Strategic Position

Because public disclosure is still relatively light, Typewriter currently looks like an early-stage gene editing company defined more by technical promise and investor quality than by disclosed pipeline depth. The available public materials indicate a Japan-U.S. operating footprint and a clear gene-writing positioning. [[1]](https://www.typewritertx.com/jp/)
