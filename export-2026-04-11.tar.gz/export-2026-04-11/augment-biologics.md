# Augment Biologics

## Overview
Augment Biologics is a biotechnology company developing mucosal immunotherapies, initially focused on respiratory viruses and COVID-19.[[1]](https://sosv.com/company/augment-biologics/) The company is part of the SOSV ecosystem.

## Technology
SOSV describes Augment as developing a “throat swab vaccine” based on a dissolvable film placed in the mouth to boost antiviral immune responses in the upper airway and reduce transmissibility.[[1]](https://sosv.com/company/augment-biologics/) This is a mucosal immunotherapy and delivery concept rather than a conventional injected vaccine platform.

## Investors
SOSV lists Augment Biologics as one of its portfolio companies.[[1]](https://sosv.com/company/augment-biologics/) I did not identify a fuller company-issued financing history during this pass.

## Acquisitions and Corporate Activity
No acquisition involving Augment Biologics was identified in the reviewed public sources. The accessible public record is currently limited and centered on its early-stage mucosal immunotherapy concept.[[1]](https://sosv.com/company/augment-biologics/)
