# CENTOGENE — Research Notes

## Overview

CENTOGENE N.V. (formerly NASDAQ: CNTG) is a Hamburg/Rostock, Germany-based rare disease genomics diagnostics company providing data-driven diagnostic solutions for rare and neurodegenerative diseases. Operates the world's largest real-world rare disease biodatabank (850,000+ analyzed patient cases). **In August 2024, CNTG was suspended from NASDAQ trading; in March 2025, the company sold its operating subsidiaries to an affiliate of Charme Capital Partners and was renamed Crown LiquidationCo N.V.** [[1]](https://www.centogene.com/) [[2]](https://investors.centogene.com/news-releases/news-release-details/centogene-biodatabank-grows-incorporate-disease-insights-over)

---

## Technology & Products

- **CentoGenome®**: Comprehensive whole genome sequencing assay for rare and neurodegenerative diseases; detects nearly all disease-causing variant types in a single assay. [[3]](https://www.stocktitan.net/news/CNTG/centogene-launches-new-cento-genome-r-world-s-most-comprehensive-gd83xirpuwnm.html)
- **CENTOGENE MOx 2.0**: Single-step multiomic solution combining DNA sequencing, biochemical testing, and RNA transcriptomics. [[3]](https://www.stocktitan.net/news/CNTG/centogene-launches-new-cento-genome-r-world-s-most-comprehensive-gd83xirpuwnm.html)
- **CentoCloud®**: Cloud-based SaaS platform for genomic variant analysis and rare disease diagnostics, enabling decentralized laboratory diagnostics. [[4]](https://www.stocktitan.net/news/CNTG/centogene-s-cento-cloud-r-set-to-revolutionize-rare-disease-lx43enzhxjc7.html)
- **Biodatabank**: Over 850,000 diverse rare disease patient cases (as of end-2023, +13% YoY), supporting drug development and biomarker discovery partnerships with pharma companies. [[2]](https://investors.centogene.com/news-releases/news-release-details/centogene-biodatabank-grows-incorporate-disease-insights-over)
- Partnership with Twist Bioscience for rare disease and hereditary cancer NGS panels. [[5]](https://investors.centogene.com/news-releases/news-release-details/twist-bioscience-and-centogene-launch-three-panels-advance-rare)

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| NASDAQ IPO | Nov 2019 | NASDAQ: CNTG |
| NASDAQ suspension | Aug 2024 | Trading suspended; moved to OTC Markets (CNTGF) |
| Sale to Charme Capital Partners | Mar 2025 | Operating subsidiaries sold; parent renamed Crown LiquidationCo N.V. |

[[1]](https://www.centogene.com/)

---

## References

1. CENTOGENE — Company website: [https://www.centogene.com/](https://www.centogene.com/)
2. CENTOGENE — Biodatabank 850,000 patients: [https://investors.centogene.com/news-releases/news-release-details/centogene-biodatabank-grows-incorporate-disease-insights-over](https://investors.centogene.com/news-releases/news-release-details/centogene-biodatabank-grows-incorporate-disease-insights-over)
3. StockTitan — CentoGenome launch: [https://www.stocktitan.net/news/CNTG/centogene-launches-new-cento-genome-r-world-s-most-comprehensive-gd83xirpuwnm.html](https://www.stocktitan.net/news/CNTG/centogene-launches-new-cento-genome-r-world-s-most-comprehensive-gd83xirpuwnm.html)
4. StockTitan — CentoCloud SaaS platform: [https://www.stocktitan.net/news/CNTG/centogene-s-cento-cloud-r-set-to-revolutionize-rare-disease-lx43enzhxjc7.html](https://www.stocktitan.net/news/CNTG/centogene-s-cento-cloud-r-set-to-revolutionize-rare-disease-lx43enzhxjc7.html)
5. CENTOGENE — Twist Bioscience NGS panel partnership: [https://investors.centogene.com/news-releases/news-release-details/twist-bioscience-and-centogene-launch-three-panels-advance-rare](https://investors.centogene.com/news-releases/news-release-details/twist-bioscience-and-centogene-launch-three-panels-advance-rare)
