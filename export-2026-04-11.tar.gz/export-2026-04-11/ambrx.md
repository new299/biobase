# Ambrx

## Overview
Ambrx Biopharma was a clinical-stage biotechnology company developing next-generation antibody-drug conjugates and other precision biologics using an expanded genetic code platform.[[1]](https://www.investor.jnj.com/news/news-details/2024/Johnson--Johnson-to-Acquire-Ambrx-Advancing-Next-Generation-Antibody-Drug-Conjugates-to-Transform-the-Treatment-of-Cancer/default.aspx)[[2]](https://ambrx.com/) Its lead programs included ARX517 and ARX788.[[1]](https://www.investor.jnj.com/news/news-details/2024/Johnson--Johnson-to-Acquire-Ambrx-Advancing-Next-Generation-Antibody-Drug-Conjugates-to-Transform-the-Treatment-of-Cancer/default.aspx)

## Technology
Ambrx’s core differentiator was protein engineering using synthetic amino acids in living cells to create highly stable, site-specific ADCs and other engineered biologics.[[1]](https://www.investor.jnj.com/news/news-details/2024/Johnson--Johnson-to-Acquire-Ambrx-Advancing-Next-Generation-Antibody-Drug-Conjugates-to-Transform-the-Treatment-of-Cancer/default.aspx)[[2]](https://ambrx.com/)

## Investors
In November 2020, Ambrx announced a $200 million crossover financing with participation from Fidelity Management & Research, BlackRock-managed funds, Cormorant Asset Management, HBM Healthcare Investments, Invus, Adage Capital Partners, and Suvretta Capital Management.[[3]](https://ambrx.com/news/ambrx-closes-200-million-in-crossover-financing-with-leading-healthcare-investors-to-advance-its-clinical-and-preclinical-pipeline-of-precision-biologics/) The local note’s 5AM reference reflects earlier company history, but the strongest reviewed primary source was the later crossover financing.

## Acquisitions and Corporate Activity
Johnson & Johnson announced in January 2024 that it would acquire Ambrx in an all-cash deal worth approximately $2.0 billion and completed the acquisition in March 2024.[[1]](https://www.investor.jnj.com/news/news-details/2024/Johnson--Johnson-to-Acquire-Ambrx-Advancing-Next-Generation-Antibody-Drug-Conjugates-to-Transform-the-Treatment-of-Cancer/default.aspx)[[4]](https://www.investor.jnj.com/investor-news/news-details/2024/Johnson--Johnson-Completes-Acquisition-of-Ambrx/default.aspx)
