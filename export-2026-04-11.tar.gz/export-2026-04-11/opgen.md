# OpGen

## Overview
OpGen is a molecular diagnostics and precision-medicine company with a history in antimicrobial-resistance diagnostics and pathogen analysis.[[1]](https://ir.opgen.com/investor-faqs/)[[2]](https://ir.opgen.com/news/opgen-announces-acquisition-of-preferred-stock-by-david-lazar/) The local note's "optical genome mapping" characterization is broader than the public materials I reviewed; the clearest recent public record focuses on diagnostics and corporate restructuring.

## Technology and Business
Public investor materials emphasize diagnostic and precision-medicine operations rather than a conventional therapeutics pipeline.[[1]](https://ir.opgen.com/investor-faqs/) The company historically operated around infectious-disease diagnostics and genomics, though the reviewed recent sources were more focused on financing and corporate status than on detailed platform descriptions.[[1]](https://ir.opgen.com/investor-faqs/)

## Investors and Financing
As a public company, OpGen has been financed through public-market investors and private placements. In March 2024 it announced a securities purchase agreement under which David Lazar acquired 3,000,000 shares of Series E Convertible Preferred Stock for $3.0 million in gross proceeds.[[2]](https://ir.opgen.com/news/opgen-announces-acquisition-of-preferred-stock-by-david-lazar/)

## Acquisitions and Corporate Activity
In the same March 25, 2024 announcement, OpGen also disclosed leadership and board changes following Lazar's investment.[[2]](https://ir.opgen.com/news/opgen-announces-acquisition-of-preferred-stock-by-david-lazar/) The investor FAQ currently states that OpGen's securities are suspended from trading on Nasdaq and are on the expert market, reflecting material financial and listing pressure.[[1]](https://ir.opgen.com/investor-faqs/)
