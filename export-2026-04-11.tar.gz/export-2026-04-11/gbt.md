# Global Blood Therapeutics (GBT) — Research Notes

## Overview

Global Blood Therapeutics, Inc. (NASDAQ: GBT) was a South San Francisco, CA-based biopharmaceutical company dedicated to sickle cell disease (SCD), founded in 2012. The company developed voxelotor (Oxbryta®), the first FDA-approved therapy directly targeting hemoglobin S polymerization — the root cause of SCD. FDA granted accelerated approval in November 2019 (adults ≥12 years); expanded approval December 2021 (≥4 years). Pfizer acquired GBT for approximately $5.4 billion ($68.50/share) in October 2022. [[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance) [[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-completes-acquisition-global-blood-therapeutics)

---

## Technology & Products

- **Voxelotor (Oxbryta®, HbS polymerization inhibitor)**: First-in-class oral small molecule increasing hemoglobin's affinity for oxygen; oxygenated HbS does not polymerize, thereby preventing sickling and hemolytic anemia. FDA approved Nov 2019 (accelerated, SCD ≥12 years), expanded Dec 2021 (≥4 years). Net Oxbryta sales ~$195M in 2021. [[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance)
- **GBT021601 (GBT601)**: Next-generation HbS polymerization inhibitor; Phase 1/2 at time of acquisition. [[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance)
- **Inclaclumab (anti-P-selectin mAb)**: Anti-inflammatory antibody to reduce vaso-occlusive crises in SCD; Phase 3 at time of acquisition. [[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance)

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 2012 | South San Francisco, CA |
| IPO (NASDAQ: GBT) | 2015 | ~$126M |
| FDA approval (Oxbryta) | Nov 2019 | Accelerated approval SCD ≥12 years |
| FDA expansion | Dec 2021 | SCD ≥4 years |
| Acquired by Pfizer | Oct 2022 | $5.4B ($68.50/share) |

[[1]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance) [[2]](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-completes-acquisition-global-blood-therapeutics)

---

## References

1. Pfizer — Acquisition announcement (Aug 2022): [https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-acquire-global-blood-therapeutics-54-billion-enhance)
2. Pfizer — Acquisition completion: [https://www.pfizer.com/news/press-release/press-release-detail/pfizer-completes-acquisition-global-blood-therapeutics](https://www.pfizer.com/news/press-release/press-release-detail/pfizer-completes-acquisition-global-blood-therapeutics)
