# Kolibri

## Overview

Kolibri is a biotechnology manufacturing startup developing acoustic bioreactor systems for cell and gene therapy production.[[1]](https://sosv.com/company/kolibri/) SOSV describes the company as using sound waves to improve mammalian cell growth and address manufacturing bottlenecks in advanced therapies.[[1]](https://sosv.com/company/kolibri/)

## Technology

Kolibri's technology centers on ultrasound-enabled bioreactors that move cells gently and create lower-shear conditions than conventional systems. According to SOSV, the approach can materially increase yield and reduce production costs in cell and gene therapy manufacturing.[[1]](https://sosv.com/company/kolibri/)

## Investors

Kolibri is an SOSV / IndieBio portfolio company.[[1]](https://sosv.com/company/kolibri/) No clearly disclosed broader institutional financing round or detailed investor syndicate was identified in the reviewed public sources.

## Acquisitions and Strategic Transactions

No acquisition involving Kolibri was identified in the reviewed sources. The public footprint reviewed here is early-stage and focused on platform development.[[1]](https://sosv.com/company/kolibri/)
