# Asteroid Therapeutics — Research Notes

## Overview

Asteroid Therapeutics is a biotechnology company founded in 2021, headquartered in San Carlos, CA. Develops cancer immunotherapy treatments. Private; backed by ARCH Venture Partners. Total raised: $25M. [[1]](https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf) [[2]](https://pitchbook.com/profiles/company/501005-80)

---

## Technology

- Cancer immunotherapy platform; specific targets and technology not fully disclosed publicly as of April 2026. Listed in ARCH Venture Partners' comprehensive portfolio. [[1]](https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | ~2021–2023 | $25M | ARCH Venture Partners, Cardinal Partners, NexTech Invest, Versant Ventures |

Total raised: $25M. [[2]](https://pitchbook.com/profiles/company/501005-80)

**ARCH Venture Partners Investment**.

---

## References

1. ARCH Venture Partners — Portfolio list (Jul 2024): [https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf](https://www.archventure.com/wp-content/uploads/2024/08/comprehensive-portfolio-list-07-31-2024.pdf)
2. PitchBook — Asteroid Therapeutics profile: [https://pitchbook.com/profiles/company/501005-80](https://pitchbook.com/profiles/company/501005-80)
