# ViaCyte

## Overview

ViaCyte was a private cellular therapy company focused on stem cell-derived cell replacement therapies as a functional cure for type 1 diabetes. The company had significant clinical and preclinical work in islet cell replacement, including gene-edited hypoimmune approaches. [[1]](https://news.vrtx.com/news-releases/news-release-details/vertex-acquire-viacyte-goal-accelerating-its-potentially) [[2]](https://www.cooley.com/news/coverage/2022/2022-07-13-biotech-company-viacyte-to-be-acquired-by-vertex-pharmaceuticals)

## Technology

ViaCyte's platform centered on stem cell-derived pancreatic islet replacement therapies for diabetes. Vertex said the acquisition would bring additional human stem cell lines, intellectual property around stem cell differentiation, GMP manufacturing capabilities, and access to novel hypoimmune stem cell assets from ViaCyte's collaboration with CRISPR Therapeutics. [[1]](https://news.vrtx.com/news-releases/news-release-details/vertex-acquire-viacyte-goal-accelerating-its-potentially)

## Acquisition

Vertex announced in July 2022 that it would acquire ViaCyte for $320 million in cash. The transaction was framed as a way to accelerate Vertex's cell therapy programs in type 1 diabetes, especially VX-880. [[1]](https://news.vrtx.com/news-releases/news-release-details/vertex-acquire-viacyte-goal-accelerating-its-potentially) [[2]](https://www.cooley.com/news/coverage/2022/2022-07-13-biotech-company-viacyte-to-be-acquired-by-vertex-pharmaceuticals)

## Strategic Significance

ViaCyte's importance lies in the depth of its diabetes cell therapy IP, manufacturing infrastructure, and clinical experience. The Vertex acquisition positioned those assets as foundational to a broader effort to build potentially curative stem-cell-based diabetes therapies. [[1]](https://news.vrtx.com/news-releases/news-release-details/vertex-acquire-viacyte-goal-accelerating-its-potentially)
