# Pearl Bio

## Overview
Pearl Bio is a synthetic biology company developing next-generation biomaterials and engineered biologics through genome and ribosome engineering.[[1]](https://www.pearlbio.com/)[[2]](https://www.pearlbio.com/about-us/) The company describes its platform as enabling programmable biologics and biomaterials with chemistries not accessible through conventional biologics manufacturing.[[1]](https://www.pearlbio.com/)

## Technology
Pearl Bio says its proprietary platform couples genome engineering and ribosome engineering to create template-directed biomaterials with tunable properties.[[1]](https://www.pearlbio.com/) Business Wire coverage describes this as encoding synthetic chemistries into biologics to create "smart" biologics and biomaterials.[[3]](https://www.businesswire.com/news/home/20230620160553/en/Pearl-Bio-Secures-Breakthrough-IP-for-Multi-Functionalized-Biologics/)

## Investors
Pearl Bio's about page and Business Wire materials explicitly identify Khosla Ventures as its investor.[[2]](https://www.pearlbio.com/about-us/)[[3]](https://www.businesswire.com/news/home/20230620160553/en/Pearl-Bio-Secures-Breakthrough-IP-for-Multi-Functionalized-Biologics/) I did not identify a fuller company-issued financing history during this pass.

## Acquisitions and Corporate Activity
No acquisition involving Pearl Bio was identified in the reviewed public sources. A notable business-development event was its March 2024 collaboration with Merck, under which Pearl said it could receive up to $1 billion across upfront, option, milestone, and royalty economics.[[4]](https://www.businesswire.com/news/home/20240312580796/en/Pearl-Bio-Inks-Collaboration-with-Merck-to-Discover-Novel-Engineered-Biologics)
