# Innovent Biologics — Research Notes

## Overview

Innovent Biologics, Inc. is a Suzhou, China-based biopharmaceutical company (HKEX: 1801) listed on the Hong Kong Stock Exchange since October 2018, developing and commercializing biologics — including PD-1/PD-L1 antibodies, biosimilars, and other oncology and metabolic disease therapies — for the Chinese and global markets. Its lead product sintilimab (TYVYT®, co-developed with Eli Lilly) is a PD-1 inhibitor widely approved in China across multiple oncology indications. Innovent has 18+ products on the market. Key investors include Eli Lilly, Fidelity Investments, Hillhouse Capital, Temasek, and China Life; Sanofi made a €300M strategic equity investment in 2022. [[1]](https://en.wikipedia.org/wiki/Innovent_Biologics) [[2]](https://investor.innoventbio.com/)

---

## Technology & Products

- **Sintilimab (TYVYT®, IBI301)**: PD-1 IgG4 monoclonal antibody co-developed with Eli Lilly; approved in China for classical Hodgkin lymphoma, NSCLC, HCC, gastric cancer, esophageal cancer, and others. [[1]](https://en.wikipedia.org/wiki/Innovent_Biologics)
- **Bevacizumab biosimilar (BYVASDA®, IBI305)**: Anti-VEGF biosimilar of Avastin; NMPA-approved in China. [[1]](https://en.wikipedia.org/wiki/Innovent_Biologics)
- **IBI363 (Anti-PD-1/IL-2 Bispecific)**: Novel bispecific antibody; in clinical development. [[2]](https://investor.innoventbio.com/)
- **Broad Oncology Pipeline**: 18+ marketed products spanning biosimilars and novel biologics in oncology, ophthalmology, metabolism, and autoimmune diseases. [[2]](https://investor.innoventbio.com/)

---

## Funding & Investors

| Event | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Eli Lilly collaboration | Mar 2015 | $56M upfront + up to $400M milestones | Eli Lilly and Company |
| Pre-IPO rounds | 2015–2018 | Undisclosed | Fidelity Investments, Hillhouse Capital, Temasek, China Life |
| IPO (HKEX: 1801) | Oct 2018 | ~$421M | Public market |
| Sanofi strategic collaboration + investment | Aug 2022 | €300M equity investment | Sanofi |

[[1]](https://en.wikipedia.org/wiki/Innovent_Biologics)

---

## References

1. Wikipedia — Innovent Biologics: [https://en.wikipedia.org/wiki/Innovent_Biologics](https://en.wikipedia.org/wiki/Innovent_Biologics)
2. Innovent Biologics — Investor Relations: [https://investor.innoventbio.com/](https://investor.innoventbio.com/)
