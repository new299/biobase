# Takara Bio

## Overview

Takara Bio is a Japanese biotechnology company with businesses spanning life-science research reagents, CDMO services, gene and cell therapy, and related biotechnology fields. Public company materials describe it as a global supplier of molecular biology, genomics, gene-editing, and stem-cell products and services. [[1]](https://www.takara-bio.com/about/our_businesses.html) [[2]](https://www.takara-bio.com/about/profile.html)

## Technology

Takara's technology base includes PCR and qPCR reagents, qPCR instruments, NGS sample-preparation tools, gene-editing products, stem-cell systems, viral-vector tools, and clinical-support technologies such as RetroNectin. The company also positions itself in regenerative medicine and cell/gene therapy support, including GMP-grade materials and CDMO capabilities. [[1]](https://www.takara-bio.com/about/our_businesses.html) [[3]](https://help.takarabio.com/36168/kb/article/109833/does-takara-bio-provide-a-clinicalgrade-retronectin-reagent)

## Acquisitions

Takara has used acquisitions to expand its platform. In 2014 it acquired the stem-cell business firm formerly known as Cellartis AB from Cellectis, strengthening its stem-cell and regenerative medicine position. In 2017, Takara Bio USA Holdings completed the acquisition of Rubicon Genomics for $75 million, expanding its NGS sample-preparation capabilities, and it also completed the acquisition of WaferGen Bio-systems that year to strengthen transcriptomics and single-cell genomics offerings. [[4]](https://www.takara-bio.com/en/news/news_Release-292313809826589460.html) [[5]](https://www.takara-bio.com/en/news/news_Release-1244474015736305809.html) [[6]](https://www.takara-bio.com/en/news/news_Release6938310625890014359.html)

## Strategic Position

Takara's business model is broader than that of a single-modality biotech. It sits at the intersection of tools, platforms, and therapy enablement, using both internal R&D and M&A to extend its reach across research, translational, and clinical workflows. [[1]](https://www.takara-bio.com/about/our_businesses.html) [[5]](https://www.takara-bio.com/en/news/news_Release-1244474015736305809.html)
