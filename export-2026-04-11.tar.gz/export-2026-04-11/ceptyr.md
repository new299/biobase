# Ceptyr — Research Notes

## Overview

Ceptyr was a Bothell, WA-based biopharmaceutical company focused on protein tyrosine phosphatase (PTP) inhibitors — a largely unexplored class of pharmaceutical targets. Focused on therapeutic areas including immunosuppression, type 2 diabetes, obesity, and oncology. Total raised: ~$11.5M (Series C). Backed by ARCH Venture Partners. [[1]](https://www.drugdiscoveryonline.com/doc/ceptyr-closes-115-million-equity-investment-t-0001) [[2]](https://www.crunchbase.com/organization/ceptyr)

---

## Technology

- **Protein Tyrosine Phosphatase (PTP) Inhibitors**: Develops small molecule inhibitors targeting PTPs — enzymes that remove phosphate groups from tyrosine residues on proteins, regulating cell signaling pathways. PTPs are implicated in metabolic disease (type 2 diabetes, obesity) and immune regulation. Ceptyr's focus on PTPs represented a differentiated, underexplored target class compared to kinase inhibitors. [[1]](https://www.drugdiscoveryonline.com/doc/ceptyr-closes-115-million-equity-investment-t-0001)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A/B | ~2000–2004 | Undisclosed | ARCH Venture Partners, LODH Private Equity Partners, GeneChem Management, Falcon Technology Venture Partners, Tredegar |
| Series C | ~2007 | $11.5M | ARCH Venture Partners, LODH Private Equity Partners, others |

Total raised: ~$11.5M (Series C close; total undisclosed). [[1]](https://www.drugdiscoveryonline.com/doc/ceptyr-closes-115-million-equity-investment-t-0001)

**ARCH Venture Partners Investment**

---

## References

1. Drug Discovery Online — Ceptyr closes $11.5M Series C: [https://www.drugdiscoveryonline.com/doc/ceptyr-closes-115-million-equity-investment-t-0001](https://www.drugdiscoveryonline.com/doc/ceptyr-closes-115-million-equity-investment-t-0001)
2. Crunchbase — Ceptyr profile: [https://www.crunchbase.com/organization/ceptyr](https://www.crunchbase.com/organization/ceptyr)
