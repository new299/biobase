# Vical

## Overview

Vical was a biotechnology company focused historically on nucleic acid and vaccine technologies before later combining with Brickell Biotech in 2019. By the end of its independent life, the company functioned largely as a cash shell and public listing vehicle in the merger. [[1]](https://www.globenewswire.com/news-release/2019/08/30/1909218/11023/en/Vical-Stockholders-Approve-Reverse-Stock-Split-and-Merger-with-Brickell.html) [[2]](https://www.globenewswire.com/news-release/2019/09/03/1909823/0/en/Brickell-Biotech-Completes-Merger-with-Vical.html)

## Technology And Historical Role

Vical had earlier been associated with DNA-based therapeutics and vaccine development, but the most visible accessible public records now relate to the merger rather than its legacy technology portfolio. In the merger disclosures, the key value drivers were its Nasdaq listing, cash balance, and the ability to combine with Brickell's dermatology pipeline. [[1]](https://www.globenewswire.com/news-release/2019/08/30/1909218/11023/en/Vical-Stockholders-Approve-Reverse-Stock-Split-and-Merger-with-Brickell.html) [[2]](https://www.globenewswire.com/news-release/2019/09/03/1909823/0/en/Brickell-Biotech-Completes-Merger-with-Vical.html)

## Strategic Transaction

In September 2019, Brickell Biotech completed its merger with Vical, creating the Nasdaq-listed company Brickell Biotech. Brickell said the merger brought about $60 million in combined cash and R&D funding from NovaQuest to support its lead dermatology program. [[2]](https://www.globenewswire.com/news-release/2019/09/03/1909823/0/en/Brickell-Biotech-Completes-Merger-with-Vical.html)

## Historical Context

This note is intentionally historical. The public record now supports describing Vical mainly through its final merger and transition into Brickell rather than as an ongoing standalone biotech. [[1]](https://www.globenewswire.com/news-release/2019/08/30/1909218/11023/en/Vical-Stockholders-Approve-Reverse-Stock-Split-and-Merger-with-Brickell.html) [[2]](https://www.globenewswire.com/news-release/2019/09/03/1909823/0/en/Brickell-Biotech-Completes-Merger-with-Vical.html)
