# Pliant Therapeutics

## Overview
Pliant Therapeutics is a clinical-stage biotechnology company focused on fibrosis, developing integrin-targeted therapies for lung, liver, and other fibrotic diseases.[[1]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-raises-100-million-series-c-financing)[[2]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-announces-pricing-upsized-2500-million)

## Technology
The company’s core therapeutic approach is selective integrin inhibition to modulate TGF-beta activation and fibrotic disease biology. Public materials highlight programs such as PLN-74809 and other integrin-focused assets.[[1]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-raises-100-million-series-c-financing)[[2]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-announces-pricing-upsized-2500-million)

## Investors / Financing
Pliant raised a $100 million Series C in March 2020 led by Novartis, then entered into a loan facility of up to $100 million with Oxford Finance in 2022. In January 2023 it priced an upsized public offering raising about $250 million gross.[[1]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-raises-100-million-series-c-financing)[[3]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-enters-100-million-loan-facility-agreement)[[2]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-announces-pricing-upsized-2500-million)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[2]](https://ir.pliantrx.com/news-releases/news-release-details/pliant-therapeutics-announces-pricing-upsized-2500-million)
