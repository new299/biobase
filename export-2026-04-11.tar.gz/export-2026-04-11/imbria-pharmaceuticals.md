# Imbria Pharmaceuticals — Research Notes

## Overview

Imbria Pharmaceuticals is a Cambridge, MA-based cardiovascular biotechnology company focused on cardiac energy metabolism — translating understanding of how the heart produces and uses energy into novel cardiovascular disease treatments. Its lead candidate ninerafaxstat is a cardiac energy modulator in development for non-obstructive hypertrophic cardiomyopathy (nHCM) and other cardiovascular conditions. Total raised: $152M. **RA Capital Investment.** [[1]](https://imbria.com/) [[2]](https://www.crunchbase.com/organization/imbria-pharmaceuticals)

---

## Technology & Products

- **Ninerafaxstat**: Cardiac energy modulator designed to restore mitochondrial energy efficiency in the failing heart by reducing reliance on fatty acid oxidation and enhancing glucose utilization; in Phase 2b FORTITUDE-HCM trial for non-obstructive hypertrophic cardiomyopathy (nHCM); trial initiation planned Q2 2025, topline data expected late 2026. [[1]](https://imbria.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Earlier rounds | Pre-2025 | ~$94.5M | SV Health Investors, **RA Capital Investment** |
| Series B | Apr 2025 | $57.5M | Deep Track Capital (lead, new), AN Ventures (new), Catalio Capital Management (new), Cytokinetics (new), **RA Capital Investment**, SV Health Investors, AXA IM Alts |
| Total | — | $152M | — |

[[2]](https://www.crunchbase.com/organization/imbria-pharmaceuticals)

---

## References

1. Imbria Pharmaceuticals — Homepage: [https://imbria.com/](https://imbria.com/)
2. Crunchbase — Imbria Pharmaceuticals: [https://www.crunchbase.com/organization/imbria-pharmaceuticals](https://www.crunchbase.com/organization/imbria-pharmaceuticals)
