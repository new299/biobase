# CORE Diagnostics

## Overview
CORE Diagnostics is an India-based diagnostics company focused on high-end pathology, molecular diagnostics, genomics, and disease-stratification testing.[[1]](https://in.linkedin.com/company/core-diagnostics)[[2]](https://www.thecompanycheck.com/company/b/core-diagnostics/05s16i6n8dwxjcwoq)

## Technology
Public company descriptions emphasize advanced oncology and specialty diagnostics, including genetic testing, molecular profiling, and other next-generation laboratory services rather than a therapeutic pipeline.[[1]](https://in.linkedin.com/company/core-diagnostics)[[2]](https://www.thecompanycheck.com/company/b/core-diagnostics/05s16i6n8dwxjcwoq)

## Investors
Secondary company databases report backing from F-Prime Capital, Eight Roads Ventures, Artiman, and InnoVen Capital, with roughly $17 million of total funding disclosed across multiple rounds.[[2]](https://www.thecompanycheck.com/company/b/core-diagnostics/05s16i6n8dwxjcwoq)[[3]](https://www.cbinsights.com/company/core-diagnostics/financials)

## Acquisitions / Other
Secondary databases indicate that Metropolis Healthcare acquired CORE Diagnostics in December 2024.[[2]](https://www.thecompanycheck.com/company/b/core-diagnostics/05s16i6n8dwxjcwoq)[[3]](https://www.cbinsights.com/company/core-diagnostics/financials)
