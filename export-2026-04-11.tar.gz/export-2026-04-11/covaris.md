# Covaris — Research Notes

## Overview

Covaris, Inc. is a Woburn, MA-based life sciences instrumentation company providing Adaptive Focused Acoustics® (AFA®) technology for biological and chemical sample preparation. Acquired by PerkinElmer in January 2022. Prior to acquisition, raised ~$52.4M and had received a New Mountain Capital majority investment. [[1]](https://www.covaris.com/blogs/perkinelmer-acquires-covaris/) [[2]](https://www.newmountaincapital.com/covaris-announces-growth-partnership-with-new-mountain-capital/)

---

## Technology

- **Adaptive Focused Acoustics® (AFA®)**: Proprietary technology using focused acoustic energy to perform sample preparation including DNA/RNA shearing (for NGS library prep), cell lysis, and compound dissolution. Based on shock wave physics to deliver high-energy density with speed, reproducibility, and precision. Industry gold standard for DNA shearing for next-generation sequencing library preparation. [[3]](https://www.covaris.com/)
- **Products**: ME220 and LE220+ focused ultrasonicators, truChIP chromatin shearing kits, SNAP-OPEN lysis technology, microTUBE and milliTUBE consumables. [[3]](https://www.covaris.com/)
- **Partnership**: Illumina co-marketing agreement for NGS DNA shearing. [[4]](https://www.proactiveinvestors.com/companies/news/74006/illumina-signs-co-marketing-agreement-for-covaris-dna-shearing-technology-8741.html)

---

## Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | ~2000 | Woburn, MA |
| New Mountain Capital majority investment | 2022 | Growth partnership (pre-acquisition) |
| Acquired by PerkinElmer | Jan 2022 | Integrated into PerkinElmer life sciences portfolio |

[[1]](https://www.covaris.com/blogs/perkinelmer-acquires-covaris/)

---

## References

1. Covaris — PerkinElmer acquisition announcement: [https://www.covaris.com/blogs/perkinelmer-acquires-covaris/](https://www.covaris.com/blogs/perkinelmer-acquires-covaris/)
2. New Mountain Capital — Covaris growth partnership: [https://www.newmountaincapital.com/covaris-announces-growth-partnership-with-new-mountain-capital/](https://www.newmountaincapital.com/covaris-announces-growth-partnership-with-new-mountain-capital/)
3. Covaris — Company website: [https://www.covaris.com/](https://www.covaris.com/)
4. Proactive Investors — Illumina + Covaris co-marketing agreement: [https://www.proactiveinvestors.com/companies/news/74006/illumina-signs-co-marketing-agreement-for-covaris-dna-shearing-technology-8741.html](https://www.proactiveinvestors.com/companies/news/74006/illumina-signs-co-marketing-agreement-for-covaris-dna-shearing-technology-8741.html)
