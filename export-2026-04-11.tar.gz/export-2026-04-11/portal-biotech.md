# Portal Biotech

## Overview
- **Company:** Portal Biotech
- **Focus:** Single-molecule proteomics and protein sequencing
- **Mission:** Enable next-generation cell engineering and drug discovery through advanced protein analysis
- **Status:** Active (independent company, not acquired as of latest available info)

---

## Core Concept: Proteomics
- DNA = blueprint of life
- Proteins = functional molecules that execute biological processes
- Understanding the **proteome** is key to:
  - Human health insights
  - Disease mechanisms
  - Drug discovery

## Technology

### Nanopore Platform
- Originates from research at the Maglia Lab, University of Groningen
- Uses **nanopores** as biosensors to analyze single molecules

### How it Works
- Molecules pass through a nanopore
- This generates unique electrical signals
- Signals encode molecular structure at near atomic resolution
- Machine learning decodes signals into:
  - Protein identity
  - Sequence information
  - Modifications

### Key Capabilities
- Single-molecule detection
- End-to-end protein sequencing
- Works on:
  1. Molecules
  2. Peptides
  3. Proteins

---

## Platform Advantages

- **Rapid workflows**
  - Real-time results

- **Flexible assays**
  - From small peptides to large proteins (>100 kDa)

- **Full-length analysis**
  - Detect mutations and modifications in context

- **Accessible**
  - Bench-top instruments

- **Scalable**
  - Suitable for low- and high-throughput labs

- **Quantitative**
  - Direct molecule counting

---

## Applications

### Structural / Identity
- Isoforms
- Truncations
- Mutations
- Translation errors
- Chirality

### Quantitative
- Protein abundance
- Synthesis and degradation rates
- Impurities

### Modifications (Post-translational)
- Phosphorylation
- Glycosylation
- Acetylation
- Deamidation
- Conjugation
- Proteolysis

---

## Products & Services

### Services
- Protein characterization via company labs
- Collaboration opportunities (academic + commercial)
- Early Access Program for partners

### Instruments
- Bench-top protein sequencing systems
- Target users:
  - Academic labs
  - Biotech and pharma
  - Industrial labs
  - Core facilities

---

## Leadership Team

- **Andy Heron** — CEO & Co-founder  
- **Giovanni Maglia** — CSO & Co-founder  
- **Selly Saini** — COO  
- **Tim Massingham** — VP Machine Learning & Bioinformatics  

- Executive team has 50+ years combined experience in:
  - Biosensors
  - Nanopore science

---

## Locations

- **UK Headquarters**
  - London (Scale Space, White City)

- **Netherlands**
  - Groningen

---

## Technology Positioning

- Competes in emerging **single-molecule proteomics** space
- Analogous to what companies like Oxford Nanopore did for DNA sequencing
- Focus advantage:
  - Direct protein sequencing (harder than DNA sequencing)
  - Full proteoform resolution

---

## Investors & Funding

- Public investor information is limited in the provided material
- Known to be venture-backed (typical for deep-tech biotech startups)
- Likely funding sources:
  - VC firms (life sciences / deep tech)
  - Grants (EU/UK research ecosystems)
  - Academic spinout support

(Note: Exact investors should be confirmed from Crunchbase, PitchBook, or press releases)

---

## Business Model

- Instrument sales (bench-top devices)
- Service-based revenue (protein analysis)
- Early-access partnerships
- Potential future:
  - Consumables
  - Data/analytics platforms

---

## Strategic Importance

- Addresses major gap in biology:
  - DNA sequencing is mature
  - Protein sequencing is still limited

- Enables:
  - Better drug development
  - Precision medicine
  - Synthetic biology advances

---

## Key Takeaways

- Portal Biotech is a **deep-tech proteomics company**
- Core innovation = **nanopore-based protein sequencing**
- Combines:
  - Hardware (nanopores)
  - Chemistry
  - Machine learning
- Positioned at the frontier of:
  - Proteomics
  - Drug discovery
  - Bioengineering

## ASeq Posts

- [Portal Protein Pattern Pinpointing](https://aseq.substack.com/p/portal-protein-pattern-pinpointing)
