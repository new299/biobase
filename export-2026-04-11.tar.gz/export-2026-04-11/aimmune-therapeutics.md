# Aimmune Therapeutics

## Overview
Aimmune Therapeutics was a biopharmaceutical company focused on oral immunotherapies for food allergies.[[1]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-to-acquire-aimmune-therapeutics)[[2]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-completes-acquisition-aimmune-therapeutics) Its lead commercial product was PALFORZIA for peanut allergy.[[1]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-to-acquire-aimmune-therapeutics)

## Technology and Products
Aimmune’s core approach was Characterized Oral Desensitization ImmunoTherapy, or CODIT, using defined quantities of allergen to desensitize patients.[[1]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-to-acquire-aimmune-therapeutics) This was a food-allergy therapeutic strategy rather than a conventional molecular biotech platform.

## Investors
Nestlé Health Science disclosed that it had invested a total of $473 million in Aimmune by February 2020, reaching an approximate 25.6% equity ownership stake before full acquisition.[[3]](https://www.nestlehealthscience.com/newsroom/press-releases/health-science-further-invests-in-aimmune-therapeutics) The local note’s RA Capital reference reflects Aimmune’s broader biotech investor base, though the strongest reviewed sources centered on Nestlé’s role.

## Acquisitions and Corporate Activity
Nestlé Health Science announced in August 2020 that it would acquire Aimmune and completed the acquisition in October 2020.[[1]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-to-acquire-aimmune-therapeutics)[[2]](https://www.nestle.com/media/pressreleases/allpressreleases/nestle-completes-acquisition-aimmune-therapeutics)
