# PIC Therapeutics

## Overview
PIC Therapeutics is a clinical-stage biotechnology company developing cancer therapeutics based on modulation of RNA translation.[[1]](https://www.gaebler.com/Funded-Company-547C8860-3C2F-41CA-8733-46DB3C9BBD85-PIC-Therapeutics)[[2]](https://www.cbinsights.com/company/pic-therapeutics)

## Technology
Public company databases describe PIC as building a new class of cancer therapeutics that act through RNA translation control, aiming to address difficult oncology targets with a differentiated mechanism.[[1]](https://www.gaebler.com/Funded-Company-547C8860-3C2F-41CA-8733-46DB3C9BBD85-PIC-Therapeutics)[[2]](https://www.cbinsights.com/company/pic-therapeutics)

## Investors
Gaebler reports at least $40 million in venture funding across two rounds, with backing from OrbiMed, Harrington Discovery Institute, Lumira Capital, Advent Life Sciences, and private investors.[[1]](https://www.gaebler.com/Funded-Company-547C8860-3C2F-41CA-8733-46DB3C9BBD85-PIC-Therapeutics)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources. Because the direct company press archive was limited in the reviewed set, this note relies partly on secondary funding databases.[[1]](https://www.gaebler.com/Funded-Company-547C8860-3C2F-41CA-8733-46DB3C9BBD85-PIC-Therapeutics)[[2]](https://www.cbinsights.com/company/pic-therapeutics)
