# Hua Medicine — Research Notes

## Overview

Hua Medicine is a Shanghai, China-based clinical-stage biopharmaceutical company founded in 2011 by CEO Chen Li (former China CSO at Roche), in-licensing Roche's glucokinase activator (GKA) program including dorzagliatin in 2011. Hua's lead product dorzagliatin (HuaTangNing) is a first-in-class GKA that targets the glucose sensor glucokinase in the liver, pancreas, and gut to restore glucose sensitivity and stabilize blood glucose in type 2 diabetes (T2D). Dorzagliatin was approved by China's NMPA on September 30, 2022, and has since received approval from Hong Kong SAR's Department of Health. Hua has filed an IND with the US FDA. Total raised: ~$242M. Key investors: ARCH Venture Partners, Venrock, Fidelity Investments, WuXi AppTec, GIC (Singapore), K11, Ping An Ventures, Ally Bridge Group. [[1]](https://www.huamedicine.com/En/news-165) [[2]](https://www.huamedicine.com/En/news-256)

---

## Technology & Pipeline

- **Dorzagliatin / HuaTangNing (GKA for T2D)**: First-in-class glucokinase activator (GKA); activates glucose sensor glucokinase in the liver, pancreas, and gut to restore the glucose-sensing system's ability to respond to changing blood glucose levels — addressing the fundamental loss of glucose sensitivity in T2D. NMPA approved Sep 2022 (China); HK SAR approved 2024; US FDA IND filed; WHO ATC classification listing granted. [[1]](https://www.huamedicine.com/En/news-165) [[2]](https://www.huamedicine.com/En/news-256)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2011–2014 | — | **ARCH Venture Partners**, Venrock, Fidelity Investments, WuXi Ventures |
| Series B | ~2016 | $25M | Ally Bridge Group (lead), Frontline BioVentures, TF Capital; ARCH, Venrock, Fidelity, WuXi returning |
| Later rounds | ~2018–2022 | — | GIC (Singapore), K11, Ping An Ventures |
| Total | — | ~$242M | — |

**ARCH Venture Partners Investment**

[[1]](https://www.huamedicine.com/En/news-165)

---

## References

1. Hua Medicine — $25M Series B announcement: [https://www.huamedicine.com/En/news-165](https://www.huamedicine.com/En/news-165)
2. Hua Medicine — Hong Kong NMPA filing acceptance: [https://www.huamedicine.com/En/news-256](https://www.huamedicine.com/En/news-256)
