# Vitarka Therapeutics

## Overview

Vitarka Therapeutics is a U.K. preclinical biotech company developing non-viral intracellular delivery technologies for RNA therapeutics, especially in solid tumors. The company says its EndoPore platform is designed to overcome endosomal escape and deliver therapeutic cargo directly into the cytosol. [[1]](https://www.vitarka.co.uk/2023/04/06/uk-biotech-start-up-secures-1-27m-to-revolutionise-intracellular-drug-delivery-through-tumour-targeted-technology/) [[2]](https://sosv.com/company/vitarka-therapeutics/)

## Technology

EndoPore uses pore-forming proteins for targeted intracellular delivery of RNA therapeutics. Public descriptions emphasize tumor targeting, cytosolic delivery, and applicability to siRNA, ASO, peptides, and other cargo types that conventional non-viral systems struggle to deliver efficiently. [[1]](https://www.vitarka.co.uk/2023/04/06/uk-biotech-start-up-secures-1-27m-to-revolutionise-intracellular-drug-delivery-through-tumour-targeted-technology/) [[2]](https://sosv.com/company/vitarka-therapeutics/) [[3]](https://www.cbinsights.com/company/vitarka-therapeutics)

## Investors

In April 2023, Vitarka announced that it had raised GBP1.27 million in equity from SOSV and the U.K. Innovation & Science Seed Fund, plus grant funding from Innovate UK. The local SOSV note is therefore directly supported by the public record. [[1]](https://www.vitarka.co.uk/2023/04/06/uk-biotech-start-up-secures-1-27m-to-revolutionise-intracellular-drug-delivery-through-tumour-targeted-technology/) [[4]](https://find-and-update.company-information.service.gov.uk/company/13291464)

## Strategic Position

Vitarka is an enabling-platform company rather than a single-asset therapeutics developer. Its strategic claim is that delivery, especially cytosolic delivery in tumors, is still a bottleneck in RNA medicine and that EndoPore can materially improve it. [[1]](https://www.vitarka.co.uk/2023/04/06/uk-biotech-start-up-secures-1-27m-to-revolutionise-intracellular-drug-delivery-through-tumour-targeted-technology/) [[2]](https://sosv.com/company/vitarka-therapeutics/)
