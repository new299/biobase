# Azenta Life Sciences — Research Notes

## Overview

Azenta Life Sciences (NASDAQ: AZTA) is a Burlington, MA-based life sciences services company providing sample management, cryogenic storage, and genomics/sequencing services. Formerly Brooks Automation, rebranded to Azenta in 2021. Manages approximately 60 million biological samples globally. ~$595M TTM revenue (FY2025). Under CEO John Marotta (appointed Sep 2024), pursuing a strategic turnaround. [[1]](https://www.azenta.com/) [[2]](https://investors.azenta.com/)

---

## Technology & Services

- **Sample Management & Cryogenic Storage**: Automated sample storage, retrieval, and management systems for biobanks, pharma, and research institutions. Flagship platforms include the SampleStore™ and custom automated biobanks. [[1]](https://www.azenta.com/)
- **GENEWIZ Genomics Services**: Full-service genomics division providing Sanger sequencing, next-generation sequencing (NGS), gene synthesis, gene editing (CRISPR), and bioinformatics. One of the world's largest sequencing services providers. [[3]](https://www.genewiz.com/)
- **UK Biocentre Acquisition** (2024): Acquired UK Biocentre to expand genomics services in Europe. [[4]](https://www.azenta.com/news/azenta-acquires-uk-biocentre)

---

## Funding & Financials

| Event | Date | Details |
|-------|------|---------|
| NASDAQ listing (AZTA) | 2021 | Rebranded from Brooks Automation |
| CEO John Marotta appointed | Sep 2024 | Strategic turnaround initiated |
| TTM Revenue | FY2025 | ~$595M |

[[2]](https://investors.azenta.com/)

---

## References

1. Azenta — Website: [https://www.azenta.com/](https://www.azenta.com/)
2. Azenta — Investor Relations: [https://investors.azenta.com/](https://investors.azenta.com/)
3. GENEWIZ — Website: [https://www.genewiz.com/](https://www.genewiz.com/)
4. Azenta — UK Biocentre acquisition: [https://www.azenta.com/news/azenta-acquires-uk-biocentre](https://www.azenta.com/news/azenta-acquires-uk-biocentre)
