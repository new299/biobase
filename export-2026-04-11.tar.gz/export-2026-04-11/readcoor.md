# ReadCoor

## Overview
ReadCoor developed an in situ spatial sequencing platform based on FISSEQ technology for tissue-scale transcriptomic analysis [[1]](https://www.cbinsights.com/company/readcoor) [[2]](https://www.technologynetworks.com/genomics/product-news/10x-genomics-signs-agreement-to-acquire-readcoor-341327).

## Technology
CB Insights describes ReadCoor's technology as fluorescence in situ sequencing that integrates sequencing, morphometric analysis, cellular localization, and three-dimensional spatial imaging [[1]](https://www.cbinsights.com/company/readcoor). Nature Biotechnology's acquisition coverage also described the platform as whole-transcriptome in situ sequencing with subcellular spatial context [[3]](https://www.nature.com/articles/s41587-020-0734-6).

## Investors
CB Insights reports ReadCoor raised about $52.4 million before its acquisition [[1]](https://www.cbinsights.com/company/readcoor).

## Acquisitions / Strategic Transactions
10x Genomics announced its acquisition of ReadCoor in October 2020 for $350 million in cash and stock consideration to strengthen its in situ analysis capabilities [[2]](https://www.technologynetworks.com/genomics/product-news/10x-genomics-signs-agreement-to-acquire-readcoor-341327).

## References
[[1]](https://www.cbinsights.com/company/readcoor)
[[2]](https://www.technologynetworks.com/genomics/product-news/10x-genomics-signs-agreement-to-acquire-readcoor-341327)
[[3]](https://www.nature.com/articles/s41587-020-0734-6)
