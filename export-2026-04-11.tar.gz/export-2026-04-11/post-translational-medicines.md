# Post Translational Medicines

## Overview
Post Translational Medicines is an early-stage therapeutics company developing drugs against proteoforms and aging-related protein dysfunction.[[1]](https://sosv.com/company/post-translational-medicines/)[[2]](https://sosv.com/tx_company/post-translational-medicines/)

## Technology
SOSV says PTM is unlocking the "dark proteome" by mapping and targeting proteoforms, the functional protein states shaped by post-translational modifications and conformation. Its Surveyor platform combines next-generation proteomics and AI, with an initial focus on lysosomal dysfunction and age-related disease biology.[[1]](https://sosv.com/company/post-translational-medicines/)[[2]](https://sosv.com/tx_company/post-translational-medicines/)

## Investors
The clearest public investor signal is SOSV portfolio inclusion. SOSV also states that PTM had roughly half of its round already in the bank at the time of the profile, but it does not provide a fully named financing announcement in the reviewed sources.[[1]](https://sosv.com/company/post-translational-medicines/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://sosv.com/company/post-translational-medicines/)
