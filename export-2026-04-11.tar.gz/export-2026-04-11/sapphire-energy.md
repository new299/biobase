# Sapphire Energy

## Overview
Sapphire Energy is known for developing algae-based renewable fuels and chemicals, especially "green crude" and related bio-based products [[1]](https://en.wikipedia.org/wiki/Sapphire_Energy).

## Technology
Public descriptions characterize Sapphire's platform as algae cultivation and downstream processing aimed at producing renewable crude oil and chemicals compatible with existing infrastructure [[1]](https://en.wikipedia.org/wiki/Sapphire_Energy).

## Investors
The reviewed public source reports seed financing from ARCH Ventures and Larry Bock, a Series B of more than $100 million involving ARCH Venture Partners, Wellcome Trust, Venrock, and Cascade Investment, and a 2012 Series C of $144 million with participation from Monsanto and other investors [[1]](https://en.wikipedia.org/wiki/Sapphire_Energy).

## Acquisitions / Strategic Transactions
The reviewed public source did not identify a major acquisition. Instead, major strategic milestones included federal support for its Green Crude Farm and partnerships such as its work with Phillips 66 [[1]](https://en.wikipedia.org/wiki/Sapphire_Energy).

## References
[[1]](https://en.wikipedia.org/wiki/Sapphire_Energy)
