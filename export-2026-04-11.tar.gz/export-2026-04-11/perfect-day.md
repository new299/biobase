# Perfect Day

## Overview
Perfect Day is a food technology company using precision fermentation to produce animal-free dairy proteins and related ingredients.[[1]](https://perfectday.com/newsroom/perfect-day-raises-350-million-to-expand-consumer-and-enterprise-biology-platforms/)[[2]](https://perfectday.com/newsroom/perfect-day-accelerates-next-chapter-of-impact-with-pre-series-e-of-up-to-90-million-and-leadership-updates/)

## Technology
The company says it uses microflora fermentation to make whey and other dairy proteins without cows, positioning the platform around sustainable dairy ingredients and broader enterprise biology applications.[[1]](https://perfectday.com/newsroom/perfect-day-raises-350-million-to-expand-consumer-and-enterprise-biology-platforms/)[[2]](https://perfectday.com/newsroom/perfect-day-accelerates-next-chapter-of-impact-with-pre-series-e-of-up-to-90-million-and-leadership-updates/)

## Investors
Perfect Day announced a $350 million Series D in September 2021 co-led by Temasek and CPP Investments. On January 5, 2024, it announced a pre-Series E financing round of up to $90 million led by internal investors.[[1]](https://perfectday.com/newsroom/perfect-day-raises-350-million-to-expand-consumer-and-enterprise-biology-platforms/)[[2]](https://perfectday.com/newsroom/perfect-day-accelerates-next-chapter-of-impact-with-pre-series-e-of-up-to-90-million-and-leadership-updates/)

## Acquisitions / Other
The reviewed source set did not show a company-level acquisition of Perfect Day itself. Public reporting in 2025 instead focused on the sale of its consumer packaged goods business, The Urgent Company, to Superlatus/TRxADE-linked buyers.[[3]](https://superlatus.com/news/superlatus-takes-on-perfect-days-animal-free-brands-through-acquisition-of-the-urgent-company-plus-further-surprise-moves)
