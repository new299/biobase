# Intabio — Research Notes

## Overview

Intabio was a Newark, CA-based biopharmaceutical analytical tools company founded in 2015, developing the Blaze™ system — a benchtop microchip instrument integrating imaged capillary isoelectric focusing (cIEF) with electrospray ionization mass spectrometry (MS) for rapid, comprehensive characterization of biotherapeutic protein product quality attributes. Intabio raised $29.72M total and was acquired by SCIEX in January 2021. Key investors included Vertical Venture Partners, Genoa Ventures, Northpond Ventures, and SCIEX. [[1]](https://sciex.com/about-us/press-releases/2021/sciex-acquires-intabio) [[2]](https://www.crunchbase.com/organization/intabio)

---

## Technology & Products

- **Blaze™ System (imaged cIEF-MS)**: Benchtop microchip-based analytical instrument integrating capillary isoelectric focusing (cIEF) protein isoform separation with 280-nm UV imaging (isoform quantification) and electrospray ionization for downstream mass spectrometry; provides 100-fold higher throughput than traditional approaches; enables rapid detection and identification of subtle protein modifications (charge variants, deamidation, glycoforms) critical for biotherapeutic product quality control. [[1]](https://sciex.com/about-us/press-releases/2021/sciex-acquires-intabio)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | 2015–2019 | ~$11.72M | Vertical Venture Partners, Genoa Ventures, NSF, others |
| Series B | 2020 | $18M | SCIEX (strategic), Northpond Ventures, Vertical Venture Partners, Genoa Ventures |
| Total | — | $29.72M | — |
| Acquired by SCIEX | Jan 2021 | Undisclosed | SCIEX (Danaher/Sciex subsidiary) |

[[2]](https://www.crunchbase.com/organization/intabio)

---

## References

1. SCIEX — Intabio acquisition: [https://sciex.com/about-us/press-releases/2021/sciex-acquires-intabio](https://sciex.com/about-us/press-releases/2021/sciex-acquires-intabio)
2. Crunchbase — Intabio: [https://www.crunchbase.com/organization/intabio](https://www.crunchbase.com/organization/intabio)
