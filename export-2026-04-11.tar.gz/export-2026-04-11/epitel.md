# Epitel — Research Notes

## Overview

Epitel is a Salt Lake City, UT-based medical device company developing wearable, scalp-applied EEG monitoring systems for epilepsy diagnosis and management. The company's REMI™ system provides medical-grade continuous seizure monitoring with AI-powered event detection. The company received FDA 510(k) clearance in April 2024 for both the REMI Remote EEG Monitoring System for Ambulatory Use and the REMI Vigilenz AI For Event Detection. Total raised: ~$20M+. Key investors: CHV Capital, Genoa Ventures, Dexcom Ventures, Catalyst Health Ventures, OSF HealthCare. [[1]](https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/) [[2]](https://www.crunchbase.com/organization/epitel)

---

## Technology & Products

- **REMI™ Remote EEG Monitoring System**: Rechargeable, scalp-adhesive wearable device for continuous, medical-grade EEG recording. Pairs via Bluetooth with a mobile app to detect and record seizures, enabling ambulatory monitoring outside hospital settings. [[1]](https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/)
- **REMI Vigilenz™ AI**: FDA-cleared AI platform for automated seizure event detection from REMI EEG recordings. [[1]](https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/)
- **FDA Clearance (Apr 2024)**: Both REMI Remote EEG Monitoring System and REMI Vigilenz AI received FDA 510(k) clearance simultaneously in April 2024.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| NIH/Epilepsy Foundation Grants | ~2016–2021 | $7.5M+ | NIH, Epilepsy Foundation |
| Series A | Feb 2022 | $12.5M | CHV Capital (lead), Genoa Ventures, Dexcom Ventures, Catalyst Health Ventures, Angel Physicians Fund, OSF HealthCare |

Total raised: $20M+. [[1]](https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/)

---

## References

1. Frontlines.io — What Epitel Learned Raising $20M After Years of Grant Funding: [https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/](https://www.frontlines.io/what-epitel-learned-raising-20m-after-years-of-grant-funding/)
2. Crunchbase — Epitel: [https://www.crunchbase.com/organization/epitel](https://www.crunchbase.com/organization/epitel)
