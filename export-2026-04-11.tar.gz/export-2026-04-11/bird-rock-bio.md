# Bird Rock Bio

## Overview
Bird Rock Bio was a biopharmaceutical company developing therapeutic antibodies against validated biologic targets.[[1]](https://www.gaebler.com/Funded-Company-6239E5D7-E902-4236-931C-F29DFD122C0A-Bird-Rock-Bio) Public information is limited and largely database-based.

## Technology and Pipeline
Gaebler describes Bird Rock Bio as developing first-in-class and best-in-class therapeutic antibodies with significant clinical and commercial differentiation against targets with strong human proof of mechanism.[[1]](https://www.gaebler.com/Funded-Company-6239E5D7-E902-4236-931C-F29DFD122C0A-Bird-Rock-Bio)

## Investors
Gaebler reports that Bird Rock Bio raised at least $7.5 million across two venture rounds and identifies 5AM Ventures as its investor.[[1]](https://www.gaebler.com/Funded-Company-6239E5D7-E902-4236-931C-F29DFD122C0A-Bird-Rock-Bio) The local note is therefore supported by the reviewed public source.

## Acquisitions and Corporate Activity
I did not identify a completed acquisition involving Bird Rock Bio in the reviewed public sources. The accessible public record is sparse and primarily financing-database based.[[1]](https://www.gaebler.com/Funded-Company-6239E5D7-E902-4236-931C-F29DFD122C0A-Bird-Rock-Bio)
