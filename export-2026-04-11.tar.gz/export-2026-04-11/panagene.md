# Panagene (HLB Panagene Co., Ltd.)

**Panagene** (officially **HLB Panagene Co., Ltd.**, KOSDAQ: 046210) is a **South Korean molecular diagnostics and liquid biopsy company** that develops and commercializes **genetic diagnostic kits** — including **liquid biopsy solutions** — primarily for oncology and other precision medicine applications. It also manufactures related molecular diagnostic tools and PNA‑based reagents. [[1]](https://stockanalysis.com/quote/kosdaq/046210/company/) [[2]](https://kr.linkedin.com/company/hlbpanagene)

## Company Overview
- **Founded:** 1976 (originally Panagene Inc.; became HLB Panagene in 2023). [[1]](https://stockanalysis.com/quote/kosdaq/046210/company/)  
- **Headquarters:** **Daejeon, South Korea**. [[1]](https://stockanalysis.com/quote/kosdaq/046210/company/)  
- **Industry:** **Molecular diagnostics / biotech**.  
- **Publicly Traded:** Listed on **KOSDAQ (046210)**. [[1]](https://stockanalysis.com/quote/kosdaq/046210/company/)  
- **Employees:** ~80–100. [[2]](https://kr.linkedin.com/company/hlbpanagene)

## Liquid Biopsy & Diagnostic Technology

Panagene is known for its **molecular diagnostic product portfolio** centered on **liquid biopsy and PCR‑based mutation detection**:

- **PANAMutyper:** A high‑sensitivity **liquid biopsy kit** that detects low‑frequency mutations in **cell‑free DNA (cfDNA)** from blood, used for cancer mutation genotyping (e.g., EGFR, KRAS, NRAS). [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/) [[turn0search19]](https://www.medical-xprt.com/companies/panagene-inc-120363/products)  
- **PNAClamp:** A **peptide nucleic acid (PNA)‑based PCR assay** that selectively amplifies mutated DNA sequences from tissue or blood samples. [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/)  
- **PANA RealTyper & PANA qPCR:** Additional PNA‑based genotyping and multiplex PCR tools used for both oncology and infectious disease detection. [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/)

The company leverages its proprietary **PNA (peptide nucleic acid)** chemistry to enhance sensitivity and specificity of mutation detection in liquid biopsies — enabling **less invasive cancer profiling and companion diagnostics** versus traditional tissue biopsies. [[turn0search3]](https://www.medicalsdir.com/listing/hlb-panagene-co-ltd) [[turn0search14]](https://surpriser.tistory.com/1584)

## Market & Applications
Panagene’s diagnostic products are primarily used for:
- **Oncology liquid biopsy:** Detecting tumor mutations such as EGFR, KRAS/NRAS, BRAF in circulating cell‑free DNA from blood samples. [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/) [[turn0search19]](https://www.medical-xprt.com/companies/panagene-inc-120363/products)  
- **Companion diagnostics:** Approved tests for targeted therapies (e.g., ROS1 companion diagnostic in Korea). [[turn0search6]](https://pharm.edaily.co.kr/news/read?newsId=04093446642141040)  
- **Infectious disease diagnostics:** PNA‑based assays for SNP discrimination and pathogen detection. [[turn0search3]](https://www.medicalsdir.com/listing/hlb-panagene-co-ltd)

Panagene’s liquid biopsy technology enables **mutation analysis from small volumes of blood** — a non‑invasive alternative to surgical tissue biopsy — which is valuable for **cancer detection, monitoring, and personalized therapy selection**. [[turn0search7]](https://pulse.mk.co.kr/news/english/8042928)

## Business Status
Panagene remains an **active public company** operating in the molecular diagnostics space with a **focus on precision oncology diagnostics and liquid biopsy products**. It continues to expand its product offerings and international market reach through regulatory approvals and partnerships. [[turn0search6]](https://pharm.edaily.co.kr/news/read?newsId=04093446642141040)

## Headquarters
- 54, Techno 10‑ro, Yuseong‑gu, **Daejeon, South Korea**. [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/)

## Summary
**Panagene** (now **HLB Panagene**) is a South Korean molecular diagnostics company specializing in **PNA‑based genetic tests** including **liquid biopsy kits** for oncology. It leverages proprietary peptide nucleic acid chemistry to deliver high‑sensitivity mutation detection, provides **companion diagnostic solutions**, and continues to operate as a publicly listed firm with global diagnostic product distribution. [[turn0search0]](https://stockanalysis.com/quote/kosdaq/046210/company/) [[turn0search3]](https://www.medicalsdir.com/listing/hlb-panagene-co-ltd)

## References

1. Panagene company profile and overview. https://stockanalysis.com/quote/kosdaq/046210/company/ turn0search0  
2. HLB Panagene LinkedIn profile — company & technologies. https://kr.linkedin.com/company/hlbpanagene turn0search1  
3. Panagene diagnostics technology and product summary. https://www.medicalsdir.com/listing/hlb-panagene-co-ltd turn0search3  
4. Panagene product listings including liquid biopsy kits. https://www.medical-xprt.com/companies/panagene-inc-120363/products turn0search19  
5. Company background and historical summary. https://surpriser.tistory.com/1584 turn0search14
