# Trubion Pharmaceuticals

## Overview

Trubion Pharmaceuticals was a biotechnology company developing protein therapeutics for oncology and autoimmune disease. Public acquirer materials describe the company as having advanced-stage candidates and novel therapeutic protein platforms. [[1]](https://www.emergentbiosolutions.com/press/news-releases-news-release-details-emergent-biosolutions-completes-acquisition-trubion/)

## Technology

The most accessible public description of Trubion's technology comes from Emergent BioSolutions, which said the acquisition provided access to Trubion's multiple advanced-stage candidates and versatile protein therapeutic platforms intended to address limitations of monoclonal antibodies. [[1]](https://www.emergentbiosolutions.com/press/news-releases-news-release-details-emergent-biosolutions-completes-acquisition-trubion/)

## Acquisition

Emergent BioSolutions completed its acquisition of Trubion in October 2010. Emergent said the deal would help diversify the company beyond infectious disease and support development into a more integrated biopharmaceutical company. [[1]](https://www.emergentbiosolutions.com/press/news-releases-news-release-details-emergent-biosolutions-completes-acquisition-trubion/)

## Historical Context

Because Trubion no longer operates independently, the most relevant public profile is historical and transaction-driven. The acquisition by Emergent is the main public strategic event that defines the company's later-stage identity. [[1]](https://www.emergentbiosolutions.com/press/news-releases-news-release-details-emergent-biosolutions-completes-acquisition-trubion/)
