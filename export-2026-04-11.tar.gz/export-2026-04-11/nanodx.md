# NanoDX

## Overview

NanoDx is a diagnostics company developing rapid point-of-care testing systems based on nanowire biosensor technology.[[1]](https://nanodiagnostics.com/investors/)

## Technology

The company says its NanoDx Tbit System uses nanowire technology protected by patents licensed from Harvard University together with additional company IP and semiconductor technology licensed from IBM Research.[[1]](https://nanodiagnostics.com/investors/) It also notes FDA Breakthrough Device Designation for the platform and frames the system as expandable to multiple future assays.[[1]](https://nanodiagnostics.com/investors/)

## Investors

The investor page reviewed is designed to solicit investment but does not enumerate current investors in text. As a result, this note records platform and regulatory information while leaving investor detail intentionally incomplete.[[1]](https://nanodiagnostics.com/investors/)

## Acquisitions and Strategic Transactions

No acquisition involving NanoDx was identified in the reviewed sources. The public footprint reviewed is centered on technology development and future regulatory/commercial potential rather than M&A.[[1]](https://nanodiagnostics.com/investors/)

## ASeq Posts

- [Nanodx](https://aseq.substack.com/p/nanodx)
