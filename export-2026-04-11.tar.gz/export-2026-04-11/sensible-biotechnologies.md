# Sensible Biotechnologies

## Overview
Sensible Biotechnologies is developing a cell-based platform for the design, optimization, and manufacturing of mRNA therapeutics [[1]](https://www.sensible.bio/press-release/sensible-biotechnologies-teams-up-with-nvidia-to-develop-computational-engine-for-cell-based-mrna-therapeutics-design).

## Technology
The company says its platform is designed to produce highly functional, low-immunogenic mRNA in living cells and combines cell engineering, computational biology, and precision fermentation [[1]](https://www.sensible.bio/press-release/sensible-biotechnologies-teams-up-with-nvidia-to-develop-computational-engine-for-cell-based-mrna-therapeutics-design).

## Investors
Sensible's 2024 company materials said it had raised more than $13 million from investors including Recode Ventures, BlueYard Capital, Kaya VC, Backed VC, Y Combinator, ZAKA VC, and Onsight [[1]](https://www.sensible.bio/press-release/sensible-biotechnologies-teams-up-with-nvidia-to-develop-computational-engine-for-cell-based-mrna-therapeutics-design). Gaebler also reports an earlier $4.2 million round with backing from Recode Health Ventures, Amino Collective, Civilization Ventures, ZAKA, BlueYard Capital, and others [[2]](https://www.gaebler.com/Funded-Company-7B4653B1-C705-41DC-A283-D7AEEE52BC45-Sensible-Biotechnologies).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. A notable strategic development was the 2024 NVIDIA collaboration to build a computational engine for cell-based mRNA therapeutics design [[1]](https://www.sensible.bio/press-release/sensible-biotechnologies-teams-up-with-nvidia-to-develop-computational-engine-for-cell-based-mrna-therapeutics-design).

## References
[[1]](https://www.sensible.bio/press-release/sensible-biotechnologies-teams-up-with-nvidia-to-develop-computational-engine-for-cell-based-mrna-therapeutics-design)
[[2]](https://www.gaebler.com/Funded-Company-7B4653B1-C705-41DC-A283-D7AEEE52BC45-Sensible-Biotechnologies)
