# LanzaTech

## Overview

LanzaTech is a carbon recycling and synthetic biology company that converts waste carbon streams into fuels, chemicals, materials, and protein.[[1]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-and-amci-acquisition-corp-ii-announce-closing-business/) The company is not a traditional therapeutics biotech, but it uses biological conversion platforms and is often grouped with industrial biotech and synthetic biology businesses.[[1]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-and-amci-acquisition-corp-ii-announce-closing-business/)

## Technology

LanzaTech's core technology uses engineered microbes and gas fermentation to convert industrial waste gases and other carbon sources into ethanol and downstream products.[[1]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-and-amci-acquisition-corp-ii-announce-closing-business/) In January 2025, the company announced plans to spin out LanzaX, a business unit dedicated to its synthetic biology platform, as a joint venture with Tharsis Capital.[[2]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-form-new-joint-venture-and-launch-spin-out-lanzax)

## Investors

When LanzaTech completed its business combination with AMCI Acquisition Corp. II in February 2023, it received approximately $240 million in gross proceeds, including a $185 million PIPE anchored by investors and strategic partners such as ArcelorMittal, BASF, K1W1, Khosla Ventures, Mitsui, NZ Super Fund, Oxy Low Carbon Ventures, Primetals, SHV Energy, and Trafigura.[[1]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-and-amci-acquisition-corp-ii-announce-closing-business/) In January 2026, LanzaTech also closed a $20 million private placement including new investor SiteGround.[[3]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-announces-successful-closing-private-placement/)

## Acquisitions and Strategic Transactions

Key strategic transactions include the 2023 de-SPAC transaction that took LanzaTech public and the 2025 planned spin-out/joint venture for LanzaX.[[1]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-and-amci-acquisition-corp-ii-announce-closing-business/) [[2]](https://ir.lanzatech.com/news-releases/news-release-details/lanzatech-form-new-joint-venture-and-launch-spin-out-lanzax) No reviewed source indicated a change-of-control acquisition of LanzaTech itself.
