# EV Biotech

## Overview
EV Biotech is a synthetic biology company working to convert gas into chemicals and sustainable products using engineered methanotrophic bacteria.[[1]](https://www.evbiotech.com/about-us)[[2]](https://www.evbiotech.com/)

## Technology
The company says it engineers methane-eating bacteria and related bioprocesses to produce chemicals and ingredients from methane and carbon dioxide, with a focus on industrial sustainability and biomanufacturing.[[1]](https://www.evbiotech.com/about-us)[[2]](https://www.evbiotech.com/)

## Investors
The reviewed public materials are clearer on grants, programs, and industrial partnerships than on a fully disclosed institutional cap table. EV Biotech highlights support from the European Innovation Council and related innovation programs.[[3]](https://www.evbiotech.com/news)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[2]](https://www.evbiotech.com/)
