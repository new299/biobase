# Faze Medicines — Research Notes

## Overview

Faze Medicines is a Cambridge, MA-based biotechnology company founded in 2020 developing a new class of medicines that target the biology of biomolecular condensates — membrane-less organelles (phase-separated clusters of proteins and nucleic acids) that regulate key cellular functions and are dysregulated in diseases like ALS and myotonic dystrophy type 1 (DM1). Launched with an $81M Series A. Key investors: Third Rock Ventures (lead), Novartis Venture Fund, Eli Lilly, AbbVie Ventures, Invus, Catalio Capital Management, Casdin Capital, Alexandria Venture Investments. [[1]](https://www.businesswire.com/news/home/20201210005178/en/Faze-Medicines-Launches-With-%2481-Million-Series-A-Financing-to-Leverage-New-Biology-of-Biomolecular-Condensates-to-Treat-Disease)

---

## Technology & Pipeline

- **Biomolecular Condensate Platform**: First company focused exclusively on drugging pathological biomolecular condensates — membrane-less clusters of proteins and nucleic acids that dynamically organize to perform cellular functions and are dysregulated in neurodegenerative, neuromuscular, and other diseases. [[1]](https://www.businesswire.com/news/home/20201210005178/en/Faze-Medicines-Launches-With-%2481-Million-Series-A-Financing-to-Leverage-New-Biology-of-Biomolecular-Condensates-to-Treat-Disease)
- **ALS**: Initial therapeutic focus on amyotrophic lateral sclerosis — condensate-driven TDP-43 and FUS protein aggregation.
- **Myotonic Dystrophy Type 1 (DM1)**: Second initial focus area — RNA-protein condensate dysregulation in DM1 muscle disease.
- **Condensate Discovery**: Research to identify and target condensates in additional disease areas beyond the initial two.

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | Dec 2020 | $81M | Third Rock Ventures (lead), Novartis Venture Fund, Eli Lilly, AbbVie Ventures, Invus, Catalio Capital Management, Casdin Capital, Alexandria Venture Investments |

Total raised: $81M. [[1]](https://www.businesswire.com/news/home/20201210005178/en/Faze-Medicines-Launches-With-%2481-Million-Series-A-Financing-to-Leverage-New-Biology-of-Biomolecular-Condensates-to-Treat-Disease)

---

## References

1. BusinessWire — Faze Medicines launches with $81M Series A (Dec 2020): [https://www.businesswire.com/news/home/20201210005178/en/Faze-Medicines-Launches-With-%2481-Million-Series-A-Financing-to-Leverage-New-Biology-of-Biomolecular-Condensates-to-Treat-Disease](https://www.businesswire.com/news/home/20201210005178/en/Faze-Medicines-Launches-With-%2481-Million-Series-A-Financing-to-Leverage-New-Biology-of-Biomolecular-Condensates-to-Treat-Disease)
