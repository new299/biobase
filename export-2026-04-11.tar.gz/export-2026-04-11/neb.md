# New England Biolabs

## Overview

New England Biolabs (`NEB`) is a privately held life science tools company focused on enzymes, reagents, and workflows for molecular biology, genomics, synthetic biology, and diagnostics.[[1]](https://www.neb.com/about-neb)

## Technology

NEB's technology base spans restriction enzymes, polymerases, ligases, CRISPR reagents, NGS sample prep, synthetic biology tools, and diagnostic reagent components.[[1]](https://www.neb.com/about-neb) The company is a core reagent supplier for research and applied molecular biology workflows globally.[[1]](https://www.neb.com/about-neb)

## Investors

No venture financing syndicate was identified in the reviewed public sources. NEB presents as a long-standing privately held operating company rather than a venture-backed startup.[[1]](https://www.neb.com/about-neb)

## Acquisitions and Strategic Transactions

In May 2021, NEB announced that it would acquire Fluorogenics Limited, a UK-based lyophilization R&D service company, to strengthen its ability to address lyophilized reagent needs in molecular diagnostics and point-of-care testing.[[2]](https://www.neb.com/about-neb/news-and-press-releases/new-england-biolabs-to-acquire-fluorogenics-limited)
