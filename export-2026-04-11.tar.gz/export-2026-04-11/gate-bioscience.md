# Gate Bioscience — Research Notes

## Overview

Gate Bioscience is a San Francisco, CA-based biotechnology company developing a new class of small molecule medicines called "Molecular Gates" — compounds that selectively block and eliminate disease-causing secreted proteins before they are secreted from cells. The company's proprietary Molecular Gate Discovery Platform targets high-value inflammatory and neurological disease proteins. Total raised: $135M ($65M Series B Nov 2025 + earlier). Strategic partnership with Eli Lilly ($856M in biobucks). Key investors: Versant Ventures, Andreessen Horowitz (a16z) Bio, GV, ARCH Venture Partners, Forbion, Eli Lilly. [[1]](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic) [[2]](https://www.biospace.com/deals/eli-lilly-commits-856m-in-biobucks-to-gate-bioscience-for-new-class-of-medicines)

---

## Technology & Pipeline

- **Molecular Gate™ Technology**: Novel therapeutic modality — small molecules that enter cells and selectively bind to disease-causing proteins in the secretory pathway, blocking their secretion and marking them for intracellular degradation. Differentiated from biologics (cannot cross cell membranes) and protein degraders (PROTACs target cytosolic proteins) — uniquely targets the secreted proteome. [[1]](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic)
- **Molecular Gate Discovery Platform**: Integrates a privileged library of molecular gate compounds, secretion-focused assays/technologies, and deep biology expertise in the secretory pathway for rapid, repeatable discovery of selective molecular gates against validated targets. [[1]](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic)
- **Indications**: Inflammatory diseases (cytokine targets) and neurological disorders (CNS-penetrant molecular gates for secreted neurological disease proteins). Pipeline advancing toward IND/clinical stage. [[1]](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic)
- **Eli Lilly Partnership**: $856M potential in biobucks deal with Eli Lilly for molecular gates collaboration. [[2]](https://www.biospace.com/deals/eli-lilly-commits-856m-in-biobucks-to-gate-bioscience-for-new-class-of-medicines)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | ~2023 | ~$70M | Versant Ventures, a16z Bio, GV, ARCH Venture Partners |
| Series B | Nov 2025 | $65M | Forbion (new lead), Eli Lilly, Versant Ventures, a16z Bio, GV, ARCH Venture Partners |

Total raised: $135M. [[1]](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic)

**ARCH Venture Partners Investment**

---

## References

1. Gate Bioscience — $65M Series B announcement (Nov 2025): [https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic](https://www.gatebio.com/gate-bioscience-announces-65-million-oversubscribed-series-b-financing-to-advance-oral-molecular-gate-medicines-into-the-clinic)
2. BioSpace — Eli Lilly $856M biobucks deal with Gate Bioscience: [https://www.biospace.com/deals/eli-lilly-commits-856m-in-biobucks-to-gate-bioscience-for-new-class-of-medicines](https://www.biospace.com/deals/eli-lilly-commits-856m-in-biobucks-to-gate-bioscience-for-new-class-of-medicines)
