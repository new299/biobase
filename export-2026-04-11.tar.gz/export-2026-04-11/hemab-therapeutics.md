# Hemab Therapeutics — Research Notes

## Overview

Hemab Therapeutics is a dual-headquartered (Cambridge, MA and Copenhagen, Denmark) clinical-stage biopharmaceutical company developing prophylactic antibody therapeutics for rare, underserved bleeding and thrombotic disorders including von Willebrand Disease (VWD), Glanzmann thrombasthenia, and Factor VII Deficiency. Total raised: ~$292M ($135M Series B + $157M Series C Oct 2025). Key investors: RA Capital Management, Sofinnova Partners, Novo Holdings, Access Biotechnology, Deep Track Capital, HealthCap, Invus, Avoro Ventures, Rock Springs Capital, Maj Invest Equity. [[1]](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders) [[2]](https://cen.acs.org/business/investment/Hemab-raises-135-million-series/101/i7)

---

## Technology & Pipeline

- **HMB-002 (anti-VWF for von Willebrand Disease)**: First-in-class monoclonal antibody targeting the C-terminal CK domain of von Willebrand Factor (VWF), shielding VWF from proteolytic degradation by ADAMTS13 and other clearance pathways — boosting endogenous VWF levels to treat VWD (the most common inherited bleeding disorder). Phase 1 clinical development. [[1]](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders)
- **HMB-003**: Additional novel drug candidate for announcement H1 2026. [[1]](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders)
- **Additional Pipeline**: Prophylactic treatments for Glanzmann thrombasthenia (ITGA2B/ITGB3) and Factor VII Deficiency — rare platelet and coagulation disorders with high unmet need. [[1]](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series B | ~2023 | $135M | RA Capital Management, Novo Holdings, Access Biotechnology, Deep Track Capital, HealthCap, Invus, Avoro Ventures, Maj Invest Equity, Rock Springs Capital |
| Series C | Oct 2025 | $157M | Sofinnova Partners (lead), RA Capital Management, Novo Holdings, Avoro Capital Advisors, sovereign wealth fund, others |
| Total | — | ~$292M | — |

**RA Capital Investment**

[[1]](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders)

---

## References

1. Hemab — $157M Series C Oct 2025: [https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders](https://www.hemab.com/news-items/hemab-therapeutics-announces-157-million-series-c-financing-to-advance-next-generation-treatments-for-underserved-bleeding-disorders)
2. C&EN — Hemab $135M Series B: [https://cen.acs.org/business/investment/Hemab-raises-135-million-series/101/i7](https://cen.acs.org/business/investment/Hemab-raises-135-million-series/101/i7)
