# Allena Pharmaceuticals

## Overview
Allena Pharmaceuticals was a biotechnology company focused on oral enzyme therapeutics and related approaches for rare metabolic and kidney disorders.[[1]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-closes-second-95-million-tranche-series-c) Its lead asset was reloxaliase for enteric hyperoxaluria.[[1]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-closes-second-95-million-tranche-series-c)

## Technology and Pipeline
Allena’s strategy centered on non-systemic, orally delivered enzyme therapeutics intended to address metabolic substrates in the gut before systemic harm occurs.[[1]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-closes-second-95-million-tranche-series-c) The company also developed ALLN-346, an oral urate-degrading enzyme.[[2]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-announces-sale-alln-346-clinical-program)

## Investors
In May 2018, Allena closed the second $9.5 million tranche of a total $26 million Series C financing with participation from existing investors Third Rock Ventures, Frazier Healthcare Partners, and OrbiMed.[[1]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-closes-second-95-million-tranche-series-c)

## Acquisitions and Corporate Activity
Following strategic review and restructuring, Allena announced in 2023 the sale of its ALLN-346 clinical program to Pharming.[[2]](https://investor.allenapharma.com/news-releases/news-release-details/allena-pharmaceuticals-announces-sale-alln-346-clinical-program) I did not identify a completed whole-company acquisition in the reviewed public sources.
