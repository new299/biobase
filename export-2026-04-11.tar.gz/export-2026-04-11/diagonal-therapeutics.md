# Diagonal Therapeutics — Research Notes

## Overview

Diagonal Therapeutics is a Cambridge, MA-based biotechnology company launched April 2024. Develops disease-modifying "clustering antibodies" — agonist antibodies designed to correct dysregulated signaling in severe genetic disorders. Lead program: DIAG723 for hereditary hemorrhagic telangiectasia (HHT), with first-in-human trial expected H1 2026. Also advancing programs for pulmonary arterial hypertension (PAH). Total raised: ~$253M ($128M Series A + $125M Series B). [[1]](https://diagonaltx.com/news/diagonal-therapeutics-launches-with-128-million-in-financing-to-pioneer-a-new-approach-to-discovering-and-developing-agonist-antibodies-to-tackle-the-underlying-causes-of-severely-debilitating-diseases) [[2]](https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance)

---

## Technology

- **Clustering Antibodies**: Proprietary agonist antibody platform that clusters cell-surface receptors to activate or restore signaling pathways whose dysfunction drives genetic diseases. Distinguished from conventional inhibitory antibodies. [[1]](https://diagonaltx.com/news/diagonal-therapeutics-launches-with-128-million-in-financing-to-pioneer-a-new-approach-to-discovering-and-developing-agonist-antibodies-to-tackle-the-underlying-causes-of-severely-debilitating-diseases)
- **DIAG723**: Lead clustering antibody for hereditary hemorrhagic telangiectasia (HHT — a rare vascular dysplasia). First-in-human Phase 1 trial planned H1 2026. [[2]](https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance)
- **PAH Program**: Pipeline candidate for pulmonary arterial hypertension. [[2]](https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | Apr 2024 | $128M | BVF Partners (co-lead), Atlas Venture (co-lead), Lightspeed Venture Partners, RA Capital Management, Frazier Life Sciences, Viking Global Investors, Velosity Capital, Checkpoint Capital |
| Series B | Jan 2026 | $125M | Sanofi Ventures (co-lead), Janus Henderson Investors (co-lead), Deep Track Capital, EcoR1 Capital, Logos Capital, Balyasny Asset Management, Woodline Partners, plus all Series A investors |

Total raised: ~$253M. [[1]](https://diagonaltx.com/news/diagonal-therapeutics-launches-with-128-million-in-financing-to-pioneer-a-new-approach-to-discovering-and-developing-agonist-antibodies-to-tackle-the-underlying-causes-of-severely-debilitating-diseases) [[2]](https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance)

---

## References

1. Diagonal Therapeutics — $128M Series A launch (Apr 2024): [https://diagonaltx.com/news/diagonal-therapeutics-launches-with-128-million-in-financing-to-pioneer-a-new-approach-to-discovering-and-developing-agonist-antibodies-to-tackle-the-underlying-causes-of-severely-debilitating-diseases](https://diagonaltx.com/news/diagonal-therapeutics-launches-with-128-million-in-financing-to-pioneer-a-new-approach-to-discovering-and-developing-agonist-antibodies-to-tackle-the-underlying-causes-of-severely-debilitating-diseases)
2. Diagonal Therapeutics — $125M Series B (Jan 2026): [https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance](https://diagonaltx.com/news/diagonal-therapeutics-announces-oversubscribed-usd125-million-series-b-financing-to-advance)
