# Nimbus Therapeutics

## Overview
Nimbus Therapeutics is a private biotechnology company developing small-molecule medicines through structure-based and AI-enhanced computational drug discovery.[[1]](https://www.nimbustx.com/)[[2]](https://www.nimbustx.com/about/) The company focuses on oncology, immunology, and metabolic disease.[[1]](https://www.nimbustx.com/)[[2]](https://www.nimbustx.com/about/)

## Technology and Pipeline
Nimbus says its model combines computational chemistry, structural biology, and machine-learning-based predictive approaches to pursue well-validated but difficult-to-drug targets.[[2]](https://www.nimbustx.com/about/)[[3]](https://www.nimbustx.com/2026/) Its recent pipeline includes the WRN inhibitor NDI-219216 in Phase 1/2 development, a SIK2 inhibitor approaching first-in-human studies, and additional preclinical oncology, immunology, and metabolic programs.[[3]](https://www.nimbustx.com/2026/)

## Investors
Nimbus has disclosed multiple private financings over time. In 2018 it announced a $65 million round with participation from Atlas Venture, SR One, Lilly Ventures, Bill Gates, Pfizer Venture Investments, Lightstone Ventures, and Schrödinger.[[4]](https://www.nimbustx.com/2018/06/05/nimbus-therapeutics-announces-65-million-in-new-financing-to-accelerate-pipeline-progress-and-expand-discovery-efforts/) In 2022 it closed a $125 million private financing involving new investors Bain Capital Life Sciences and SV Health Investors along with existing investors including Access Biotechnology, Atlas Venture, BVF, Bill Gates, Lightstone Ventures, Pfizer Ventures, RA Capital Management, and SR One.[[5]](https://www.businesswire.com/news/home/20220912005216/en/Nimbus-Therapeutics-Closes-%24125M-Private-Financing-to-Advance-Clinical-Programs-in-Autoimmune-Diseases-and-Oncology)

## Acquisitions and Corporate Activity
Nimbus has a notable track record of program transactions. In 2016, Gilead acquired Nimbus Apollo, the Nimbus subsidiary holding its ACC inhibitor program, for a $400 million upfront payment plus potential development milestones.[[6]](https://www.nimbustx.com/2016/05/17/nimbus-therapeutics-announces-closing-of-gilead-sciences-acquisition-of-nimbus-apollo-inc-and-its-acetyl-coa-carboxylase-acc-inhibitor-program/) According to the company timeline, Takeda acquired Nimbus' TYK2 inhibitor program in 2022 in a transaction featuring $4 billion upfront and additional potential commercial milestones.[[2]](https://www.nimbustx.com/about/)
