# Aclaris Therapeutics

## Overview
Aclaris Therapeutics is a clinical-stage biopharmaceutical company focused on immuno-inflammatory diseases.[[1]](https://investor.aclaristx.com/)[[2]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-reports-first-quarter-2025-financial) Its public pipeline includes ATI-2138, bosakitug, and other immunology programs.[[2]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-reports-first-quarter-2025-financial)

## Technology and Pipeline
Aclaris develops novel drug candidates for diseases such as atopic dermatitis and other immuno-inflammatory conditions.[[1]](https://investor.aclaristx.com/)[[2]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-reports-first-quarter-2025-financial) Earlier in its history it also advanced dermatology assets such as A-101 and later generated royalty rights linked to baricitinib for alopecia areata.[[3]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-closes-21-million-series-b-financing)[[4]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-announces-sale-olumiantr-royalties-and)

## Investors
In October 2014, Aclaris closed a $21 million Series B through existing investors Vivo Ventures, Fidelity Biosciences, and Sofinnova Ventures.[[3]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-closes-21-million-series-b-financing) In November 2024, it announced an $80 million private placement led by Vivo Capital, with participation from Forge Life Science Partners, RA Capital Management, Adage Capital Partners, Decheng Capital, Logos Capital, Rock Springs Capital, and Samsara BioCapital.[[5]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-announces-80-million-private-placement)

## Acquisitions and Corporate Activity
I did not identify an acquisition involving Aclaris in the reviewed public sources. A notable recent corporate transaction was the July 2024 sale of a portion of future OLUMIANT royalties and milestones to OMERS Life Sciences for up to $31.5 million.[[4]](https://investor.aclaristx.com/news-releases/news-release-details/aclaris-therapeutics-announces-sale-olumiantr-royalties-and)
