# SOPHiA GENETICS

## Overview
SOPHiA GENETICS is a public precision medicine software and analytics company centered on its SOPHiA DDM platform for genomic and multimodal healthcare data [[1]](https://www.sophiagenetics.com/about-us/) [[2]](https://ir.sophiagenetics.com/2026-03-03-SOPHiA-GENETICS-Reports-Fourth-Quarter-and-Full-Year-2025-Results).

## Technology
The company says SOPHiA DDM decentralizes and analyzes multimodal health data to generate actionable insights for cancer and rare disease diagnosis and treatment, and its network spans hundreds of institutions globally [[1]](https://www.sophiagenetics.com/about-us/).

## Investors
As a public company, SOPHiA is financed through public markets and institutional investors. The reviewed materials were stronger on corporate profile and operating results than on named large holders [[2]](https://ir.sophiagenetics.com/2026-03-03-SOPHiA-GENETICS-Reports-Fourth-Quarter-and-Full-Year-2025-Results).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The public materials instead emphasize commercial growth, platform scale, and partnerships such as MSK-ACCESS powered by SOPHiA DDM [[2]](https://ir.sophiagenetics.com/2026-03-03-SOPHiA-GENETICS-Reports-Fourth-Quarter-and-Full-Year-2025-Results).

## References
[[1]](https://www.sophiagenetics.com/about-us/)
[[2]](https://ir.sophiagenetics.com/2026-03-03-SOPHiA-GENETICS-Reports-Fourth-Quarter-and-Full-Year-2025-Results)
