# Cell Reserves Inc

## Overview
Cell Reserves is a biopharmaceutical company focused on protein- and peptide-based therapeutics, particularly for autoimmune disease and improved delivery or persistence of biologics.[[1]](https://sosv.com/company/cell-reserves-inc/)

## Technology
SOSV says the company's platform is intended to increase the persistence and bioavailability of therapeutics in circulation and may also support nasal or oral delivery and faster tissue penetration.[[1]](https://sosv.com/company/cell-reserves-inc/)

## Investors
The clearest public investor signal is SOSV portfolio inclusion through RebelBio/IndieBio programming. I did not identify a larger institutional financing announcement in the reviewed sources.[[1]](https://sosv.com/company/cell-reserves-inc/)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://sosv.com/company/cell-reserves-inc/)
