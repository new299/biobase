# Eyebright Medical Technology — Research Notes

## Overview

Eyebright Medical Technology (Beijing) Co., Ltd. (SSE STAR Market: 688050.SH) is a Beijing, China-based ophthalmic medical device manufacturer focused on surgical treatment, myopia management, and consumer vision care. Listed on the Shanghai Stock Exchange STAR Market. Total raised: ~$31.63M (pre-IPO VC). Key investors: Mingfeng Capital, IPV Capital, Infotech Ventures, Sinopharm Capital, K2VC. The company has been expanding internationally, signing a memorandum with Invest Hong Kong in September 2024. [[1]](https://www.prnewswire.com/apac/news-releases/eyebright-medical-continues-to-employ-its-internationalization-strategy-signed-memorandum-with-invest-hong-kong-and-spotlight-at-escrs-2024-302256975.html) [[2]](http://ebmedical.com/en/)

---

## Technology & Products

- **Intraocular Lenses (IOLs)**: Core surgical product line. Refractive IOLs received national NMPA approval in January 2025. [[1]](https://www.prnewswire.com/apac/news-releases/eyebright-medical-continues-to-employ-its-internationalization-strategy-signed-memorandum-with-invest-hong-kong-and-spotlight-at-escrs-2024-302256975.html)
- **Orthokeratology (OK) Lenses**: Myopia management lenses worn overnight to reshape the cornea and temporarily reduce myopia — significant market in China given high myopia prevalence.
- **Contact Lenses**: Consumer vision care segment.
- **Internationalization Strategy**: Using Hong Kong as a base for overseas expansion; presented at ESCRS 2024 (European Society of Cataract and Refractive Surgeons) international ophthalmology conference.

---

## Funding & Corporate History

| Event | Details |
|-------|---------|
| Pre-IPO VC raised | ~$31.63M; Investors: Mingfeng Capital, IPV Capital, Infotech Ventures, Sinopharm Capital, K2VC |
| IPO (SSE STAR: 688050.SH) | Listed on Shanghai Stock Exchange STAR Market |
| Invest HK MOU | Sep 2024 — Hong Kong expansion base |

Total raised (pre-IPO): ~$31.63M. [[2]](http://ebmedical.com/en/)

---

## References

1. PRNewswire APAC — Eyebright Medical at ESCRS 2024 and Invest HK MOU (Sep 2024): [https://www.prnewswire.com/apac/news-releases/eyebright-medical-continues-to-employ-its-internationalization-strategy-signed-memorandum-with-invest-hong-kong-and-spotlight-at-escrs-2024-302256975.html](https://www.prnewswire.com/apac/news-releases/eyebright-medical-continues-to-employ-its-internationalization-strategy-signed-memorandum-with-invest-hong-kong-and-spotlight-at-escrs-2024-302256975.html)
2. Eyebright Medical Technology — Homepage: [http://ebmedical.com/en/](http://ebmedical.com/en/)
