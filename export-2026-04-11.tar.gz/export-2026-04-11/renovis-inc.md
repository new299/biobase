# Renovis Inc.

## Overview
Renovis was a biopharmaceutical company focused on pain and inflammatory diseases before being acquired by Evotec [[1]](https://www.evotec.com/en/news/evotec-to-acquire-renovis-seek-nasdaq-listing).

## Technology
Evotec described Renovis as bringing clinical and late-preclinical candidates in neurological and inflammatory diseases to the merged company [[1]](https://www.evotec.com/en/news/evotec-to-acquire-renovis-seek-nasdaq-listing).

## Investors
Venrock is identified in local notes as an investor, but the reviewed public materials here were stronger on the sale process than on historical venture syndication [[1]](https://www.evotec.com/en/news/evotec-to-acquire-renovis-seek-nasdaq-listing).

## Acquisitions / Strategic Transactions
Evotec announced in 2007 that it would acquire Renovis in a stock-for-stock transaction valued at about $151.8 million and completed the acquisition in May 2008 [[1]](https://www.evotec.com/en/news/evotec-to-acquire-renovis-seek-nasdaq-listing) [[2]](https://www.evotec.com/en/news/evotec-completes-acquisition-of-renovis).

## References
[[1]](https://www.evotec.com/en/news/evotec-to-acquire-renovis-seek-nasdaq-listing)
[[2]](https://www.evotec.com/en/news/evotec-completes-acquisition-of-renovis)
