# NanoString Technologies

## Overview

NanoString Technologies was a life science tools company focused on spatial biology and gene expression profiling.[[1]](https://www.bruker.com/en/news-and-events/news/2024/bruker-announces-completion-of-acquisition-of-majority-of-nanostring-assets.html)

## Technology

NanoString's core technologies included the nCounter gene expression platform and the GeoMx digital spatial profiling platform, both of which were widely used in translational research and spatial biology workflows.[[1]](https://www.bruker.com/en/news-and-events/news/2024/bruker-announces-completion-of-acquisition-of-majority-of-nanostring-assets.html)

## Investors

NanoString was a public company by the time of its restructuring and asset sale, so later-stage capitalization came through public-market ownership rather than current venture financing.

## Acquisitions and Strategic Transactions

Bruker announced in May 2024 that it had completed acquisition of the majority of NanoString's assets after the bankruptcy sale process.[[1]](https://www.bruker.com/en/news-and-events/news/2024/bruker-announces-completion-of-acquisition-of-majority-of-nanostring-assets.html) Bruker separately announced the original stalking horse agreement in February 2024.[[2]](https://www.bruker.com/en/news-and-events/news/2024/bruker-to-acquire-majority-of-nanostring-assets.html)

## ASeq Posts

- [More Ncounter Notes](https://aseq.substack.com/p/more-ncounter-notes)
- [Ncounter Images Look Beautiful](https://aseq.substack.com/p/ncounter-images-look-beautiful)
- [The Ncounter](https://aseq.substack.com/p/the-ncounter)
- [Nanostring Vendors](https://aseq.substack.com/p/nanostring-vendors)
- [Death And Nanostring](https://aseq.substack.com/p/death-and-nanostring)
- [Nanostring Is Dead](https://aseq.substack.com/p/nanostring-is-dead)
