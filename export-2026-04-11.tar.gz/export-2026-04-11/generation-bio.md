# Generation Bio — Research Notes

## Overview

Generation Bio (NASDAQ: GBIO) is a Cambridge, MA-based clinical-stage biopharmaceutical company founded in 2016, developing non-viral gene therapies using closed-ended DNA (ceDNA) delivered by cell-targeted lipid nanoparticles (ctLNP) for rare and prevalent diseases. The company completed a $126M IPO in June 2020. Moderna collaboration for T-cell targeting LNP delivery. Lead programs include hemophilia A (GB-FIX/FVIII), phenylketonuria, and Fabry disease. [[1]](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies) [[2]](https://hemophilianewstoday.com/news/generation-bio-gets-funding-for-hemophilia-a-gene-therapy-programs/)

---

## Technology & Pipeline

- **iqDNA (immune-quiet Closed-Ended DNA)**: Novel non-integrating closed-ended DNA cargo produced by a scalable, capsid-free manufacturing process — episomal, non-integrating, designed for redosability (unlike AAV which can only be given once due to immune response). [[1]](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies)
- **ctLNP (Cell-Targeted Lipid Nanoparticle)**: Proprietary LNP delivery system enabling targeted delivery to specific cell populations (liver, T cells) — single IV dose delivers DNA cargo to majority of circulating T cells in NHP studies. [[1]](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies)
- **Hemophilia A (GB-001)**: FVIII gene delivery to liver via ctLNP; initial clinical data disappointing (IND-enabling setback reported); program continuing with platform refinements. [[3]](https://www.biospace.com/back-to-the-drawing-board-for-generation-bio-s-hemophilia-a-program)
- **Phenylketonuria, Fabry Disease**: Additional liver-targeted programs. [[1]](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies)
- **Moderna Partnership**: Collaboration with Moderna, Inc. for cell-targeted LNP delivery including T-cell targeting. [[2]](https://hemophilianewstoday.com/news/generation-bio-gets-funding-for-hemophilia-a-gene-therapy-programs/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | 2016 | $25M | Atlas Venture (lead) |
| Series B | ~2019 | $110M | T. Rowe Price (lead), Farallon, Wellington, Atlas, Fidelity, Invus, Casdin, Deerfield, Foresite, SVB Leerink |
| IPO (NASDAQ: GBIO) | Jun 2020 | ~$126M | Public markets |

Total raised (private): ~$135M; IPO ~$126M. [[1]](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies)

---

## References

1. Fierce Biotech — Generation Bio $125M IPO filing: [https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies](https://www.fiercebiotech.com/biotech/generation-bio-tees-up-125m-ipo-to-push-next-gen-gene-therapies)
2. Hemophilia News Today — Generation Bio hemophilia funding: [https://hemophilianewstoday.com/news/generation-bio-gets-funding-for-hemophilia-a-gene-therapy-programs/](https://hemophilianewstoday.com/news/generation-bio-gets-funding-for-hemophilia-a-gene-therapy-programs/)
3. BioSpace — Generation Bio hemophilia A back to drawing board: [https://www.biospace.com/back-to-the-drawing-board-for-generation-bio-s-hemophilia-a-program](https://www.biospace.com/back-to-the-drawing-board-for-generation-bio-s-hemophilia-a-program)
