# ROME Therapeutics

## Overview
ROME Therapeutics is a biotechnology company developing medicines for cancer and autoimmune disease by targeting the repeatome, a large repetitive portion of the human genome [[1]](https://rometx.com/about-us/) [[2]](https://rometx.com/press-releases/rome-therapeutics-launches-to-develop-novel-therapies-for-cancer-and-autoimmune-diseases-by-harnessing-the-power-of-the-repeatome/).

## Technology
Its platform centers on repeatomics and drug discovery against repeatome-derived biology, including LINE-1 reverse transcriptase and other dark-genome targets [[1]](https://rometx.com/about-us/) [[3]](https://rometx.com/press-releases/rome-therapeutics-closes-oversubscribed-72-million-series-b-extension-to-support-advancement-of-lead-program-into-clinical-development-for-autoimmune-disease/).

## Investors
ROME launched in 2020 with a $50 million Series A led by GV and ARCH Venture Partners, then raised a $77 million Series B in 2021 led by Section 32 and later a $72 million Series B extension in 2023. Investors across those rounds included GV, ARCH Venture Partners, Partners Innovation Fund / Mass General Brigham Ventures, Section 32, Sanofi Ventures, Casdin Capital, Andreessen Horowitz, Alexandria Venture Investments, Johnson & Johnson Innovation-JJDC, Bristol Myers Squibb, Eurofarma Ventures, Luma Group, Mirae Asset, Raycap, and Sigmas Group [[2]](https://rometx.com/press-releases/rome-therapeutics-launches-to-develop-novel-therapies-for-cancer-and-autoimmune-diseases-by-harnessing-the-power-of-the-repeatome/) [[4]](https://rometx.com/press-releases/rome-therapeutics-secures-77-million-in-series-b-financing-to-advance-repeatome-derived-pipeline-for-cancer-and-autoimmune-diseases-and-expand-repeatomics-platform/) [[3]](https://rometx.com/press-releases/rome-therapeutics-closes-oversubscribed-72-million-series-b-extension-to-support-advancement-of-lead-program-into-clinical-development-for-autoimmune-disease/).

## Acquisitions / Strategic Transactions
The reviewed sources point to financing rounds, rather than M&A, as the central strategic transactions enabling expansion of ROME's repeatome platform and pipeline [[3]](https://rometx.com/press-releases/rome-therapeutics-closes-oversubscribed-72-million-series-b-extension-to-support-advancement-of-lead-program-into-clinical-development-for-autoimmune-disease/).

## References
[[1]](https://rometx.com/about-us/)
[[2]](https://rometx.com/press-releases/rome-therapeutics-launches-to-develop-novel-therapies-for-cancer-and-autoimmune-diseases-by-harnessing-the-power-of-the-repeatome/)
[[3]](https://rometx.com/press-releases/rome-therapeutics-closes-oversubscribed-72-million-series-b-extension-to-support-advancement-of-lead-program-into-clinical-development-for-autoimmune-disease/)
[[4]](https://rometx.com/press-releases/rome-therapeutics-secures-77-million-in-series-b-financing-to-advance-repeatome-derived-pipeline-for-cancer-and-autoimmune-diseases-and-expand-repeatomics-platform/)
