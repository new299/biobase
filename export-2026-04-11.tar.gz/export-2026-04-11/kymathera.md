# kymathera

## Overview

KymaThera is a discovery-stage biotechnology company developing best-in-class small-molecule medicines for cancer, pulmonary fibrosis, myeloproliferative neoplasms, and metabolic disease.[[1]](https://www.kymathera.com/) The company positions itself around precision structure-based drug design and experienced drug hunters.[[1]](https://www.kymathera.com/)

## Technology

KymaThera says it applies a proprietary framework for strategic structure-based drug design to produce differentiated small-molecule therapeutics.[[1]](https://www.kymathera.com/) Public materials describe programs against mutant-selective PI3Kalpha, inhaled ALK5 / TGF-beta receptor 1, mutant JAK2 V617F, and an undisclosed metabolic target.[[1]](https://www.kymathera.com/)

## Investors

KymaThera's leadership page explicitly lists Venrock and Foresite Capital as investors.[[2]](https://www.kymathera.com/leadership/) Team pages also identify board or observer roles tied to both firms, supporting that investor picture.[[3]](https://www.kymathera.com/team-member/mariana-mihalusova-ph-d/) [[4]](https://www.kymathera.com/team-member/vishal-deshmukh-phd/)

## Acquisitions and Strategic Transactions

No acquisition involving KymaThera was identified in the reviewed sources. Based on the public materials reviewed, the company remains in a discovery-stage buildout phase.[[1]](https://www.kymathera.com/)
