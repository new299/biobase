# Aeglea BioTherapeutics

## Overview
Aeglea BioTherapeutics was a biotechnology company developing human enzyme therapeutics for rare metabolic diseases.[[1]](https://ir.aeglea.com/company-overview/default.aspx) Its lead historical program was pegzilarginase for Arginase 1 Deficiency.[[1]](https://ir.aeglea.com/company-overview/default.aspx)

## Technology and Pipeline
Aeglea positioned itself around engineered human enzyme therapeutics to address inborn metabolic disorders with limited treatment options.[[1]](https://ir.aeglea.com/company-overview/default.aspx) After a strategic shift, the company sold pegzilarginase and later became the vehicle through which Spyre Therapeutics entered the public markets.[[2]](https://ir.aeglea.com/press-releases/news-details/2023/Aeglea-BioTherapeutics-Announces-Sale-of-Pegzilarginase-to-Immedica-Pharma/default.aspx)[[3]](https://ir.aeglea.com/press-releases/news-details/2023/Aeglea-BioTherapeutics-Announces-Acquisition-of-Spyre-Therapeutics/default.aspx)

## Investors and Financing
In May 2022, Aeglea announced a $45 million registered direct offering with participation from institutional investors including Bain Capital Life Sciences, Great Point Partners, Nantahala-related clients, and Sio Capital Management.[[4]](https://ir.aeglea.com/press-releases/news-details/2022/Aeglea-BioTherapeutics-Announces-45-Million-Registered-Direct-Offering-Priced-at-a-Premium-to-Market/default.aspx) The local note’s RA Capital reference is more consistent with the later Spyre-related financing than Aeglea’s original rare-disease investor mix.

## Acquisitions and Corporate Activity
In June 2023, Aeglea acquired privately held Spyre Therapeutics and concurrently entered into a $210 million private placement to pivot the public company toward inflammatory bowel disease antibodies.[[3]](https://ir.aeglea.com/press-releases/news-details/2023/Aeglea-BioTherapeutics-Announces-Acquisition-of-Spyre-Therapeutics/default.aspx) Before that, in July 2023, Aeglea sold global rights to pegzilarginase to Immedica Pharma for $15 million upfront plus up to $100 million in milestones.[[2]](https://ir.aeglea.com/press-releases/news-details/2023/Aeglea-BioTherapeutics-Announces-Sale-of-Pegzilarginase-to-Immedica-Pharma/default.aspx)
