# UNOMR

## Overview

UNOMR is a Swiss techbio startup from ETH Zurich developing single-molecule protein sequencing technology. Public startup-event materials say the company is initially focused on site-specific protein glycosylation analysis with broader applications in healthcare, pharma R&D, and food science. [[1]](https://www.b2match.com/e/global-innovation-summit-2026/participations/657646) [[2]](https://www.b2match.com/e/global-innovation-summit-2026/participants/3332708)

## Technology

The company's core platform is an interface nanopore sensor for single-molecule protein sequencing. Public descriptions emphasize high-resolution analysis of protein modifications, especially glycosylation, and frame the technology as a route to more accessible precision proteomics. [[1]](https://www.b2match.com/e/global-innovation-summit-2026/participations/657646) [[2]](https://www.b2match.com/e/global-innovation-summit-2026/participants/3332708)

## Funding And Support

UNOMR's co-founder profile states that the company has secured support from programs such as Venture Kick and InnoBooster. I did not find a detailed venture financing announcement in the accessible public sources reviewed for this note. [[2]](https://www.b2match.com/e/global-innovation-summit-2026/participants/3332708)

## Strategic Position

UNOMR appears to be a very early-stage proteomics platform company. Its public profile is still mostly conference- and ecosystem-based, but the technical differentiation around interface nanopore protein sequencing is clear. [[1]](https://www.b2match.com/e/global-innovation-summit-2026/participations/657646) [[2]](https://www.b2match.com/e/global-innovation-summit-2026/participants/3332708)

## ASeq Posts

- [The Unomr Serial Nanopore](https://aseq.substack.com/p/the-unomr-serial-nanopore)
