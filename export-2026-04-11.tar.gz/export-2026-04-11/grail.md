# GRAIL — Research Notes

## Overview

GRAIL, Inc. (NASDAQ: GRAL) is a Menlo Park, CA-based oncology company founded by Illumina in January 2016, focused on early cancer detection from a simple blood test using cell-free DNA methylation profiling. Lead product Galleri® — a multi-cancer early detection (MCED) test detecting 50+ cancer types from blood — launched commercially June 2021. GRAIL raised ~$2B before being acquired by Illumina for $7.1B in 2021; EU antitrust authorities ordered Illumina to divest GRAIL, which was completed June 2024 (GRAIL relisted as independent company). Key early investors: ARCH Venture Partners, Bill Gates, Bezos Expeditions, Johnson & Johnson. [[1]](https://grail.com/our-history/) [[2]](https://en.wikipedia.org/wiki/Grail_(company))

---

## Technology & Products

- **Galleri® (MCED blood test)**: Multi-cancer early detection test using cell-free DNA methylation profiling to detect 50+ cancer types from a single blood draw, with tissue-of-origin localization; launched June 2021 for individuals 50+. Prescription only; ~$949 per test (not yet covered by most insurance). [[1]](https://grail.com/our-history/)
- **cfDNA Methylation Platform**: Proprietary whole-genome bisulfite sequencing of cell-free DNA to detect tissue-specific methylation signatures that distinguish cancer from non-cancer; trained on large clinical cohorts (CCGA study, Strive study, NHS-Galleri trial — 140,000+ participant NHS study, UK). [[2]](https://en.wikipedia.org/wiki/Grail_(company))
- **Lung Cancer Screening (Lung Smart+)**: Supplementary test using ctDNA for high-risk lung cancer screening. [[1]](https://grail.com/)
- **NHS Galleri Trial**: 140,000-participant NHS/UK trial; preliminary results published. [[2]](https://en.wikipedia.org/wiki/Grail_(company))

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | Jan 2016 | Menlo Park, CA; spun out of Illumina |
| Series A | 2016 | $100M+ — Illumina, **ARCH Venture Partners**, Bill Gates, Bezos Expeditions, Sutter Hill |
| Series B | Mar 2017 | $900M+ — **ARCH Venture Partners** (lead), J&J Innovation |
| Series C | 2018 | $300M |
| Total pre-acquisition | ~2020 | ~$2B total raised |
| Illumina acquisition | Sep 2020 | Announced $7.1B; completed 2021 |
| EU antitrust divestiture order | Oct 2023 | Illumina ordered to divest |
| Relisted as independent NASDAQ: GRAL | Jun 2024 | GRAIL re-spun out from Illumina |

[[1]](https://grail.com/our-history/) [[2]](https://en.wikipedia.org/wiki/Grail_(company))

**ARCH Venture Partners Investment**

---

## References

1. GRAIL — Our History: [https://grail.com/our-history/](https://grail.com/our-history/)
2. Wikipedia — GRAIL (company): [https://en.wikipedia.org/wiki/Grail_(company)](https://en.wikipedia.org/wiki/Grail_(company))

## ASeq Posts

- [A Grail Cfdna Paper](https://aseq.substack.com/p/a-grail-cfdna-paper)
- [Grails Cfrna Paper](https://aseq.substack.com/p/grails-cfrna-paper)
- [Illumina Acquire Grail Maybe](https://aseq.substack.com/p/illumina-acquire-grail-maybe)
