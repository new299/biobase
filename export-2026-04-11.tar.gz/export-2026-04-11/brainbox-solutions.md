# BRAINBox Solutions — Research Notes

## Overview

BRAINBox Solutions is a Richmond, VA-based neurotechnology company founded in 2018. Develops neurotechnology products and services for brain health, diagnostics, and related applications. Total raised: ~$38M. Funded by NIH grants, angel investors, and healthcare VCs. [[1]](https://pitchbook.com/profiles/company/235019-17)

---

## Technology & Focus

- Neurotechnology solutions for brain health monitoring, diagnostics, and therapeutic applications.
- Specific products/platforms not prominently publicly disclosed; primarily pre-commercial stage. [[1]](https://pitchbook.com/profiles/company/235019-17)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Various | ~2018–present | ~$38M | CAV Angels, Virginia Innovation Partnership Corporation, Virginia Venture Partners, NIH, Ambit Health Ventures |

[[1]](https://pitchbook.com/profiles/company/235019-17)

---

## References

1. PitchBook — BRAINBox Solutions: [https://pitchbook.com/profiles/company/235019-17](https://pitchbook.com/profiles/company/235019-17)
