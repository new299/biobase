# Laronde

## Overview

Laronde was a Flagship Pioneering-founded RNA medicines company built around `Endless RNA` (`eRNA`), a circular/translatable RNA platform intended to express therapeutic proteins in vivo.[[1]](https://www.flagshippioneering.com/press/flagship-pioneering-unveils-laronde-to-advance-endless-rna-a-new-class-of-programmable-medicines-capable-of-expressing-therapeutic-proteins-inside-the-body) The company was founded in 2017 and emerged publicly in 2021.[[1]](https://www.flagshippioneering.com/press/flagship-pioneering-unveils-laronde-to-advance-endless-rna-a-new-class-of-programmable-medicines-capable-of-expressing-therapeutic-proteins-inside-the-body)

## Technology

Laronde's technology was Endless RNA, a closed-loop RNA construct designed to be persistent, non-immunogenic, and redosable, with the goal of overcoming some limitations of conventional mRNA approaches.[[1]](https://www.flagshippioneering.com/press/flagship-pioneering-unveils-laronde-to-advance-endless-rna-a-new-class-of-programmable-medicines-capable-of-expressing-therapeutic-proteins-inside-the-body) After Laronde merged into Sail Biomedicines, Flagship described Sail's combined platform as integrating eRNA with programmable nanoparticles and AI-enabled design.[[2]](https://www.flagshippioneering.com/news/press-release/flagship-pioneering-announces-the-merger-of-two-leading-programmable-medicine-platforms-to-form-sail-biomedicines)

## Investors

Flagship initially committed $50 million to support Laronde's launch.[[1]](https://www.flagshippioneering.com/press/flagship-pioneering-unveils-laronde-to-advance-endless-rna-a-new-class-of-programmable-medicines-capable-of-expressing-therapeutic-proteins-inside-the-body) In August 2021, Laronde announced a $440 million Series B that included Flagship Pioneering, T. Rowe Price, Invus, CPP Investments, Fidelity, and funds/accounts managed by BlackRock, among others.[[3]](https://www.flagshippioneering.com/news/press-release/laronde-attracts-440m-in-first-external-financing-to-further-advance-endless-rna-platform)

## Acquisitions and Strategic Transactions

In October 2023, Flagship announced the merger of Laronde and Senda Biosciences to form Sail Biomedicines.[[2]](https://www.flagshippioneering.com/news/press-release/flagship-pioneering-announces-the-merger-of-two-leading-programmable-medicine-platforms-to-form-sail-biomedicines) This followed public reporting about data integrity issues affecting some Laronde lead candidates.[[4]](https://www.statnews.com/2023/10/19/startup-laronde-merges-with-another-biotech-in-wake-of-data-integrity-issue/)
