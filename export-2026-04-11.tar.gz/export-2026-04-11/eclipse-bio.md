# Eclipse Bio (Eclipsebio) — Research Notes

## Overview

Eclipsebio (formerly Eclipse Bioinnovations) is a San Diego, CA-based biotechnology company developing first-in-class RNA genomics technologies, analyses, and platforms to support development of RNA-based and RNA-targeting therapeutics. Total raised: ~$14M (Series A). Key investor: Alexandria Venture Investments. In January 2026, Eclipsebio acquired Terrain Bio (AI/ML RNA design and manufacturing analytics). [[1]](https://www.prnewswire.com/news-releases/eclipsebio-announces-a-14-million-series-a-financing-to-advance-its-rna-genomics-technology-platform-301502159.html) [[2]](https://eclipsebio.com/)

---

## Technology & Products

- **eMERGE™ Platform**: End-to-end solution for characterization and optimization of RNA-based therapeutic products including vaccines, protein/gene therapies, and monoclonal antibodies — launched July 2024. [[3]](https://eclipsebio.com/news/press-release/eclipsebio-launches-emerge/)
- **eSENSE dsRNA™**: Assay for detection of double-stranded RNA (dsRNA) contamination in RNA therapeutics — launched September 2024. [[2]](https://eclipsebio.com/)
- **eVERSE™**: AI-ready datasets portfolio generated from all key aspects of RNA biology, intended to inform therapeutic development from target discovery to drug design. [[2]](https://eclipsebio.com/)
- **Terrain Bio Acquisition**: In January 2026, Eclipsebio acquired Terrain Bio, a techbio company specializing in AI/ML for RNA design and manufacturing analytics. [[2]](https://eclipsebio.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A | Mar 2022 | $14M | Alexandria Venture Investments (lead), iGlobe, Photon Venture Alpha, Phoenix Venture Partners |

Total raised: ~$14M. [[1]](https://www.prnewswire.com/news-releases/eclipsebio-announces-a-14-million-series-a-financing-to-advance-its-rna-genomics-technology-platform-301502159.html)

---

## References

1. PRNewswire — Eclipsebio $14M Series A financing (Mar 2022): [https://www.prnewswire.com/news-releases/eclipsebio-announces-a-14-million-series-a-financing-to-advance-its-rna-genomics-technology-platform-301502159.html](https://www.prnewswire.com/news-releases/eclipsebio-announces-a-14-million-series-a-financing-to-advance-its-rna-genomics-technology-platform-301502159.html)
2. Eclipsebio — Homepage: [https://eclipsebio.com/](https://eclipsebio.com/)
3. Eclipsebio — eMERGE platform launch (Jul 2024): [https://eclipsebio.com/news/press-release/eclipsebio-launches-emerge/](https://eclipsebio.com/news/press-release/eclipsebio-launches-emerge/)
