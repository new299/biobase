# Tasso

## Overview

Tasso is a Seattle healthcare technology company developing patient-centric, at-home blood collection systems. The company says its devices enable simple, convenient, and virtually painless collection of clinical-grade blood for research, diagnostics, and decentralized clinical trials. [[1]](https://www.tassoinc.com/kits) [[2]](https://www.tassoinc.com/press-releases/tasso-device-earns-fda-510k-class-ii-medical-device-clearance)

## Technology

Tasso's core products include the Tasso+ and Tasso Mini blood collection devices, along with dried blood spot collection systems such as Tile-T20. The company has built the platform around self-collection hardware plus logistics and service layers for remote testing and trial support. [[1]](https://www.tassoinc.com/kits) [[3]](https://www.tassoinc.com/press-releases/tasso-announces-next-generation-technology-for-patient-centric-dried-blood-spot-sample-collection)

## Investors

Tasso announced a $17 million Series A in July 2020 led by Hambrecht Ducera Growth Ventures, with participation from Foresite Capital, Merck Global Health Innovation Fund, Vertical Venture Partners, Techstars, and Cedars-Sinai. In December 2021, it announced an oversubscribed $100 million Series B led by RA Capital Management, with participation from the D.E. Shaw group, Senvest, InCube, SVB Innovation Fund, and existing investors. [[4]](https://www.tassoinc.com/press-releases/2020/07/22/2020-7-22-tasso-series-a-financing) [[5]](https://www.tassoinc.com/press-releases/tasso-secures-100m-in-series-b-financing)

## Regulatory And Commercial Development

Tasso has added significant regulatory milestones, including FDA 510(k) Class II clearance for Tasso+ in 2022 and CE Mark certifications for multiple products. Those milestones support its push into decentralized trials, home diagnostics, and international markets. [[2]](https://www.tassoinc.com/press-releases/tasso-device-earns-fda-510k-class-ii-medical-device-clearance) [[6]](https://www.tassoinc.com/press-releases/tasso-high-volume-liquid-blood-collection-device-earns-ce-mark-certification) [[7]](https://www.tassoinc.com/press-releases/tasso-secures-additional-north-american-and-european-regulatory-clearances-for-tasso-mini-device)
