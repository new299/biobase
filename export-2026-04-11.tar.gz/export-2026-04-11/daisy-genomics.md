# Daisy Genomics — Research Notes

## Overview

Daisy Genomics (formerly Armonica Technologies) is an Albuquerque, NM-based genomics startup developing optical long-read DNA sequencing technology using nanochannel and surface-enhanced Raman spectroscopy (SERS)-based platforms. Raised $2.5M seed round (January 2026) to advance precision medicine applications. [[1]](https://www.genomeweb.com/sequencing/daisy-genomics-raises-25m-seed-funding-develop-optical-long-read-sequencing-tech) [[2]](https://innovations.unm.edu/2026/01/05/local-startup-daisy-genomics-raises-2-5m-to-scale-locally/)

---

## Technology

- **Optical Long-Read Sequencing**: Proprietary nanochannel and SERS (surface-enhanced Raman spectroscopy)-based DNA sequencing platform. Aims to deliver long-read sequencing capability at reduced cost and complexity for precision medicine applications including clinical diagnostics. [[1]](https://www.genomeweb.com/sequencing/daisy-genomics-raises-25m-seed-funding-develop-optical-long-read-sequencing-tech)
- **Applications**: Advancing chip performance for clinical genomics, expanding collaborations with universities and diagnostics companies. [[2]](https://innovations.unm.edu/2026/01/05/local-startup-daisy-genomics-raises-2-5m-to-scale-locally/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed | Jan 2026 | $2.5M | Cottonwood Technology Fund (existing), Tramway Venture Partners (existing), Waves Capital Partners (new) |

Total raised: ~$2.5M publicly disclosed. [[1]](https://www.genomeweb.com/sequencing/daisy-genomics-raises-25m-seed-funding-develop-optical-long-read-sequencing-tech)

---

## References

1. GenomeWeb — Daisy Genomics raises $2.5M seed for optical long-read sequencing: [https://www.genomeweb.com/sequencing/daisy-genomics-raises-25m-seed-funding-develop-optical-long-read-sequencing-tech](https://www.genomeweb.com/sequencing/daisy-genomics-raises-25m-seed-funding-develop-optical-long-read-sequencing-tech)
2. UNM Rainforest Innovations — Daisy Genomics raises $2.5M: [https://innovations.unm.edu/2026/01/05/local-startup-daisy-genomics-raises-2-5m-to-scale-locally/](https://innovations.unm.edu/2026/01/05/local-startup-daisy-genomics-raises-2-5m-to-scale-locally/)

## ASeq Posts

- [Daisy Genomics](https://aseq.substack.com/p/daisy-genomics)
- [A New Armonica Patent](https://aseq.substack.com/p/a-new-armonica-patent)
- [Armonica](https://aseq.substack.com/p/armonica)
