# Element Biosciences — Research Notes

## Overview

Element Biosciences is a San Diego, CA-based genomics company developing next-generation DNA sequencing and multi-omics platforms. Commercial product: AVITI™ benchtop sequencer — an Illumina-competitive short-read NGS system praised for data quality, flexibility, and affordability. Total raised: ~$680M+ (including $277M Series D July 2024 led by Wellington Management). Install base grew from ~40 to 190+ instruments in 12 months. [[1]](https://www.elementbiosciences.com/news/element-biosciences-raises-over-277-million-to-develop-and-commercialize-differentiated-products-and-continue-rapid-growth)

---

## Technology & Products

- **AVITI™ System**: Benchtop short-read DNA sequencer with reimagined avidity-based sequencing chemistry delivering high accuracy, flexibility, and lower cost than established platforms. Serves as a direct competitor to Illumina's NextSeq/MiSeq. [[2]](https://www.elementbiosciences.com/products/aviti)
- **AVITI24™**: Next-generation platform announced with Series D funding — the first instrument combining state-of-the-art DNA sequencing with cyto-profiling (cell characterization mapping) in a single integrated platform. [[1]](https://www.elementbiosciences.com/news/element-biosciences-raises-over-277-million-to-develop-and-commercialize-differentiated-products-and-continue-rapid-growth)
- **Proximity Ligation Partnerships**: Validated Dovetail Genomics' proximity ligation-based NGS library prep for epigenomics on the AVITI platform. [[3]](https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Series A–C | ~2017–2022 | ~$403M | Venrock, Foresite Capital, Fidelity, others |
| Series D | Jul 2024 | $277M | Wellington Management (lead), Samsung Electronics, Fidelity, Foresite Capital, T. Rowe Price, Venrock |

Total raised: ~$680M+. [[1]](https://www.elementbiosciences.com/news/element-biosciences-raises-over-277-million-to-develop-and-commercialize-differentiated-products-and-continue-rapid-growth)

---

## References

1. Element Biosciences — $277M Series D raise (Jul 2024): [https://www.elementbiosciences.com/news/element-biosciences-raises-over-277-million-to-develop-and-commercialize-differentiated-products-and-continue-rapid-growth](https://www.elementbiosciences.com/news/element-biosciences-raises-over-277-million-to-develop-and-commercialize-differentiated-products-and-continue-rapid-growth)
2. Element Biosciences — AVITI system: [https://www.elementbiosciences.com/products/aviti](https://www.elementbiosciences.com/products/aviti)
3. Element Biosciences — Dovetail Genomics partnership: [https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system](https://www.elementbiosciences.com/news/element-partners-with-dovetail-genomics-to-validate-its-proximity-ligation-based-ngs-library-prep-solutions-for-epigenetics-on-elements-aviti-system)

## ASeq Posts

- [Element High Throughput Vitari](https://aseq.substack.com/p/element-high-throughput-vitari)
- [Elements Progress At Jpm](https://aseq.substack.com/p/elements-progress-at-jpm)
- [Element Sues Illumina](https://aseq.substack.com/p/element-sues-illumina)
- [Element Pricing Disappeared](https://aseq.substack.com/p/element-pricing-disappeared)
- [Illumina Sue Element](https://aseq.substack.com/p/illumina-sue-element)
- [Elementjpm](https://aseq.substack.com/p/elementjpm)
- [Element Biosciences Further Thoughts](https://aseq.substack.com/p/element-biosciences-further-thoughts)
- [Element Biosciences Chemistry](https://aseq.substack.com/p/element-biosciences-chemistry)
- [Element Biosciences Launch Review](https://aseq.substack.com/p/element-biosciences-launch-review)
