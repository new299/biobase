# POINT Biopharma

## Overview
POINT Biopharma was a radiopharmaceutical company developing targeted radioligand therapies for cancer.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-point-biopharma-expand-oncology-capabilities-next)[[2]](https://investor.lilly.com/news-releases/news-release-details/lilly-completes-acquisition-point-biopharma)

## Technology
Lilly described POINT as having a pipeline of clinical and preclinical radioligand therapies, including PSMA- and FAP-alpha-targeted programs, supported by in-house manufacturing and isotope supply capabilities.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-point-biopharma-expand-oncology-capabilities-next)

## Investors
By the time of the key transaction, POINT was a Nasdaq-listed public company rather than a private venture-stage biotech.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-point-biopharma-expand-oncology-capabilities-next)

## Acquisitions / Other
Lilly announced in October 2023 that it would acquire POINT for $12.50 per share in cash, valuing the company at about $1.4 billion, and completed the acquisition on December 27, 2023.[[1]](https://investor.lilly.com/news-releases/news-release-details/lilly-acquire-point-biopharma-expand-oncology-capabilities-next)[[2]](https://investor.lilly.com/news-releases/news-release-details/lilly-completes-acquisition-point-biopharma)
