# Dunad Therapeutics

## Overview
Dunad Therapeutics is a transatlantic biotech company developing covalent medicines for neurodegenerative diseases including ALS and Parkinson's disease.[[1]](https://www.dunadtx.com/)[[2]](https://www.biospace.com/press-releases/dunad-therapeutics-launches-with-20-million-seed-financing-to-pioneer-a-novel-class-of-neurodegeneration-therapeutics)

## Technology
The company says it combines tunable covalent chemistry with disease biology to discover selective and durable medicines. Its public positioning is centered on covalent approaches against disease drivers in neurodegeneration.[[1]](https://www.dunadtx.com/)[[2]](https://www.biospace.com/press-releases/dunad-therapeutics-launches-with-20-million-seed-financing-to-pioneer-a-novel-class-of-neurodegeneration-therapeutics)

## Investors
Dunad launched in 2024 with $20 million in seed financing from Epidarex Capital, Boehringer Ingelheim Venture Fund, Wellington Partners, and BGF.[[2]](https://www.biospace.com/press-releases/dunad-therapeutics-launches-with-20-million-seed-financing-to-pioneer-a-novel-class-of-neurodegeneration-therapeutics)

## Acquisitions / Other
No acquisition was identified in the reviewed public sources.[[1]](https://www.dunadtx.com/)
