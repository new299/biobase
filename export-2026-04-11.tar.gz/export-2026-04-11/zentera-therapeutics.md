# Zentera Therapeutics — Company Overview

## 🧬 Basic Information
**Name:** Zentera Therapeutics (正腾康生物科技（上海）有限公司)  
**Type:** Private clinical‑stage biopharmaceutical company  
**Founded:** 2020 :contentReference[oaicite:0]{index=0}  
**Headquarters:** Shanghai, China (also reported operations in Beijing) :contentReference[oaicite:1]{index=1}  
**Employees:** ~11‑50 (LinkedIn) :contentReference[oaicite:2]{index=2}  
**Website:** https://zenteratx.com :contentReference[oaicite:3]{index=3}  
**Industry:** Biotechnology / Oncology / Pharmaceutical development :contentReference[oaicite:4]{index=4}

## 🧠 Mission & Focus
Zentera Therapeutics is a **clinical‑stage oncology drug developer** focused on small molecule cancer therapies aimed at unmet needs in solid and liquid tumors. The company was spun out as a China‑focused venture in partnership with Zentalis Pharmaceuticals. :contentReference[oaicite:5]{index=5}

---

## 💊 Products & Pipeline
Zentera does not have any **commercial products approved for sale**. Its main focus is **advancing clinical candidates** discovered by Zentalis Pharmaceuticals:

### Main Pipeline Candidates
- **ZN‑c3 (Azenosertib):** oral **WEE1 inhibitor** targeting DNA damage response in solid tumors. :contentReference[oaicite:6]{index=6}  
- **ZN‑c5:** oral **Selective Estrogen Receptor Degrader (SERD)** for ER+/HER2‑ breast cancer. :contentReference[oaicite:7]{index=7}  
- **ZN‑d5 (Asaretoclax):** **BCL‑2 inhibitor** for hematologic cancers such as Non‑Hodgkin’s lymphoma (development status varies). :contentReference[oaicite:8]{index=8}

No marketed products exist yet; all are in **clinical or early development in China**. :contentReference[oaicite:9]{index=9}

---

## 📍 Market & Strategy
- Zentera’s **primary market** is **China & Greater China (PRC, Hong Kong, Macau, Taiwan)**. :contentReference[oaicite:10]{index=10}  
- It was established to develop and commercialize oncology assets in China using Zentalis’ drug candidates. :contentReference[oaicite:11]{index=11}  
- Historically, there were plans discussed for a **Hong Kong public listing** after Series B capital raise. :contentReference[oaicite:12]{index=12}

---

## 💰 Funding & Investors
Zentera has completed **two major funding rounds**:

### Funding Rounds
- **Series A (2020) ~$20M** — led by **Tybourne Capital Management** and **OrbiMed Asia**; established the joint venture with Zentalis. :contentReference[oaicite:13]{index=13}  
- **Series B (2021) ~$75M** — led by **OrbiMed Advisors Asia** and **Tybourne Capital Management** with participation from Avidity Partners, Casdin Capital, Surveyor Capital, Farallon Capital Management, Lilly Asia Ventures, Logos Capital, Perceptive Advisors, Redmile Group, Viking Global Investors. :contentReference[oaicite:14]{index=14}

**Total Raised:** approximately **$95M** across rounds. :contentReference[oaicite:15]{index=15}  

**Investors:** OrbiMed, Tybourne Capital, Avidity Partners, Casdin Capital, Farallon Capital, Redmile, Viking Global, Perceptive Advisors, Lilly Asia Ventures, Logos Capital, Surveyor Capital. :contentReference[oaicite:16]{index=16}

---

## 📊 Status / Active?
- The company is reported as **active (Series B stage)** with no public revenue yet and no marketed products. :contentReference[oaicite:17]{index=17}  
- It **remains clinical stage** and requires substantial capital and regulatory success to commercialize drugs. :contentReference[oaicite:18]{index=18}  
- Some reports suggest ongoing clinical trials (e.g., ZN‑c3, ZN‑c5, ZN‑d5) in China with several clinical trial applications approved. :contentReference[oaicite:19]{index=19}  
- There are indications that development rights for certain assets may have changed or been reacquired by Zentalis (reported in 2023 Zentalis filings), but detailed confirmation is outside the free sources. :contentReference[oaicite:20]{index=20}

---

## 👤 Leadership & Founders
- **Dr. Anthony Y. Sun, M.D. — CEO of Zentera Therapeutics** (also Chairman & CEO of Zentalis Pharmaceuticals). :contentReference[oaicite:21]{index=21}  
- Founded as a joint venture between Zentalis and major biotech investors. :contentReference[oaicite:22]{index=22}

---

## 📍 Geography & Operations
- **Shanghai, China:** primary headquarters and clinical development base. :contentReference[oaicite:23]{index=23}  
- Reported smaller presence in **Beijing** as well. :contentReference[oaicite:24]{index=24}  
- Some foreign career listings mention **New York & San Diego**, but those likely represent Zentalis parent operations, not Zentera’s core HQ. :contentReference[oaicite:25]{index=25}

---

## 📚 Sources

- **Zentera Therapeutics Series B financing announcement**: https://ir.zentalis.com/news‑releases/news‑release‑details/zentera‑therapeutics‑announces‑closing‑75‑million‑series‑B‑financing :contentReference[oaicite:26]{index=26}  
- **Company overview & funding snapshot**: https://www.cbinsights.com/company/zentera‑therapeutics :contentReference[oaicite:27]{index=27}  
- **Series A JV press release**: https://ir.zentalis.com/news‑releases/news‑release‑details/zentalis‑pharmaceuticals‑announces‑20‑million‑series‑financing/ :contentReference[oaicite:28]{index=28}  
- **CRUNCHBASE profile**: https://www.crunchbase.com/organization/zentera‑therapeutics :contentReference[oaicite:29]{index=29}  
- **LinkedIn (company profile)**: https://www.linkedin.com/company/zentera%E6%AD%A3%E8%85%BE%E5%BA%B7/ :contentReference[oaicite:30]{index=30}  
- **Additional Fierce Biotech context**: https://www.fiercebiotech.com/biotech/zentera‑therapeutics‑raises‑75m‑series‑b‑to‑advance‑three‑oncology‑assets‑eyes‑2022‑listing :contentReference[oaicite:31]{index=31}
