# Keros Therapeutics

## Overview

Keros Therapeutics is a clinical-stage biopharmaceutical company developing therapeutics modulating the transforming growth factor-beta (`TGF-beta`) family for hematological, pulmonary, cardiovascular, and neuromuscular disorders.[[1]](https://ir.kerostx.com/) The company describes itself as a leader in understanding TGF-beta family proteins as regulators of red blood cell and platelet production and tissue maintenance.[[1]](https://ir.kerostx.com/)

## Technology

Keros develops ligand trap and related biologic therapeutics targeting TGF-beta superfamily signaling. Its programs have included KER-050 and RKER-050 for hematologic disorders and rinvatercept/cibotercept programs in pulmonary and cardiovascular indications.[[1]](https://ir.kerostx.com/) Public filings and presentations position the platform around modulating master regulatory pathways rather than single-disease product optimization.[[1]](https://ir.kerostx.com/)

## Investors

In March 2020, Keros closed a $56 million Series C led by new investors Foresite Capital, OrbiMed, Cowen Healthcare Investments, and Venrock, bringing total venture funding to $78.5 million at that time.[[2]](https://ir.kerostx.com/news-releases/news-release-details/keros-therapeutics-closes-56-million-series-c-financing-advance) As a public company, Keros later raised follow-on capital through the public markets, including an upsized public offering in January 2024 priced for gross proceeds of $140 million before underwriter option exercise.[[3]](https://www.globenewswire.com/news-release/2024/01/04/2803690/0/en/Keros-Therapeutics-Announces-Pricing-of-Upsized-Public-Offering-of-Common-Stock.html)

## Acquisitions and Strategic Transactions

No acquisition involving Keros was identified in the reviewed sources. A notable recent capital-allocation event was its 2025 $375 million capital return program, including a $194.4 million tender offer.[[4]](https://www.globenewswire.com/news-release/2025/10/20/3169169/0/en/Keros-Therapeutics-Commences-Issuer-Tender-Offer-to-Repurchase-up-to-194-4-Million-Shares.html)
