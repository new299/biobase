# Exact Sciences — Research Notes

## Overview

Exact Sciences Corporation (NASDAQ: EXAS) is a Madison, WI-based precision oncology company that developed Cologuard® — the world's first FDA-approved stool DNA test for colorectal cancer screening. Founded in 1995 by Stanley Lapidus and Anthony Shuber in Marlborough, MA. Under CEO Kevin Conroy (starting ~2009), the company pivoted to Cologuard and partnered with Mayo Clinic; Cologuard received FDA PMA in August 2014. The company also developed Oncotype DX (acquired via Genomic Health 2019) for breast/prostate/colon cancer tumor profiling, and the blood-based CancerGuard multi-cancer early detection test. Abbott Laboratories announced acquisition of Exact Sciences for ~$21B in November 2025. [[1]](https://www.exactsciences.com/newsroom/press-releases/exact-sciences-launches-the-cologuard-plus-test-transforming-colorectal-cancer-screening) [[2]](https://en.wikipedia.org/wiki/Exact_Sciences_Corporation)

---

## Technology & Products

- **Cologuard® (stool DNA)**: Non-invasive FDA-approved colorectal cancer screening test analyzing stool DNA and hemoglobin — highly sensitive detection of colorectal cancer and pre-cancerous polyps without bowel prep or colonoscopy. FDA PMA August 2014. [[1]](https://www.exactsciences.com/newsroom/press-releases/exact-sciences-launches-the-cologuard-plus-test-transforming-colorectal-cancer-screening)
- **Cologuard Plus® (stool DNA)**: Next-generation Cologuard with improved specificity. Launched 2025. FDA approved.
- **Oncotype DX® (Genomic Health)**: Multi-gene expression tumor profiling assay for treatment decisions in breast, prostate, and colon cancers. Acquired via Genomic Health acquisition for ~$2.8B (2019).
- **CancerGuard®**: Blood-based multi-cancer early detection (MCED) test for multiple cancer types from a single blood draw. In development/early commercialization.
- **Mayo Clinic Partnership**: Key early clinical collaboration providing scientific validation for Cologuard; Mayo Clinic Ventures also an investor.

---

## Funding & Corporate History

| Event | Date | Details |
|-------|------|---------|
| Founded | 1995 | Stanley Lapidus + Anthony Shuber; Marlborough, MA |
| IPO (NASDAQ: EXAS) | 2001 | Initial public offering |
| Cologuard FDA approval | Aug 2014 | PMA for stool DNA colorectal cancer screening |
| Genomic Health acquisition | 2019 | ~$2.8B; adds Oncotype DX franchise |
| Cologuard Plus FDA approval | ~2025 | Next-gen version |
| Abbott acquisition announced | Nov 2025 | ~$21B deal |

Total raised: Public company since 2001; no current VC investors. [[2]](https://en.wikipedia.org/wiki/Exact_Sciences_Corporation)

---

## References

1. Exact Sciences — Cologuard Plus launch: [https://www.exactsciences.com/newsroom/press-releases/exact-sciences-launches-the-cologuard-plus-test-transforming-colorectal-cancer-screening](https://www.exactsciences.com/newsroom/press-releases/exact-sciences-launches-the-cologuard-plus-test-transforming-colorectal-cancer-screening)
2. Wikipedia — Exact Sciences Corporation: [https://en.wikipedia.org/wiki/Exact_Sciences_Corporation](https://en.wikipedia.org/wiki/Exact_Sciences_Corporation)
