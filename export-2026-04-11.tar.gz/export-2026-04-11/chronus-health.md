# Chronus Health — Research Notes

## Overview

Chronus Health is a Silicon Valley-based medical device company developing a portable, rapid, point-of-care blood analyzer. Uses electrical sensing-based technology (rather than optical) to perform comprehensive blood panels in ~15 minutes from a fingerstick or small blood sample. Total raised: ~$28M. [[1]](https://www.chronushealth.com/) [[2]](https://hitconsultant.net/2022/01/12/chronus-health-series-a-funding/)

---

## Technology

- **Electrical Sensing-Based Blood Testing**: Proprietary platform using electrochemical/electrical sensing (rather than optical methods) for rapid, lab-quality blood analysis at point-of-care. Can measure multiple blood analytes from a single small-volume sample in approximately 15 minutes. Unveiled at ADLM 2024 conference. [[3]](https://www.biospace.com/electric-is-the-future-chronus-health-to-unveil-its-electrical-sensing-based-blood-testing-technology-at-adlm-2024)
- Designed to bring comprehensive blood testing to decentralized settings (clinics, pharmacies, home). [[1]](https://www.chronushealth.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Pre-Series A | ~2019–2021 | ~$6M | SOSV, SeedFolio, K3 Ventures |
| Series A | Jan 2022 | $22M | Tarsadia Investments (lead), Monta Vista Capital, SOSV, Savantus Ventures |
| Debt - II | Jan 2024 | $2.17M | SOSV |

Total raised: ~$28M. [[2]](https://hitconsultant.net/2022/01/12/chronus-health-series-a-funding/) [[4]](https://www.crunchbase.com/organization/chronus-health)

---

## References

1. Chronus Health — Company website: [https://www.chronushealth.com/](https://www.chronushealth.com/)
2. HIT Consultant — Chronus Health $22M Series A (Jan 2022): [https://hitconsultant.net/2022/01/12/chronus-health-series-a-funding/](https://hitconsultant.net/2022/01/12/chronus-health-series-a-funding/)
3. BioSpace — Chronus Health electrical sensing blood testing at ADLM 2024: [https://www.biospace.com/electric-is-the-future-chronus-health-to-unveil-its-electrical-sensing-based-blood-testing-technology-at-adlm-2024](https://www.biospace.com/electric-is-the-future-chronus-health-to-unveil-its-electrical-sensing-based-blood-testing-technology-at-adlm-2024)
4. Crunchbase — Chronus Health: [https://www.crunchbase.com/organization/chronus-health](https://www.crunchbase.com/organization/chronus-health)

## ASeq Posts

- [Chronus Health Inc](https://aseq.substack.com/p/chronus-health-inc)
