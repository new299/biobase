# Labcorp

## Overview

Labcorp is a large public laboratory services and life sciences company providing clinical diagnostics, central laboratory services, and drug development support globally.[[1]](https://www.labcorp.com/) The company operates across routine testing, specialty diagnostics, oncology, and biopharma services.[[1]](https://www.labcorp.com/)

## Technology and Services

Labcorp's capabilities span clinical diagnostics, molecular testing, genomic profiling, and biomarker-driven oncology services. Its acquisition of Personal Genome Diagnostics in 2022 specifically expanded Labcorp's NGS-based cancer genomics and liquid biopsy capabilities.[[2]](https://ir.labcorp.com/news-releases/news-release-details/labcorp-completes-acquisition-personal-genome-diagnostics)

## Investors

Labcorp is a NYSE-listed public company (`LH`), so its capitalization is primarily through public-market ownership rather than venture financing.[[2]](https://ir.labcorp.com/news-releases/news-release-details/labcorp-completes-acquisition-personal-genome-diagnostics)

## Acquisitions and Strategic Transactions

Labcorp has continued to expand through acquisitions. It completed the acquisition of Personal Genome Diagnostics in February 2022.[[2]](https://ir.labcorp.com/news-releases/news-release-details/labcorp-completes-acquisition-personal-genome-diagnostics) In March 2025, it announced an agreement to acquire select oncology assets of BioReference Health.[[3]](https://www.labcorp.com/education-events/press-releases/labcorp-announces-acquisition-select-assets-bioreference-healths-innovative-oncology-and-related) In May 2025, it also announced an agreement to acquire select clinical testing assets from Incyte Diagnostics.[[4]](https://www.labcorp.com/labcorp-acquire-select-assets-incyte-diagnostics-clinical-and-anatomic-pathology-testing-businesses)
