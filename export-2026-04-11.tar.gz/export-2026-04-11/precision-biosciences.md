# Precision BioSciences

## Overview
Precision BioSciences is a clinical-stage gene editing company built around its proprietary ARCUS genome editing platform.[[1]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-announces-75-million-offering-common-stock)[[2]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-announces-400-million-offering-common/)[[3]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-enters-private-convertible-note-financing)

## Technology
The company says ARCUS differs from other gene editing technologies in how it cuts and in its compact size and structure, and it applies the platform to in vivo gene editing and other therapeutic modalities.[[1]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-announces-75-million-offering-common-stock)

## Investors / Financing
Precision announced a $40 million public offering in March 2024 and a $75 million offering in November 2025. Earlier, in 2019, it entered into a private convertible note financing of about $40 million and said total funding since inception had exceeded $300 million.[[2]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-announces-400-million-offering-common/)[[1]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-announces-75-million-offering-common-stock)[[3]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-enters-private-convertible-note-financing)

## Acquisitions / Other
Precision has reshaped its portfolio through asset transactions rather than acquisitions, including reacquiring global rights to its allogeneic CAR-T programs from Servier in 2021 and a strategic transaction with Imugene related to azer-cel.[[4]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-reacquires-global-rights-its-allogeneic)[[5]](https://investor.precisionbiosciences.com/news-releases/news-release-details/precision-biosciences-receives-13-million-proceeds-imugene)
