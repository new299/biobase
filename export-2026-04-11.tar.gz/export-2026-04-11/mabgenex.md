# mAbGenEx

## Overview

mAbGenEx is a biotechnology company developing precision therapeutic antibodies and diagnostics using proprietary antibody discovery platforms.[[1]](https://www.mabgenex.com/)

## Technology

The company says it is built around its `PrecinAb` biology-aware antibody discovery platform and `OptinAb` cell-surface display platform.[[1]](https://www.mabgenex.com/) Public materials describe a biology-first approach that starts with selecting the right epitope and then applies AI/ML-assisted antibody discovery to generate safer and more specific therapeutic antibodies, including for hard-to-drug targets.[[1]](https://www.mabgenex.com/)

## Investors

No clearly disclosed institutional financing round or investor syndicate was identified in the reviewed public sources. The company website reviewed is focused on the platform, team, and partnerships rather than fundraising.[[1]](https://www.mabgenex.com/)

## Acquisitions and Strategic Transactions

No acquisition involving mAbGenEx was identified in the reviewed sources. The public footprint reviewed is centered on internal platform development and partnerships rather than M&A.[[1]](https://www.mabgenex.com/)
