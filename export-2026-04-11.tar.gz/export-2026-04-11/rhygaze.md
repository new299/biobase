# RhyGaze

## Overview
RhyGaze is a biotechnology company based in Basel and Philadelphia developing gene therapies for retinal diseases that cause blindness [[1]](https://www.rhygaze.com/) [[2]](https://fprimecapital.com/company/rhygaze/).

## Technology
The company says its platform combines optogenetic proteins and gene therapy tools to engineer photosensitivity into cells in the eye to restore vision [[1]](https://www.rhygaze.com/).

## Investors
RhyGaze closed an $86 million Series A in January 2025 led by GV, with participation from ARCH Venture Partners, F-Prime Capital, and founding investors BioGeneration Ventures and Novartis Venture Fund [[3]](https://www.finsmes.com/2025/01/rhygaze-closes-usd-86m-series-a-funding.html) [[4]](https://www.walderwyss.com/en/news/2025-01-28_walder-wyss-advised-rhygaze-ag-on-usd-86m-series-a-financing-round).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources; the key strategic transaction was the 2025 Series A financing to advance its lead optogenetic vision-restoration candidate [[3]](https://www.finsmes.com/2025/01/rhygaze-closes-usd-86m-series-a-funding.html).

## References
[[1]](https://www.rhygaze.com/)
[[2]](https://fprimecapital.com/company/rhygaze/)
[[3]](https://www.finsmes.com/2025/01/rhygaze-closes-usd-86m-series-a-funding.html)
[[4]](https://www.walderwyss.com/en/news/2025-01-28_walder-wyss-advised-rhygaze-ag-on-usd-86m-series-a-financing-round)
