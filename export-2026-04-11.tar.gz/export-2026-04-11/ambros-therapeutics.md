# Ambros Therapeutics

## Overview
Ambros Therapeutics is a clinical-stage biotechnology company developing late-stage therapies for severe diseases with high unmet need, beginning with complex regional pain syndrome type 1.[[1]](https://ambrostherapeutics.com/about/)[[2]](https://ambrostherapeutics.com/news/ambros-therapeutics-launches/) Its lead program is neridronate for CRPS-1.[[1]](https://ambrostherapeutics.com/about/)

## Technology and Pipeline
Ambros is an asset-centric clinical developer rather than a broad platform company. It is advancing neridronate through a Phase 3 registrational program for CRPS-1, using biomarker-informed patient selection and an expanding IP estate around the indication.[[1]](https://ambrostherapeutics.com/about/)[[2]](https://ambrostherapeutics.com/news/ambros-therapeutics-launches/)[[3]](https://www.globenewswire.com/news-release/2026/03/31/3265529/0/en/Ambros-Therapeutics-Announces-Notice-of-Allowance-for-New-U-S-Patent-Application-Covering-Neridronate-for-Complex-Regional-Pain-Syndrome-Type-1.html)

## Investors
Ambros announced in December 2025 that it launched with an oversubscribed $125 million Series A co-led by RA Capital Management and Patient Square Capital’s platform Enavate Sciences, with participation from Abiogen Pharma, Janus Henderson Investors, Arkin Bio, Balyasny Asset Management, Transhuman Capital, Adage Capital Partners, and other life sciences investors.[[2]](https://ambrostherapeutics.com/news/ambros-therapeutics-launches/)

## Acquisitions and Corporate Activity
At launch, Ambros also announced a strategic collaboration with Abiogen Pharma under which it obtained exclusive rights to neridronate in North America with an option for broader market expansion.[[2]](https://ambrostherapeutics.com/news/ambros-therapeutics-launches/) I did not identify a whole-company acquisition involving Ambros in the reviewed public sources.
