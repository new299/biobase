# National Resilience

## Overview

National Resilience, often branded as Resilience, is a technology-forward biopharmaceutical manufacturing and development company focused on enabling development and production of complex biologics and advanced therapies.[[1]](https://resilience.com/)

## Technology and Operations

Resilience positions itself as a biomanufacturing network rather than a traditional therapeutics company. Its capabilities span drug substance and drug product manufacturing, analytical development, process development, and support for biologics, nucleic acid medicines, vaccines, and cell therapies.[[1]](https://resilience.com/)

## Investors

Resilience announced a $625 million Series D financing in November 2024 led by UAE-based ADQ, with participation from Mubadala, Goldman Sachs Alternatives, and existing investors such as ARCH Venture Partners, 8VC, Ally Bridge Group, DCVC, Koch Disruptive Technologies, New Enterprise Associates, and SoftBank Vision Fund 2.[[2]](https://resilience.com/press-release/resilience-closes-over-625m-in-series-d-financing/) The company said total capital raised then exceeded $2 billion.[[2]](https://resilience.com/press-release/resilience-closes-over-625m-in-series-d-financing/)

## Acquisitions and Strategic Transactions

Resilience has grown in part through acquisitions and network expansion. Its public materials include multiple site and business integrations, and the company has used large financing rounds to scale those capabilities. No change-of-control acquisition of Resilience itself was identified in the reviewed sources.[[1]](https://resilience.com/) [[2]](https://resilience.com/press-release/resilience-closes-over-625m-in-series-d-financing/)
