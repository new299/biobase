# Regulus Therapeutics

## Overview
Regulus Therapeutics was a clinical-stage biopharmaceutical company focused on microRNA therapeutics, most recently centered on ADPKD [[1]](https://www.novartis.com/news/media-releases/novartis-acquire-regulus-therapeutics-and-farabursen-investigational-microrna-inhibitor-treat-adpkd-most-common-genetic-cause-renal-failure).

## Technology
Its lead asset was farabursen, a next-generation oligonucleotide targeting miR-17 with kidney-preferential exposure for ADPKD [[1]](https://www.novartis.com/news/media-releases/novartis-acquire-regulus-therapeutics-and-farabursen-investigational-microrna-inhibitor-treat-adpkd-most-common-genetic-cause-renal-failure).

## Investors
As a public company, Regulus was financed through public markets. The reviewed strategic materials focused on the acquisition rather than pre-acquisition shareholder composition [[1]](https://www.novartis.com/news/media-releases/novartis-acquire-regulus-therapeutics-and-farabursen-investigational-microrna-inhibitor-treat-adpkd-most-common-genetic-cause-renal-failure).

## Acquisitions / Strategic Transactions
Novartis announced in April 2025 that it would acquire Regulus for $0.8 billion upfront plus a potential $0.9 billion regulatory milestone payment, and completed the acquisition in June 2025 [[1]](https://www.novartis.com/news/media-releases/novartis-acquire-regulus-therapeutics-and-farabursen-investigational-microrna-inhibitor-treat-adpkd-most-common-genetic-cause-renal-failure) [[2]](https://www.novartis.com/news/media-releases/novartis-completes-acquisition-regulus-therapeutics).

## References
[[1]](https://www.novartis.com/news/media-releases/novartis-acquire-regulus-therapeutics-and-farabursen-investigational-microrna-inhibitor-treat-adpkd-most-common-genetic-cause-renal-failure)
[[2]](https://www.novartis.com/news/media-releases/novartis-completes-acquisition-regulus-therapeutics)
