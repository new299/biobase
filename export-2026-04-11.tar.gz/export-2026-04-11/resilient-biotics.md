# Resilient Biotics

## Overview
Resilient Biotics is developing live microbiome therapeutics to prevent complex respiratory infections in human and animal health [[1]](https://resilientbiotics.com/company-overview/).

## Technology
The company says it uses proprietary discovery analytics to identify and design microbiome products that prevent pathogens from establishing in the respiratory tract [[1]](https://resilientbiotics.com/company-overview/).

## Investors
Owler reports Resilient has raised about $10.9 million across a 2020 Series A and 2022 debt financing, with investors including Berkeley Catalyst Fund, Fulcrum Global Capital, Elanco Animal Health, Innovation in Motion, and Viking Global Investors [[2]](https://www.owler.com/company/resilientbiotics/funding). F6S similarly shows backing from Fulcrum Global Capital and other investors [[3]](https://www.f6s.com/company/resilientbiotics).

## Acquisitions / Strategic Transactions
No acquisition was identified in the reviewed sources during this pass. The main strategic events visible publicly were its Series A and follow-on financing rounds [[2]](https://www.owler.com/company/resilientbiotics/funding).

## References
[[1]](https://resilientbiotics.com/company-overview/)
[[2]](https://www.owler.com/company/resilientbiotics/funding)
[[3]](https://www.f6s.com/company/resilientbiotics)
