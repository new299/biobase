# Dicerna Pharmaceuticals — Research Notes

## Overview

Dicerna Pharmaceuticals was a Lexington, MA-based RNAi therapeutics company founded in 2006. Developed the proprietary GalXC™ RNAi platform for liver-targeted gene silencing using GalNAc-conjugated siRNA. Pre-acquisition funding: ~$420.5M total. Acquired by Novo Nordisk for $3.3B ($38.25/share, 80% premium) in November 2021; now operates as a Novo Nordisk subsidiary. [[1]](https://www.novonordisk.com/content/nncorp/global/en/news-and-media/news-and-ir-materials/news-details.html?id=87435) [[2]](https://www.businesswire.com/news/home/20211118005644/en/Novo-Nordisk-to-Acquire-Dicerna)

---

## Technology

- **GalXC™ RNAi Platform**: Proprietary siRNA molecules chemically conjugated to a GalNAc (N-acetylgalactosamine) ligand targeting ASGPR receptors highly expressed on hepatocytes — enabling efficient, selective liver delivery of siRNA. Enables subcutaneous dosing for sustained gene silencing. [[1]](https://www.novonordisk.com/content/nncorp/global/en/news-and-media/news-and-ir-materials/news-details.html?id=87435)
- **Applications**: Liver-related cardiometabolic diseases, NASH, type 2 diabetes, obesity, rare liver diseases. Pre-acquisition Novo Nordisk collaboration (Nov 2019, up to $607M) explored 30+ liver cell targets. [[3]](https://www.pharmtech.com/view/novo-nordisk-and-dicerna-partner-collaboration-worth-607-million-0)

---

## Funding & Corporate History

| Event | Date | Amount / Details |
|-------|------|-----------------|
| Founded | 2006 | Lexington, MA |
| Pre-acquisition funding | 2006–2021 | ~$420.5M total |
| Novo Nordisk collaboration | Nov 2019 | Up to $607M deal value |
| Acquisition | Nov 2021 | $38.25/share (~$3.3B) by Novo Nordisk |

---

## References

1. Novo Nordisk — Acquisition of Dicerna Pharmaceuticals announcement (Nov 2021): [https://www.novonordisk.com/content/nncorp/global/en/news-and-media/news-and-ir-materials/news-details.html?id=87435](https://www.novonordisk.com/content/nncorp/global/en/news-and-media/news-and-ir-materials/news-details.html?id=87435)
2. BusinessWire — Novo Nordisk to acquire Dicerna (Nov 2021): [https://www.businesswire.com/news/home/20211118005644/en/Novo-Nordisk-to-Acquire-Dicerna](https://www.businesswire.com/news/home/20211118005644/en/Novo-Nordisk-to-Acquire-Dicerna)
3. Pharmaceutical Technology — Novo Nordisk and Dicerna $607M collaboration (2019): [https://www.pharmtech.com/view/novo-nordisk-and-dicerna-partner-collaboration-worth-607-million-0](https://www.pharmtech.com/view/novo-nordisk-and-dicerna-partner-collaboration-worth-607-million-0)
