# Biointron

## Overview
Biointron is a biotechnology services company providing antibody discovery, recombinant antibody expression, and related biologics research services.[[1]](https://www.biointron.com/about-us/) It is a CRO/service provider rather than a therapeutics developer.

## Technology and Services
Biointron says it offers gene-to-antibody workflows, recombinant antibody production, antibody humanization, affinity maturation, and high-throughput expression platforms.[[1]](https://www.biointron.com/about-us/) This aligns with the local description of going from gene sequence to purified antibody.

## Investors
I did not identify a public financing history or investor roster during this pass. The reviewed public materials focus on service capabilities and operational footprint rather than venture financing.[[1]](https://www.biointron.com/about-us/)

## Acquisitions and Corporate Activity
No acquisition involving Biointron was identified in the reviewed public sources. The accessible public record centers on its CRO-style antibody services business.[[1]](https://www.biointron.com/about-us/)
