# Bikam Pharmaceuticals

## Overview
Bikam Pharmaceuticals was a drug discovery company focused on ophthalmology therapies for serious eye diseases.[[1]](https://mergr.com/company/bikam-pharmaceuticals) Public information is sparse, and the clearest accessible public source in this pass is transaction-database coverage.

## Technology and Focus
Mergr describes Bikam as developing novel therapies for diseases of the eye with high unmet need.[[1]](https://mergr.com/company/bikam-pharmaceuticals) I did not identify a richer primary-source description of its scientific platform during this pass.

## Investors
Mergr indicates Bikam had private-investor backing before acquisition and identifies Eight Roads as a former owner/investor.[[1]](https://mergr.com/company/bikam-pharmaceuticals) The local F-Prime note aligns with Eight Roads/F-Prime lineage, though I did not find a cleaner company-issued financing announcement during this pass.

## Acquisitions and Corporate Activity
Mergr reports that Shire acquired Bikam Pharmaceuticals on July 9, 2014.[[1]](https://mergr.com/company/bikam-pharmaceuticals) I did not locate a stronger primary-source acquisition press release during this pass, so this note remains intentionally concise.
