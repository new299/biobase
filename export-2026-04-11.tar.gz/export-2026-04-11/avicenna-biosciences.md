# Avicenna Biosciences — Research Notes

## Overview

Avicenna Biosciences is a drug discovery company founded in 2020, headquartered in Durham, NC. Uses machine learning-enhanced medicinal chemistry to accelerate lead-to-candidate optimization for small molecule drugs. Total raised: ~$20.5M. [[1]](https://www.avicenna-bio.com/) [[2]](https://www.crunchbase.com/organization/avicenna-biosciences)

---

## Technology

- **ML-Enhanced Medicinal Chemistry**: Integrates machine learning with traditional medicinal chemistry to accelerate the hit-to-lead and lead-to-candidate optimization process for small molecule drug development. Targets undisclosed programs in drug discovery. [[1]](https://www.avicenna-bio.com/)

---

## Funding & Investors

| Round | Date | Amount | Notable Investors |
|-------|------|--------|-------------------|
| Seed/Series A | ~2020–2022 | ~$14.5M | DCVC Bio, DCVC, b2venture |
| Debt | Nov 2023 | $6M | Conventional debt round |

Total raised: ~$20.5M. [[2]](https://www.crunchbase.com/organization/avicenna-biosciences)

---

## References

1. Avicenna Biosciences — Website: [https://www.avicenna-bio.com/](https://www.avicenna-bio.com/)
2. Crunchbase — Avicenna Biosciences: [https://www.crunchbase.com/organization/avicenna-biosciences](https://www.crunchbase.com/organization/avicenna-biosciences)
